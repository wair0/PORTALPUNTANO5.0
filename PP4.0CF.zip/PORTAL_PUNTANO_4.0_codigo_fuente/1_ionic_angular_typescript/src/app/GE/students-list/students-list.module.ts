import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { StudentsListPageRoutingModule } from './students-list-routing.module';

import { StudentsListPage } from './students-list.page';
import { HttpClient } from '@angular/common/http';
import { StudentService } from 'src/app/services/student.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    StudentsListPageRoutingModule
  ],
  providers: [
    HttpClient,
    StudentService
  ],
  declarations: [StudentsListPage]
})
export class StudentsListPageModule {}
