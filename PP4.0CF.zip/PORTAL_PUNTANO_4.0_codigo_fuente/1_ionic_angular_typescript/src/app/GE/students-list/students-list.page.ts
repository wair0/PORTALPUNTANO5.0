import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import {ActivatedRoute, NavigationExtras, Router} from '@angular/router';
import {Storage} from '@ionic/storage';
import { LoadingService } from 'src/app/services/loading.service';
import { StudentService } from 'src/app/services/student.service';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import { constants } from 'src/app/utils/constants';

@Component({
  selector: 'app-students-list',
  templateUrl: './students-list.page.html',
  styleUrls: ['./students-list.page.scss'],
})
export class StudentsListPage implements OnInit {

  studentsList:any = [] 
  token:any;
  httpOptions: any = null;
  studentsListShow: boolean = false;


  constructor(
    private route: ActivatedRoute,
    private navController:NavController,
    private storage: Storage,
    public loading: LoadingService,
    private router: Router,
    private alertController: AlertController,
    private studentService: StudentService
  ) { }

  ngOnInit() {
    // this.getStudents();
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.studentsList = this.router.getCurrentNavigation().extras.state.content;
        this.studentsListShow = true;
      }else{
        this.goToHome()
      }
    });
  }

  goToHome(){
    this.navController.navigateRoot("/home");
  }

  goToStudent(student:any){
    let navigationExtras: NavigationExtras = {
      state: {
        content: student,
        list: this.studentsList,
        token: this.token
      }
    };
    this.router.navigate(['/student-options'], navigationExtras);
    // this.navController.navigateRoot("/student-options");
  }
  
  getStudents(){    
    this.loading.present();
    this.getToken().then(value => {     
      this.studentService.getStudents(this.httpOptions).subscribe((response:any) => {
        if(response){
          this.studentsList = response;
          if(this.studentsList.length === 1 && !this.studentsList[0].studentId){
            this.alert('El usuario no tiene alumnos asociados.');
              this.goToHome();
          }
          this.studentsListShow = true;
          this.loading.dismiss()
        }
      }, error => {
        this.loading.dismiss(); 
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else{
          this.alert(constants.GENERIC_ERROR);
        } 
      });
    })
  }

  async getToken() {
    await this.storage.get('token').then(value => {
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
    })
  }

  async alert(messageText:string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
          }
        }
      ]
    });

    await alert.present();
  }
}
