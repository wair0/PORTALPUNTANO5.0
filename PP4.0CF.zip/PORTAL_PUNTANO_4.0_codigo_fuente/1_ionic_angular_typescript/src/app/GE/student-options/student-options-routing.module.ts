import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { StudentOptionsPage } from './student-options.page';

const routes: Routes = [
  {
    path: '',
    component: StudentOptionsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StudentOptionsPageRoutingModule {}
