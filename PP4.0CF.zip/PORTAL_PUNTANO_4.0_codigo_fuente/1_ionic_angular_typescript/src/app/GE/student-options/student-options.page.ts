import { Component, OnInit } from '@angular/core';
import { LoadingController, Platform } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { AlertController, NavController } from '@ionic/angular';
import { StudentService } from 'src/app/services/student.service';
import { constants } from 'src/app/utils/constants';
import { Storage } from '@ionic/storage';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { LoadingService } from 'src/app/services/loading.service';
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import * as moment from 'moment';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { DeviceDetailsService } from 'src/app/device/device.service';


@Component({
  selector: 'app-student-options',
  templateUrl: './student-options.page.html',
  styleUrls: ['./student-options.page.scss'],
})
export class StudentOptionsPage implements OnInit {
  public fileTransfer: FileTransferObject;

  panelOpenState = false;
  infoOfAssistance = 'asdasddas';
  formMatriculation: FormGroup;
  formAsistanse: FormGroup;
  formNotes: FormGroup;
  student: any;
  typeTestCode: String;
  token: String;
  httpOptions: any = null;
  schoolCycle: any = null;
  schoolCycleList: any = [];
  step = 0;
  matriculations: any = [];
  formDateAsistanse: boolean = true;  //(disabled)
  fromDateAsistanse: any = null; // max-date
  formDateNotes: boolean = true;  //(disabled)
  fromDateNotes: any = null; // max-date
  daysLimit: number = 7; // Limite de dias   
  subjectsList: any[];
  testTypeList = [{ name: 'Evaluación', code: 'EVALUACION' }, { name: 'Recuperatorio', code: 'RECUPERATORIO' }];
  testOfStudentList: any[];
  assistOfStudentList: any[];
  studentList: any;
  reportCard: any;
  subLevelName: any;
  levelName: any;
  analytics: any = [];

  constructor(
    private fb: FormBuilder,
    private navController: NavController,
    private route: ActivatedRoute,
    private studentService: StudentService,
    private router: Router,
    private storage: Storage,
    private alertController: AlertController,
    public loading: LoadingService,
    private fileOpener: FileOpener,
    private file: File,
    private transfer: FileTransfer,
    private platform: Platform,
    private deviceDetailsService: DeviceDetailsService,
    private loadingController: LoadingController
  ) { }

  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.token = this.router.getCurrentNavigation().extras.state.token;
        this.student = this.router.getCurrentNavigation().extras.state.content;
        this.studentList = this.router.getCurrentNavigation().extras.state.list;
        this.getSchoolCycleByPersonId(this.student.personId);
        this.getAnalytics(this.student.docNumber)
      } else {
        this.goToStudentList()
      }
    });

    this.createFormMatriculation();
    this.createFormAsistance();
    this.createFormNotes();
    this.pruebaDeServ()
  }

  getSchoolCycleByPersonId(personId: any) {
    this.getToken().then(value => {
      this.loading.present();
      this.studentService.getSchoolCycleByPersonId(personId, this.httpOptions).subscribe((response: any) => {
        this.loading.dismiss();
        this.schoolCycleList = response;
        if (response && response.length > 0) {
          this.daysLimit = Number(response[0].quantityDaysFilters);
        }

      }, error => {
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });
    })
  }

  getSubjects() {
    this.subjectsList = [];
    this.getToken().then(value => {
      if (!this.loading.isLoading) {
        this.loading.present();
      }
      this.studentService.getSubjects(this.student.studentId, this.schoolCycle.id, this.httpOptions).subscribe((response: any) => {
        if (this.loading.isLoading) {
          this.loading.dismiss();
        }
        if (response) {
          this.subjectsList = response
        }
      }, error => {
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
        this.loading.dismiss();
      })
    })

    this.getReportCard(this.student.studentId, this.schoolCycle.id);
  }

  schoolCycleChange() {
    if (this.schoolCycle) {
      this.getToken().then(value => {
        if (!this.loading.isLoading) {
          this.loading.present();
        }
        this.studentService.getRegistrationByStudent(this.student.studentId, this.schoolCycle.id, this.httpOptions).subscribe((response: any) => {
          if (this.loading.isLoading) {
            this.loading.dismiss();
          }
          this.matriculations = response;
          if (response && response.length > 0) {
            if (response.length == 1) {
              this.subLevelName = response[0].subLevelName;
              this.levelName = response[0].levelName;
            } else {
              response.forEach(element => {
                if (element.status == 'ACT' || element.status == 'END') {
                  this.subLevelName = element.subLevelName;
                  this.levelName = element.levelName;
                }
              });
            }
          }

        }, error => {
          if (error.status === 409) {
            this.alert(error.error.message);
          }
          else {
            this.alert(constants.GENERIC_ERROR);
          }
          this.loading.dismiss();
        })
      })
      this.getSubjects();
      this.assistOfStudentList = [];
      this.testOfStudentList = [];
      this.formAsistanse.get('subjectAsistanceCtrl').setValue('');
      this.formAsistanse.get('subjectNotesCtrl').setValue('');
    };
  }

  getReportCard(studentId: any, cicleId: any) {
    this.getToken().then(value => {
      if (!this.loading.isLoading) {
        this.loading.present();
      }
      this.studentService.getReportCardByStudentAndCicle(studentId, cicleId, this.httpOptions).subscribe((response: any) => {
        if (this.loading.isLoading) {
          this.loading.dismiss();
        }
        this.reportCard = response;
      }, error => {
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
        this.loading.dismiss();
      })
    })
  }

  checkDate() {
    let desde = this.formAsistanse.get('dateFromAsistanceCtrl').value
    let hasta = this.formAsistanse.get('dateToAsistanceCtrl').value
    if (desde > hasta) {
      return false
    } else {
      if (desde <= hasta) {
        if (desde._i.year == hasta._i.year) {
          if (desde._i.month == hasta._i.month) {
            return true;
          } else {
            if (desde._i.month - 1 == hasta._i.month) {
              if (desde._i.date > 20) {
                return true;
              } else {
                return false;
              }
            } else {
              return true;
            }
          }
        }
        else {
          return false;
        }
      }
    }
  }


  checkDateNotes() {
    let desde = this.formNotes.get('dateFromNotesCtrl').value
    let hasta = this.formNotes.get('dateToNotesCtrl').value
    if (desde > hasta) {
      return false
    } else {
      if (desde <= hasta) {
        if (desde._i.year == hasta._i.year) {
          if (desde._i.month == hasta._i.month) {
            return true;
          } else {
            if (desde._i.month - 1 == hasta._i.month) {
              if (desde._i.date > 20) {
                return true;
              } else {
                return false;
              }
            } else {
              return true;
            }
          }
        }
        else {
          return false;
        }
      }
    }
  }
  setStep(index: number) {
    this.step = index;
  }

  createFormMatriculation() {
    this.formMatriculation = this.fb.group({
      dateFromMatriCtrl: ['', [Validators.required]],
      dateToMatriCtrl: ['', [Validators.required]],
      subjectMatriCtrl: ['', [Validators.required]],
    });
  }

  createFormAsistance() {
    this.formAsistanse = this.fb.group({
      dateFromAsistanceCtrl: ['', [Validators.required]],
      dateToAsistanceCtrl: ['', [Validators.required]],
      subjectAsistanceCtrl: [''],
      presentAsistanceCtrl: [false],
    });
  }

  createFormNotes() {
    this.formNotes = this.fb.group({
      dateFromNotesCtrl: ['', [Validators.required]],
      dateToNotesCtrl: ['', [Validators.required]],
      subjectNotesCtrl: [''],
      typeTestCodeCrtl: [''],
    });
  }

  submitAsistance() {
    this.assistOfStudentList = [];
    if (!this.schoolCycle) {
      this.alert('Debe seleccionar el ciclo lectivo.');
      return;
    }
    if (!this.formAsistanse.get('dateFromAsistanceCtrl').value) {
      this.alert('Debe cargar la fecha desde.');
      return;
    }
    if (!this.formAsistanse.get('dateToAsistanceCtrl').value) {
      this.alert('Debe cargar la fecha Hasta.');
      return;
    }

    let cheackDate = this.checkDate()
    if (!cheackDate) {
      this.alert('Ingrese fechas correctas');
      return;
    }
    if (this.formAsistanse.valid) {
      this.getToken().then(value => {
        this.loading.present();
        this.studentService.getAssistanceOfStudent(
          this.student.studentId,
          moment(this.formAsistanse.get('dateFromAsistanceCtrl').value).format('YYYY-MM-DD'),
          moment(this.formAsistanse.get('dateToAsistanceCtrl').value).format('YYYY-MM-DD'),
          this.createParamAsist(),
          this.httpOptions
        ).subscribe((response: any) => {
          if (response) {
            this.assistOfStudentList = response;
            this.loading.dismiss();
          }
        }, error => {
          if (error.status === 409) {
            this.alert(error.error.message);
          }
          else {
            this.alert(constants.GENERIC_ERROR);
          }
        })
      }
      )
    }
  }

  cleanFiltersAssistance() {
    this.formAsistanse.get('subjectAsistanceCtrl').setValue('');
    this.formAsistanse.get('presentAsistanceCtrl').setValue(false);
    this.formAsistanse.get('dateFromAsistanceCtrl').setValue('');
    this.formAsistanse.get('dateToAsistanceCtrl').setValue('');
  }

  cleanFiltersNotes() {
    this.formNotes.get('subjectNotesCtrl').setValue('');
    this.formNotes.get('typeTestCodeCrtl').setValue('');
    this.formNotes.get('dateFromNotesCtrl').setValue('');
    this.formNotes.get('dateToNotesCtrl').setValue('');
  }

  submitNotes() {
    this.testOfStudentList = [];
    if (!this.formNotes.get('dateFromNotesCtrl').value) {
      this.alert('Debe cargar la fecha desde.');
      return;
    }
    if (!this.formNotes.get('dateToNotesCtrl').value) {
      this.alert('Debe cargar la fecha Hasta.');
      return;
    }
    // if(!this.formNotes.get('subjectNotesCtrl').value){
    //   this.alert('Debe seleccionar la materia.');
    //   return;
    // }
    if (!this.schoolCycle) {
      this.alert('Debe seleccionar el ciclo lectivo.');
      return;
    }
    let check = this.checkDateNotes();
    if (!check) {
      this.alert('Ingrese fechas correctas');
      return;
    }

    if (this.formNotes.valid) {
      this.getToken().then(value => {
        this.loading.present();
        this.studentService.getResultTest(this.student.studentId, this.schoolCycle.id, this.createParamTest(), this.httpOptions).subscribe((response: any) => {
          if (response) {
            this.testOfStudentList = response;
            this.loading.dismiss();
          }
        }, error => {
          if (error.status === 409) {
            this.alert(error.error.message);
          }
          else {
            this.alert(constants.GENERIC_ERROR);
          }
        })
      })
    }
  }



  createParamAsist() {
    let param = '';
    this.formAsistanse.get('subjectAsistanceCtrl').value != '' ? param = param + '&subjectId=' + this.formAsistanse.get('subjectAsistanceCtrl').value.id : '';
    // this.formAsistanse.get('presentAsistanceCtrl').value != '' ? param = param + '&typeTestCode=' + this.formAsistanse.get('presentAsistanceCtrl').value : '';
    param = param + '&present=' + this.formAsistanse.get('presentAsistanceCtrl').value;
    if (param.length > 0) {
      param = param.replace('&', '?');
    }
    return param
  }
  createParamTest() {
    let param = '';
    this.formNotes.get('dateFromNotesCtrl').value != '' ? param = param + '&dateFrom=' + moment(this.formNotes.get('dateFromNotesCtrl').value).format("YYYY-MM-DD") : '';
    this.formNotes.get('dateToNotesCtrl').value != '' ? param = param + '&dateTo=' + moment(this.formNotes.get('dateToNotesCtrl').value).format("YYYY-MM-DD") : '';
    this.formNotes.get('subjectNotesCtrl').value != '' ? param = param + '&subjectId=' + this.formNotes.get('subjectNotesCtrl').value.id : '';
    this.formNotes.get('typeTestCodeCrtl').value != '' ? param = param + '&typeTestCode=' + this.formNotes.get('typeTestCodeCrtl').value : '';
    if (param.length > 0) {
      param = param.replace('&', '?');
    }
    return param
  }


  async alert(messageText: string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano - SGE',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'sge',
          handler: () => {
          }
        }
      ]
    });

    await alert.present();
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }


  goToStudentList() {
    let navigationExtras: NavigationExtras = {
      state: {
        content: this.studentList,
      }
    };
    this.navController.navigateRoot(["/students-list"], navigationExtras);
  }

  async getToken() {
    await this.storage.get('token').then(value => {
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
      this.token = value;
    })
  }

  pruebaDeServ() {
    // this.studentService.getStudents(null).subscribe((response:any)=>{
    //   let dsasd = response
    // })
  }

  setDateFromAsistance() {
    this.formAsistanse.get('dateToAsistanceCtrl').reset('');
    this.formDateAsistanse = false;
    this.fromDateAsistanse = new Date(this.formAsistanse.get('dateFromAsistanceCtrl').value)
    this.fromDateAsistanse.setDate(this.fromDateAsistanse.getDate() + this.daysLimit);
    this.fromDateAsistanse = this.fromDateAsistanse.toISOString()
  }

  // export class DateRangePickerFormsExample {
  //   range = new FormGroup({
  //     start: new FormControl(),
  //     end: new FormControl()
  //   });

  setDateFromNotes() {
    this.formNotes.get('dateToNotesCtrl').reset('');
    this.formDateNotes = false;
    this.fromDateNotes = new Date(this.formNotes.get('dateFromNotesCtrl').value)
    this.fromDateNotes.setDate(this.fromDateNotes.getDate() + this.daysLimit);
    this.fromDateNotes = this.fromDateNotes.toISOString()
  }


  //DOWNLOAD REPORT CARD

  async downloadPdfFixed() {

    // this.loading('Descargando');

    let fileName = this.student.lastName + ' ' + this.student.firstName + '.pdf';
    let filePath = constants.URL_BASE_PORTAL + "secure/education/studentId/" + this.student.studentId + "/schoolCycle/" + this.schoolCycle.id + "/reportCard/file";

    let url = encodeURI(filePath);
    this.fileTransfer = this.transfer.create();

    let directory = this.file.documentsDirectory;

    // if (this.platform.is("android")) {
    //   if(this.file.externalRootDirectory){
    //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
    //     }else{
    //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
    //     }
    // }

    if (this.platform.is("android")) {
      let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
      //if(this.file.externalRootDirectory){
      console.log("[HOME] OS VERSION: " + soVersion);
      if (soVersion < 11) {
        if (this.file.externalRootDirectory) {
          directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
        } else {
          directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
        }
      } else {
        directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
      }
    }

    this.getToken().then(value => {
      let options = {
        headers: {
          "X-Authorization": "Bearer " + this.token
        }
      };
      this.fileTransfer.download(url, directory + fileName, true, options).then((entry) => {
        this.loadingController.dismiss();
        //here logging our success downloaded file path in mobile. 
        console.log('download completed: ' + entry.toURL());

        this.file.resolveDirectoryUrl(directory).then((rootDir) => {
          this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
            fileEntry.getMetadata(metadata => {
              if (metadata.size != 0) {
                // open downloaded file 
                this.openFileHandler(entry.toURL());

                if (this.platform.is("android")) {
                  let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                  if (soVersion < 11) {
                    if (this.file.externalRootDirectory) {
                      this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + constants.FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                    }
                  }
                }

              } else {
                this.alert(constants.FILE_SIZE_0_ERROR);
              }
            })

          });

        });

      }).catch((error) => {
        this.loadingController.dismiss();
        if (error != null && error.http_status != null && error.http_status == 409) {
          this.alert(JSON.parse(error.body).message);
        } else {
          this.alert(constants.GENERIC_ERROR)
          //here logging an error. 
          console.log('download failed: ' + JSON.stringify(error));
        }
      });
    })
  }

  openFileHandler(path: any) {
    this.fileOpener.open(path, '')
      .then(() => console.log('File is opened'))
      .catch(e => console.log('Error opening file', e));
  }

  downloadPdf(downloadPDF) {
    debugger
    //base 64
    fetch('data:application/pdf;base64,' + downloadPDF.base64,
      {
        method: "GET"
      }).then(res => res.blob()).then(blob => {
        this.file.writeFile(this.file.externalApplicationStorageDirectory, (this.student.lastName + ' ' + this.student.firstName + '.pdf'), blob, { replace: true }).then(res => {
          this.fileOpener.open(
            res.toInternalURL(),
            'application/pdf'
          ).then((res) => {

          }).catch(err => {
            console.log('open', err)
          });
        }).catch(err => {
          console.log('save', err)
        });
      }).catch(err => {
        console.log(err)
      });
  }

  //Descarga de documento
  // async download(action: any, studentName:String, base64) {

  //   let fileName = "Libreta de "+ studentName + ".pdf";

  //   //let filePath = constants.URL_BASE_PORTAL + "secure/files/download/action/" + action.nroAction;
  //   //let url = encodeURI(filePath);
  //   let url = encodeURI(filePath);
  //   this.fileTransfer = this.transfer.create();

  //   let options = {
  //     headers: {
  //       "X-Authorization": "Bearer " + this.token
  //     }
  //   };

  //   let directory = this.file.documentsDirectory;

  //   // if (this.platform.is("android")) {
  //   //   if(this.file.externalRootDirectory){
  //   //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
  //   //     }else{
  //   //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
  //   //     }
  //   // }

  //   if (this.platform.is("android")) {
  //     let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
  //     //if(this.file.externalRootDirectory){
  //     console.log("[HOME] OS VERSION: " + soVersion);
  //     if (soVersion < 11) {
  //       if(this.file.externalRootDirectory){
  //         directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
  //       }else{
  //         directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
  //       }
  //     }else{
  //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
  //     }
  //   }

  //   this.fileTransfer.download(url, directory + fileName, true, options).then((entry) => {
  //     this.loading.dismiss();
  //     //here logging our success downloaded file path in mobile. 
  //     console.log('download completed: ' + entry.toURL());

  //     this.file.resolveDirectoryUrl(directory).then((rootDir) => {
  //       this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
  //         fileEntry.getMetadata(metadata => {
  //           if (metadata.size != 0) {
  //             // open downloaded file 
  //             this.openFileHandler(entry.toURL());

  //             if (this.platform.is("android")) {
  //               let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
  //               if (soVersion < 11) {
  //                 if(this.file.externalRootDirectory){
  //                   this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + constants.FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
  //                 }
  //               }
  //             }

  //           } else {
  //             this.alert(constants.FILE_SIZE_0_ERROR);
  //           }
  //         })

  //       });

  //     });

  //   }).catch((error) => {
  //     this.loading.dismiss();
  //     if (error != null && error.http_status != null && error.http_status == 409) {
  //       this.alert(JSON.parse(error.body).message);
  //     } else {
  //       this.alert(constants.GENERIC_ERROR);
  //     }
  //     //here logging an error. 
  //     console.log('download failed: ' + JSON.stringify(error));
  //   });
  // }

  // openFileHandler(path: any) {
  //   this.fileOpener.open(path, '')
  //     .then(() => console.log('File is opened'))
  //     .catch(e => console.log('Error opening file', e));
  // }

  getAnalytics(docNumber: any) {
    this.getToken().then(value => {
      if (!this.loading.isLoading) {
        this.loading.present();
      }
      this.studentService.getAnalytics(docNumber, this.httpOptions).subscribe((response: any) => {
        if (this.loading.isLoading) {
          this.loading.dismiss();
        }
        this.analytics = response;
      }, error => {
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
        this.loading.dismiss();
      })
    })
  }

    //DOWNLOAD ANALYTIC
  // 
  redirect(link: any){
    debugger
    window.open(link, "_blank");
  }

}
