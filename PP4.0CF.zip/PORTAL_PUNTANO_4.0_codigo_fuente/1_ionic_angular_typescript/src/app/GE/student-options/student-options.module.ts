import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import {MatExpansionModule} from '@angular/material/expansion';
import { StudentOptionsPageRoutingModule } from './student-options-routing.module';

import { StudentOptionsPage } from './student-options.page';
import { SgeAssistanceInfoComponent } from 'src/app/components/sge-assistance-info/sge-assistance-info.component';
import { SgeNoteInfoComponent } from 'src/app/components/sge-note-info/sge-note-info.component';
import { SgeMatriculationComponent } from 'src/app/components/sge-matriculation/sge-matriculation.component';
import { HttpClient } from '@angular/common/http';
import { StudentService } from 'src/app/services/student.service';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx'; 
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { File } from '@ionic-native/file/ngx';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatMomentDateModule } from '@angular/material-moment-adapter';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    StudentOptionsPageRoutingModule,
    MatExpansionModule,
    ReactiveFormsModule,
    MatDatepickerModule,        
    MatNativeDateModule,        
    MatMomentDateModule, 
    MatInputModule
  ],
  providers: [
    HttpClient,
    StudentService,
    FileOpener,
    File,
    FileTransfer,
    FileTransferObject,
  ],
  declarations: [
    StudentOptionsPage,
    SgeAssistanceInfoComponent,
    SgeNoteInfoComponent,
    SgeMatriculationComponent
  ]
})
export class StudentOptionsPageModule {}


// providers: [HttpClient,
//   FileTransfer,
//   FileTransferObject,
//   File,
//   RefreshUtils,
//   FileOpener],