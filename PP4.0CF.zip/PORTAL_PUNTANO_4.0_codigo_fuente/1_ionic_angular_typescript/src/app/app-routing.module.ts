import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomePageModule) },
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
  { path: 'rm', loadChildren: () => import('./RM/rm.module').then(m => m.RmModule) },
  { path: 'consultations', loadChildren: () => import('./RM/consultations/consultations.module').then(m => m.ConsultationsModule) },
  { path: 'diagnosis', loadChildren: () => import('./RM/diagnosis/diagnosis.module').then(m => m.DiagnosisModule) },
  { path: 'prescriptions', loadChildren: () => import('./RM/prescriptions/prescriptions.module').then(m => m.PrescriptionsModule) },
  { path: 'studies', loadChildren: () => import('./RM/studies/studies.module').then(m => m.StudiesModule) },
  { path: 'consultation', loadChildren: () => import('./RM/consultation/consultation.module').then(m => m.ConsultationModule) },
  { path: 'prescription', loadChildren: () => import('./RM/prescription/prescription.module').then(m => m.PrescriptionModule) },
  { path: 'health-certificate', loadChildren: () => import('./RM/health-certificates/health-certificates.module').then(m => m.HealthCertificatesModule) },
  { path: "all-consultations", loadChildren: () => import('./RM/all-consultations/all-consultations.module').then(m => m.AllConsultationsModule) },
  { path: 'study', loadChildren: () => import('./RM/study/study.module').then(m => m.StudyModule) },
  { path: 'liquidations', loadChildren: () => import('./liquidations/liquidations.module').then(m => m.LiquidationsModule) },
  { path: 'liquidation', loadChildren: () => import('./liquidation/liquidation.module').then(m => m.LiquidationModule) },
  { path: 'driverLicense', loadChildren: () => import('./driverLicense/driverLicense.module').then(m => m.DriverLicenseModule) },
  { path: 'proceduresHome', loadChildren: () => import('./procedures/proceduresHome.module').then(m => m.ProceduresHomeModule) },
  { path: 'procedures', loadChildren: () => import('./procedures/proceduresAll/procedures.module').then(m => m.ProceduresModule) },
  { path: 'newProcedure', loadChildren: () => import('./procedures/new-procedure/new-procedure.module').then(m => m.NewProcedureModule) },
  { path: 'completedProcedures', loadChildren: () => import('./procedures/completed-procedures/completed-procedures.module').then(m => m.CompletedProceduresModule) },
  { path: 'dynamic-form', loadChildren: () => import('./procedures/dynamic-form/dynamic-form.module').then(m => m.DynamicFormModule) },
  { path: 'currentProcedures', loadChildren: () => import('./procedures/current-procedures/current-procedures.module').then(m => m.CurrentProceduresModule) },
  { path: 'procedureDetail', loadChildren: () => import('./procedures/procedureDetail/procedureDetail.module').then(m => m.ProcedureDetailModule) },
  { path: 'judicialExpedients', loadChildren: () => import('./judicialExpedients/judicialExpedients.module').then(m => m.JudicialExpedientsModule) },
  { path: 'judicialExpedientsAll', loadChildren: () => import('./judicialExpedientsAll/judicialExpedientsAll.module').then(m => m.JudicialExpedientsAllModule) },
  { path: 'judicialExpedientDetail', loadChildren: () => import('./judicialExpedientDetail/judicialExpedientDetail.module').then(m => m.JudicialExpedientDetailModule) },
  { path: 'screenError', loadChildren: () => import('./screenError/screenError.module').then(m => m.ScreenErrorModule) },
  {
    path: 'change-password',
    loadChildren: () => import('./change-password/change-password.module').then(m => m.ChangePasswordPageModule)
  },
  {
    path: 'proceedings',
    loadChildren: () => import('./RC/proceedings/proceedings.module').then(m => m.ProceedingsPageModule)
  },
  {
    path: 'shifts',
    loadChildren: () => import('./shifts/shifts.module').then(m => m.ShiftsPageModule)
  },
  {
    path: 'new-shifts',
    loadChildren: () => import('./shifts/new-shift/new-shift.module').then(m => m.NewShiftModule)
  },
  {
    path: 'available-shifts',
    loadChildren: () => import('./shifts/available-shift/available-shift.module').then(m => m.AvailableShiftModule)
  },
  {
    path: 'shifts-details',
    loadChildren: () => import('./shifts-details/shifts-details.module').then(m => m.ShiftsDetailsPageModule)
  },
  {
    path: 'shifts-details-rm',
    loadChildren: () => import('./shift-details-rm/shift-details-rm.module').then(m => m.ShiftDetailsRMPageModule)
  },
  {
    path: 'credentials',
    loadChildren: () => import('./credentials/credentials.module').then(m => m.CredentialsPageModule)
  },
  {
    path: 'health-credential',
    loadChildren: () => import('./health-credential/health-credential.module').then(m => m.HealthCredentialPageModule)
  },
  {
    path: 'students-list',
    loadChildren: () => import('./GE/students-list/students-list.module').then(m => m.StudentsListPageModule)
  },
  {
    path: 'student-options',
    loadChildren: () => import('./GE/student-options/student-options.module').then(m => m.StudentOptionsPageModule)
  },
  {
    path: 'health',
    loadChildren: () => import('./health/health.module').then(m => m.HealthModule)
  },
  {
    path: 'sportMap',
    loadChildren: () => import('./health/sport-map/sport-map.module').then(m => m.SportMapModule)
  },
  {
    path: 'studentSportMap',
    loadChildren: () => import('./health/sport-map/student-sport-map/student-sport-map.module').then(m => m.StudentSportMapModule)
  },



];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
