import { DatePipe } from "@angular/common";
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { LoadingController } from "@ionic/angular";
import { RemotePersonDto } from "src/app/core/models/RemotePersonDto";
import { AlertService } from "src/app/services/alert.service";
import { LoadingService } from "src/app/services/loading.service";
import { PersonService } from "src/app/services/person.service";


@Component({
  selector: 'search-person',
  templateUrl: './search-person.component.html',
  styleUrls: [ './search-person.component.scss' ],
})
export class SearchPersonComponent implements OnInit {
  genders = [
    { name: 'Masculino', value: 'M' },
    { name: 'Femenino', value: 'F' },
    { name: 'No binario', value: 'X' }
  ];
  docNumber: number;
  birthDate: Date;
  genderSelected: string;
  @Output() person: EventEmitter<RemotePersonDto> = new EventEmitter();

  constructor(
    private personService: PersonService,
    private datePipe: DatePipe,
    private alertService: AlertService,
    private loadingController: LoadingController
  ) { }

  ngOnInit() { }

  async loading() {
    const loading = await this.loadingController.create({
      message: 'Buscando...',
    });
    await loading.present();
  }

  searchPerson() {
    this.loading(); // Mostrar el loader antes de la llamada al servicio

    let birthDate = this.datePipe.transform(this.birthDate, "yyyy-MM-dd")
    this.personService.searchPerson(this.docNumber, this.genderSelected, birthDate).subscribe((response) => {
      this.loadingController.dismiss(); // Ocultar el loader después de recibir la respuesta
      this.person.emit(response);
    }, (error) => {
      this.loadingController.dismiss();
      this.alertService.showErrorAlert(error.error.message)
    })
  }


}
