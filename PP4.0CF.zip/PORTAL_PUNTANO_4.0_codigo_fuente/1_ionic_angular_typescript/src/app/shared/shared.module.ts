import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { SharedRoutingModule } from './shared-routing.module';
import { FormsModule } from "@angular/forms";
import { IonicModule } from "@ionic/angular";
import { SearchPersonComponent } from "./search-person/search-person.component";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatMomentDateModule } from "@angular/material-moment-adapter";
import { MatInputModule } from "@angular/material/input";



@NgModule({
  declarations: [
    SearchPersonComponent,
  ],
  imports: [
    CommonModule,
    SharedRoutingModule,
    FormsModule,
    IonicModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatInputModule
  ],
  exports: [
    SearchPersonComponent
  ],
  providers: [
    DatePipe
  ]
})
export class SharedModule { }
