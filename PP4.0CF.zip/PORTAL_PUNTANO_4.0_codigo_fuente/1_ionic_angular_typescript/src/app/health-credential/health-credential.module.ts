import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HealthCredentialPageRoutingModule } from './health-credential-routing.module';

import { HealthCredentialPage } from './health-credential.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HealthCredentialPageRoutingModule
  ],
  declarations: [HealthCredentialPage]
})
export class HealthCredentialPageModule {}
