import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import { constants } from '../utils/constants';
import {AlertController, LoadingController, NavController, Platform, ToastController} from '@ionic/angular';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'app-health-credential',
  templateUrl: './health-credential.page.html',
  styleUrls: ['./health-credential.page.scss'],
})
export class HealthCredentialPage implements OnInit {

  token:any;
  data:any;
  displayImage:any;

  constructor(private route: ActivatedRoute,
    private http: HttpClient,
    private alertController: AlertController,
    private sanitizer: DomSanitizer,
    private router: Router,) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        // this.shifts = this.router.getCurrentNavigation().extras.state.shifts;
        this.token = this.router.getCurrentNavigation().extras.state.token;
        this.data = this.router.getCurrentNavigation().extras.state.data;
        this.displayImage = 'data:image/jpeg;base64,' + this.data.photoBase64;
        //this.makeLiquidationsCollapse();
      }
    });
  }


  async alert(messageText:string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
          }
        }
      ]
    });

    await alert.present();
  }

  processError = function(error: any) {
    return new Promise<any>((resolve, reject) => {
      // this.loadingController.dismiss();
      if (error.status === 500) {
        if (error.error.exception === 'io.jsonwebtoken.ExpiredJwtException') {
          this.storage.get('psw').then((val: any) => {
            if (val) {
              // this.loading();
              this.refreshUtils.refreshToken(val).then((value: any) => {
                resolve(value);
              }).catch((errorRefresh: { status: number; }) => {
                // this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();
                } else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            } else {
              this.alert(constants.GENERIC_ERROR);
            }
          });

        } else {
          this.alert(constants.GENERIC_ERROR);
        }
      } else if (error.status == 401) {
        this.deleteDataAndExitToLogin();
      } else if (error.status == 409) {
        this.alert(error.error.message);
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  };


}
