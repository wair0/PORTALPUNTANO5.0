import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from "@ionic/angular";
import { HttpClient, HttpClientModule } from "@angular/common/http";
import { RouterModule } from "@angular/router";
import { CurrentProceduresComponent } from "./current-procedures.component";
import { RefreshUtils } from "src/app/utils/refreshUtils";



@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    HttpClientModule,
    RouterModule.forChild([
      {
        path: '',
        component: CurrentProceduresComponent
      }
    ])

  ],
  providers: [ HttpClient, RefreshUtils ],
  declarations: [ CurrentProceduresComponent ]
})
export class CurrentProceduresModule { }
