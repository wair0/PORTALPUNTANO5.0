import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { LoadingController } from "@ionic/angular";
import { Storage } from "@ionic/storage";
import { AttrsParseDto } from "src/app/core/models/AttrsParseDto";
import { GroupModel } from "src/app/core/models/GroupModel";
import { ProcedureStep } from "src/app/core/models/ProcedureStep";
import { ProcedureType } from "src/app/core/models/ProcedureType";
import { ProcedureTypeAttr } from "src/app/core/models/ProcedureTypeAttr";
import { RemotePersonDto } from "src/app/core/models/RemotePersonDto";
import { UserDto } from "src/app/core/models/UserDto";
import { AlertService } from "src/app/services/alert.service";
import { ProceduresService } from "src/app/services/procedures.service";
import { InputsNames } from "./InputsNames";

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: [ './dynamic-form.component.scss' ],
})
export class DynamicFormComponent implements OnInit {
  form: ProcedureType;
  steps: ProcedureStep[] = [];
  currentStep: ProcedureStep;
  currentsAttrs: ProcedureTypeAttr[] = [];
  currentUser: UserDto = {
    docNumber: "",
    docType: "",
    sex: ""
  };

  nextPage: number = 0
  currentPage: number = 0;
  omitNextPage: boolean = true;
  groupsModel: GroupModel = {
    nameGroup: '',
  }
  groupStep: ProcedureTypeAttr;
  lastIndex: number[] = [ 0 ];
  countOfGroups: number;
  promises: any[] = [];
  groups: ProcedureTypeAttr[];
  // ARCHIVOS CONVERTIDOS A BASE64 QUE SE ENVIARÁN AL BACK
  filesToPost: any[] = [];
  // VARIABLE PARA MANEJAR LOS ARCHIVOS QUE CORRESPONDAN A CADA STEP
  filesStep: any[] = []
  procedureId: number;
  quantityGroupsLocal: number[] = [ 1 ];
  phoneNumber: string;
  isValidateCode: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private storage: Storage,
    private alertService: AlertService,
    private procedureService: ProceduresService,
    private loadingController: LoadingController
  ) {
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.form = this.router.getCurrentNavigation().extras.state.procedureType;
        this.procedureId = this.form.id;
      }
    });
  }

  ngOnInit() {
    if (this.form.id) {
      this.getUser();
      this.getPhoneNumber();
    }
  }

  getPhoneNumber() {
    this.storage.get('phoneNumber').then((phoneNumber) => {
      this.phoneNumber = phoneNumber;
      this.buildForm()
    })
  }

  getUser() {
    this.storage.get('psw').then((user) => {
      this.currentUser = user;
      this.getPhoneNumber();
      this.buildForm();
    })
  }

  goToBack() {
    this.router.navigate([ '/newProcedure' ])
  }
  // FUNCIONES PARA ASIGNAR LOS ATRIBUTOS A LOS GRUPOS
  addProcedureAttrs(index: number) {
    if (this.currentsAttrs.filter((attr) => attr.idgroup === index).length === 0) {
      this.procedureService.getProcedureAttrs(this.procedureId, index, this.currentStep.step).subscribe((response) => {
        response.forEach((attr) => {
          attr.idgroup = index;
        })
        this.currentsAttrs = this.currentsAttrs.concat(response);
        if (this.groupsModel.quantityOfGroups.length > 1) {
          this.quantityGroupsLocal = this.groupsModel.quantityOfGroups;
        }
        this.setDataOnGroups();
      })
    }
  }

  // FUNCIONES PARA ASIGNAR LOS ATRIBUTOS A LOS GRUPOS
  getProcedureAttrs(index: number) {
    this.procedureService.getProcedureAttrs(this.procedureId, index, this.currentStep.step).subscribe((response) => {
      this.currentsAttrs = response;
    })
  }

  setDataOnGroups() {
    if ((this.currentsAttrs && this.currentsAttrs.length > 0) && (this.groups && this.groups.length > 0)) {
      this.currentsAttrs.forEach((currentAttr) => {
        this.groups.forEach((attrGroup) => {
          if (attrGroup.idgroup === currentAttr.idgroup) {
            if (!currentAttr.dataValue && attrGroup.id === currentAttr.id) {
              currentAttr.dataValue = attrGroup.dataValue;
            }
          }
        })
      })
    }
  }

  buildForm(step: number = 0) {
    let form: ProcedureType = this.form
    this.groupsModel.quantityOfGroups = [];
    this.currentPage = step;

    // ASIGNAMOS LOS STEPS  MOSTRARLOS EN LA VISTA
    this.steps = form.procedureSteps
    if (form.procedureSteps && step < form.procedureSteps.length) {
      // SI EL STEP TIENE GRUPOS, CREAMOS LOS GRUPOS
      if (form.procedureSteps[ step ].groups >= 1 && this.groupsModel.quantityOfGroups.length === 0) {
        this.createGroup(form.procedureSteps[ step ].groups, form.procedureSteps[ step ].name);
        this.currentStep = form.procedureSteps[ step ];
      }
      else {
        this.currentStep = form.procedureSteps[ step ];
        this.currentsAttrs = form.procedureTypeAttrs.filter((el) => {
          if (el.tipo === 'VALIDATION_CODE') {
            this.isValidateCode = true;
          }
          return el.step === this.currentStep.step
        })
      }
      this.setDefaultValues(form.procedureTypeAttrs)

    }
  }

  setDefaultValues(procedureTypeAttrs: ProcedureTypeAttr[]) {
    procedureTypeAttrs.forEach((el) => {
      switch (el.name) {
        case InputsNames.PROVINCIA:
          if (!el.dataValue && el.tipo === 'READONLY') {
            el.dataValue = 'San Luis'
          }
          break;
        case InputsNames.GENERO:
          if (el.tipo === 'READONLY') {
            el.dataValue = this.currentUser.sex === 'M' ? 'Masculino' : 'Femenino'
          }
          break;
        case InputsNames.PHONE_NUMBER:
          if (el.tipo === 'READONLY') {
            el.dataValue = this.phoneNumber ? this.phoneNumber : ''
          }
      }
    })
  }

  // GUARDAMOS LA DATA DE LOS GRUPOS EN UNA VARIABLE DENTRO DEL COMPONENTE
  // PARA QUE AL IR A OTRO STEP NO SE PIERDA LA INFORMACIÓN.
  // porque currentsAttrs pisa los atributos cada vez q cambia los steps
  saveGroup() {
    if (!this.groups) {
      this.groups = this.currentsAttrs;
    }

    if (this.currentsAttrs.length > 0 && this.currentsAttrs.length >= this.groups.length) {
      this.groups = this.currentsAttrs;
    }
  }

  // CREAMOS LA CANTIDAD DE GRUPOS MÁXIMOS.
  createGroup(quantityOfGroups: number, name: string) {
    this.countOfGroups = quantityOfGroups;


    if (this.groupsModel.quantityOfGroups && this.groupsModel.quantityOfGroups.length === 0) {
      this.groupsModel.nameGroup = name;
      this.groupsModel.quantityOfGroups.push(1);

      this.getProcedureAttrs(this.groupsModel.quantityOfGroups.length);
    }

  }

  addNewGroup(name: string) {
    let quantityOfGroups = this.countOfGroups;
    while (this.groupsModel.quantityOfGroups.length < quantityOfGroups) {
      this.groupsModel.nameGroup = name;
      this.groupsModel.quantityOfGroups.push(this.groupsModel.quantityOfGroups.length);
      this.addProcedureAttrs(this.groupsModel.quantityOfGroups.length - 1);
      return;
    }
  }

  deleteGroup(index: number, error: string) {
    if (this.quantityGroupsLocal.length > 1) {
      this.quantityGroupsLocal.splice(index, 1)

      if (this.currentsAttrs && this.currentsAttrs.length > 0) {
        this.currentsAttrs = this.currentsAttrs.filter((attr) => attr.idgroup !== index)
      }

      if (this.groups && this.groups.length > 0) {
        this.groups = this.groups.filter((attr) => attr.idgroup !== index)
      }

    } else {
      this.alertService.showErrorAlert(error);
    }
  }

  // ESTA FUNCIÓN CONVIERTE A LOS DATOS DEL FORMULARIO 
  transformAttr() {
    let tramiteAttrs: AttrsParseDto[] = []

    // LO QUE TENEMOS GUARDADO EN LOS GRUPOS, SE LOS AGREGAMOS AL DTO
    // QUE ENVIAREMOS AL BACK-END
    if (this.groups && this.groups.length > 0) {
      this.groups.forEach((attr) => {
        let model: AttrsParseDto = {
          fieldName: '',
          procedureTypeAttrId: null,
          valor: '',
        }
        model.fieldName = attr.name ? attr.name : '';
        model.valor = attr.dataValue ? attr.dataValue : '';
        model.procedureTypeAttrId = attr.id ? attr.id : null;
        tramiteAttrs.push(model);
      })
    }

    this.form.procedureTypeAttrs.forEach((el) => {
      let model: AttrsParseDto = {
        fieldName: '',
        procedureTypeAttrId: null,
        valor: '',
      }
      model.fieldName = el.name ? el.name : '';
      model.valor = el.dataValue ? el.dataValue : '';
      model.procedureTypeAttrId = el.id ? el.id : null;

      tramiteAttrs.push(model);
    })
    return tramiteAttrs;
  }

  // VALIDAMOS LOS CAMPOS OBLIGATORIOS
  validateForm() {
    let currentAttr: ProcedureTypeAttr[] = this.currentsAttrs
    currentAttr.forEach((el) => {
      if (el.required && !el.dataValue) {
        throw new Error(`El campo ${el.name} es requerido`);
      }
    })
  }

  validateCode(): Promise<boolean> {
    return new Promise<boolean>((resolve, reject) => {
      this.storage.get('validationCode').then((val) => {
        if (val) {
          let isValid = true;
          this.currentsAttrs.forEach((el) => {
            if (parseInt(el.dataValue) !== val) {
              isValid = false;
            }
          });
          resolve(isValid);
        } else {
          resolve(false);
        }
      }).catch((error) => {
        reject(error);
      });
    });
  }

  async sendForm() {
    try {
      await this.validateForm();

      let attrsParse = this.transformAttr();

      let model = {
        comments: "",
        userId: this.procedureService.userId,
        procedureTypeId: this.form.id,
        documentDtoList: this.filesToPost,
        tramiteAttrs: attrsParse
      }
      // ESTO ESTÁ HECHO ASÍ PORQUE ME LO PIDIERON DOS DÍAS ANTES DE IRME
      // SEPA DISCULPAR, ES PARA EL TRÁMITE DE DEFENSORÍA DEL PUEBLO - RECLAMOS
      let isValidCode;
      if (!this.isValidateCode) {
        isValidCode = true;
      } else {
        isValidCode = await this.validateCode();
      }

      if (isValidCode) {
        this.loading();
        this.procedureService.createProcedure(model).subscribe((response) => {
          this.loadingController.dismiss(); // Ocultar el loader después de recibir la respuesta
          this.router.navigateByUrl('/proceduresHome')
        }, (error) => {
          this.loadingController.dismiss(); // Ocultar el loader después de recibir la respuesta
          this.alertService.showErrorAlert(error.error.message);
        });
      } else {
        this.alertService.showCustomAlert({
          message: "El código de validación es distinto al que hemos enviado"
        });
      }
    } catch (error) {
      this.alertService.showCustomAlert(error);
    }
  }


  converToBase64(fileToUpload, attrId) {
    const reader = new FileReader();
    reader.readAsDataURL(fileToUpload);
    reader.onload = (event) => {
      if (event.target) {
        let fileConvert = {
          id: attrId,
          base64: reader.result,
          mimeType: fileToUpload.type,
          originalName: fileToUpload.name ? fileToUpload.name : '',
        };
        // EMITIMOS EL BASE64 AL CMP PADRE
        this.filesToPost.push(fileConvert);
      }
    };
  }
  // GUARDAMOS LOS ARCHIVOS EN UNA VARIABLE LOCAL
  // PARA NO PERDER LA INFORMACIÓN AL IR A OTRO STEP
  saveFileInStep($event, fileToUpload: File) {
    for (let file of this.filesStep) {
      if (file.id === parseInt($event.target.id)) {
        this.alertService.showErrorAlert("Ya cargó un archivo, elimine el actual y vuelva a cargar uno");
        return; // Detener la ejecución del método
      }
    }

    let file = {
      id: parseInt($event.target.id),
      step: this.currentStep.step,
      label: $event.target.files[ 0 ].name,
      file: $event.target.files[ 0 ]
    }
    this.filesStep.push(file);
    this.converToBase64(fileToUpload, parseInt($event.target.id));

  }

  deleteFile(fileId: number, step: number) {
    this.filesToPost.forEach((file, index) => {
      if (file.id === fileId) {
        this.filesToPost.splice(index, 1)
      }
    })
    this.filesStep.forEach((file, index) => {
      if (file.id === fileId) {
        this.filesStep.splice(index, 1)
      }
    })
  }

  cleanCurrentAttr() {
    this.currentsAttrs.forEach((attr) => {
      if (attr.tipo !== 'READONLY')
        attr.dataValue = null;
    })

    this.filesStep = [];
  }

  emitterFn($event: ProcedureTypeAttr) {
    if ($event.name === InputsNames.PEDIDOXTERCERO) {
    }
  }

  // FUNCIÓN TRAE LOS ARCHIVOS DEL COMPONENTE HIJO
  setFilesFn($event) {
    let fileToUpload: File = $event.target.files.item(0) as File;
    if (fileToUpload) {
      const allowedFileTypes = [ '/pdf', '/png', '/jpg', '/jpeg' ];
      const fileType = fileToUpload.type;
      const fileExtension = fileType.substring(fileType.lastIndexOf('/'));

      const fileSizeInMB = fileToUpload.size / (1024 * 1024); // Tamaño del archivo en MB
      // VALIDAMOS QUE EL TAMAÑO NO SUPERE LOS 10MB
      if (fileSizeInMB > 10) {
        this.alertService.showErrorAlert('El tamaño del archivo no puede ser mayor a 10MB.');
        return;
      }

      // VALIDAMOS LAS EXTENSIONES PERMITIDAS
      if (allowedFileTypes.includes(fileExtension)) {
        this.saveFileInStep($event, fileToUpload);
      } else {
        this.alertService.showErrorAlert('Tipo de archivo no válido. Por favor, selecciona un archivo .pdf, .png o .jpg.');
      }
    }
  }

  addPersonEmitterFn() {
    this.currentsAttrs.forEach((el) => {
      if (el.dataValue) {
        let model: any[] = [];
        if (el.name !== InputsNames.ADDPERSON) {
          model.push(el.dataValue);
        } else {
          el.dataValue
        }
      } else {
        this.alertService.showErrorAlert("Debe completar todos los campos del formulario.")
      }
    })
  }

  personResultFn($event: RemotePersonDto, index: number) {

    if (index || (index !== null && index !== undefined)) {
      this.currentsAttrs.filter((attr) => attr.idgroup === index).forEach((el) => {
        switch (el.name) {
          case InputsNames.APELLIDOYNOMBRE:
            el.dataValue = $event.lastName.toUpperCase() + ' ' + $event.name.toUpperCase();
            break;
          case InputsNames.DOMICILIO:
            el.dataValue = ($event.street ? $event.street.toUpperCase() + ' ' + ($event.number ? $event.number : '') : '');
        }
      })
    } else {
      this.currentsAttrs.forEach((el) => {
        switch (el.name) {
          case InputsNames.APELLIDOYNOMBRE:
            el.dataValue = $event.lastName.toUpperCase() + ' ' + $event.name.toUpperCase();
            break;
          case InputsNames.DOMICILIO:
            el.dataValue = ($event.street ? $event.street.toUpperCase() + ' ' + ($event.number ? $event.number : '') : '');
        }
      })
    }
  }

  // MOVERME ENTRE LOS STEPS
  goToNextStep() {
    try {
      const nextStepIndex = this.currentPage + 1;
      if (this.steps[ this.currentPage ] && this.steps[ this.currentPage ].groups) {
        // funcion para guardar grupo y que no se pierda la información al ir a otro step.
        this.saveGroup();
      }
      this.currentsAttrs.forEach((el) => {
        if (el.name === InputsNames.PEDIDOXTERCERO && !el.dataValue) {
          this.nextPage = nextStepIndex + 1;
        } else {
          this.nextPage = nextStepIndex;
        }
      })
      this.validateForm();

      this.lastIndex.push(this.nextPage);
      this.buildForm(this.nextPage)
    } catch (error) {
      this.alertService.showCustomAlert(error)
    }
  }
  // MOVERME ENTRE LOS STEPS
  goToBackStep() {
    this.lastIndex.pop()
    let index = this.lastIndex[ this.lastIndex.length - 1 ]

    this.buildForm(index)
  }

  async loading() {
    const loading = await this.loadingController.create({
      message: 'Cargando',
    });
    await loading.present();
  }
}
