import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ProcedureTypeAttr } from "src/app/core/models/ProcedureTypeAttr";
import { RemotePersonDto } from "src/app/core/models/RemotePersonDto";
import { PersonService } from "src/app/services/person.service";
import { Storage } from '@ionic/storage';
import { AlertService } from "src/app/services/alert.service";
import { LoadingController } from "@ionic/angular";

@Component({
  selector: 'dynamic-form-item',
  templateUrl: './dynamic-form-item.component.html',
  styleUrls: [ './dynamic-form-item.component.scss' ],
})
export class DynamicFormItemComponent implements OnInit {
  @Input() stepInput: ProcedureTypeAttr;
  @Input() groupId: number;
  @Output() personResult: EventEmitter<RemotePersonDto> = new EventEmitter();
  @Output() genericEmitter: EventEmitter<ProcedureTypeAttr> = new EventEmitter();
  @Output() addPersonEmitter: EventEmitter<any> = new EventEmitter();
  @Output() sendFilesEmitter: EventEmitter<any> = new EventEmitter();
  phoneNumber: number;
  validationCode: number;

  constructor(
    private personService: PersonService,
    private storage: Storage,
    private alertService: AlertService,
    private loadingController: LoadingController,
  ) { }

  ngOnInit(
  ) { }

  personSearchFn($event) {
    this.personResult.emit($event)
  }

  checkboxChange(procedureTypeAttrs) {
    this.genericEmitter.emit(procedureTypeAttrs);
  }

  addPerson() {
    this.addPersonEmitter.emit();
  }


  validatePhone(telefono): boolean {
    const patternPhoneNumber = /^\d{10}$/;
    return patternPhoneNumber.test(telefono);
  }
  async loading() {
    const loading = await this.loadingController.create({
      message: 'Cargando',
    });
    await loading.present();
  }

  setFilesEmitter($event) {
    this.sendFilesEmitter.emit($event);
  }

  getCode() {
    let isValidCode = this.validatePhone(this.phoneNumber)
    if (!isValidCode) {
      this.alertService.showErrorAlert("Debe ingresar un número de telefóno válido.");
      return;
    }
    try {
      this.personService.getCodeValidation(this.phoneNumber).subscribe((respon) => {
        this.alertService.showCustomAlert({
          message: 'Enviamos su código de verifcación por SMS'
        })
        this.validationCode = respon;
        this.storage.set('validationCode', this.validationCode);
      }, (error) => {
        this.alertService.showErrorAlert(error.error.message)
      })
    } catch (error) {
      this.alertService.showErrorAlert(error);
    }
  }

}
