export const InputsNames = {
    PROVINCIA: 'Provincia',
    CUILCUIT: 'CUIL/CUIT',
    DNI: 'Tipo y Nro DU',
    GENERO: 'Género',
    PEDIDOXTERCERO: 'El pedido lo hace un tercero',
    APELLIDOYNOMBRE: 'Apellido y Nombre',
    DOMICILIO: 'Domicilio',
    PHONE_NUMBER: 'Número de teléfono',
    ADDPERSON: 'ADD_PERSON',
}