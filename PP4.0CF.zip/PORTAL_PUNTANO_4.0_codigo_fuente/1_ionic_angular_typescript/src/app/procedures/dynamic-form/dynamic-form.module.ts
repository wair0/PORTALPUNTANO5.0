import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { IonicModule } from "@ionic/angular";
import { RouterModule } from "@angular/router";
import { DynamicFormComponent } from "./dynamic-form.component";
import { DynamicFormItemComponent } from "./dynamic-form-item/dynamic-form-item.component";
import { SharedModule } from "src/app/shared/shared.module";
import { AlertService } from "src/app/services/alert.service";
import { MatExpansionModule } from "@angular/material/expansion";
import { ProceduresService } from "src/app/services/procedures.service";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatFormFieldModule } from "@angular/material/form-field";
import { AttrGroupFilterPipe } from "src/app/core/pipes/attr-group-filter.pipe";



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SharedModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatDatepickerModule,
    RouterModule.forChild([
      {
        path: '',
        component: DynamicFormComponent
      }
    ])
  ],
  declarations: [
    DynamicFormComponent,
    DynamicFormItemComponent,
    AttrGroupFilterPipe
  ],
  providers: [
    AlertService,
    ProceduresService
  ]
})
export class DynamicFormModule { }
