import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from "@angular/common/http";
import { IonicModule } from "@ionic/angular";
import { RouterModule } from "@angular/router";
import { NewProcedureComponent } from "./new-procedure.component";
import { MatExpansionModule } from "@angular/material/expansion";



@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    HttpClientModule,
    MatExpansionModule,
    RouterModule.forChild([
      {
        path: '',
        component: NewProcedureComponent
      }
    ])
  ],
  declarations: [ NewProcedureComponent ],

})
export class NewProcedureModule { }
