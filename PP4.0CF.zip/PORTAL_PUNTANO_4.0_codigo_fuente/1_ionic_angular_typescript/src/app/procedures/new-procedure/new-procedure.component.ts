import { Component, OnInit } from '@angular/core';
import { ProceduresService } from "src/app/services/procedures.service";
import { Procedures } from "src/app/utils/ProcedureEnums";
import { ProcedureType } from "src/app/core/models/ProcedureType";
import { NavigationExtras, Router } from "@angular/router";


@Component({
  selector: 'app-new-procedure',
  templateUrl: './new-procedure.component.html',
  styleUrls: [ './new-procedure.component.scss' ],
})
export class NewProcedureComponent implements OnInit {

  procedures = Procedures;
  userId: number;
  procedureType: ProcedureType;

  constructor(
    private procedureService: ProceduresService,
    private router: Router
  ) {
  }

  ngOnInit() { }

  goToBack() {
    this.router.navigate([ '/proceduresHome' ])
  }

  goToNewProcedure(procedureId: number) {
    this.procedureService.generateNewProcedure(procedureId).subscribe((response) => {
      this.procedureType = response;
      if (this.procedureType.id) {
        const navigationExtras: NavigationExtras = {
          state: {
            procedureType: this.procedureType
          }
        };
        this.router.navigate([ '/dynamic-form' ], navigationExtras);
      }
    })
  }
}
