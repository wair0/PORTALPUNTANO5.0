import { Component, OnInit } from '@angular/core';
import { ProceduresService } from "src/app/services/procedures.service";
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { LoadingController } from "@ionic/angular";
import { NavigationExtras, Router } from "@angular/router";

@Component({
  selector: 'app-completed-procedures',
  templateUrl: './completed-procedures.component.html',
  styleUrls: [ './completed-procedures.component.scss' ],
})
export class CompletedProceduresComponent implements OnInit {
  userId: number;
  procedures: any[] = []

  constructor(
    private proceduresService: ProceduresService,
    private screenOrientation: ScreenOrientation,
    private loadingController: LoadingController,
    private router: Router
  ) {
    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);

  }

  ngOnInit() {
    this.getProcedures();
  }

  getAllProcedures() {
    this.loading();
    this.proceduresService.getCurrentProcedures('FIN').subscribe((response) => {
      if (response && response.content && response.content.length > 0) {
        this.loadingController.dismiss();
        this.procedures = response.content;
      }
    },
      (error) => {
        this.loadingController.dismiss();
      })
  }

  getProcedures() {
    this.loading();
    this.proceduresService.getCurrentProcedures('FIN', 5).subscribe((response) => {
      this.loadingController.dismiss();
      if (response && response.content && response.content.length > 0) {
        this.procedures = response.content;
      } else
        alert("No se encontraron datos");
    },
      (error) => {
        this.loadingController.dismiss();
      })
  }

  async loading() {
    const loading = await this.loadingController.create({
      message: 'Cargando',
    });
    await loading.present();
  }

  async getProcedureDetail(idProcedure: any) {
    this.loading();
    this.proceduresService.getDetailsProcedures(idProcedure).subscribe((data: any) => {
      this.makeProcedure(data)
    })
  }

  public makeProcedure(procedure: any) {
    let steps = new Map();
    procedure.procedureSteps.forEach(element => {
      steps.set(element.step, element.title);
    });
    let attributes = new Map();
    let files: Array<any> = new Array();
    procedure.procedureTypeAttrs.forEach(element => {
      if (element.step) {
        if (attributes.get(element.step)) {
          attributes.get(element.step).push(element);
        } else {
          let array: Array<any> = new Array();
          array.push(element);
          attributes.set(element.step, array);
        }
      }
      else {
        files.push(element);
      }

    });
    let array: Array<any> = new Array();
    if (files.length > 0) {
      let dataFiles = {
        name: "",
        attributes: files

      };
      array.push(dataFiles);
    }
    attributes.forEach((value, key) => {
      let data = {
        name: steps.get(key),
        attributes: value

      };
      array.push(data);
    });

    if (procedure.comments) {
      let attributeComments = {
        name: "Observaciones",
        dataValue: procedure.comments

      };
      let arrayComments: Array<any> = new Array();
      arrayComments.push(attributeComments);

      let stepComments = {
        name: "COMENTARIOS",
        attributes: arrayComments
      }
      array.push(stepComments);
    }
    this.goToProcedureDetail(procedure, array);
  }


  goToProcedureDetail(procedureItem: any, steps: Array<any>) {
    this.loadingController.dismiss();
    if (steps.length > 0) {
      let navigationExtras: NavigationExtras = {
        state: {
          procedureItem: procedureItem,
          steps: steps,
        }
      };
      this.router.navigate([ 'procedureDetail' ], navigationExtras)
    } else {
      alert("No se encontraron datos");
    }
  }
}
