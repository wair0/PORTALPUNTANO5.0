import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from "@ionic/angular";
import { HttpClient, HttpClientModule } from "@angular/common/http";
import { RouterModule } from "@angular/router";
import { CompletedProceduresComponent } from "./completed-procedures.component";
import { RefreshUtils } from "src/app/utils/refreshUtils";



@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    HttpClientModule,
    RouterModule.forChild([
      {
        path: '',
        component: CompletedProceduresComponent
      }
    ])
  ],
  providers: [ HttpClient, RefreshUtils ],
  declarations: [ CompletedProceduresComponent ],
})
export class CompletedProceduresModule { }
