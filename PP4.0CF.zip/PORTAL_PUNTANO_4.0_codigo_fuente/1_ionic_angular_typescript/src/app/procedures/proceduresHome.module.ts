import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ProceduresHomePage } from './proceduresHome.page';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import {RefreshUtils} from '../utils/refreshUtils';


@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      HttpClientModule,
      RouterModule.forChild([
        {
          path: '',
          component: ProceduresHomePage
        }
      ])
    ],
    providers: [HttpClient
    ,RefreshUtils],
    declarations: [ProceduresHomePage]
  })
  
  export class ProceduresHomeModule {}