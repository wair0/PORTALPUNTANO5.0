import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { Storage } from '@ionic/storage';
import { constants } from '../utils/constants';
import { RefreshUtils } from '../utils/refreshUtils';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { ProceduresService } from "../services/procedures.service";


@Component({
  selector: 'app-proceduresHome',
  templateUrl: 'proceduresHome.page.html',
  styleUrls: [ 'proceduresHome.page.scss' ],
})
export class ProceduresHomePage implements OnInit {

  public proceduresAct: Array<any>;
  public proceduresFin: Array<any>;
  public procedures: Array<any>;
  public token: String;
  public idUser: any;

  public allProceduresAct: any[] = [];
  public allProceduresFin: any[] = [];
  public allProcedures: Array<any>;


  public totalProceduresAct: number;
  public totalProceduresFin: number;


  constructor(
    private alertController: AlertController,
    private loadingController: LoadingController,
    private http: HttpClient,
    private storage: Storage,
    private router: Router,
    private screenOrientation: ScreenOrientation,
    private statusBar: StatusBar,
    private navController: NavController,
    private proceduresService: ProceduresService
  ) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    this.storage.get('token').then((val) => {
      if (val) {
        this.token = val
        this.storage.get('userId').then((val2) => {
          if (val2) {
            this.idUser = val2
          }
        })
      }
    })
  }

  ionViewWillEnter() {
    this.statusBar.backgroundColorByHexString('#FF0067');
  }

  ngOnInit() {
  }

  async deleteDataAndExitToLogin() {

    this.storage.clear().then(() => {
      this.navController.navigateRoot("/login");
    });

  }


  async alert(messageText: string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }


  async loading() {
    const loading = await this.loadingController.create({
      message: 'Cargando',
    });
    await loading.present();
  }

  async loadingWithMessage(messageText: string) {
    const loading = await this.loadingController.create({
      message: messageText,
    });
    await loading.present();
  }

  async getProceduresAct() {

    this.loading();

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Authorization': 'Bearer ' + this.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }),
      })
    };

    this.http.get(constants.URL_BASE_PORTAL + "secure/procedure/user/" + this.idUser + "?status=ACT&search=&page=0&size=500&sort=dateCreated,desc", httpOptions)
      .subscribe((data: any) => {
        this.allProceduresAct = data.content;
        this.goToProceduresAct(this.allProceduresAct, "MIS TRÁMITES VIGENTES");

      }, () => {
        this.allProceduresAct = [];


      });
  }

  async getProceduresFin() {    
    this.router.navigate([ 'completedProcedures' ])
  }

  async getProcedureDetail(idProcedure: any) {

    this.loading();

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Authorization': 'Bearer ' + this.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }),
      })
    };
    this.http.get(constants.URL_BASE_PORTAL + "secure/procedure/" + idProcedure, httpOptions)
      .subscribe((data: any) => {

        this.loadingController.dismiss();

        this.makeProcedure(data);

      }, error => {
        this.processError(error).then(() => {
          this.getProcedureDetail(idProcedure);
        });

      });
  }

  public makeProcedure(procedure: any) {

    let steps = new Map();
    procedure.procedureSteps.forEach(element => {
      steps.set(element.step, element.title);
    });

    let attributes = new Map();
    let files: Array<any> = new Array();
    procedure.procedureTypeAttrs.forEach(element => {

      if (element.step) {
        if (attributes.get(element.step)) {
          attributes.get(element.step).push(element);
        } else {
          let array: Array<any> = new Array();
          array.push(element);
          attributes.set(element.step, array);
        }
      }
      else {
        files.push(element);
      }

    });

    let array: Array<any> = new Array();

    if (files.length > 0) {
      let dataFiles = {
        name: "",
        attributes: files

      };
      array.push(dataFiles);
    }

    attributes.forEach((value, key) => {

      let data = {
        name: steps.get(key),
        attributes: value

      };

      array.push(data);


    });

    if (procedure.comments) {
      let attributeComments = {
        name: "Observaciones",
        dataValue: procedure.comments

      };

      let arrayComments: Array<any> = new Array();
      arrayComments.push(attributeComments);

      let stepComments = {
        name: "COMENTARIOS",
        attributes: arrayComments
      }

      array.push(stepComments);

    }

    console.log(steps);
    console.log(attributes);
    console.log(array)

    this.goToProcedureDetail(procedure, array);
  }


  goToProcedureDetail(procedureItem: any, steps: Array<any>) {

    this.loadingController.dismiss();

    if (steps.length > 0) {
      let navigationExtras: NavigationExtras = {
        state: {
          procedureItem: procedureItem,
          steps: steps,
          token: this.token,
        }
      };
      this.router.navigate([ 'procedureDetail' ], navigationExtras)
    } else {
      alert("No se encontraron datos");
    }
  }


  goToProceduresAct(procedures: Array<any>, title: String) {
    this.loadingController.dismiss();
    if (this.allProceduresAct.length > 0) {
      let navigationExtras: NavigationExtras = {
        state: {
          procedures: procedures,
          token: this.token,
          title: title
        }
      };
      this.router.navigate([ 'currentProcedures' ], navigationExtras)
    } else {
      alert("No se encontraron datos");
    }
  }

  processError = function (error: any) {
    return new Promise<any>((resolve) => {
      console.log("Error!!!!!");
      console.log(JSON.stringify(error));
      this.loadingController.dismiss();
      if (error.status == 500) {
        if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
          this.storage.get('psw').then((val: any) => {
            if (val) {
              this.loading();
              this.refreshUtils.refreshToken(val).then((value: any) => {
                this.loadingController.dismiss();
                resolve(value);
              }).catch((errorRefresh: { status: number; }) => {
                this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();
                } else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            }
            else {
              this.alert(constants.GENERIC_ERROR);
            }
          });

        } else {
          this.alert(constants.GENERIC_ERROR);
        }
      } else if (error.status == 401) {
        this.deleteDataAndExitToLogin();
      } else if (error.status == 409) {
        this.alert(error.error.message);
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }


}