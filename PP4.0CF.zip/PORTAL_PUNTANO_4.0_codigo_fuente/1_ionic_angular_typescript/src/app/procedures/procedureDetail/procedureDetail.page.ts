import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController,NavController,Platform } from '@ionic/angular';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { log } from 'util';
import { Alert } from 'selenium-webdriver';
import { Storage } from '@ionic/storage';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx'; 
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';

import {constants} from '../../utils/constants';
import {RefreshUtils} from '../../utils/refreshUtils';

import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';

import { StatusBar } from '@ionic-native/status-bar/ngx';
import { DeviceDetailsService } from '../../device/device.service';

@Component({
  selector: 'app-procedureDetail',
  templateUrl: 'procedureDetail.page.html',
  styleUrls: ['procedureDetail.page.scss'],
})
export class ProcedureDetailPage implements OnInit {

  public item: any;
  public steps: Array<any>;
  public token:String;
  public fileTransfer: FileTransferObject;
  public storageDirectory:any;
  

  constructor(private alertController: AlertController,
    private loadingController: LoadingController,
    private http: HttpClient,
    private storage: Storage,
    private route: ActivatedRoute, 
    private router: Router,
    private transfer: FileTransfer,
    private file: File,
    private fileOpener: FileOpener
    ,private deviceDetailsService: DeviceDetailsService
    ,private screenOrientation: ScreenOrientation
    ,private statusBar: StatusBar
    ,private navController: NavController
    ,private refreshUtils: RefreshUtils
    ,private platform: Platform
     ) {

      this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
      this.route.queryParams.subscribe(params => {
        if (this.router.getCurrentNavigation().extras.state) {
          this.item = this.router.getCurrentNavigation().extras.state.procedureItem;
          this.steps = this.router.getCurrentNavigation().extras.state.steps;
          this.token = this.router.getCurrentNavigation().extras.state.token;
        }
      });


     }

     ionViewWillEnter(){
      this.statusBar.backgroundColorByHexString('#FF0067');
    }

    ngOnInit(){
    }

    async deleteDataAndExitToLogin(){

      this.storage.clear().then(()=>{
        this.navController.navigateRoot("/login");
      });
    
    }
    
    
    async alert(messageText:string) {
      const alert = await this.alertController.create({
        header: 'Portal puntano',
        message: messageText,
        buttons: [
          {
            text: 'OK',
            role: 'cancel',
            cssClass: 'primary',
            handler: () => {
              console.log('OK pressed!!');
            }
          }
        ]
      });
    
      await alert.present();
    }
    
    
    async loading(){
      const loading = await this.loadingController.create({
        message: 'Cargando',
      });
      await loading.present();
    }
    
    async loadingWithMessage(messageText:string){
      const loading = await this.loadingController.create({
        message: messageText,
      });
      await loading.present();
    }

    async checkPassword(attribute:any) {
      this.loadingWithMessage("Descargando");
      this.storage.get('token').then((val) => {
        if (val) {
          this.token = val;
  
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + this.token,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };
  
      console.log("URL: " + constants.URL_BASE_PORTAL + "secure/mobile/check/password");
      console.log("TOKEN: " + 'Bearer ' + this.token);
  
      this.http.get(constants.URL_BASE_PORTAL + "secure/mobile/check/password", httpOptions)
        .subscribe((data: any) => {
  
          this.download(attribute);
  
        }, error => {
          this.processError(error).then(value => {
            this.checkPassword(attribute);
          });
        });
      }
      else {
        this.loadingController.dismiss();
        this.alert("Ocurrió un problema, intente nuevamente");
      }
    });
    }

    async download(attribute:any) {


      let fileName = attribute.name+"_"+attribute.dataValue+".pdf";

      //http://64.215.200.21:8080/portalServer/secure/files/download/1443afa5-98b5-4b59-a70a-1054e43517ae
      let filePath = constants.URL_BASE_PORTAL+"secure/files/download/"+attribute.dataValue;

      let url = encodeURI(filePath);
      this.fileTransfer = this.transfer.create();

      let options = {
        headers: {
          "X-Authorization": "Bearer "+this.token
      }
      };

      let directory = this.file.documentsDirectory;

      // if (this.platform.is("android")) {
      //   if(this.file.externalRootDirectory){
      //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
      //     }else{
      //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
      //     }
      // }
  
      if (this.platform.is("android")) {
        let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
        //if(this.file.externalRootDirectory){
        console.log("[HOME] OS VERSION: " + soVersion);
        if (soVersion < 11) {
          if(this.file.externalRootDirectory){
            directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
          }else{
            directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
          }
        }else{
          directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
        }
      }
    
      this.fileTransfer.download(url, directory+ fileName, true,options).then((entry) => {
        this.loadingController.dismiss();
        //here logging our success downloaded file path in mobile. 
        console.log('download completed: ' + entry.toURL());
    
        this.file.resolveDirectoryUrl(directory).then((rootDir) => {
          this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
            fileEntry.getMetadata(metadata => {
              if (metadata.size != 0) {
                // open downloaded file 
                this.openFileHandler(entry.toURL());
  
                if (this.platform.is("android")) {
                  let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                  if (soVersion < 11) {
                    if(this.file.externalRootDirectory){
                      this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + constants.FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                    }
                  }
                }
  
              } else {
                this.alert(constants.FILE_SIZE_0_ERROR);
              }
            })
  
          });
  
        });
        
      }).catch((error) => {
        this.loadingController.dismiss();
        if(error!=null && error.http_status!=null&&error.http_status==409){
        this.alert(JSON.parse(error.body).message);
        }else{
          this.alert(constants.GENERIC_ERROR);
        }
        //here logging an error. 
        console.log('download failed: ' + JSON.stringify(error));
      });
    }

    openFileHandler(path:any) {
      this.fileOpener.open(path, '')
        .then(() => console.log('File is opened'))
        .catch(e => console.log('Error opening file', e));
    }


    processError = function(error:any){
      return new Promise<any>((resolve,reject)=>{
      console.log("Error!!!!!");
      console.log(JSON.stringify(error));
      this.loadingController.dismiss();
       if(error.status == 500){
        if(error.error.exception==="io.jsonwebtoken.ExpiredJwtException"){
          this.storage.get('psw').then((val: any) => {
            if(val){
              this.loadingWithMessage("Descargando");
               this.refreshUtils.refreshToken(val).then((value: any) => {
                 this.loadingController.dismiss();
                resolve(value);
              }).catch((errorRefresh: { status: number; })=>{
                this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();  
                }else {
                this.alert(constants.GENERIC_ERROR);
                }
              });
            }
            else{
              this.alert(constants.GENERIC_ERROR);
            }
          });
         
        }else{
          this.alert(constants.GENERIC_ERROR);
        }
      }else if (error.status == 401) {
        this.deleteDataAndExitToLogin();  
      }else if(error.status == 409){
        this.alert(error.error.message);
      }else{
        this.alert(constants.GENERIC_ERROR);
      }
    });
  
    }

    goToHome(){
      this.navController.navigateRoot("/home");
      }
}