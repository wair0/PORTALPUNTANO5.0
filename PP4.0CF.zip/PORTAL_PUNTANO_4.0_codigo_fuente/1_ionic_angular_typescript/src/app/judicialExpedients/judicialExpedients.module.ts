import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { JudicialExpedientsPage } from './judicialExpedients.page';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx'; 
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import {RefreshUtils} from '../utils/refreshUtils';


@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      HttpClientModule,
      RouterModule.forChild([
        {
          path: '',
          component: JudicialExpedientsPage
        }
      ])
    ],
    providers: [HttpClient,
      FileTransfer,
      FileTransferObject,
      File,
      RefreshUtils,
      FileOpener],
    declarations: [JudicialExpedientsPage]
  })
  
  export class JudicialExpedientsModule {}