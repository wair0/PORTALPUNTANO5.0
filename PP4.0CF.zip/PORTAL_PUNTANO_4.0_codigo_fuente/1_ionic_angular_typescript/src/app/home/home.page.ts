import { Component } from '@angular/core';
import { LoadingController, AlertController, NavController, Platform, ToastController } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { constants } from '../utils/constants';
import { RefreshUtils } from '../utils/refreshUtils';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import {
  SwiperConfigInterface
} from 'ngx-swiper-wrapper';
import { MessageService } from '../services/message.service';
import { StudentService } from '../services/student.service';
import { LoadingService } from '../services/loading.service';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: [ 'home.page.scss' ],
})
export class HomePage {
  studentList: any;
  studentListToSportMap: any;
  geDisabled = false;


  constructor(
    private alertController: AlertController,
    private loadingController: LoadingController,
    private storage: Storage,
    private router: Router,
    private http: HttpClient,
    private platform: Platform,
    private screenOrientation: ScreenOrientation,
    private navController: NavController,
    private toastCtrl: ToastController,
    private refreshUtils: RefreshUtils,
    private statusBar: StatusBar,
    private androidPermissions: AndroidPermissions,
    private messageService: MessageService,
    private studentService: StudentService,
    public load: LoadingService
  ) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    try {
      let height = window.innerHeight;
      let width = window.innerWidth;
      if (this.router.getCurrentNavigation().extras.state) {
        if (this.router.getCurrentNavigation().extras.state.height) {
          height = this.router.getCurrentNavigation().extras.state.height;
        }
        if (this.router.getCurrentNavigation().extras.state.width) {
          width = this.router.getCurrentNavigation().extras.state.width;
        }
      }
      let percentage = 50;
      if (width < height) {
        percentage = width * 100 / height;
      } else {
        percentage = height * 100 / width;
      }
      if (percentage > 64) {
        if (percentage > 64 && percentage < 77) {
          this.colSize = 5;
        } else if (percentage >= 77) {
          this.colSize = 4;
        }
      }

    } catch (exception) {
    }


    this.platform.ready().then(() => {
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?', result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE)
      );
      this.androidPermissions.requestPermissions([ this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE, this.androidPermissions.PERMISSION.GET_ACCOUNTS ]);
      this.getStudentsOfGE()
    });

  }

  subscription: any;

  public dataRm = {
    token: '',
    consultations: [],
    prescriptions: [],
    studies: []

  };

  public data = {
    token: '',
    iduser: 0,
    dni: 0,
    liquidations: [],
    judicialExpedients: [],
    proceduresAct: [],
    proceduresFin: [],
    procedures: [],
    totalProceduresAct: 0,
    totalProceduresFin: 0
  };

  public slideOpts = {
    // initialSlide: 0,
    // speed: 200,
    // pagination: {
    //   el: '.swiper-pagination',
    //   type: 'bullets',
    // },
    slidesPerView: 1.07,
    spaceBetween: 0,
    // centeredSlides: true
    //  height: '80%',
    //  spaceBetween:-18
    // autoHeight: true

  };

  public colSize = 6;



  public config: SwiperConfigInterface = {
    a11y: true,
    direction: 'horizontal',
    loop: true,
    slidesPerView: 5,
    keyboard: true,
    mousewheel: true,
    scrollbar: false,
    navigation: true,
    pagination: false
  };

  ionViewWillEnter() {
    this.statusBar.backgroundColorByHexString('#FFFFFF');
  }

  ionViewDidEnter() {
    let lastTimeBackPress = 0;
    const timePeriodToExit = 2000;
    this.subscription = this.platform.backButton.subscribe(() => {
      console.log('BACK BUTTON PRESSED!!!!!');
      if (new Date().getTime() - lastTimeBackPress < timePeriodToExit) {
        let newVariable: any;

        newVariable = window.navigator;
        // navigator.app.exitApp();
        newVariable.app.exitApp();
      } else {
        this.exitToast();
        lastTimeBackPress = new Date().getTime();
      }

    });
  }



  async exitToast() {
    const toast = await this.toastCtrl.create({
      message: 'Pulse nuevamente para salir',
      duration: 2000,
      position: 'bottom'
    });
    toast.present();
  }


  ionViewWillLeave() {
    this.subscription.unsubscribe();
  }


  async deleteDataAndExitToLogin() {

    this.loadingController.dismiss();

    this.storage.clear().then(() => {
      this.navController.navigateRoot('/login');
    });

  }


  async alert(messageText: string) {
    this.loadingController.dismiss();
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }

  async changePassword() {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: 'Cambiar contraseña',
      inputs: [
        {
          name: 'password',
          type: 'password',
          placeholder: 'Ingrese su contraseña actual'
          // value: this.operator.person.email
        },
        {
          name: 'new_password',
          type: 'password',
          placeholder: 'Ingrese una nueva contraseña'
          // value: this.operator.person.phone
        },
        {
          name: 'new_password_again',
          type: 'password',
          placeholder: 'Repita su nueva contraseña'
          // value: this.operator.person.phone
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Cancel Change data');
          }
        }, {
          text: 'Cambiar contraseña',
          handler: (data) => {
            // this.changeDataAction(data.email,data.phone);
          }
        }
      ]
    });

    await alert.present();
  }


  async loading() {
    this.loadingController.dismiss();
    const loading = await this.loadingController.create({
      message: 'Cargando',
      duration: 5000,
    });
    await loading.present();
  }

  async loadingWithMessage(messageText: string) {
    this.loadingController.dismiss();
    const loading = await this.loadingController.create({
      message: messageText,
    });
    await loading.present();
  }


  async settings() {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      buttons: [
        {
          text: 'Cambiar contraseña',
          handler: (data) => {
            // this.changePassword();
            this.navigateChangePassword();
          }
        },
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        },
        {
          text: 'Cerrar sesión',
          handler: (data) => {

            this.closeSession();
          }
        }
        // ,
        // {
        //   text: 'Cerrar todas las sesiones',
        //   handler: (data) => {
        //     this.closeAllSessions();
        //   }
        //
        // }

      ]
    });

    await alert.present();
  }

  async closeSession() {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: 'Desea cerrar sesión?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Cerrar sesión',
          handler: (data) => {
            this.deleteDataAndExitToLogin();
          }
        }
      ]
    });

    await alert.present();
  }

  async closeAllSessions() {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: 'Desea cerrar todas las sesiones?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Cerrar todas las sesiones',
          handler: (data) => {

            this.getTokenForCloseAllSessions();
          }
        }
      ]
    });

    await alert.present();
  }

  async getTokenForCloseAllSessions() {
    this.loading();
    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;
        this.storage.get('userId').then((val2) => {
          if (val2) {
            this.data.iduser = val2;
            this.deleteAllPasswords();
          } else {
            this.loadingController.dismiss();
            this.alert('Ocurrió un problema, intente nuevamente');
          }
        });

      } else {
        this.alert('Ocurrió un problema, intente nuevamente');
      }
    });

  }

  async deleteAllPasswords() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.data.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    this.http.delete(constants.URL_BASE_PORTAL + 'secure/mobile/password/user/' + this.data.iduser, httpOptions)
      .subscribe((data: any) => {
        this.deleteDataAndExitToLogin();

        this.loadingController.dismiss();

      }, error => {
        this.processError(error).then(value => {
          this.getTokenForCloseAllSessions();
        });
      });
  }


  // Liquidations
  async getTokenForLiquidations() {
    this.loading();
    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;
        this.storage.get('userId').then((val2) => {
          if (val2) {
            this.data.iduser = val2;
            this.getLiquidations();
          } else {
            this.alert(constants.GENERIC_ERROR);
          }
        });

      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  }

  async getLiquidations() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.data.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    console.log('URL: ' + constants.URL_BASE_PORTAL + 'secure/liquidations/' + this.data.iduser);
    console.log('TOKEN: ' + 'Bearer ' + this.data.token);

    this.http.get(constants.URL_BASE_PORTAL + 'secure/liquidations/' + this.data.iduser, httpOptions)
      .subscribe((data: any) => {


        console.log('RESPONSE GET LIQUIDATIONS!: ');

        console.log(data);

        if (data != null && data.liquidations != null && data.liquidations.length > 0) {
          this.data.liquidations = data.liquidations;
          this.goToLiquidations();

        } else {
          // this.alert("No posee recibos de sueldo");
          this.goToScreenErrorMessage('La visualización de los recibos de sueldo es exclusivamente para empleados estatales de San Luis.\nEn caso de ser un empleado de gobierno y no poder visualizar los recibos, contactarse con RRHH.');
        }

        // this.loadingController.dismiss();

      }, error => {
        this.processError(error).then(value => {
          this.getTokenForLiquidations();
        });
      });
  }


  // Judicial Expedients
  async getTokenForJudicialExpedients() {
    this.loading();
    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;
        this.storage.get('userId').then((val2) => {
          if (val2) {
            this.data.iduser = val2;
            this.storage.get('psw').then((val3) => {
              if (val3) {
                this.data.dni = val3.docNumber;
                this.getjudicialExpedients();
              } else {
                // this.loadingController.dismiss();
                this.alert('Ocurrió un problema, intente nuevamente');
              }
            });

          } else {
            // this.loadingController.dismiss();
            this.alert('Ocurrió un problema, intente nuevamente');
          }
        });

      } else {
        // this.loadingController.dismiss();
        this.alert('Ocurrió un problema, intente nuevamente');
      }
    });

  }

  async getjudicialExpedients() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.data.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    console.log('URL: ' + constants.URL_BASE_PORTAL + 'secure/judicialExpedient/docType/DNI/docNumber/' + this.data.dni); // "secure/liquidations/"+this.data.iduser);
    console.log('TOKEN: ' + 'Bearer ' + this.data.token);

    this.http.get(constants.URL_BASE_PORTAL + 'secure/judicialExpedient/docType/DNI/docNumber/' + this.data.dni, httpOptions)
      .subscribe((data: any) => {


        console.log('RESPONSE GET JUDICIAL EXPEDIENTS!: ');

        // HARDCODING!!!!!!!!
        // data = [{"year":"2019","expedients":[{"id":"1138065","name":"OFR 340866/3 (Acumulado a EXP 340866/19): OFICIO RELACIONADO CUELLO JUAN GERONIMO  S/ SUCESION AB INTESTATO (C) - JUZGADO CIVIL, COMERCIAL Y MINAS NRO.1 VM","actions":null},{"id":"1131021","name":"OFR 340866/2: OFICIO RELACIONADO CUELLO JUAN GERONIMO  S/ SUCESION AB INTESTATO (ASIGNAR) - JUZGADO CIVIL, COMERCIAL Y MINAS NRO.1 VM","actions":null},{"id":"1117412","name":"OFR 340866/1 (Acumulado a EXP 340866/19): OFICIO RELACIONADO CUELLO JUAN GERONIMO  S/ SUCESION AB INTESTATO(S) - JUZGADO CIVIL, COMERCIAL Y MINAS NRO.1 VM","actions":null},{"id":"1077275","name":"EXP 340866/19: CUELLO JUAN GERONIMO  S/ SUCESION AB INTESTATO (C) - JUZGADO CIVIL, COMERCIAL Y MINAS NRO.1 VM","actions":null}]},{"year":"2017","expedients":[{"id":"846936","name":"INC 234500/2: INCIDENTE PRUEBAS SECRETARIA INFORMATICA PRUEBA 2 DE TESTING 04/12/2014 - JUZGADO CIVIL, COMERCIAL Y MINAS NRO. 1 SL","actions":null}]},{"year":"2014","expedients":[{"id":"547164","name":"OFR 234500/2: PRUEBA2 - JUZGADO CIVIL, COMERCIAL Y MINAS NRO. 1 SL","actions":null},{"id":"533639","name":"OFR 234500/12: PRUEBA SECRETARIA CV - JUZGADO CIVIL, COMERCIAL Y MINAS NRO. 1 SL","actions":null}]}];

        console.log(JSON.stringify(data));

        if (data != null && data.length > 0) {

          this.data.judicialExpedients = data;
          console.log('JUDICIAL EXPEDIENTS!!!!');
          console.log(JSON.stringify(data));
          this.goToJudicialExpedients();

        } else {
          this.alert('No posee expedientes judiciales');
        }

      }, error => {
        this.processError(error).then(value => {
          this.getTokenForJudicialExpedients();
        });
      });
  }


  // RM
  async checkPasswordRM() {

    this.loading();

    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;


        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'X-Authorization': 'Bearer ' + this.data.token,
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };

        console.log('URL: ' + constants.URL_BASE_PORTAL + 'secure/mobile/check/password');
        console.log('TOKEN: ' + 'Bearer ' + this.data.token);

        this.http.get(constants.URL_BASE_PORTAL + 'secure/mobile/check/password', httpOptions)
          .subscribe((data: any) => {

            this.getDataRm();

          }, error => {
            this.processError(error).then(value => {
              this.checkPasswordRM();
            });
          });
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });
  }

  async getDataRm() {
    this.storage.get('tokenRM').then((val) => {
      if (val) {
        this.dataRm.token = val;
        this.getConsultations();
      } else {
        this.storage.get('token').then((val) => {
          if (val) {
            this.refreshUtils.refreshTokenRM(val).then(value => {
              this.getDataRm();
            }).catch(error => {
              if (error && error.status && error.status === 409 && error.error && error.error.message) {
                this.alert(error.error.message);
              } else {
                this.alert(constants.GENERIC_ERROR);
              }
            });

          } else {
            this.alert(constants.GENERIC_ERROR);
          }
        });

      }
    });

  }

  async getConsultations() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.dataRm.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    console.log('URL: ' + constants.URL_RM + 'secure/external/mobile/consultation/person?specialtyId=0&dateFrom=&dateTo=&size=2');
    console.log('TOKEN: ' + 'Bearer ' + this.dataRm.token);

    this.http.get(constants.URL_RM + 'secure/external/mobile/consultation/person?specialtyId=0&dateFrom=&dateTo=&size=2', httpOptions)
      .subscribe((data: any) => {
        console.log(data);

        console.log('RESPONSE GET CONSULTATIONS!: ');

        console.log(data);

        this.dataRm.consultations = data.content;
        this.getPrescriptions();

      }, error => {
        if (error.status == 500) {
          if (error.error.exception === 'io.jsonwebtoken.ExpiredJwtException') {
            this.storage.get('token').then((val) => {
              if (val) {
                this.refreshUtils.refreshTokenRM(val).then(value => {
                  this.getDataRm();
                }).catch(error => {
                  this.alert('Ocurrió un problema, intente nuevamente');
                });
              } else {
                this.alert('Ocurrió un problema, intente nuevamente');
              }
            });
          } else {
            console.log('Error!!!!!');
            console.log(JSON.stringify(error));
            this.dataRm.consultations = [];
            this.getPrescriptions();
          }
        } else {
          console.log('Error!!!!!');
          console.log(JSON.stringify(error));
          this.dataRm.consultations = [];
          this.getPrescriptions();

        }

      });
  }

  async getPrescriptions() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.dataRm.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    console.log('URL: ' + constants.URL_RECIPE + 'secure/external/mobile/prescriptions?benefitType=M&specialtyId=0&dateFrom=&dateTo=&size=2');
    console.log('TOKEN: ' + 'Bearer ' + this.dataRm.token);

    this.http.get(constants.URL_RECIPE + 'secure/external/mobile/prescriptions?benefitType=M&specialtyId=0&dateFrom=&dateTo=&size=2', httpOptions)
      .subscribe((data: any) => {
        this.getStudies();


      }, error => {
        this.dataRm.prescriptions = [];
        this.getStudies();

      });
  }

  async getStudies() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.dataRm.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    console.log('URL: ' + constants.URL_RECIPE + 'secure/external/mobile/prescriptions?benefitType=P&specialtyId=0&dateFrom=&dateTo=&size=2');
    console.log('TOKEN: ' + 'Bearer ' + this.dataRm.token);

    this.http.get(constants.URL_RECIPE + 'secure/external/mobile/prescriptions?benefitType=P&specialtyId=0&dateFrom=&dateTo=&size=2', httpOptions)
      .subscribe((data: any) => {
        console.log(data);
        this.loadingController.dismiss();
        this.goToRm();

      }, error => {
        this.dataRm.studies = [];
      });
  }


  // Driver License
  async checkPasswordDL() {
    this.loading();
    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;

        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'X-Authorization': 'Bearer ' + this.data.token,
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };

        console.log('URL: ' + constants.URL_BASE_PORTAL + 'secure/mobile/check/password');
        console.log('TOKEN: ' + 'Bearer ' + this.data.token);

        this.http.get(constants.URL_BASE_PORTAL + 'secure/mobile/check/password', httpOptions)
          .subscribe((data: any) => {

            this.getLocalDriverLicense();

          }, error => {
            this.processError(error).then(value => {
              this.checkPasswordDL();
            });
          });
      } else {
        // this.loadingController.dismiss();
        this.alert('Ocurrió un problema, intente nuevamente');
      }
    });
  }

  goToCredentials() {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        token: this.data.token
      }
    };
    this.router.navigate([ 'credentials' ], navigationExtras);

  }

  goToHealth() {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        token: this.data.token,
        content: this.studentListToSportMap
      }
    };
    this.router.navigate([ 'health' ], navigationExtras);
  }

  async getLocalDriverLicense() {

    this.storage.get('driverLicense').then((val) => {
      if (val) {
        // this.loadingController.dismiss();
        this.goToDriverLicense(val);

      } else {
        this.getDriverLicense();
      }
    });

  }

  async getDriverLicense() {

    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };


        // HARDCODING!!!!!!
        //   let dataDL = {
        //     "firstName": "LUCAS EMANUEL",
        //     "lastName": "DOMENE",
        //     "dateFrom": "12 ene 18",
        //     "dateTo": "12 ene 22",
        //     "driverLicenseTypes": [
        //         {
        //             "name": "Clase A4",
        //             "vehicleTypeDescription": "Motocicleta, triciclo motorizado, motocarga y cuatriciclo de más de 300 cc y de menor cilindrada"
        //         },
        //         {
        //             "name": "Clase B2",
        //             "vehicleTypeDescription": "Automóviles y camionetas de hasta 3.500 Kgs c/acoplado hasta 750 Kgs, o casa rodante no motorizada"
        //         }
        //     ],
        //     "driverLicenseVisas": [],
        //     "qrBase64": "iVBORw0KGgoAAAANSUhEUgAAAfQAAAH0AQAAAADjreInAAABeUlEQVR42u3cO3LCMBQFUGUoUrIElsLSkqV5KVkCJUUmBuGPPhgMZCZFdF6H7OPyjt+TReh/VYfA8zzP8zzP8zzP8zzP/43/CUVt4loIH313/rHtj+XVLc/zfOFTrBwnH2uXFob64nmev/KfY7rE2y+BlPJnMyXUnud5fsXP7y9T/vA8zz/u48JwO8/z/Iqv+p/U7rzWP/E834wv569jIE358/T8luf5ZvxVFfOTF/aPeZ5vxmfdTVW7810hb4h4nufr/Ilx01/8e/7AqiEaBrI8z/O17+a4mQcq07hkntDyPM/fmp9s0wMX8md9/srzfMt+cf9mDKRudX7L83xjfmn+OrU7h3ND9B3e8g/SeJ7n7+7/5g1RiH59fsvzfJs+LWefqw4V8ycMD+x5nucXfHX+Lr2/FPnz8Pk9nucb9UVlB2pu79/wPM/fOG53tSHM8zx/t//Z1/nz5PyE5/km/N3zd9UCz/O8/4/meZ7neZ7neZ7neZ7/3/4EY9wd8L1+icEAAAAASUVORK5CYII="
        // }
        // this.storage.set('driverLicense', dataDL);

        // END HARDCODING!!!!!!




        const postData = {
          token: this.data.token
        };

        console.log(constants.URL_BASE_PORTAL + 'secure/driverLicense/license');

        console.log(JSON.stringify(postData));


        this.http.post(constants.URL_BASE_PORTAL + 'secure/driverLicense/license', postData, httpOptions)
          .subscribe((data: any) => {

            console.log('RESPONSE DRIVER LICENSE!!!');

            console.log(data);

            this.storage.set('driverLicense', data);


            this.goToDriverLicense(data);

          }, error => {
            this.processError(error).then(value => {
              this.getDriverLicense();
            });

          });

      } else {
        // this.loadingController.dismiss();
        this.alert('Ocurrió un problema, intente nuevamente');
      }
    });



  }


  // Procedures
  async getTokenForProcedures() {
    this.loading();
    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;
        this.storage.get('userId').then((val2) => {
          if (val2) {
            this.data.iduser = val2;
            this.goToProcedures();
          } else {
            // this.loadingController.dismiss();
            this.alert('Ocurrió un problema, intente nuevamente');
          }
        });

      } else {
        // this.loadingController.dismiss();
        this.alert('Ocurrió un problema, intente nuevamente');
      }
    });

  }

  async getProceduresAct() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.data.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    this.http.get(constants.URL_BASE_PORTAL + 'secure/procedure/user/' + this.data.iduser + '?status=ACT&search=&page=0&size=2&sort=dateCreated,desc', httpOptions)
      .subscribe((data: any) => {

        this.data.proceduresAct = data.content;
        this.data.totalProceduresAct = data.page.totalElements;
        this.getProceduresFin();

      }, error => {
        this.processError(error).then(value => {
          this.getTokenForProcedures();
        });
      });
  }

  async getProceduresFin() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.data.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };
    this.http.get(constants.URL_BASE_PORTAL + 'secure/procedure/user/' + this.data.iduser + '?status=FIN&search=&page=0&size=2&sort=dateCreated,desc', httpOptions)
      .subscribe((data: any) => {
        this.data.proceduresFin = data.content;
        this.data.totalProceduresFin = data.page.totalElements;
        this.goToProcedures();

      }, error => {
        this.processError(error).then(value => {
          this.getTokenForProcedures();
        });
      });
  }

  // Obtengo la lista de alumnos de GE

  async getStudentsOfGE() {
    this.loading();
    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;

        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'X-Authorization': 'Bearer ' + this.data.token,
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };
        this.studentService.getStudents(httpOptions).subscribe((response: any) => {
          if (response) {
            this.studentListToSportMap = response
            this.load.dismiss();
            if (response.length > 0) {
              if (response.length === 1 && response[ 0 ].studentId == null) {
                this.changeColorOfSGE()
              } else {
                this.studentList = response;
              }
            } else {
              this.changeColorOfSGE()
            }
          }
        })

      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  }

  // Cambio el color de sge

  changeColorOfSGE() {
    this.geDisabled = true;
    let sgeDisabled
    sgeDisabled = document.getElementById('sge')
    sgeDisabled.classList.remove('map')
    sgeDisabled.classList.add('mapDisabled')
  }



  // Shifts
  async getTokenForShifts() {
    this.loading();
    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;
        this.getShifts();
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  }
  async getShifts() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.data.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    console.log('URL: ' + constants.URL_BASE_PORTAL + 'secure/appointments');
    console.log('TOKEN: ' + 'Bearer ' + this.data.token);

    //this.http.get(constants.URL_BASE_PORTAL + 'secure/judicialExpedient/docType/DNI/docNumber/' + this.data.dni, httpOptions)
    // this.http.get(constants.URL_BASE_PORTAL + 'secure/appointments/rm', httpOptions)
    //     .subscribe((data: any) => {

    //       console.log('RESPONSE GET SHIFTS ');
    //       console.log(JSON.stringify(data));

    //       if (data && data.length > 0) {
    //         this.goToShifts(data);
    //       } else {
    //        this.alert('No se encontraron turnos');
    //       }


    //     }, error => {
    //       this.processError(error).then(value => {
    //         this.getTokenForShifts();
    //       });
    //     });
    this.goToShifts();
  }

  // Proceedings
  async getTokenForProceedings() {
    this.loading();
    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;
        this.getProceedings();
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  }
  async getProceedings() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.data.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    console.log('URL: ' + constants.URL_BASE_PORTAL + 'secure/civilRegistration/certificates');
    console.log('TOKEN: ' + 'Bearer ' + this.data.token);

    this.http.get(constants.URL_BASE_PORTAL + 'secure/civilRegistration/certificates', httpOptions)
      .subscribe((data: any) => {

        console.log('RESPONSE GET PROCEEDINGS ');
        console.log(JSON.stringify(data));

        if (data && data.length > 0) {
          this.goToCivilRegistration(data);
        } else {
          this.alert('No se encontraron datos');
        }


      }, error => {
        this.processError(error).then(value => {
          this.getTokenForProceedings();
        });
      });
  }


  // navigate screens
  goToProcedures() {

    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        token: this.data.token,
        idUser: this.data.iduser,
      }
    };
    
    this.router.navigate([ 'proceduresHome' ], navigationExtras);

  }

  goToRm() {
    this.loadingController.dismiss();
    if (this.dataRm.consultations.length > 0 || this.dataRm.prescriptions.length > 0 || this.dataRm.studies.length > 0) {
      const navigationExtras: NavigationExtras = {
        state: {
          consultations: this.dataRm.consultations,
          prescriptions: this.dataRm.prescriptions,
          studies: this.dataRm.studies,
          token: this.dataRm.token
        }
      };
      this.router.navigate([ 'rm' ], navigationExtras);
    } else {
      this.alert('No se encontraron datos');
    }
  }

  goToLiquidations() {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        liquidations: this.data.liquidations,
        token: this.data.token
      }
    };
    this.router.navigate([ 'liquidations' ], navigationExtras);

  }


  goToShifts() {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        token: this.data.token
      }
    };
    this.router.navigate([ 'shifts' ], navigationExtras);

  }

  goToCivilRegistration(proceedings) {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        proceedings,
        token: this.data.token
      }
    };
    this.router.navigate([ 'proceedings' ], navigationExtras);

  }

  goToJudicialExpedients() {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        judicialExpedients: this.data.judicialExpedients,
        token: this.data.token
      }
    };
    this.router.navigate([ 'judicialExpedients' ], navigationExtras);

  }

  goToDriverLicense(driverLicense: any) {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        driverLicense,
        token: this.data.token
      }
    };
    this.router.navigate([ 'driverLicense' ], navigationExtras);

  }

  goToScreenError() {
    // this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        message: 'Ésta funcionalidad estará disponible en próximas versiones',
      }
    };
    this.router.navigate([ 'screenError' ], navigationExtras);
  }

  goToGE() {
    if (!this.geDisabled) {
      const navigationExtras: NavigationExtras = {
        state: {
          content: this.studentList,
        }
      };
      this.router.navigate([ 'students-list' ], navigationExtras);
    }
  }

  goToScreenErrorMessage(message: any) {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        message,
      }
    };
    this.router.navigate([ 'screenError' ], navigationExtras);
  }


  // error managers
  processError = function (error: any) {
    return new Promise<any>((resolve, reject) => {
      console.log('Error!!!!!');
      console.log(JSON.stringify(error));
      // this.loadingController.dismiss();
      if (error.status === 500) {
        if (error.error.exception === 'io.jsonwebtoken.ExpiredJwtException') {
          this.storage.get('psw').then((val: any) => {
            if (val) {
              // this.loading();
              this.refreshUtils.refreshToken(val).then((value: any) => {
                resolve(value);
              }).catch((errorRefresh: { status: number; }) => {
                // this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();
                } else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            } else {
              this.alert(constants.GENERIC_ERROR);
            }
          });

        } else {
          this.alert(constants.GENERIC_ERROR);
        }
      } else if (error.status == 401) {
        this.deleteDataAndExitToLogin();
      } else if (error.status == 409) {
        this.alert(error.error.message);
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  };

  processErrorRM = function (error: any) {
    return new Promise<any>((resolve, reject) => {
      console.log('Error!!!!!');
      console.log(JSON.stringify(error));
      if (error.status == 500) {
        if (error.error.exception === 'io.jsonwebtoken.ExpiredJwtException') {
          this.storage.get('token').then((val: any) => {
            if (val) {
              this.refreshUtils.refreshTokenRM(val).then((value: any) => {
                resolve(value);
              }).catch((errorRefresh: { status: number; }) => {
                this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.alert(constants.GENERIC_ERROR);
                } else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            } else {
              this.alert(constants.GENERIC_ERROR);
            }
          });

        } else {
          this.alert(constants.GENERIC_ERROR);
        }
      } else if (error.status == 401) {
        this.alert(constants.GENERIC_ERROR);
      } else if (error.status == 409) {
        this.alert(error.error.message);
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  };

  navigateChangePassword() {
    const navigationExtras: NavigationExtras = {
      state: {
        fromHome: true
      }
    };
    this.navController.navigateRoot('/change-password', navigationExtras);

  }

}

