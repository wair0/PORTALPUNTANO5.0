import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { LoadingController, AlertController,NavController,Platform, ToastController } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';
import {constants} from '../utils/constants';
import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root'})
export class RefreshUtils {

    constructor(private storage: Storage, private router: Router,
         private http: HttpClient,private loadingController: LoadingController
         ) {}

         refreshToken = function(val:any) {
          return new Promise<any>((resolve,reject)=>{
    const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };
  
      let postData = {
        "docType": "DNI",
        "docNumber": val.docNumber,
        "sex": val.sex,
        "password": val.password
      }
      console.log("LOGIN PP DATA!!!");
      console.log(JSON.stringify(postData));
  
  
      console.log(constants.URL_BASE_PORTAL+"token/mobile/login");

      this.http.post(constants.URL_BASE_PORTAL+"token/mobile/login", postData, httpOptions)
        .subscribe((data:any) => {
    
          console.log("RESPONSE LOGIN PP!!!");
  
          console.log(JSON.stringify(postData));
  
          console.log("TOKEN!!: "+data.authToken.token);
  
          this.storage.set('psw',postData);
  
          this.storage.set('token',data.authToken.token);
  
          this.storage.set('userId',data.user.userId);
  
          this.storage.set('liquidations',data.liquidations);
  
          this.storage.set('externalDocument',data.externalDocument);
  
          this.storage.set('judicialExpedient',data.judicialExpedient);

          resolve(data);
  
        }, error => {
          reject(error);
        });

});


}



refreshTokenRM = function(val:any) {
  return new Promise<any>((resolve,reject)=>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }),
      })
    };

    let postData = {
      "apiCode": constants.API_CODE,
      "externalToken": "Bearer "+val
    }
    this.http.post(constants.URL_RM+"token/external/login", postData, httpOptions)
      .subscribe((data:any) => {
        console.log(data);
        console.log("RESPONSE LOGIN RM!!: "+data[0].authToken);

        this.storage.set('tokenRM',data[0].authToken.token);

        resolve(data);

      }, error => {
        console.log("Error!!!!!");
        console.log(error);

       reject(error);

      }) ;

});


}


}