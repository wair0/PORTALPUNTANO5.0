export enum Procedures {
    individual = 62,
    legalEntity = 63,
    cityClaims = 64
}