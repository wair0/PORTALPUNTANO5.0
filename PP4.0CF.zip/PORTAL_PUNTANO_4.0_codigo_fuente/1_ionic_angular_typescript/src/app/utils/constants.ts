// LOCAL
// export const constants = {
//     URL_BASE_PORTAL: "http://localhost:9091/portalServer/",
//     //URL_BASE_DRIVER_LICENSE: "http://64.215.200.21:8080/portalServer/secure/driverLicense/",
//     URL_RM: "http://localhost:8080/saludServer/",
//     URL_RM_PREFIX: "http://localhost:9091/portalServer/secure/bus/rm/",
//     URL_RECIPE: "http://localhost:8081/recipeServer/",
//     URL_GE: "http://64.215.200.241:8080/educacionalcenterServer/",
//     API_CODE: "8f6324c1-ea19-409a-9b0d-f11ddf3d3e4c"


//     , GENERIC_ERROR: "Ocurrió un problema, intente nuevamente"
//     , FOLDER_DOWNLOAD: "Portal Puntano 4.0/"
//     , FILE_SIZE_0_ERROR: "Error al descargar el archivo, por favor contáctese con soporte técnico"
//     , SCANN_QR: true
//     , REGEX_PASSWORD: /(?!.* )(?=.*\d)(?=.*[A-Z]).{8,16}$/ // /(?=.*[0-9])(?=.*[A-Z]).{8,16}$/
// };

// Minis
// export const constants = {
//     URL_BASE_PORTAL: "http://64.215.200.235:8080/portalServer/",
//     //URL_BASE_DRIVER_LICENSE: "http://64.215.200.235:8080/portalServer/secure/driverLicense/",
//     URL_RM_PREFIX: "http://64.215.200.235:8080/portalServer/secure/bus/rm/",

//     URL_RM: "http://64.215.200.235:8080/saludServer/",
//     URL_RECIPE: "http://64.215.200.235:8080/recipeServer/",
//     URL_GE: "http://64.215.200.235:8080/educacionalcenterServer/",
//     API_CODE: "8f6324c1-ea19-409a-9b0d-f11ddf3d3e4c"


//     , GENERIC_ERROR: "Ocurrió un problema, intente nuevamente"
//     , FOLDER_DOWNLOAD: "Portal Puntano 4.0/"
//     , FILE_SIZE_0_ERROR: "Error al descargar el archivo, por favor contáctese con soporte técnico"
//     , SCANN_QR: false
//     , REGEX_PASSWORD: /(?!.* )(?=.*\d)(?=.*[A-Z]).{8,16}$/ // /(?=.*[0-9])(?=.*[A-Z]).{8,16}$/
// };


//DEVELOP
// export const constants = {
// URL_BASE_PORTAL: "http://64.215.200.245:8080/portalServer/",
// // URL_BASE_DRIVER_LICENSE: "http://64.215.200.245:8080/portalServer/secure/driverLicense/",
// URL_RM_PREFIX: "http://64.215.200.200:8080/portalServer/secure/bus/rm/",
// URL_RM: "http://64.215.200.200:8080/saludServer/",
// URL_RECIPE: "http://64.215.200.200:8080/recipeServer/",
// URL_GE: "http://64.215.200.237:8080/educacionalcenterServer/",
// API_CODE: "8f6324c1-ea19-409a-9b0d-f11ddf3d3e4c"
// ,GENERIC_ERROR : "Ocurrió un problema, intente nuevamente"
// ,FOLDER_DOWNLOAD: "Portal Puntano 4.0/"
// ,FILE_SIZE_0_ERROR: "Error al descargar el archivo, por favor contáctese con soporte técnico"
//     ,SCANN_QR: true
//     ,REGEX_PASSWORD: /(?!.* )(?=.*\d)(?=.*[A-Z]).{8,16}$/ // /(?=.*[0-9])(?=.*[A-Z]).{8,16}$/
// };

// TESTING
// export const constants = {
//     URL_BASE_PORTAL: "http://64.215.200.21:8080/portalServer/",
//     //URL_BASE_DRIVER_LICENSE: "http://64.215.200.21:8080/portalServer/secure/driverLicense/",
//     URL_RM_PREFIX: "http://64.215.200.21:8080/portalServer/secure/bus/rm/",
//     URL_RM: "http://testrm30.sanluis.gob.ar:8080/saludServer/",
//     URL_RECIPE: "http://testrm30.sanluis.gob.ar:8080/recipeServer/",
//     URL_GE: "http://201.222.57.26:8080/educacionalcenterServer/",
//     API_CODE: "8f6324c1-ea19-409a-9b0d-f11ddf3d3e4c"
//     , GENERIC_ERROR: "Ocurrió un problema, intente nuevamente"
//     , FOLDER_DOWNLOAD: "Portal Puntano 4.0/"
//     , FILE_SIZE_0_ERROR: "Error al descargar el archivo, por favor contáctese con soporte técnico"
//     , SCANN_QR: true
//     , REGEX_PASSWORD: /(?!.* )(?=.*\d)(?=.*[A-Z]).{8,16}$/ // /(?=.*[0-9])(?=.*[A-Z]).{8,16}$/
// };

// PRODUCCIÓN
export const constants = {
    URL_BASE_PORTAL: "http://puntano.gob.ar:8080/portalServer/",
    URL_RM_PREFIX: "http://puntano.gob.ar:8080/portalServer/secure/bus/rm/",
    //URL_BASE_DRIVER_LICENSE: "http://puntano.gob.ar:8080/portalServer/secure/driverLicense/",
    URL_RM: "http://www.registrosmedicos.sanluis.gob.ar:8080/saludServer/",
    URL_RECIPE: "https://recetadigital.sanluis.gob.ar:8080/recipeServer/",
    URL_GE: "http://www.Escuelas3punto0.sanluis.gob.ar:8080/educacionalcenterServer/",
    API_CODE: "8f6324c1-ea19-409a-9b0d-f11ddf3d3e4c",
    GENERIC_ERROR: "Ocurrió un problema, intente nuevamente"
    , FOLDER_DOWNLOAD: "Portal Puntano 4.0/"
    , FILE_SIZE_0_ERROR: "Error al descargar el archivo, por favor contáctese con soporte técnico"
    , SCANN_QR: true
    , REGEX_PASSWORD: /(?!.* )(?=.*\d)(?=.*[A-Z]).{8,16}$/ // /(?=.*[0-9])(?=.*[A-Z]).{8,16}$/
};
