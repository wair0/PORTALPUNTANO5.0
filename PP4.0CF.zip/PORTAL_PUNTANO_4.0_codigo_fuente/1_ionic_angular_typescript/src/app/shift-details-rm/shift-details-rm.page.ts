import { Component, OnInit } from '@angular/core';
import { AlertController, LoadingController, NavController, Platform, ToastController } from '@ionic/angular';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { ActivatedRoute, Router } from '@angular/router';
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { RefreshUtils } from '../utils/refreshUtils';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { constants } from '../utils/constants';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2'
import { ShiftService } from '../services/shift.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { LoadingService } from '../services/loading.service';

@Component({
  selector: 'app-shift-details-rm',
  templateUrl: './shift-details-rm.page.html',
  styleUrls: [ './shift-details-rm.page.scss' ],
  animations: [
    trigger('visibilityChanged', [
      state('shown', style({ opacity: 1 })),
      state('hidden', style({ opacity: 0 })),
      transition('* => *', animate('500ms'))
    ])
  ]
})
export class ShiftDetailsRMPage implements OnInit {

  public content: any = null;
  public token: String;
  public storageDirectory: any;
  dependents = [];
  httpOptions: any = null;
  formAppointment: FormGroup;
  years = [];
  historic = [];
  emptyShift = false;

  constructor(private alertController: AlertController,
    private loadingController: LoadingController,
    private http: HttpClient,
    private storage: Storage,
    private route: ActivatedRoute,
    private router: Router,
    private shiftService: ShiftService,
    private fb: FormBuilder,
    public loading: LoadingService,
    public toastController: ToastController
    , private screenOrientation: ScreenOrientation
    , private navController: NavController
    , private statusBar: StatusBar
    , private dialog: MatDialog
    , private platform: Platform) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);

  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.token = this.router.getCurrentNavigation().extras.state.token;
        this.content = this.router.getCurrentNavigation().extras.state.content;
      }
    });

    if (this.content == null) {
      this.loading.present();
      this.getAppointments();
    }
    this.getDependents();
    this.getYear();
    this.createForm();
  }

  getAppointments() {
    this.getToken().then(value => {
      this.shiftService.getAppointmentsRM(this.httpOptions, null).subscribe(response => {

        //this.loadingController.dismiss(); 
        this.content = response[ 0 ];
        this.loading.dismiss();

      }, error => {
        this.loading.dismiss();

        //this.loadingController.dismiss(); 
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });
    })
  }

  getAppointmentsParam(param: any) {
    this.getToken().then(value => {
      this.shiftService.getAppointmentsRM(this.httpOptions, param).subscribe((response: any) => {
        this.historic = response;
        if (this.historic[ 0 ].appointmentItemDtoList.length > 0) {
          this.emptyShift = false;
        }
        else {
          this.emptyShift = true;
        }
        this.loading.dismiss();
      }, error => {
        this.loading.dismiss();
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });
    })
  }

  getDependents() {
    this.loading.present();
    this.dependents.push({ docNumber: null, fullName: 'Mis Turnos', sex: null })
    this.getToken().then(value => {

      this.shiftService.getDependents(this.httpOptions).subscribe((response: any) => {
        if (response && response.wards.length > 0) {
          response.wards.forEach(element => {
            this.dependents.push(element)
          });
        }
        this.loading.dismiss();
      }, error => {
        this.loading.dismiss();
        this.dependents = [];
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }

      });

    })
    ////this.loadingController.dismiss();
  }


  createForm() {
    this.formAppointment = this.fb.group({
      personsCtrl: [ '' ],
      yearCtrl: [ '' ],
    });
  }

  getYear() {
    let today = new Date().getFullYear();

    for (let i = today; i >= 2000; i--) {
      this.years.push(i);
    }

  }

  async deleteDataAndExitToLogin() {

    this.storage.clear().then(() => {
      this.navController.navigateRoot("/login");
    });

  }

  async getToken() {
    await this.storage.get('token').then(value => {
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
    })
  }

  async alert(messageText: string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }

  // async loading(messageText:string){
  //   const loading = await this.loadingController.create({
  //     message: messageText,
  //   });
  //   await loading.present();
  // }


  ionViewWillEnter() {
    this.statusBar.backgroundColorByHexString('#20B572');
  }

  goNewShift() {
    //this.navController.navigateRoot("/new-appointment-rm", navigationExtras);
    this.router.navigate([ 'new-shifts' ]);
  }

  cancelShift(shift: any) {
    Swal.fire({
      title: 'Aviso',
      text: '¿Desea cancelar el Turno reservado?',
      imageUrl: "../../assets/icon/GreenWarning.png",
      imageWidth: 100,
      imageHeight: 100,
      showCancelButton: true,
      confirmButtonColor: '#20B572',
      confirmButtonText: 'Aceptar',
      cancelButtonText: "Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.shiftService.updateAppointmentCancel(this.httpOptions, shift.items[ 0 ].value).subscribe((response: any) => {
          if (this.historic.length < 1) {
            this.getAppointments();
          } else {
            let param = '';
            this.formAppointment.get("yearCtrl").value ? param = param + '&year=' + this.formAppointment.get("yearCtrl").value : '';
            this.formAppointment.get("personsCtrl").value.sex ? param = param + '&wardSex=' + this.formAppointment.get("personsCtrl").value.sex : '';
            this.formAppointment.get("personsCtrl").value.docNumber ? param = param + '&wardDocNumber=' + this.formAppointment.get("personsCtrl").value.docNumber : '';
            if (param.length > 0) {
              param = param.replace('&', '?');
            }
            this.getAppointmentsParam(param);
          }
          this.presentToast();
        }, error => {
          //this.loadingController.dismiss(); 
          if (error.status === 409) {
            this.alert(error.error.message);
          }
          else {
            this.alert(constants.GENERIC_ERROR);
          }
        });
      }
    });
  }

  search() {
    this.loading.present();
    let param = '';
    this.formAppointment.get("yearCtrl").value ? param = param + '&year=' + this.formAppointment.get("yearCtrl").value : '';
    this.formAppointment.get("personsCtrl").value.sex ? param = param + '&wardSex=' + this.formAppointment.get("personsCtrl").value.sex : '';
    this.formAppointment.get("personsCtrl").value.docNumber ? param = param + '&wardDocNumber=' + this.formAppointment.get("personsCtrl").value.docNumber : '';
    if (param.length > 0) {
      param = param.replace('&', '?');
    }
    this.getAppointmentsParam(param);
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

  async presentToast() {
    const toast = await this.toastController.create({
      message: 'El Turno se Cancelo exitosamente',
      duration: 5000
    });
    toast.present();
  }

}
