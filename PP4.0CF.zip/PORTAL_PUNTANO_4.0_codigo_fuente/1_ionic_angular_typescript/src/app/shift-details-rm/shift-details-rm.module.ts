import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ShiftDetailsRMPageRoutingModule } from './shift-details-rm-routing.module';

import { ShiftDetailsRMPage } from './shift-details-rm.page';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RefreshUtils } from '../utils/refreshUtils';
import {MatDialogModule} from '@angular/material/dialog';
import { ShiftService } from '../services/shift.service';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HttpClientModule,
    ShiftDetailsRMPageRoutingModule,
    ReactiveFormsModule,
    MatDialogModule
  ],
  providers: [HttpClient,
    ShiftService,
    RefreshUtils],
  declarations: [ShiftDetailsRMPage]
})
export class ShiftDetailsRMPageModule {}
