import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ShiftDetailsRMPage } from './shift-details-rm.page';

const routes: Routes = [
  {
    path: '',
    component: ShiftDetailsRMPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ShiftDetailsRMPageRoutingModule {}
