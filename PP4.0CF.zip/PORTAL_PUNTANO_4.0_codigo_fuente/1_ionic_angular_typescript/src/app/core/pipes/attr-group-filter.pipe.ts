import { Pipe, PipeTransform } from '@angular/core';
import { ProcedureTypeAttr } from "../models/ProcedureTypeAttr";

@Pipe({
  name: 'attrGroupFilter'
})
export class AttrGroupFilterPipe implements PipeTransform {

  transform(value: ProcedureTypeAttr[], ...args: any[]): ProcedureTypeAttr[] {
    return value.filter((attr) => attr.idgroup === args[ 0 ]);
  }

}
