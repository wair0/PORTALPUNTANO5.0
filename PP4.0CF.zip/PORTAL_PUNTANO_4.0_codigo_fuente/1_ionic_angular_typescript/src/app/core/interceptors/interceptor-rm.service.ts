import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { from, Observable, throwError } from 'rxjs';
import { Storage } from '@ionic/storage';
import { catchError, finalize, map, switchMap } from 'rxjs/operators';
import { AlertController, LoadingController } from '@ionic/angular';
import { LoadingService } from 'src/app/services/loading.service';

@Injectable()
export class InterceptorRm implements HttpInterceptor {
  
  public loader

  constructor(
    private storage: Storage,
    private loadingService: LoadingService
  ) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.loadingService.present()

    return from(this.storage.get("token"))
      .pipe(
        switchMap(token => {
          if (token) {
            request = request.clone({ headers: request.headers.set('X-Authorization', 'Bearer ' + token) });
            request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
            request = request.clone({ headers: request.headers.set('Accept', 'application/json') });
          }
          return next.handle(request).pipe(
            map((event: HttpEvent<any>) => {
              if (event instanceof HttpResponse) {
                // do nothing for now
              }
              return event;
            }),
            catchError((error: HttpErrorResponse) => {
              const status = error.status;
              const reason = error && error.error.reason ? error.error.reason : '';
              return throwError(error);
            }),
            finalize( () => {
              this.loadingService.dismiss()
            })
          );
        })
      );
  }

}



