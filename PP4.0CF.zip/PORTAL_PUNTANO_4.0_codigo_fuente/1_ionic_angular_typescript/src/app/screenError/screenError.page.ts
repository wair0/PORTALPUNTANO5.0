import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { log } from 'util';
import { Alert } from 'selenium-webdriver';
import { Storage } from '@ionic/storage';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx'; 
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';

import {constants} from '../utils/constants';

import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';

import { StatusBar } from '@ionic-native/status-bar/ngx';


@Component({
  selector: 'app-screenError',
  templateUrl: 'screenError.page.html',
  styleUrls: ['screenError.page.scss'],
})
export class ScreenErrorPage implements OnInit {

  public message: any;
  

  constructor(private alertController: AlertController,
    private loadingController: LoadingController,
    private http: HttpClient,
    private storage: Storage,
    private route: ActivatedRoute, 
    private router: Router,
    private transfer: FileTransfer,
    private file: File,
    private fileOpener: FileOpener
    ,private screenOrientation: ScreenOrientation
    ,private statusBar: StatusBar
    ,private navController:NavController) {

      this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
      
      this.route.queryParams.subscribe(params => {
        if (this.router.getCurrentNavigation().extras.state) {
          this.message = this.router.getCurrentNavigation().extras.state.message;
        }
      });


     }

     ionViewWillEnter(){
      this.statusBar.backgroundColorByHexString('#932a7e');
    }

    goToHome(){
    this.navController.navigateRoot("/home");
    }

    ngOnInit(){
    }


}