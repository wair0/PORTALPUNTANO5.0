import { LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { IonicStorageModule } from '@ionic/storage';
import { DatePipe } from '@angular/common';

import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';

import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MessageService } from './services/message.service';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { HttpClientModule } from '@angular/common/http';
import { Device } from '@ionic-native/device/ngx';
import { registerLocaleData } from '@angular/common';
import  localEsAr  from '@angular/common/locales/es-AR';
import { ConsultationService } from './services/consultation.service';

registerLocaleData(localEsAr,'es-Ar');

@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule, HttpClientModule , IonicModule.forRoot(), AppRoutingModule,BrowserAnimationsModule , IonicStorageModule.forRoot({
    name: '_portalDb',
    driverOrder: ['indexeddb', 'sqlite', 'websql']
  }), BrowserAnimationsModule],
  providers: [
    StatusBar,
    SplashScreen,
    BarcodeScanner,
    DatePipe,
    ScreenOrientation,
    LocalNotifications,
    Device,
    MessageService,
    ConsultationService,
    { provide: LOCALE_ID, useValue: 'es-Ar'},
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
