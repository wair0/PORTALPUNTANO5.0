import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { log } from 'util';
import { Alert } from 'selenium-webdriver';
import { Storage } from '@ionic/storage';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx'; 
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';

import {constants} from '../utils/constants';

import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { RefreshUtils } from '../utils/refreshUtils';


@Component({
  selector: 'app-judicialExpedientsAll',
  templateUrl: 'judicialExpedientsAll.page.html',
  styleUrls: ['judicialExpedientsAll.page.scss'],
})
export class JudicialExpedientsAllPage implements OnInit {

  public judicialExpedients:any;
  public token:String;
  public fileTransfer: FileTransferObject;
  public storageDirectory:any;
  

  constructor(private alertController: AlertController,
    private loadingController: LoadingController,
    private http: HttpClient,
    private storage: Storage,
    private route: ActivatedRoute, 
    private router: Router,
    private transfer: FileTransfer,
    private file: File,
    private fileOpener: FileOpener
    ,private screenOrientation: ScreenOrientation
    ,private statusBar: StatusBar
    ,private refreshUtils:RefreshUtils
    ,private navController:NavController) {

      this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
      this.route.queryParams.subscribe(params => {
        if (this.router.getCurrentNavigation().extras.state) {
          this.judicialExpedients = this.router.getCurrentNavigation().extras.state.content;
          this.token = this.router.getCurrentNavigation().extras.state.token;
        }
      });


     }
     ionViewWillEnter(){
      this.statusBar.backgroundColorByHexString('#003F79');
    }

    ngOnInit(){
    }

    async deleteDataAndExitToLogin(){

      this.storage.clear().then(()=>{
        this.navController.navigateRoot("/login");
      });
    }
    
    
    async alert(messageText:string) {
      this.loadingController.dismiss();
      const alert = await this.alertController.create({
        header: 'Portal puntano',
        message: messageText,
        buttons: [
          {
            text: 'OK',
            role: 'cancel',
            cssClass: 'primary',
            handler: () => {
              console.log('OK pressed!!');
            }
          }
        ]
      });
    
      await alert.present();
    }
    
    
    async loading(){
      this.loadingController.dismiss();
      const loading = await this.loadingController.create({
        message: 'Cargando',
      });
      await loading.present();
    }
    
    async loadingWithMessage(messageText:string){
      const loading = await this.loadingController.create({
        message: messageText,
      });
      await loading.present();
    }

    async getjudicialExpedientDetail(judicialExpedient:any) {
     this.loading();
     this.storage.get('token').then((val) => {
      if (val) {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + this.token,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };
  
      console.log("URL: " + constants.URL_BASE_PORTAL + "secure/actions/expedient/"+judicialExpedient.id);//"secure/liquidations/"+this.data.iduser);
      console.log("TOKEN: " + 'Bearer ' + this.token);
  
      this.http.get(constants.URL_BASE_PORTAL + "secure/actions/expedient/"+judicialExpedient.id, httpOptions)
        .subscribe((data: any) => {
  
  
          console.log("RESPONSE GET JUDICIAL EXPEDIENT DETAIL!: ");
  
          //HARDCODING!!!!!!!!
  
          // data = {"id":null,"name":"1077275","actions":[{"nroAction":"16857016","dateSign":"2019-12-23 12:32:49","extract":"CONSTANCIA DE ENTREGA DE EDICTOS"},{"nroAction":"16391024","dateSign":"2019-11-04 12:57:30","extract":"ACUMULESE OFR"},{"nroAction":"16100175","dateSign":"2019-10-04 11:14:15","extract":"VERONICA VIVIAN CUELLO LAPETINA"},{"nroAction":"16068414","dateSign":"2019-09-30 11:56:22","extract":"COMPROBANTE CEDULA RUSSO ADELA AURORA"},{"nroAction":"16068413","dateSign":"2019-09-30 11:56:22","extract":"COMPROBANTE CEDULA RUSSO ADELA AURORA"},{"nroAction":"16031395","dateSign":"2019-09-30 11:56:22","extract":"VERONICA CUELLO LAPETINA"},{"nroAction":"16022798","dateSign":"2019-09-30 11:56:22","extract":"CEDULA RUSSO ADELA AURORA"},{"nroAction":"16022860","dateSign":"2019-09-30 11:56:22","extract":"CEDULA POSTAL CUELLO LAPETINA VERONICA VIVIAN"},{"nroAction":"16022856","dateSign":"2019-09-30 11:56:22","extract":"CEDULA POSTAL CUELLO SUAREZ PABLO MARTIN"},{"nroAction":"16022921","dateSign":"2019-09-30 11:56:22","extract":"CEDULA POSTAL CUELLO SUAREZ ALEJANDRO HERNAN"},{"nroAction":"16044865","dateSign":"2019-09-30 08:25:14","extract":"ALEJANDRO HERNAN CUELLO SUAREZ"},{"nroAction":"16022740","dateSign":"2019-09-26 13:06:27","extract":"RECTIFICA"},{"nroAction":"15982402","dateSign":"2019-09-23 12:55:03","extract":"EDICTO"},{"nroAction":"16004378","dateSign":"2019-09-23 10:39:04","extract":"ADVIERTE ERROR - NUEVA CEDULA"},{"nroAction":"15943796","dateSign":"2019-09-20 10:38:11","extract":"CEDULA POSTAL CUELLO LAPETINA VERONICA VIVIAN"},{"nroAction":"15943794","dateSign":"2019-09-20 10:38:11","extract":"CEDULA POSTAL CUELLO SUAREZ PABLO MARTIN"},{"nroAction":"15987299","dateSign":"2019-09-20 10:38:11","extract":"COMPROBANTE CEDULA RUSSO ADELA AURORA"},{"nroAction":"15943755","dateSign":"2019-09-20 10:38:11","extract":"CEDULA RUSSO ADELA AURORA"},{"nroAction":"15943795","dateSign":"2019-09-20 10:38:11","extract":"CEDULA POSTAL CUELLO SUAREZ ALEJANDRO HERNAN"},{"nroAction":"15943325","dateSign":"2019-09-19 09:41:56","extract":"ABRE PROCESO SUCESORIO Y ORDENA MEDIDAS"},{"nroAction":"15812995","dateSign":"2019-09-04 12:51:58","extract":"CONTESTA VISTA"},{"nroAction":"15740804","dateSign":"2019-08-29 13:41:54","extract":"CORRASE VISTA FISCAL"},{"nroAction":"15602252","dateSign":"2019-08-15 12:41:45","extract":"OFICIO RJU VISTA FISCAL"},{"nroAction":"15553684","dateSign":"2019-08-07 11:05:12","extract":"ADJUNTA ESCRITO FIRMADO PROMOVIENTE"},{"nroAction":"15410980","dateSign":"2019-07-30 11:46:24","extract":"INFORME COLEGIO DE ESCRIBANOS "},{"nroAction":"15410991","dateSign":"2019-07-30 11:46:24","extract":"DECRETO-AGREGUESE "},{"nroAction":"15337404","dateSign":"2019-07-04 12:54:59","extract":"POR ACOMPA?ADO APORTE- POR CONSTITUIDO DOMICILIO PROCESAL"},{"nroAction":"15202957","dateSign":"2019-06-19 07:55:44","extract":"Cumplimenta-Aclara"},{"nroAction":"15170693","dateSign":"2019-06-14 11:47:26","extract":"ACLARE- POR PRESENTADOS HEREDEROS- CONSTITUYA DOMICILIO "},{"nroAction":"15035013","dateSign":"2019-05-31 09:54:11","extract":"ADJUNTA OFICIO CONTROL"},{"nroAction":"15034894","dateSign":"2019-05-31 07:34:19","extract":"Se notifican personalmente. Rectifican domicilio"},{"nroAction":"14984753","dateSign":"2019-05-29 11:11:32","extract":"CONSTANCIA DE COTEJO SE CONDICE"},{"nroAction":"14985147","dateSign":"2019-05-29 10:42:32","extract":"LIBRAR OFICIO COLEGIO DE ESCRIBANOS"},{"nroAction":"14951184","dateSign":"2019-05-23 10:49:44","extract":"ADJUNTA ESCRITO SUSCRIPTO PROMOVIENTE"},{"nroAction":"14919505","dateSign":"2019-05-22 07:25:43","extract":"CONSTANCIA DE RECEPCION DE DOCUMENTAL"},{"nroAction":"14882338","dateSign":"2019-05-20 12:18:41","extract":"DECRETO SIMPLE "},{"nroAction":"14840047","dateSign":"2019-05-14 09:17:06","extract":"DEMANDA DE IOL"}]};
  
          console.log(JSON.stringify(data));
  
          if (data != null) {
  
            data.name=judicialExpedient.name;
  
            // this.data.judicialExpedients = data;
            console.log("JUDICIAL EXPEDIENT DETAIL!!!!")
            console.log(JSON.stringify(data));
             this.goToExpedientDetail(data);
  
          } else {
            this.alert(constants.GENERIC_ERROR);
          }
  
          this.loadingController.dismiss();
  
        }, error => {
          this.processError(error).then(value => {
            this.getjudicialExpedientDetail(judicialExpedient);
          });
        });
      }else {
        this.alert("Ocurrió un problema, intente nuevamente");
      }});
    }

    goToExpedientDetail(judicialExpedient:any){

      let navigationExtras: NavigationExtras = {
        state: {
          content: judicialExpedient,
          token: this.token
        }
      };
      this.router.navigate(['judicialExpedientDetail'], navigationExtras)

    }


    processError = function(error:any){
      return new Promise<any>((resolve,reject)=>{
      console.log("Error!!!!!");
      console.log(JSON.stringify(error));
      this.loadingController.dismiss();
       if(error.status == 500){
        if(error.error.exception==="io.jsonwebtoken.ExpiredJwtException"){
          this.storage.get('psw').then((val: any) => {
            if(val){
              this.loading();
               this.refreshUtils.refreshToken(val).then((value: any) => {
                 this.loadingController.dismiss();
                resolve(value);
              }).catch((errorRefresh: { status: number; })=>{
                this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();  
                }else {
                this.alert(constants.GENERIC_ERROR);
                }
              });
            }
            else{
              this.alert(constants.GENERIC_ERROR);
            }
          });
         
        }else{
          this.alert(constants.GENERIC_ERROR);
        }
      }else if (error.status == 401) {
        this.deleteDataAndExitToLogin();  
      }else if(error.status == 409){
        this.alert(error.error.message);
      }else{
        this.alert(constants.GENERIC_ERROR);
      }
    });
  
    }

    goToHome(){
      this.navController.navigateRoot("/home");
      }

}