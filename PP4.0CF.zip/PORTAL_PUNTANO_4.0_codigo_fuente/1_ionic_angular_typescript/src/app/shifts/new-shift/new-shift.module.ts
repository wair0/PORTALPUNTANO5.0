import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NewShiftsRoutingModule } from './new-shifts-routing.module';
import { FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { RefreshUtils } from 'src/app/utils/refreshUtils';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { NewShiftComponent } from './new-shift.component';
import { IonicModule } from '@ionic/angular';
import { ShiftService } from 'src/app/services/shift.service';
import {MatExpansionModule} from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatMomentDateModule } from '@angular/material-moment-adapter';





@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HttpClientModule,
    NewShiftsRoutingModule,
    ReactiveFormsModule ,
    MatExpansionModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatMomentDateModule,
  ],
  providers: [HttpClient,
  ShiftService,
  MatDatepickerModule],
  declarations: [NewShiftComponent]
})
export class NewShiftModule { }
