import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewShiftComponent } from './new-shift.component';


const routes: Routes = [
  {
    path: '',
    component: NewShiftComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NewShiftsRoutingModule {}
