import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { AlertController, NavController } from '@ionic/angular';
import { ShiftService } from 'src/app/services/shift.service';
import { constants } from 'src/app/utils/constants';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavigationExtras, Router } from '@angular/router';
import * as moment from 'moment';
import { LoadingService } from 'src/app/services/loading.service';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { LocalStorageService } from "src/app/services/local-storage.service";
import { UserDto } from "src/app/core/models/UserDto";
import { HealthCenterDto } from "src/app/core/models/HealthCenterDto";
import { BusProfessionalDto } from "src/app/core/models/BusProfessionalDto";

export const FORMAT = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


@Component({
  selector: 'app-new-shift',
  templateUrl: './new-shift.component.html',
  styleUrls: [ './new-shift.component.scss' ],
  providers: [
    { provide: MAT_DATE_FORMATS, useValue: FORMAT },
  ],
})
export class NewShiftComponent implements OnInit {

  infiniteScroll = false;

  formPersonal: FormGroup;
  formPerHasDep: FormGroup;

  model: any;
  currentForm: string = 'Personal';
  shiftDependentPerson: boolean = true;
  shiftPersonal: boolean = true;
  isSearching: boolean = false;

  specialtyList: any = [];
  specialtyperHasDepList: any = [];
  specialties: any;
  specialtiesPerHasDep: any;

  specialtySelected: any = null;
  seeListSpecialty: boolean = false;

  specialtyPerHasDepSelected: any = null;
  seeListPerHasDepSpecialty: boolean = false;

  professionalList: BusProfessionalDto[] = [];
  professionals: any;
  professionalSelected: any;
  seeListProfessional: boolean = false;

  servicesPersonalList: any = [];
  servicePersonalSelected: any = null;
  //seeListServices:boolean =  false;

  servicesPerHasDepList: any = [];
  seePerHasDepListServices: any = null;

  dependents: any = [];

  httpOptions: any = null;
  param: String = '';

  panelOpenState = true;

  lastDay: any;

  classPersonal = "green";
  classPersHasDep = "white";

  noShiftAvalable: boolean = false;
  noShiftAvalableHasPer: boolean = false;
  formPersonalValid: boolean = false;
  formPerHasDepValid: boolean = false;

  today = new Date();

  seeDependents: boolean = false;

  cmSpecialty: boolean = true;
  cmSpecialtyPerHasDep: boolean = true;
  userInfo: UserDto;
  healthCenters: HealthCenterDto[] = [];
  healthCenterSelected: HealthCenterDto

  constructor(
    private storage: Storage,
    private shiftService: ShiftService,
    private alertController: AlertController,
    private fb: FormBuilder,
    private navController: NavController,
    public loading: LoadingService,
    private router: Router,
    private localStorageService: LocalStorageService
  ) {
  }

  ngOnInit() {
    this.getUserInfo();
    this.getDependents();
    this.createForma();
  }

  getUserInfo() {
    this.localStorageService.getUserData().then((response: UserDto) => [
      this.userInfo = response,
      this.getHealthCentersByPersonData()

    ])
  }

  getHealthCentersByPersonData() {
    let user = this.userInfo;

    this.loading.present();
    this.getToken().then(value => {
      this.shiftService.getHealthCenterByPersonData(user, this.httpOptions).subscribe((response: any) => {
        this.healthCenters = response;
        this.loading.dismiss();
      })

    })
  }


  createForma() {
    this.formPersonal = this.fb.group({
      healthCenterCtrl: [ '', Validators.required ],
      specialtyCtrl: [ '', Validators.required ],
      professionalCtrl: [ '' ],
      fromDateCtrl: [ '' ],
    });
    this.formPerHasDep = this.fb.group({
      healthCenterCtrl: [ '', Validators.required ],
      personsCtrl: [ '', Validators.required ],
      specialtyCtrl: [ '', Validators.required ],
      professionalCtrl: [ '' ],
      fromDateCtrl: [ '' ],
    });
  }

  chargeForm(input: string) {
    this.currentForm = input;
    if (input === 'Personal') {
      this.classPersonal = 'green';
      this.classPersHasDep = 'white';
    }
    if (input === 'PersonaACargo') {
      this.classPersonal = 'white';
      this.classPersHasDep = 'green';
    }
  }


  selectSpecialtPerHasDep(item: any) {
    this.specialtyPerHasDepSelected = item;
    this.seeListPerHasDepSpecialty = false;
  }

  searchSpecialty() {
    this.specialtyList = [];
    if (this.formPersonal.get('specialtyCtrl').value.length > 0) {
      this.specialties.forEach(element => {
        if (element.name.toUpperCase().search(this.formPersonal.get('specialtyCtrl').value.toUpperCase()) > -1) {
          this.specialtyList.push(element);
        }
      });
      this.seeListSpecialty = true;
      this.formPersonalValid = false;
    }
  }

  searchSpecialtyPerHasDep() {
    this.specialtyperHasDepList = [];
    if (this.formPerHasDep.get('specialtyCtrl').value.length > 0) {
      this.specialtiesPerHasDep.forEach(element => {
        if (element.name.toUpperCase().search(this.formPerHasDep.get('specialtyCtrl').value.toUpperCase()) > -1) {
          this.specialtyperHasDepList.push(element);
        }
      });
      this.seeListPerHasDepSpecialty = true;
      this.formPerHasDepValid = false;
    }
  }

  searchPersonal() {
    this.specialtySelected = this.formPersonal.get('specialtyCtrl').value
    this.healthCenterSelected = this.formPersonal.get('healthCenterCtrl').value
    let professionalId = this.formPersonal.get("professionalCtrl").value.id

    if (this.formPersonal.valid) {
      if (this.specialtySelected || this.formPersonal.get("professionalCtrl").value) {
        let param = '';
        this.specialtySelected != null ? param = param + '&specialtyCode=' + this.specialtySelected.code : '';
        this.healthCenterSelected != null ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
        professionalId && professionalId != '' || professionalId != null ?
          param = param + '&professionalId=' + professionalId : '';
        this.formPersonal.get("fromDateCtrl").value ? param = param + '&dateFrom=' + moment(this.formPersonal.get("fromDateCtrl").value).format('YYYY-MM-DD') : '';
        this.infiniteScroll = false;
        this.noShiftAvalable = false;
        this.formPersonalValid = true;

        if (param.length > 0) {
          param = param.replace('&', '?');
        }
        this.servicesPersonalList = [];

        this.loading.present();
        this.shiftService.getShifts(this.httpOptions, param).subscribe((response: any) => {
          this.servicesPersonalList = response;

          if (this.servicesPersonalList.serviceDateGroups.length < 1) {
            this.servicesPersonalList.dateFrom = response.stringDateFrom;
            this.servicesPersonalList.dateTo = response.stringDateTo;
            this.servicesPersonalList.stringDateFrom = response.stringDateFrom;
            this.servicesPersonalList.stringDateTo = response.stringDateTo;
            //this.alert("No exiten turnos disponibles, modifique los filtros para obtenes mas resultados");  
            this.noShiftAvalable = true;
          } else {
            this.lastDay = response.dateTo;
            param = '';
            this.specialtySelected != null ? param = param + '&specialtyCode=' + this.specialtySelected.code : '';
            this.formPersonal.get("professionalCtrl").value != '' ? param = param + '&professionalName=' + this.formPersonal.get("professionalCtrl").value : '';

            //En Safari el replace remplaza el primer x caracter que encuentre
            let aux = this.lastDay.replace('-', '/');
            aux = aux.replace('-', '/');
            let fechaLastDay = new Date(aux)

            fechaLastDay.setDate(fechaLastDay.getDate() + 1);
            this.lastDay ? param = param + '&dateFrom=' + moment(fechaLastDay).format('YYYY-MM-DD') : '';

            if (param.length > 0) {
              param = param.replace('&', '?');
            }

            if (!this.validCount(this.servicesPersonalList.serviceDateGroups)) {
              this.loading.present();
              this.shiftService.getShifts(this.httpOptions, param).subscribe((response: any) => {
                this.loading.dismiss();
                this.lastDay = response.dateTo;

                if (response) {
                  if (response.serviceDateGroups.length > 0) {
                    response.serviceDateGroups.forEach(element => {
                      this.servicesPersonalList.serviceDateGroups.push(element);
                    });
                  } else {
                    this.servicesPersonalList.dateFrom = response.stringDateFrom;
                    this.servicesPersonalList.dateTo = response.stringDateTo;
                    this.servicesPersonalList.stringDateFrom = response.stringDateFrom;
                    this.servicesPersonalList.stringDateTo = response.stringDateTo;
                    //this.alert("No se encontraron Turnos disponibles desde : "+response.dateFrom+ " Hasta "+response.dateTo ); 
                    this.noShiftAvalable = false;
                    this.infiniteScroll = true;
                  }
                }

              }, error => {
                this.loading.dismiss();
                if (error.status === 409) {
                  this.alert(error.error.message);
                }
                else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });

            }
          }


          this.loading.dismiss();
        }, error => {
          this.loading.dismiss();
          if (error.status === 409) {
            this.alert(error.error.message);
          }
          else {
            this.alert(constants.GENERIC_ERROR);
          }
        });

        this.panelOpenState = false;
        //this.getService(param)
      } else {
        this.alert("Debe filtrar por Especialidad y/o Profesional");
      }
    } else {
      this.alert("El campo Fecha es Obligatorio");
    }
  }

  searchPerHasDep() {
    this.specialtyPerHasDepSelected = this.formPerHasDep.get('specialtyCtrl').value
    this.healthCenterSelected = this.formPerHasDep.get('healthCenterCtrl').value
    let professionalId = this.formPerHasDep.get("professionalCtrl").value.id

    if (this.formPerHasDep.valid) {
      if (this.specialtyPerHasDepSelected || this.formPerHasDep.get("professionalCtrl").value) {
        let param = '';
        this.specialtyPerHasDepSelected != null ? param = param + '&specialtyCode=' + this.specialtyPerHasDepSelected.code : '';
        this.healthCenterSelected != null ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
        professionalId && professionalId != '' ? param = param + '&professionalId=' + professionalId : '';
        this.formPerHasDep.get("fromDateCtrl").value ? param = param + '&dateFrom=' + moment(this.formPerHasDep.get("fromDateCtrl").value).format('YYYY-MM-DD') : '';
        this.formPerHasDep.get("personsCtrl").value != '' ? param = param + '&sexWards=' + this.formPerHasDep.get("personsCtrl").value.sex : '';
        this.formPerHasDep.get("personsCtrl").value ? param = param + '&docNumberWards=' + this.formPerHasDep.get("personsCtrl").value.docNumber : '';
        this.infiniteScroll = false;
        this.noShiftAvalableHasPer = false;
        this.formPerHasDepValid = true;


        if (param.length > 0) {
          param = param.replace('&', '?');
        }
        this.servicesPerHasDepList = [];

        this.loading.present();
        this.shiftService.getShifts(this.httpOptions, param).subscribe((response: any) => {

          this.servicesPerHasDepList = response;

          if (this.servicesPerHasDepList.serviceDateGroups.length < 1) {
            this.servicesPerHasDepList.dateFrom = response.stringDateFrom;
            this.servicesPerHasDepList.dateTo = response.stringDateTo;
            this.servicesPerHasDepList.stringDateFrom = response.stringDateFrom;
            this.servicesPerHasDepList.stringDateTo = response.stringDateTo;
            this.noShiftAvalableHasPer = true;
          } else {
            this.lastDay = response.dateTo;
            param = '';
            this.specialtyPerHasDepSelected != null ? param = param + '&specialtyCode=' + this.specialtyPerHasDepSelected.code : '';
            this.formPerHasDep.get("professionalCtrl").value != '' ? param = param + '&professionalName=' + this.formPerHasDep.get("professionalCtrl").value : '';
            //this.lastDay ? param = param + '&dateFrom=' + moment(this.lastDay).format('YYYY-MM-DD') : '';
            this.formPerHasDep.get("personsCtrl").value != '' ? param = param + '&sexWards=' + this.formPerHasDep.get("personsCtrl").value.sex : '';
            this.formPerHasDep.get("personsCtrl").value ? param = param + '&docNumberWards=' + this.formPerHasDep.get("personsCtrl").value.docNumber : '';

            //En Safari el replace remplaza el primer x caracter que encuentre
            let aux = this.lastDay.replace('-', '/');
            aux = aux.replace('-', '/');
            let fechaLastDay = new Date(aux)

            fechaLastDay.setDate(fechaLastDay.getDate() + 1);
            this.lastDay ? param = param + '&dateFrom=' + moment(fechaLastDay).format('YYYY-MM-DD') : '';

            if (param.length > 0) {
              param = param.replace('&', '?');
            }

            if (!this.validCount(this.servicesPerHasDepList.serviceDateGroups)) {
              this.loading.present();

              this.shiftService.getShifts(this.httpOptions, param).subscribe((response: any) => {
                this.loading.dismiss();
                this.lastDay = response.dateTo;

                if (response) {
                  if (response.serviceDateGroups.length > 0) {
                    response.serviceDateGroups.forEach(element => {
                      this.servicesPerHasDepList.serviceDateGroups.push(element);
                    });
                  } else {
                    this.servicesPerHasDepList.dateFrom = response.stringDateFrom;
                    this.servicesPerHasDepList.dateTo = response.stringDateTo;
                    this.servicesPerHasDepList.stringDateFrom = response.stringDateFrom;
                    this.servicesPerHasDepList.stringDateTo = response.stringDateTo;
                    this.noShiftAvalableHasPer = false;
                    this.infiniteScroll = true;
                  }
                }

              }, error => {
                this.loading.dismiss();
                if (error.status === 409) {
                  this.alert(error.error.message);
                }
                else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });

            }
          }

          this.loading.dismiss();
        }, error => {
          this.loading.dismiss();
          if (error.status === 409) {
            this.alert(error.error.message);
          }
          else {
            this.alert(constants.GENERIC_ERROR);
          }
        });

        this.panelOpenState = false;
        //this.getService(param)
      } else {
        this.alert("Debe filtrar por Especialidad y/o Profesional");
      }
    } else {
      if (!this.formPerHasDep.get("personsCtrl").valid && !this.formPerHasDep.get("fromDateCtrl").valid) {
        this.alert("El campo a Persona a Cargo y Fecha son Obligatorios");
      }
      else {
        if (!this.formPerHasDep.get("personsCtrl").valid) {
          this.alert("Debe seleccionar una Persona a Cargo");
        }
        if (!this.formPerHasDep.get("fromDateCtrl").valid) {
          this.alert("El campo Fecha es Obligatorio");
        }
      }
    }
  }

  validCount(itemList: any) {

    let serviceCount = 6;
    let countAux = 0;

    itemList.forEach(element => {
      element.serviceGroup.forEach(element => {
        countAux++
      });
    });

    if (countAux >= serviceCount) {
      return true;
    }
    else {
      return false;
    }
  }

  getSpecialty() {
    this.loading.present();
    this.getToken().then(value => {
      let param = ''
      this.healthCenterSelected = this.formPersonal.get('healthCenterCtrl').value
      this.healthCenterSelected ? param = param + '?healthCenterId=' + this.healthCenterSelected : '';

      this.shiftService.getSpecialty(param, this.httpOptions).subscribe((response: any) => {
        this.specialties = response;
        this.specialties.sort((a, b) => a.name.localeCompare(b.name));

        if (response.length) {
          this.cmSpecialty = false;
        }
        this.loading.dismiss();
      }, error => {
        this.specialties = [];
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });
    })
  }

  getSpecialtyPerHasDep(per: any) {
    this.loading.present();
    this.getToken().then(value => {
      this.shiftService.getSpecialty(per, this.httpOptions).subscribe((response: any) => {
        this.specialtiesPerHasDep = response;
        if (response.length) {
          this.cmSpecialtyPerHasDep = false;
        }
        this.loading.dismiss();
      }, error => {
        this.specialtiesPerHasDep = [];
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });
    })
  }

  getDependents() {

    this.getToken().then(value => {

      this.shiftService.getDependents(this.httpOptions).subscribe((response: any) => {

        this.dependents = response.wards;

        this.seeDependents = this.dependents.length > 0

        this.loading.dismiss();
      }, error => {
        this.dependents = [];
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }

      });
    })
    //this.loading.dismiss();
  }


  async getToken() {
    await this.storage.get('token').then(value => {
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
    })
  }

  getProfessionals() {
    this.specialtySelected = this.formPersonal.get('specialtyCtrl').value.code
    let healthCenterId = this.formPersonal.get('healthCenterCtrl').value;
    this.getToken().then(value => {
      this.shiftService.getProfessionalsBySpecialtyCode(this.specialtySelected, healthCenterId, this.httpOptions).subscribe((response: any) => {
        this.professionalList = response;
      })
    })
  }

  getProfessionalsHasDep() {
    this.specialtySelected = this.formPerHasDep.get('specialtyCtrl').value.code
    let healthCenterId = this.formPerHasDep.get('healthCenterCtrl').value;
    this.getToken().then(value => {
      this.shiftService.getProfessionalsBySpecialtyCode(this.specialtySelected, healthCenterId, this.httpOptions).subscribe((response: any) => {
        this.professionalList = response;
      })
    })
  }

  async alert(messageText: string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }

  enableSearchSpecialty(): void {
    this.specialtySelected = null;
    this.formPersonal.get('specialtyCtrl').setValue('');
    //this.searchText = null;
  }

  enableSearchSpecialtyPerHasDep(): void {
    this.specialtyPerHasDepSelected = null;
    this.formPerHasDep.get('specialtyCtrl').setValue('');
  }

  loadDataPersonal(event) {
    if (this.formPersonalValid) {
      let param = '';

      let fechaLastDay = new Date(this.lastDay.year, this.lastDay.monthValue - 1, this.lastDay.dayOfMonth + 1)

      this.specialtySelected != null ? param = param + '&specialtyCode=' + this.specialtySelected.code : '';
      this.healthCenterSelected ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
      this.formPersonal.get("professionalCtrl").value != '' ? param = param + '&professionalId=' + this.formPersonal.get("professionalCtrl").value.id : '';
      this.lastDay ? param = param + '&dateFrom=' + moment(fechaLastDay).format('YYYY-MM-DD') : '';

      if (param.length > 0) {
        param = param.replace('&', '?');
      }

      this.shiftService.getShifts(this.httpOptions, param).subscribe((response: any) => {
        this.loading.dismiss();
        event.target.complete();
        this.lastDay = response.dateTo;

        if (response) {
          if (response.serviceDateGroups.length > 0) {
            response.serviceDateGroups.forEach(element => {
              this.servicesPersonalList.serviceDateGroups.push(element);
              this.servicesPersonalList.dateTo = element.stringDate;
              this.servicesPersonalList.stringDateTo = element.stringDate;
            });
            this.lastDay = response.dateTo;
          } else {
            //this.alert("No se encontraron Turnos disponibles desde : "+response.dateFrom+ " Hasta "+response.dateTo );              

            this.servicesPersonalList.dateFrom = this.servicesPersonalList.stringDateTo
            this.servicesPersonalList.dateTo = response.stringDateTo;
            this.servicesPersonalList.stringDateFrom = this.servicesPersonalList.dateTo
            this.servicesPersonalList.stringDateTo = response.stringDateTo;
            this.noShiftAvalable = true;
            event.target.complete();
            this.infiniteScroll = true;
          }
        }
      }, error => {
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });


      console.log("Cargando ...")
    } else {
      event.target.complete();
    }

  }

  loadDataPerHasDep(event) {
    if (this.formPerHasDepValid) {
      let param = '';
      
      let fechaLastDay = new Date(this.lastDay.year, this.lastDay.monthValue - 1, this.lastDay.dayOfMonth + 1)

      this.specialtyPerHasDepSelected != null ? param = param + '&specialtyCode=' + this.specialtyPerHasDepSelected.code : '';
      this.healthCenterSelected ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
      this.formPerHasDep.get("professionalCtrl").value != '' ? param = param + '&professionalId=' + this.formPerHasDep.get("professionalCtrl").value.id : '';
      this.lastDay ? param = param + '&dateFrom=' + moment(fechaLastDay).format('YYYY-MM-DD') : '';
      
      if (param.length > 0) {
        param = param.replace('&', '?');
      }

      this.shiftService.getShifts(this.httpOptions, param).subscribe((response: any) => {
        this.loading.dismiss();
        event.target.complete();
        this.lastDay = response.dateTo;

        if (response) {
          if (response.serviceDateGroups.length > 0) {
            response.serviceDateGroups.forEach(element => {
              this.servicesPerHasDepList.serviceDateGroups.push(element);
              this.servicesPerHasDepList.dateTo = element.stringDate;
              this.servicesPerHasDepList.stringDateTo = element.stringDate;
            });
            this.lastDay = response.dateTo;
          } else {
            //this.alert("No se encontraron Turnos disponibles desde : "+response.dateFrom+ " Hasta "+response.dateTo ); 

            this.servicesPerHasDepList.dateFrom = this.servicesPerHasDepList.stringDateTo;
            this.servicesPerHasDepList.dateTo = response.stringDateTo;
            this.servicesPerHasDepList.stringDateFrom = this.servicesPerHasDepList.stringDateTo;
            this.servicesPerHasDepList.stringDateTo = response.stringDateTo;
            this.noShiftAvalableHasPer = true;
            event.target.complete();
            this.infiniteScroll = true;
          }
        }
      }, error => {
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });


      console.log("Cargando ...")
    } else {
      event.target.complete();
    }

  }

  seeShiftHours(item: any) {
    this.loading.dismiss();
    if (item) {
      let navigationExtras: NavigationExtras = {
        state: {
          shift: item,
          person: this.formPerHasDep.get("personsCtrl").value ? this.formPerHasDep.get("personsCtrl").value : null,
        }
      };
      this.router.navigate([ 'available-shifts' ], navigationExtras)
    }
  }

  clearFilterList() {
    this.formPersonal.get("specialtyCtrl").setValue("");
    this.formPersonal.get("professionalCtrl").setValue("");
    this.formPersonal.get("fromDateCtrl").setValue(null);

    this.formPerHasDep.get("personsCtrl").setValue("");
    this.formPerHasDep.get("specialtyCtrl").setValue("");
    this.formPerHasDep.get("professionalCtrl").setValue("");
    this.formPerHasDep.get("fromDateCtrl").setValue(null);

    this.servicesPerHasDepList = [];
    this.servicesPersonalList = [];

    this.specialtySelected = null;
    this.specialtyPerHasDepSelected = null;

    this.panelOpenState = true;

  }

  goToShifts() {
    this.router.navigate([ 'shifts' ]);
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

  getPerHasDep() {
    this.healthCenterSelected = this.formPerHasDep.get('healthCenterCtrl').value
    if (this.formPerHasDep.get("personsCtrl").value) {
      this.enableSearchSpecialtyPerHasDep();
      let param = '';
      this.formPerHasDep.get("personsCtrl").value != '' ? param = param + '&sexWards=' + this.formPerHasDep.get("personsCtrl").value.sex : '';
      this.formPerHasDep.get("personsCtrl").value ? param = param + '&docNumberWards=' + this.formPerHasDep.get("personsCtrl").value.docNumber : '';
      this.healthCenterSelected ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
      if (param.length > 0) {
        param = param.replace('&', '?');
      }
      this.cmSpecialtyPerHasDep = true;
      this.getSpecialtyPerHasDep(param);
    }
  }

  setStep() {
    this.panelOpenState = true;
  }

}
