import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ShiftsPageRoutingModule } from './shifts-routing.module';

import { ShiftsPage } from './shifts.page';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import {FileTransfer, FileTransferObject} from '@ionic-native/file-transfer/ngx';
import {File} from '@ionic-native/file/ngx';
import {RefreshUtils} from '../utils/refreshUtils';
import {FileOpener} from '@ionic-native/file-opener/ngx';
import { ShiftService } from '../services/shift.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HttpClientModule,
    ShiftsPageRoutingModule
  ],
  providers: [HttpClient,
    FileTransfer,
    FileTransferObject,
    File,
    RefreshUtils,
    FileOpener,
    ShiftService],
  declarations: [ShiftsPage]
})
export class ShiftsPageModule {}
