import { Component, OnInit } from '@angular/core';
import {FileTransfer, FileTransferObject} from '@ionic-native/file-transfer/ngx';
import {AlertController, LoadingController, NavController, Platform, ToastController} from '@ionic/angular';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {Storage} from '@ionic/storage';
import {ActivatedRoute, NavigationExtras, Router} from '@angular/router';
import {File} from '@ionic-native/file/ngx';
import {FileOpener} from '@ionic-native/file-opener/ngx';
import {ScreenOrientation} from '@ionic-native/screen-orientation/ngx';
import {RefreshUtils} from '../utils/refreshUtils';
import {StatusBar} from '@ionic-native/status-bar/ngx';
import {constants} from '../utils/constants';
import Swal from 'sweetalert2'
import { ShiftService } from '../services/shift.service';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { LoadingService } from '../services/loading.service';


@Component({
  selector: 'app-shifts',
  templateUrl: './shifts.page.html',
  styleUrls: ['./shifts.page.scss'],
  animations: [
    trigger('visibilityChanged', [
      state('shown', style({ opacity: 1 })),
      state('hidden', style({ opacity: 0 })),
      transition('* => *', animate('500ms'))
    ])
  ]
})
export class ShiftsPage implements OnInit{

  public shifts: Array<any>;
  public shiftsRC: Array<any>;
  public token:String;
  public fileTransfer: FileTransferObject;
  public storageDirectory:any;
  httpOptions: any = null;
  seeAll : boolean = false;

  constructor(private alertController: AlertController,
              private loadingController: LoadingController,
              private http: HttpClient,
              private storage: Storage,
              private route: ActivatedRoute,
              private router: Router,
              private transfer: FileTransfer,
              private file: File,
              private fileOpener: FileOpener,
              private shiftService: ShiftService,
              public loading: LoadingService ,
              public toastController: ToastController

      ,private screenOrientation: ScreenOrientation
      ,private navController: NavController
      ,private refreshUtils: RefreshUtils
      ,private statusBar: StatusBar
      ,private platform: Platform) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        // this.shifts = this.router.getCurrentNavigation().extras.state.shifts;
        this.token = this.router.getCurrentNavigation().extras.state.token;
        //this.makeLiquidationsCollapse();
      }
    });
  }

  getAppointmentsRM(){    
    this.loading.present();
    this.getToken().then(value => {
     
      this.shiftService.getAppointmentsRM(this.httpOptions,null).subscribe((response:any) => {
        
        this.loading.dismiss(); 
        this.shifts = response;  
        
        if(response[0].appointmentItemDtoList.length > 0){
          this.seeAll=true;
        }else{
          this.seeAll=false;
        } 

        this.makeLiquidationsCollapse();   
                 
      }, error => {
        this.loading.dismiss(); 
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else{
          this.alert(constants.GENERIC_ERROR);
        } 
      });
    })
  }

  getAppointmentsRC(){    
    this.loading.present();
    this.getToken().then(value => {
     
      this.shiftService.getAppointmentsRC(this.httpOptions).subscribe((response:any) => {
        
        this.loading.dismiss(); 
        this.shiftsRC = response;   
        this.makeLiquidationsCollapseRC();   
                 
      }, error => {
        this.loading.dismiss(); 
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else{
          this.alert(constants.GENERIC_ERROR);
        } 
      });
    })
  }
  
  makeLiquidationsCollapse(){
    let shiftsTemporal: Array<any> = [];
    let firstTime = true;
    this.shifts.forEach(element => {
      let elementTemporal = {
        type: element.type,
        typeDesc: element.typeDesc,
        appointmentItemDtoList: element.appointmentItemDtoList,
        expanded: firstTime,
      };

      shiftsTemporal.push(elementTemporal);
      firstTime = false;

    });
    this.shifts = shiftsTemporal;
  }

  makeLiquidationsCollapseRC(){
    let shiftsTemporal: Array<any> = [];
    let firstTime = true;
    this.shiftsRC.forEach(element => {
      let elementTemporal = {
        type: element.type,
        typeDesc: element.typeDesc,
        appointmentItemDtoList: element.appointmentItemDtoList,
        expanded: firstTime,
      };

      shiftsTemporal.push(elementTemporal);
      firstTime = false;

    });
    this.shiftsRC = shiftsTemporal;
  }

  expandOrCollapse(item:any){
    item.expanded = !item.expanded;
  }

  ionViewWillEnter(){
    this.statusBar.backgroundColorByHexString('#20B572');
  }

  ngOnInit(){
    this.getAppointmentsRM();
    this.getAppointmentsRC();
  }

  async deleteDataAndExitToLogin(){

    this.storage.clear().then(()=>{
      this.navController.navigateRoot("/login");
    });

  }

  async alert(messageText:string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }


  goToShiftsDetails(shifts:any){

    let navigationExtras: NavigationExtras = {
      state: {
        content: shifts,
        token: this.token
      }
    };
    this.router.navigate(['shifts-details'], navigationExtras);

  }

  goToShiftsDetailsRM(shifts:any){

    let navigationExtras: NavigationExtras = {
      state: {
        content: shifts,
        token: this.token
      }
    };
    this.router.navigate(['shifts-details-rm'], navigationExtras);

  }

  goToHome(){
    this.navController.navigateRoot("/home");
  }

  goNewShift(){
    //this.navController.navigateRoot("/new-appointment-rm", navigationExtras);
    this.router.navigate(['new-shifts']);

  }

  cancelShift(shift){
    this.loading.present();
    
    Swal.fire({
      title: 'Aviso',
      text: '¿Desea cancelar el Turno reservado?',
      imageUrl: "../../assets/icon/GreenWarning.png",
      imageWidth: 100,
      imageHeight: 100,
      showCancelButton: true,
      confirmButtonColor: '#20B572',
      confirmButtonText: 'Aceptar',
      cancelButtonText: "Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.getToken().then(value => {
          this.shiftService.updateAppointmentCancel(this.httpOptions,shift.items[0].value).subscribe((response:any) => {
            if(response){
              this.getAppointmentsRM();
            }
          },error => {     
            this.loading.dismiss(); 
            if (error.status === 409) {
              this.alert(error.error.message);
            }
            else{
              this.alert(constants.GENERIC_ERROR);
            } 
          }); 
        })
      }
    });
  }

  async presentToast() {
    const toast = await this.toastController.create({
      message: 'El Turno se Cancelo exitosamente',
      duration: 5000
    });
    toast.present();
  }

  async getToken() {
    await this.storage.get('token').then(value => {
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
    })
  }

}

