import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AvailableShiftComponent } from './available-shift.component';


const routes: Routes = [
  {
    path: '',
    component: AvailableShiftComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AvailableShiftRoutingModule {}
