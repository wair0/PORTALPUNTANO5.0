import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { AlertController, LoadingController, NavController, ToastController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import * as moment from 'moment';
import Swal from 'sweetalert2'
import { ShiftService } from 'src/app/services/shift.service';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { constants } from 'src/app/utils/constants';
import { LoadingService } from 'src/app/services/loading.service';


@Component({
  selector: 'app-available-shift',
  templateUrl: './available-shift.component.html',
  styleUrls: ['./available-shift.component.scss'],
  animations: [
    trigger('visibilityChanged', [
      state('shown', style({ opacity: 1 })),
      state('hidden', style({ opacity: 0 })),
      transition('* => *', animate('500ms'))
    ])
  ]
})
export class AvailableShiftComponent implements OnInit {


  appointments={
    appointments: [],
    endTime: '',
    healthCenterName: '',
    initTime: '',
    professionalNames: '',
    specialtyNames: '',
  }

  appointment = {
    endDate: '',
    professionalPlanningId: null,
    startDate: '',
  };
  

  data:any;
  showHrList: string = 'shown';
  showHrSelected: string = 'hidden';
  appointmentDate:any;

  horarioSelected: any = null;
  httpOptions: any = null;

  person:any = null;

  constructor(
    private storage: Storage,
    private route: ActivatedRoute,
    private loadingController: LoadingController,
    private router: Router, 
    private alertController: AlertController,
    public toastController: ToastController,
    private shiftService: ShiftService,
    private navController: NavController,
    public loading: LoadingService ,
    private localNotifications: LocalNotifications
  ) {
    
   }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {      
      if (this.router.getCurrentNavigation().extras.state) {       
        this.data = this.router.getCurrentNavigation().extras.state.shift;  
        
        this.appointments.endTime = this.data.endTime;
        this.appointments.healthCenterName = this.data.healthCenterName;
        this.appointments.initTime = this.data.initTime;
        this.appointments.professionalNames = this.data.professionalNames
        this.appointments.specialtyNames = this.data.specialtyNames;

        
        this.data.appointments.forEach(element => {     
          let appointment = {
            endDate: '',
            professionalPlanningId: null,
            startDate: '',
          };
          this.appointmentDate = moment(element.startDate).format('DD-MM-YYYY');
          appointment.endDate = moment(element.endDate).format('HH:mm');
          appointment.startDate = moment(element.startDate).format('HH:mm');
          appointment.professionalPlanningId = element.professionalPlanningId;
          this.appointments.appointments.push(appointment);
        });
        this.person = this.router.getCurrentNavigation().extras.state.person; 
      }      
    });
  }

  selectedHour(item:any){
    this.horarioSelected = item;
    this.showHrList = 'hidden';
    this.showHrSelected = 'shown';
  }

  clearHrSelected(){
    this.horarioSelected = null;
    this.showHrList = 'shown';
    this.showHrSelected = 'hidden';
  }

  async presentToast() {
    const toast = await this.toastController.create({
      message: 'TURNO SOLICITADO CON ÉXITO',
      duration: 5000
    });
    toast.present();
  }

  send(){
    
    let model = null;

    let auxDate = moment(this.appointmentDate , 'DD-MM-YYYY').format('YYYY-MM-DD');
    let start = moment(auxDate + ' ' + this.horarioSelected.startDate).format('YYYY-MM-DD HH:mm:ss');
    let end = moment(auxDate + ' ' + this.horarioSelected.endDate).format('YYYY-MM-DD HH:mm:ss');
        
    if(this.person){
      model = {
        dateFrom :  start,
        dateTo : end ,  
        patient : {
          sex: this.person.sex,
          docNumber: this.person.docNumber,
        },      
        professionalPlanning: {
            id: this.horarioSelected.professionalPlanningId
        },
      }
    }
    else{
      model = {
        dateFrom : start ,
        dateTo : end ,        
        professionalPlanning: {
            id: this.horarioSelected.professionalPlanningId
        },
      }
    }

    this.loading.present();
    this.getToken().then(value => {

      
      this.shiftService.assignShifts(this.httpOptions, model).subscribe((response: any) => {
        this.presentToast();
        this.router.navigate(['shifts-details-rm']);
        
        // Se elimino debido a que en un dispositivo rompe la APP
        // this.localNotifications.schedule({ 
        //   text: 'Su turno ha sido asignado el día: '+response.dateFrom,
        //  // sound: isAndroid? 'file://sound.mp3': 'file://beep.caf',
        //  // data: { secret: key }
        // });
      
        
        this.loading.dismiss(); 
      }, error => {
        this.loading.dismiss(); 
        if (error.status === 409) {
          Swal.fire({
            text: error.error.message ,
            imageUrl: "../../assets/icon/GreenWarning.png",
            imageWidth: 100,
            imageHeight: 100,
            confirmButtonText:'Cerrar',
            confirmButtonColor:'#A2A4AB'
          })
        }
        else{
          this.alert(constants.GENERIC_ERROR);
        }  
      });
    })
    
  }

  async getToken() {
    await this.storage.get('token').then(value => {
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
    })
  }

  async alert(messageText: string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

}
