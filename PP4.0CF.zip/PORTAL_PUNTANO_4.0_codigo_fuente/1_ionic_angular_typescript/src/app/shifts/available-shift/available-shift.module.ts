import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AvailableShiftRoutingModule } from './available-shift-routing.module';
import { AvailableShiftComponent } from './available-shift.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ShiftService } from 'src/app/services/shift.service';




@NgModule({
  imports: [
    CommonModule,
    AvailableShiftRoutingModule,
    FormsModule,
    IonicModule,
    HttpClientModule

  ],
  providers: [HttpClient,
    
    ShiftService],
  declarations: [AvailableShiftComponent]
})
export class AvailableShiftModule { }
