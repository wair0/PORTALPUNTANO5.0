import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ProceedingsPageRoutingModule } from './proceedings-routing.module';

import { ProceedingsPage } from './proceedings.page';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import {FileTransfer, FileTransferObject} from '@ionic-native/file-transfer/ngx';
import {File} from '@ionic-native/file/ngx';
import {RefreshUtils} from '../../utils/refreshUtils';
import {FileOpener} from '@ionic-native/file-opener/ngx';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HttpClientModule,
    ProceedingsPageRoutingModule
  ],
  providers: [HttpClient,
    FileTransfer,
    FileTransferObject,
    File,
    RefreshUtils,
    FileOpener],
  declarations: [ProceedingsPage]
})
export class ProceedingsPageModule {}
