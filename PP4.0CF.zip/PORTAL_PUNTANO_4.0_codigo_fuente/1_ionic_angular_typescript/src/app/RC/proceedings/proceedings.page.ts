import { Component, OnInit } from '@angular/core';
import {FileTransfer, FileTransferObject} from '@ionic-native/file-transfer/ngx';
import {AlertController, LoadingController, NavController, Platform} from '@ionic/angular';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {Storage} from '@ionic/storage';
import {ActivatedRoute, NavigationExtras, Router} from '@angular/router';
import {File} from '@ionic-native/file/ngx';
import {FileOpener} from '@ionic-native/file-opener/ngx';
import {ScreenOrientation} from '@ionic-native/screen-orientation/ngx';
import {RefreshUtils} from '../../utils/refreshUtils';
import {StatusBar} from '@ionic-native/status-bar/ngx';
import {constants} from '../../utils/constants';
import { DeviceDetailsService } from '../../device/device.service';


@Component({
  selector: 'app-proceedings',
  templateUrl: './proceedings.page.html',
  styleUrls: ['./proceedings.page.scss'],
})
export class ProceedingsPage implements OnInit {

  public proceedings: Array<any>;
  public token:String;
  public fileTransfer: FileTransferObject;
  public storageDirectory:any;


  constructor(private alertController: AlertController,
              private loadingController: LoadingController,
              private http: HttpClient,
              private storage: Storage,
              private route: ActivatedRoute,
              private router: Router,
              private transfer: FileTransfer,
              private file: File,
              private fileOpener: FileOpener
      ,       private deviceDetailsService: DeviceDetailsService
      ,private screenOrientation: ScreenOrientation
      ,private navController:NavController
      ,private refreshUtils:RefreshUtils
      ,private statusBar: StatusBar
      ,private platform: Platform) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.proceedings = this.router.getCurrentNavigation().extras.state.proceedings;
        this.token = this.router.getCurrentNavigation().extras.state.token;
        this.makeProceedingsCollapse();
      }
    });


  }

  makeProceedingsCollapse(){
    let proceedingsTemporal: Array<any> = [];
    let firstTime = true;
    this.proceedings.forEach(element => {
      let elementTemporal = {
        type: element.type,
        certificates: element.certificates,
        expanded: firstTime,
      };

      proceedingsTemporal.push(elementTemporal);
      firstTime = false;

    });
    this.proceedings = proceedingsTemporal;

  }

  expandOrCollapse(item:any){
    item.expanded = !item.expanded;
  }

  ionViewWillEnter(){
    this.statusBar.backgroundColorByHexString('#1E88E5');
  }

  ngOnInit(){}

  async deleteDataAndExitToLogin(){

    this.storage.clear().then(()=>{
      this.navController.navigateRoot("/login");
    });

  }

  async alert(messageText:string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }


  async loading(messageText:string){
    const loading = await this.loadingController.create({
      message: messageText,
    });
    await loading.present();
  }

  async checkPassword(proceeding:any) {
    this.loading("Descargando");
    this.storage.get('token').then((val) => {
      if (val) {
        this.token = val;

        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-Authorization': 'Bearer ' + this.token,
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Accept': 'application/json'
            }),
          })
        };

        console.log("URL: " + constants.URL_BASE_PORTAL + "secure/mobile/check/password");
        console.log("TOKEN: " + 'Bearer ' + this.token);

        this.http.get(constants.URL_BASE_PORTAL + "secure/mobile/check/password", httpOptions)
            .subscribe((data: any) => {

              this.download(proceeding);

            }, error => {
              this.processError(error).then(value => {
                this.checkPassword(proceeding);
              });
            });
      }
      else {
        this.loadingController.dismiss();
        this.alert(constants.GENERIC_ERROR);
      }
    });
  }

  async download(proceeding:any) {

    // this.loading('Descargando');

    let fileName = proceeding.value+".pdf";

    let filePath = constants.URL_BASE_PORTAL+"secure/civilRegistration/certificate/"+proceeding.id;

    let url = encodeURI(filePath);
    this.fileTransfer = this.transfer.create();

    let options = {
      headers: {
        "X-Authorization": "Bearer "+this.token
      }
    };

    let directory = this.file.documentsDirectory;

    if (this.platform.is("android")) {
      let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
      //if(this.file.externalRootDirectory){
      console.log("[HOME] OS VERSION: " + soVersion);
      if (soVersion < 11) {
        if(this.file.externalRootDirectory){
            directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
          }else{
            directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
          }        
      }else{
        directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
      }
    }

    this.fileTransfer.download(url, directory+ fileName, true,options).then((entry) => {
      this.loadingController.dismiss();
      //here logging our success downloaded file path in mobile.
      console.log('download completed: ' + entry.toURL());

      this.file.resolveDirectoryUrl(directory).then((rootDir) => {
        this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
          fileEntry.getMetadata(metadata => {
            if (metadata.size != 0) {
              // open downloaded file
              this.openFileHandler(entry.toURL());

              if (this.platform.is("android")) {
                let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                if (soVersion < 11) {
                  if(this.file.externalRootDirectory){
                    this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + constants.FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                  }
                }
              }

            } else {
              this.alert(constants.FILE_SIZE_0_ERROR);
            }
          })

        });

      });

    }).catch((error) => {
      this.loadingController.dismiss();
      if(error!=null && error.http_status!=null&&error.http_status==409){
        this.alert(JSON.parse(error.body).message);
      }else if(error.status == 401) {
        this.deleteDataAndExitToLogin();
      }else if(error.status == 500){
        if(error.error.exception==="io.jsonwebtoken.ExpiredJwtException"){
          this.storage.get('psw').then((val) => {
            if(val){
              this.loading('Descargando');
              this.refreshUtils.refreshToken(val).then(value => {
                this.loadingController.dismiss();
                this.download(proceeding);
              }).catch(error=>{
                this.alert(constants.GENERIC_ERROR);
              });
            }
            else{
              this.alert(constants.GENERIC_ERROR);
            }
          });

        }else{
          this.alert(constants.GENERIC_ERROR);
        }
      }else{
        this.alert(constants.GENERIC_ERROR)
      }
      //here logging an error.
      console.log('download failed: ' + JSON.stringify(error));
    });
  }

  openFileHandler(path:any) {
    this.fileOpener.open(path, '')
        .then(() => console.log('File is opened'))
        .catch(e => console.log('Error opening file', e));
  }


  processError = function(error:any){
    return new Promise<any>((resolve,reject)=>{
      console.log("Error!!!!!");
      console.log(JSON.stringify(error));
      this.loadingController.dismiss();
      if(error.status == 500){
        if(error.error.exception==="io.jsonwebtoken.ExpiredJwtException"){
          this.storage.get('psw').then((val: any) => {
            if(val){
              this.loading("Descargando");
              this.refreshUtils.refreshToken(val).then((value: any) => {
                this.loadingController.dismiss();
                resolve(value);
              }).catch((errorRefresh: { status: number; })=>{
                this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();
                }else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            }
            else{
              this.alert(constants.GENERIC_ERROR);
            }
          });

        }else{
          this.alert(constants.GENERIC_ERROR);
        }
      }else if (error.status == 401) {
        this.deleteDataAndExitToLogin();
      }else if(error.status == 409){
        this.alert(error.error.message);
      }else{
        this.alert(constants.GENERIC_ERROR);
      }
    });

  }

  goToHome(){
    this.navController.navigateRoot("/home");
  }


}
