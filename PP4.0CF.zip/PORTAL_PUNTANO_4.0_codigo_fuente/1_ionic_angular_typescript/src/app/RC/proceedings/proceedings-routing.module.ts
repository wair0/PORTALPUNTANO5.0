import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProceedingsPage } from './proceedings.page';

const routes: Routes = [
  {
    path: '',
    component: ProceedingsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProceedingsPageRoutingModule {}
