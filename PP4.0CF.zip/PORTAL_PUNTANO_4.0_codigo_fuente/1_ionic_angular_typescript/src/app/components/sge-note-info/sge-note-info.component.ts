import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-sge-note-info',
  templateUrl: './sge-note-info.component.html',
  styleUrls: ['./sge-note-info.component.scss'],
})
export class SgeNoteInfoComponent implements OnInit {
  exams:any = []

  @Input() testOfStudentList: any

  constructor() { }

  ngOnInit() {
    this.exams = this.testOfStudentList
  }

}
