import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-sport-map-details',
  templateUrl: './sport-map-details.component.html',
  styleUrls: ['./sport-map-details.component.scss'],
})
export class SportMapDetailsComponent implements OnInit {

  item: any;
  
  @Input() sportMap: any
  @Input() description: any

  constructor() { }

  ngOnInit() {
    this.item = this.sportMap
    this.item.description = this.description
  }

  
}
