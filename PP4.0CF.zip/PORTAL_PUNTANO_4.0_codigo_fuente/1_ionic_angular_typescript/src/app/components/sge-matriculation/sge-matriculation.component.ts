import { Component, OnInit, Input} from '@angular/core';

@Component({
  selector: 'app-sge-matriculation',
  templateUrl: './sge-matriculation.component.html',
  styleUrls: ['./sge-matriculation.component.scss'],
})
export class SgeMatriculationComponent implements OnInit {
  @Input() matriculations : any;

  constructor() { 
    this.matriculations;
  }

  ngOnInit() {}

}
