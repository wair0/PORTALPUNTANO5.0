import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-sge-assistance-info',
  templateUrl: './sge-assistance-info.component.html',
  styleUrls: ['./sge-assistance-info.component.scss'],
})
export class SgeAssistanceInfoComponent implements OnInit {

  @Input() infoOfAssistance: any

  constructor() { }

  ngOnInit() {
    this.infoOfAssistance
  }

}
