import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { LoadingController, AlertController, NavController, Platform, ToastController } from '@ionic/angular';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2'
import { constants } from '../utils/constants';



@Component({
  selector: 'app-credentials',
  templateUrl: './credentials.page.html',
  styleUrls: ['./credentials.page.scss'],
})
export class CredentialsPage implements OnInit {

  token:any;
  httpOptions: any = null;
  btnCredential = "btnCredentialDes";
  btnDriverLicense = "btnDriverLicenseDes";
  credentialData: any;
  licenseData: any;

  public data = {
    token: '',
    iduser: 0,
    dni: 0,
    liquidations: [],
    judicialExpedients: [],
    proceduresAct: [],
    proceduresFin: [],
    procedures: [],
    totalProceduresAct: 0,
    totalProceduresFin: 0
  };

  constructor(private storage: Storage,private http: HttpClient
    , private alertController: AlertController
    , private route: ActivatedRoute
    , private platform: Platform
    , private router: Router
    , private loadingController: LoadingController) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        // this.shifts = this.router.getCurrentNavigation().extras.state.shifts;
        this.token = this.router.getCurrentNavigation().extras.state.token;
        //this.makeLiquidationsCollapse();
      }
    });
    this.getValidateRegistration();
    this.checkPasswordDL();
  }


  async checkPasswordDL() {
    
      this.loading();
      this.getToken().then(value => {

          this.http.get(constants.URL_BASE_PORTAL + 'secure/mobile/check/password', this.httpOptions)
            .subscribe((data: any) => {
  
              this.getDriverLicense();
  
            }, error => {
              this.processError(error).then(value => {
                this.checkPasswordDL();
              });
            });        
        
      });
       
  }

  async loading() {
    this.loadingController.dismiss();
    const loading = await this.loadingController.create({
      message: 'Cargando',
      duration: 5000,
    });
    await loading.present();
  }

  // async getLocalDriverLicense() {

  //   this.storage.get('driverLicense').then((val) => {
  //     if (val) {
  //       // this.loadingController.dismiss();
  //       //this.goToDriverLicense(val);
  //       this.btnDriverLicense = "btnDriverLicenseAct";
  //       this.licenseData = val;
  //     } else {
  //       this.getDriverLicense();
  //     }
  //   });

  // }

  processError = function(error: any) {
    return new Promise<any>((resolve, reject) => {
      // this.loadingController.dismiss();
      if (error.status === 500) {
        if (error.error.exception === 'io.jsonwebtoken.ExpiredJwtException') {
          this.storage.get('psw').then((val: any) => {
            if (val) {
              // this.loading();
              this.refreshUtils.refreshToken(val).then((value: any) => {
                resolve(value);
              }).catch((errorRefresh: { status: number; }) => {
                // this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();
                } else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            } else {
              this.alert(constants.GENERIC_ERROR);
            }
          });

        } else {
          this.alert(constants.GENERIC_ERROR);
        }
      } else if (error.status == 401) {
        this.deleteDataAndExitToLogin();
      } else if (error.status == 409) {
        this.alert(error.error.message);
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  };


  goToDriverLicense() {
    if(this.btnDriverLicense == 'btnDriverLicenseAct'){          
      const navigationExtras: NavigationExtras = {
        state: {
          driverLicense:this.licenseData,
          token: this.data.token
        }
      };
      this.router.navigate(['driverLicense'], navigationExtras);
    }else{
      if(this.licenseData){
        this.alert(this.licenseData);
      }else{
        this.alert('Usted no posee licencia de conducir CIPE');
      }     
    } 
  }

  async getDriverLicense() {

    this.loading();
    this.getToken().then(value => {

        this.http.get(constants.URL_BASE_PORTAL + 'secure/driverLicense/license', this.httpOptions)
          .subscribe((response:any) => {
            this.storage.set('driverLicense', response);   
            if(JSON.stringify(response) != '{}'){
              this.licenseData = response;
              this.btnDriverLicense = "btnDriverLicenseAct";
            }
            this.loadingController.dismiss();
          }, error => {
            if (error.status === 409) {
              this.licenseData = error.error.message;
              this.alert(error.error.message);
            }
            else{
              error.error.message = constants.GENERIC_ERROR;
              this.alert(constants.GENERIC_ERROR);
            }         
          });      
    });
  }

  goToHealthCredential(){
    if(this.btnCredential == 'btnCredentialAct'){
      this.loadingController.dismiss();
      const navigationExtras: NavigationExtras = {
        state: {        
          token: this.data.token,
          data: this.credentialData
        }
      };
      this.router.navigate(['health-credential'], navigationExtras);
    }else{
      if(this.credentialData){
        this.alert(this.credentialData);
      }else{
        this.alert("Usted no posee credencial de personal de la salud");
      }
      
    }
    
  }

  async getValidateRegistration() {
    this.loading();
    this.getToken().then(value => {
    this.http.get(constants.URL_BASE_PORTAL + 'secure/ministryOfHealth/credential', this.httpOptions)
        .subscribe((data: any) => {        
        //this.goToHealthCredential(data);
        this.credentialData = data;
        this.btnCredential = 'btnCredentialAct'                
        this.loadingController.dismiss();
      }, error => {
        if (error.status === 409) {
          this.credentialData = error.error.message;
          this.alert(error.error.message);
        }
        else{
          this.credentialData = constants.GENERIC_ERROR;
          this.alert(constants.GENERIC_ERROR);
        } 
      });
    })
  }

  async alert(messageText:string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
          }
        }
      ]
    });

    await alert.present();
  }

  async getToken() {
    await this.storage.get('token').then(value => {
      
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
    })
  }


}
