import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { IonicModule } from '@ionic/angular';

import { CredentialsPageRoutingModule } from './credentials-routing.module';

import { CredentialsPage } from './credentials.page';
import {RefreshUtils} from '../utils/refreshUtils';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HttpClientModule,
    CredentialsPageRoutingModule
  ],
  providers: [
    HttpClient,
    RefreshUtils],
  declarations: [CredentialsPage]
})
export class CredentialsPageModule {}
