import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ShiftsDetailsPage } from './shifts-details.page';

const routes: Routes = [
  {
    path: '',
    component: ShiftsDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ShiftsDetailsPageRoutingModule {}
