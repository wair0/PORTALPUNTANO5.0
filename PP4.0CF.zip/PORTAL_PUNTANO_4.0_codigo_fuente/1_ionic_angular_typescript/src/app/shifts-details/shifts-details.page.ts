import { Component, OnInit } from '@angular/core';
import {FileTransfer, FileTransferObject} from '@ionic-native/file-transfer/ngx';
import {AlertController, LoadingController, NavController, Platform} from '@ionic/angular';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {Storage} from '@ionic/storage';
import {ActivatedRoute, Router} from '@angular/router';
import {File} from '@ionic-native/file/ngx';
import {FileOpener} from '@ionic-native/file-opener/ngx';
import {ScreenOrientation} from '@ionic-native/screen-orientation/ngx';
import {RefreshUtils} from '../utils/refreshUtils';
import {StatusBar} from '@ionic-native/status-bar/ngx';
import {constants} from '../utils/constants';

@Component({
  selector: 'app-shifts-details',
  templateUrl: './shifts-details.page.html',
  styleUrls: ['./shifts-details.page.scss'],
})
export class ShiftsDetailsPage implements OnInit {

  public content:any;
  public token:String;
  public fileTransfer: FileTransferObject;
  public storageDirectory:any;


  constructor(private alertController: AlertController,
              private loadingController: LoadingController,
              private http: HttpClient,
              private storage: Storage,
              private route: ActivatedRoute,
              private router: Router,
              private transfer: FileTransfer,
              private file: File,
              private fileOpener: FileOpener
      ,private screenOrientation: ScreenOrientation
      ,private refreshUtils:RefreshUtils
      ,private navController:NavController
      ,private statusBar: StatusBar
      ,private platform: Platform) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.content = this.router.getCurrentNavigation().extras.state.content;
        this.token = this.router.getCurrentNavigation().extras.state.token;
      }
    });


  }
  ionViewWillEnter(){
    this.statusBar.backgroundColorByHexString('#20B572');
  }

  ngOnInit(){
  }

  async deleteDataAndExitToLogin(){

    this.storage.clear().then(()=>{
      this.navController.navigateRoot("/login");
    });

  }

  async alert(messageText:string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }


  async loading(messageText:string){
    const loading = await this.loadingController.create({
      message: messageText,
    });
    await loading.present();
  }


  processError = function(error:any){
    return new Promise<any>((resolve,reject)=>{
      console.log("Error!!!!!");
      console.log(JSON.stringify(error));
      this.loadingController.dismiss();
      if(error.status == 500){
        if(error.error.exception==="io.jsonwebtoken.ExpiredJwtException"){
          this.storage.get('psw').then((val: any) => {
            if(val){
              this.loading("Descargando");
              this.refreshUtils.refreshToken(val).then((value: any) => {
                this.loadingController.dismiss();
                resolve(value);
              }).catch((errorRefresh: { status: number; })=>{
                this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();
                }else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            }
            else{
              this.alert(constants.GENERIC_ERROR);
            }
          });

        }else{
          this.alert(constants.GENERIC_ERROR);
        }
      }else if (error.status == 401) {
        this.deleteDataAndExitToLogin();
      }else if(error.status == 409){
        this.alert(error.error.message);
      }else{
        this.alert(constants.GENERIC_ERROR);
      }
    });

  }

  goToHome(){
    this.navController.navigateRoot("/home");
  }

}
