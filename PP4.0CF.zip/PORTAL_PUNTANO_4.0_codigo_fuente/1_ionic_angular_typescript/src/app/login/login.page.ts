import {Component, OnInit, ViewChild} from '@angular/core';
import {LoadingController, AlertController, NavController, Platform, ToastController, IonDatetime} from '@ionic/angular';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { HTTP } from '@ionic-native/http/ngx';
import { Router, NavigationExtras } from '@angular/router';
import { log } from 'util';
import { Alert } from 'selenium-webdriver';
import { Storage } from '@ionic/storage';
import * as moment from 'moment';
import { StatusBar } from '@ionic-native/status-bar/ngx';


import { constants } from '../utils/constants';

import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';

import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import {Location} from '@angular/common';
import { LocalStorageService } from '../services/local-storage.service';


@Component({
  selector: 'app-login',
  templateUrl: 'login.page.html',
  styleUrls: ['login.page.scss'],
})
export class LoginPage implements OnInit {

  dni: any;
  documentProcedureNumber: any;
  sex: any;
  tel: any;
  password: any;
  isLogged = false;
  hidePassword = true;
  passwordType = 'password';
  qrData: any;
  dniData: any;
  birthDay: any;
  passwordGenerated = true;
  subscription: any;
  width: any;
  height: any;
  buttonValue = 1;
  mustGeneratePassword = false;
  token: string;
  recover = false;

  constructor(private alertController: AlertController,
              private loadingController: LoadingController,
              private http: HttpClient, private http2: HTTP, private platform: Platform, private router: Router,
              private storage: Storage, private barcodeScanner: BarcodeScanner
    ,         public navController: NavController
    ,         public toastCtrl: ToastController
    ,         private statusBar: StatusBar
    ,         private inAppBrowser: InAppBrowser
    ,         private location: Location,
      private localStorageService: LocalStorageService
    ) {
    this.setDimesions();
  }

  async setDimesions() {
    this.storage.get('width').then((val) => {
      if (val) {
        this.width = val;
        this.storage.get('height').then((val2) => {
          if (val2) {
            this.height = val2;
          } else {
            this.storageDimensions();
          }
        });
      } else {
        this.storageDimensions();
      }
    });
  }

  async storageDimensions() {
    if (this.platform.isPortrait()) {
      this.width = window.innerWidth;
      this.height = window.innerHeight;
      this.storage.set('width', window.innerWidth);
      this.storage.set('height', window.innerHeight);
    }
  }
  ionViewWillEnter() {
    this.statusBar.backgroundColorByHexString('#932a7e');
  }

  ionViewDidEnter() {
    let lastTimeBackPress = 0;
    const timePeriodToExit = 2000;
    this.subscription = this.platform.backButton.subscribe(() => {
      console.log('BACK BUTTON PRESSED!!!!!');
      if (new Date().getTime() - lastTimeBackPress < timePeriodToExit) {
        // navigator.app.exitApp();
        let newVariable: any;

        newVariable = window.navigator;
        // navigator.app.exitApp();
        newVariable.app.exitApp();
      } else {
        this.exitToast();
        lastTimeBackPress = new Date().getTime();
      }

    });
  }

  changeHidePassword() {
    if (!this.hidePassword) {
      this.passwordType = 'password';
    } else {
      this.passwordType = 'text';
    }
    this.hidePassword = !this.hidePassword;
  }

  async exitToast() {
    const toast = await this.toastCtrl.create({
      message: 'Presione nuevamente para salir',
      duration: 2000,
      position: 'bottom'
    });
    toast.present();
  }


  ionViewWillLeave() {
    this.subscription.unsubscribe();
  }

  ngOnInit() {
    // this.storage.clear();
    this.storage.get('psw').then((val) => {
      if (val) {
        this.login(val);
      } else {
        this.isLogged = true;
      }
    });

  }

  async loading() {
    // this.loadingController.dismiss();
    const loading = await this.loadingController.create({
      message: 'Cargando',
    });
    await loading.present();
  }

  async alert(messageText: string) {
    this.loadingController.dismiss();
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }

  async generatePassword() {
    this.passwordGenerated = false;
    await this.clearDataScanned();
  }

  async recoverPassword() {

    if (this.dni && this.sex && this.tel) {

      if (this.tel.length !== 10) {
        this.alert('Por favor verifique su número de teléfono. Debe contener el código de área sin cero y sin quince, por ejemplo: "<b>2664999999</b>"');
      } else {
        const loading = await this.loadingController.create({
          message: 'Enviando código',
          // duration: 2000
        });
        await loading.present();

        console.log('sendPostRequest CALLED!!!!!!!');
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };

        const postData = {
          docNumber: this.dni,
          sex: this.sex,
          phoneNumber: this.tel
        };


        console.log(JSON.stringify(postData));

        this.http.post(constants.URL_BASE_PORTAL + 'card/less/user/recover/password', postData, httpOptions)
            .subscribe((data: any) => {
              console.log('RESPONSE REGISTER!!!!');
              console.log(data);
              this.loadingController.dismiss();
              if (data.code === 'SMS') {
                this.alert(data.result);
                this.recover = false;
              } else {
                this.alert(data.result);
              }


            }, error => {
              console.log('Error!!!!!');
              console.log(JSON.stringify(error));
              this.loadingController.dismiss();
              if (error.status === 409) {
                this.alert(error.error.message);
              } else {
                this.alert(constants.GENERIC_ERROR);
              }

            });
      }

    } else {
      this.loadingController.dismiss();
      this.alert('Por favor, complete todos los campos para poder recuperar la contraseña');
    }


  }

  async changeRecover() {
    this.recover = !this.recover;
  }

  async havePassword() {
    this.passwordGenerated = true;
    await this.clearDataScanned();
  }

  async help() {
    // TODO: Ver si en algún momento esto puede ser configurable por Base de datos para no tener que volver a compilar cuando al URL cambie
    if (this.passwordGenerated) {
      this.inAppBrowser.create('https://portalpuntano.sanluis.gob.ar/technicalSupport/');
    } else {
      this.inAppBrowser.create('https://portalpuntano.sanluis.gob.ar/smsCodeApp/');
    }
  }

  async qrScan() {
    if(constants.SCANN_QR) {
      this.barcodeScanner.scan({
        showTorchButton: true,
        prompt: 'Ponga el código de la CIPE en el area de escaneo',
        resultDisplayDuration: 50,
        showFlipCameraButton: true,
        formats: 'DATA_MATRIX',
      }).then(barcodeData => {
        if (barcodeData.cancelled) {
          this.alert('Escaneo cancelado');
        } else {
          this.qrData = barcodeData.text;
          console.log('Barcode data text', this.qrData);
        }

        console.log('Barcode data format', barcodeData.format);
        console.log('Barcode data cancelled', barcodeData.cancelled);
      }).catch(err => {
        console.log('Error', err);
      });
    } else {
      this.qrData = 'http://datos.cipe.gob.ar?id=298646';
    }
  }

  async dniScan() {

    if (constants.SCANN_QR) {
    this.barcodeScanner.scan({
      showTorchButton: true,
      prompt: 'Ponga el código del DNI en el area de escaneo',
      resultDisplayDuration: 50,
      showFlipCameraButton: true,
      formats: 'PDF_417',
    }).then(barcodeData => {
      if (barcodeData.cancelled) {
        this.alert('Escaneo cancelado');
      } else {
        this.parseDni(barcodeData.text);
      }

      console.log('Barcode data format', barcodeData.format);
      console.log('Barcode data cancelled', barcodeData.cancelled);
    }).catch(err => {
      console.log('Error', err);
    });


  } else {
       this.parseDni('00303147358@ALUMNO@CON MAPA@F@52827222@B@25/01/1988@29/09/2014@234');
    // this.testHCDprod('00303147352@HERRERA@VIVIANA GABRIELA@F@33428305@B@25/01/1988@29/09/2014@234');
    }

  }

  async parseDni(pdf417String: string) {
        const loading = await this.loadingController.create({
          message: 'Validando',
          // duration: 2000
        });
        await loading.present();

        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };

        const postData = {
          pdf417String
        };


        console.log(JSON.stringify(postData));

        this.http.post(constants.URL_BASE_PORTAL + 'card/less/user/person/parseData', postData, httpOptions)
            .subscribe((data: any) => {
              console.log(data);
              this.loadingController.dismiss();
              this.dniData = pdf417String;
              console.log('Barcode data text', this.dniData);
              this.dni = data.docNumber;
              this.documentProcedureNumber = data.documentProcedureNumber;
              this.sex = data.sex;
              this.birthDay = data.birthDayString;
            }, error => {
              console.log('Error!!!!!');
              console.log(JSON.stringify(error));
              this.loadingController.dismiss();
              if (error.status === 409) {
                this.alert(error.error.message);
              } else {
                this.alert(constants.GENERIC_ERROR);
              }

            });
  }

  async changeTypeScan(buttonValue: number) {
    if (buttonValue !== this.buttonValue) {
      this.dni = null;
      this.sex = null;
      this.tel = null;
      this.documentProcedureNumber = null;
      this.birthDay = null;
      if (buttonValue > 0) {
        this.qrData = null;
      } else {
        this.dniData = null;
      }
      this.buttonValue = buttonValue;
    }
  }
  async clearDataScanned() {
      this.dni = null;
      this.sex = null;
      this.tel = null;
      this.birthDay = null;
      this.qrData = null;
      this.dniData = null;
  }

  async validateNumber(value: any) {
   // let value = event.detail.value;
  //  console.log(this.tel);
  //   console.log(/^[0-9]*$/.test(value));
    if (!/^[0-9]*$/.test(value)) {
      this.tel = new String(value.slice(0, -1));

    }
    // console.log(this.tel);

  }
  validar() {
    if (this.buttonValue > 0) {
      this.validarDNI();
    } else {
      this.validarQr();
    }
  }

  async validarQr() {
    if (this.dni && this.sex && this.tel && this.birthDay && this.qrData) {

      if (this.tel.length !== 10) {
        this.alert('Por favor verifique su número de teléfono. Debe contener el código de área sin cero y sin quince, por ejemplo: "<b>2664999999</b>"');
      } else {
        const loading = await this.loadingController.create({
          message: 'Validando',
          // duration: 2000
        });
        await loading.present();

        console.log('sendPostRequest CALLED!!!!!!!');
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };

        const postData = {
          docType: 'DNI',
          docNumber: this.dni,
          sex: this.sex,
          phoneNumber: this.tel,
          birthDate: moment(this.birthDay).format('DD/MM/YYYY'),
          qrCode: this.qrData// "datos.cipe.gob.ar?id=298648"//this.qrData
        };


        console.log(JSON.stringify(postData));

        this.http.post(constants.URL_BASE_PORTAL + 'card/less/user/register', postData, httpOptions)
          .subscribe((data: any) => {
            console.log('RESPONSE REGISTER!!!!');
            console.log(data);
            this.loadingController.dismiss();
            if (data.code === 'SMS') {
              this.alert(data.result);
              this.passwordGenerated = true;
              // this.navigateChangePassword();
            } else {
              this.alert(data.result);
            }


          }, error => {
            console.log('Error!!!!!');
            console.log(JSON.stringify(error));
            this.loadingController.dismiss();
            if (error.status === 409) {
              this.alert(error.error.message);
            } else {
              this.alert(constants.GENERIC_ERROR);
            }

          });
      }

    } else {
      this.loadingController.dismiss();
      this.alert('Por favor, complete todos los campos para poder generar la contraseña');
    }

  }

  async validarDNI() {
    if (this.tel && this.dniData) {

      if (this.tel.length !== 10) {
       this.alert('Por favor verifique su número de teléfono. Debe contener el código de área sin cero y sin quince, por ejemplo: "<b>2664999999</b>"');
      } else {
        const loading = await this.loadingController.create({
          message: 'Validando',
          // duration: 2000
        });
        await loading.present();

        console.log('sendPostRequest CALLED!!!!!!!');
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };

        const postData = {
          docNumber: this.dni,
          sex: this.sex,
          phoneNumber: this.tel,
          dniCode: this.dniData
        };
        console.log(JSON.stringify(postData));

        this.http.post(constants.URL_BASE_PORTAL + 'card/less/user/dni/register', postData, httpOptions)
            .subscribe((data: any) => {
              console.log('RESPONSE REGISTER!!!!');
              console.log(data);
              this.loadingController.dismiss();
              if (data.code === 'SMS') {
                this.alert(data.result);
                this.passwordGenerated = true;
                // this.navigateChangePassword();
              } else {
                this.alert(data.result);
              }


            }, error => {
              console.log('Error!!!!!');
              console.log(JSON.stringify(error));
              this.loadingController.dismiss();
              if (error.status === 409) {
                this.alert(error.error.message);
              } else {
                this.alert(constants.GENERIC_ERROR);
              }

            });
      }

    } else {
      this.loadingController.dismiss();
      this.alert('Por favor, complete todos los campos para poder generar la contraseña');
    }

  }



  async login(data: any) {
    if ((data == null && this.dni && this.sex && this.password) || data) {
      this.storage.remove('token');
      this.storage.remove('tokenRM');
      this.loading();

      setTimeout(() => {



        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };

        console.log(this.dni);
        console.log(data);
        const postData = data != null ? data : {
          docType: 'DNI',
          docNumber: this.dni,
          sex: this.sex,
          password: this.password
        };
        console.log('LOGIN PP DATA!!!');
        console.log(JSON.stringify(postData));



        this.http.post(constants.URL_BASE_PORTAL + 'token/mobile/login', postData, httpOptions)
          .subscribe((data: any) => {
            
            this.storage.set('psw', postData);
            this.storage.set('token', data.authToken.token);
            this.storage.set('userId', data.user.userId);
            this.storage.set('liquidations', data.liquidations);
            this.storage.set('externalDocument', data.externalDocument);
            this.storage.set('judicialExpedient', data.judicialExpedient);
            this.storage.set('phoneNumber', data.phoneNumber);
            // this.storage.set('docNumber', data.user.docNumber);
            // this.storage.set('sex', data.user.sex);
            this.storage.set('userData', data.user);
            
            this.token = data.authToken.token;

            this.mustGeneratePassword = data.mustChangeCode;

            this.navigate(postData);

          }, error => {
            console.log('Error!!!!!');
            console.log(JSON.stringify(error));
            // this.loadingController.dismiss();
            if (error.status === 409) {
              this.alert(error.error.message);
            } else if (error.status === 401) {
              this.alert(error.error.message);
            } else {
              this.alert('Ocurrió un problema al autenticarse, por favor intente nuevamente');
            }
            this.isLogged = true;
            this.passwordGenerated = true;
            this.storage.clear();

          });

      }, 1000);

    } else {
      if (data == null) {
        this.loadingController.dismiss();
        this.alert('Por favor, complete todos los campos para poder ingresar');
      }
    }

  }

  async loginTest(data: any) {
      this.loading();
      setTimeout(() => {
        const postData = data != null ? data : {
          docType: 'DNI',
          docNumber: '32811727',
          sex: 'M',
          password: '1234'
        };
        console.log('LOGIN PP DATA!!!');
        console.log(JSON.stringify(postData));
        this.http2.sendRequest(constants.URL_BASE_PORTAL + 'token/mobile/login',
            {
              method: 'post',
              data: postData,
              headers: { 'Content-Type': 'application/json' },
              timeout: 5000
            }
        )
            .then(response => {
              this.loadingController.dismiss();
              console.log(response.status);
            })
            .catch(response => {
              this.loadingController.dismiss();
              console.log(' RESPONSE Error!!!!!');
              console.log(response.status);
              console.log(response.error);
            });
      }, 1000);
      // setTimeout(() => {
      //   const httpOptions = {
      //     headers: new HttpHeaders({
      //       'Content-Type': 'application/json',
      //       Accept: 'application/json'
      //     }),
      //     response: new HttpResponse({
      //       headers: new HttpHeaders({
      //         'Content-Type': 'application/json',
      //         Accept: 'application/json'
      //       }),
      //     })
      //   };
      //   console.log(this.dni);
      //   console.log(data);
      //   const postData = data != null ? data : {
      //     docType: 'DNI',
      //     docNumber: '32811727',
      //     sex: 'M',
      //     password: '1234'
      //   };
      //   console.log('LOGIN PP DATA!!!');
      //   console.log(JSON.stringify(postData));
      //   this.http2.post(constants.URL_BASE_PORTAL + 'token/mobile/login', postData, httpOptions)
      //       .then( response => {
      //         this.loadingController.dismiss();
      //         console.log(constants.URL_BASE_PORTAL + 'token/mobile/login');
      //         console.log(JSON.stringify(postData));
      //         console.log('RESPONSE LOGIN PP!!!');
      //         console.log(JSON.stringify(response));
      //
      //       }
      //       // , error => {
      //       //   console.log(' RESPONSE Error!!!!!');
      //       //   console.log(JSON.stringify(error));
      //       //   if (error.status === 409) {
      //       //     this.alert(error.error.message);
      //       //   } else if (error.status === 401) {
      //       //     this.alert(error.error.message);
      //       //   } else {
      //       //     this.alert('Ocurrió un problema al autenticarse, por favor intente nuevamente');
      //       //   }
      //       //   this.isLogged = true;
      //       //   this.passwordGenerated = true;
      //       //   this.storage.clear();
      //       //
      //       // }
      //       ).catch(response => {
      //     this.loadingController.dismiss();
      //     console.log('CATCH Error!!!!!');
      //     console.log(JSON.stringify(response));
      //     console.log(JSON.stringify(response.status));
      //     console.log(JSON.stringify(response.error));
      //   });
      //
      // }, 1000);
  }

  async loginRm(dataPP: any) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json'
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    const postData = {
      apiCode: constants.API_CODE,
      externalToken: 'Bearer ' + dataPP.token
    };
    this.http.post(constants.URL_RM + 'token/external/login', postData, httpOptions)
      .subscribe((data: any) => {
        console.log(data);

        console.log('RESPONSE LOGIN RM!!: ' + data[0].authToken);

        this.storage.set('tokenRM', data[0].authToken.token);

       // this.loginGe(dataPP);

      }, error => {
        console.log('Error!!!!!');
        console.log(error);

        // this.loginGe(dataPP);

      });
  }


  async loginGe(dataPP: any) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json'
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    this.http.get(constants.URL_GE + 'token/portal/login/docNumber/' + dataPP.claims.docNumber + '/sex/' + dataPP.claims.sex, httpOptions)
      .subscribe((data: any) => {
        console.log(data);
        this.loadingController.dismiss();

        this.dni = '';
        this.tel = '';
        this.sex = '';

        console.log('RESPONSE LOGIN GE!!: ');

        console.log(data);

        this.storage.set('tokenGE', data.token);


       // this.navigate();

      }, error => {
        console.log('Error!!!!!');
        console.log(error);
        this.loadingController.dismiss();

       // this.navigate();

      });
  }

  navigate(loginData: any) {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        height: this.height,
        width: this.width,
        password: loginData.password,
        token: this.token,
        dni: loginData.docNumber,
        sex: loginData.sex
      }
    };
    if (this.mustGeneratePassword) {
      this.navController.navigateRoot('/change-password', navigationExtras);
    } else {
      this.navController.navigateRoot('/home', navigationExtras);
    }

  }

  navigateChangePassword() {
    const navigationExtras: NavigationExtras = {
      state: {
        height: this.height,
        width: this.width,
        password: this.password,
        token: this.token,
        dni: this.dni,
        sex: this.sex
      }
    };
    this.navController.navigateRoot('/change-password', navigationExtras);

  }

}
