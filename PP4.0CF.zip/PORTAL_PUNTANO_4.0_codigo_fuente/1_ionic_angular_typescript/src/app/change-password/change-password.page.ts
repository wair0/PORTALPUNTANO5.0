import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {constants} from '../utils/constants';
import {NavigationExtras, Router} from '@angular/router';
import {AlertController, LoadingController, NavController} from '@ionic/angular';
import {Storage} from '@ionic/storage';
import {from} from 'rxjs';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.page.html',
  styleUrls: ['./change-password.page.scss'],
})
export class ChangePasswordPage implements OnInit {
  code: any;
  oldPassword: any;
  hideOldPassword = true;
  oldPasswordType = 'password';
  password: any;
  hidePassword = true;
  passwordType = 'password';
  passwordRepeat: any;
  hidePasswordRepeat = true;
  passwordTypeRepeat = 'password';
  height: any;
  width: any;
  token: string;
  passwordParam: any;
  dni: any;
  sex: any;
  fromHome = false;


  constructor(private location: Location, private loadingController: LoadingController,
              private router: Router, public navController: NavController,
              private storage: Storage, private http: HttpClient,
              private alertController: AlertController) {

    if (this.router.getCurrentNavigation().extras.state) {
      if (this.router.getCurrentNavigation().extras.state.height) {
        this.height = this.router.getCurrentNavigation().extras.state.height;
      }
      if (this.router.getCurrentNavigation().extras.state.width) {
        this.width = this.router.getCurrentNavigation().extras.state.width;
      }
      if (this.router.getCurrentNavigation().extras.state.password) {
        this.passwordParam = this.router.getCurrentNavigation().extras.state.password;
      }
      if (this.router.getCurrentNavigation().extras.state.token) {
        this.token = this.router.getCurrentNavigation().extras.state.token;
      }
      if (this.router.getCurrentNavigation().extras.state.dni) {
        this.dni = this.router.getCurrentNavigation().extras.state.dni;
      }
      if (this.router.getCurrentNavigation().extras.state.sex) {
        this.sex = this.router.getCurrentNavigation().extras.state.sex;
      }
      if (this.router.getCurrentNavigation().extras.state.fromHome) {
        this.fromHome = this.router.getCurrentNavigation().extras.state.fromHome;
      }
    }
  }

  ngOnInit() {
  }

  async loading() {
    const loading = await this.loadingController.create({
      message: 'Cargando',
    });
    await loading.present();
  }

  async alert(messageText: string) {
    this.loadingController.dismiss();
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
          }
        }
      ]
    });

    await alert.present();
  }

  async alertChangePassword(messageText: string, data: any) {
    this.loadingController.dismiss();
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
          }
        },
        {
          text: 'Aceptar',
          cssClass: 'primary',
          handler: () => {
            this.loading();
            this.sendPassword(data);
          }
        }
      ]
    });

    await alert.present();
  }

  changeHidePassword() {
    if (!this.hidePassword) {
      this.passwordType = 'password';
    } else {
      this.passwordType = 'text';
    }
    this.hidePassword = !this.hidePassword;
  }

  changePassword() {
    this.location.back();
  }

  changeHidePasswordRepeat() {
    if (!this.hidePasswordRepeat) {
      this.passwordTypeRepeat = 'password';
    } else {
      this.passwordTypeRepeat = 'text';
    }
    this.hidePasswordRepeat = !this.hidePasswordRepeat;
  }

  changeHideOldPassword() {
    if (!this.hideOldPassword) {
      this.oldPasswordType = 'password';
    } else {
      this.oldPasswordType = 'text';
    }
    this.hideOldPassword = !this.hideOldPassword;
  }

  passwordAction() {

    if (this.password && this.passwordRepeat
        && this.password === this.passwordRepeat && constants.REGEX_PASSWORD.test(this.password)) {
      const data = {
          oldPassword: this.fromHome ? this.oldPassword : this.passwordParam,
          password: this.password
      };
      if (this.fromHome) {
          this.alertChangePassword('Al modificar su contraseña se cerrarán todas las sesiones que se encuentren abiertas en éste y/o en otros dispositivos', data);
      } else {
        this.loading();
        this.sendPassword(data);
      }

    } else {

      if (!this.password) {
        this.alert('Debe escribir una contraseña');
      } else
      if (!this.passwordRepeat) {
        this.alert('Debe repetir la contraseña');
      } else
      if (this.password !== this.passwordRepeat) {
        this.alert('Las contraseñas no coinciden');
      } else
      if (!constants.REGEX_PASSWORD.test(this.password)) {
        this.alert('La contraseña debe tener entre 8 y 16 caracteres, contener al menos un número, al menos una letra mayúscula y no contener espacios');
      }

    }


  }


  async sendPassword(passwordObject: any) {
      this.storage.get('token').then((val) => {
        if (val) {
          this.token = val;
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json',
              'X-Authorization': 'Bearer ' + this.token,
            }),
            observe: 'response' as any,
            response: new HttpResponse({
              headers: new HttpHeaders({
                'Content-Type': 'application/json',
                Accept: 'application/json'
              })
            })
          };
          this.http.put(constants.URL_BASE_PORTAL + 'secure/user/password', passwordObject, httpOptions)
              .subscribe((data: any) => {
                if (this.fromHome) {
                  this.storage.remove('psw');
                  this.navigateLogin();
                } else {
                  this.login();
                }
              }, error => {
                this.loadingController.dismiss();
                if (error.status === 409) {
                  this.alert(error.error.message);
                } else if (error.status === 401) {
                  this.alert(error.error.message);
                } else {
                  this.alert(constants.GENERIC_ERROR);
                }

              });
        } else {
          this.loadingController.dismiss();
          this.alert(constants.GENERIC_ERROR);
        }
      });

  }

  async login() {
      this.storage.remove('token');
      this.storage.remove('tokenRM');
      setTimeout(() => {
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };
        const postData = {
          docType: 'DNI',
          docNumber: this.dni,
          sex: this.sex,
          password: this.password
        };
        this.http.post(constants.URL_BASE_PORTAL + 'token/mobile/login', postData, httpOptions)
            .subscribe((data: any) => {

              this.storage.set('psw', postData);

              this.storage.set('token', data.authToken.token);

              this.storage.set('userId', data.user.userId);

              this.storage.set('liquidations', data.liquidations);

              this.storage.set('externalDocument', data.externalDocument);

              this.storage.set('judicialExpedient', data.judicialExpedient);

              this.token = data.authToken.token;


              this.navigate();

            }, error => {
              console.log('Error!!!!!');
              console.log(error);
              // this.loadingController.dismiss();
              if (error.status === 409) {
                this.alert(error.error.message);
              } else if (error.status === 401) {
                this.alert(error.error.message);
              } else {
                this.alert('Ocurrió un problema al autenticarse, por favor intente nuevamente');
              }
              this.storage.clear();

            });

      }, 1000);

  }



  navigate() {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        height: this.height,
        width: this.width,
      }
    };
    this.navController.navigateRoot('/home', navigationExtras);
  }

  navigateLogin() {
    this.loadingController.dismiss();
    const navigationExtras: NavigationExtras = {
      state: {
        height: this.height,
        width: this.width,
      }
    };
    this.navController.navigateRoot('/login', navigationExtras);
  }
}
