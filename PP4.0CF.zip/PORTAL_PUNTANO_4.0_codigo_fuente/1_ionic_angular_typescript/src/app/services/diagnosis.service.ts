
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { constants } from 'src/app/utils/constants';
import { BusDiagnosisEvolutionDto } from '../core/models/BusDiagnosisEvolutionDto';

@Injectable()
export class DiagnosisService {

    constructor(
        private http: HttpClient,
    ) {}
    
    getDiagnosisByPatientId(patientId: number){
        return this.http.get<any>(`${constants.URL_RM_PREFIX}diagnosis/patient/${patientId}`);
    }
    
    getDiagnosisEvolutionByDiagnosisIdAndPatientId(diagnosisEvolutionId: number, patientId: number) {
        return this.http.get<BusDiagnosisEvolutionDto[]>(`${constants.URL_RM_PREFIX}diagnosisEvolutions/${diagnosisEvolutionId}/patient/${patientId}`);
    }
    
    postHiddenDiagnosisPermission(patientId: number, diagnosisId: number, professionalIds: number[]) {
        return this.http.post(`${constants.URL_RM_PREFIX}patient/${patientId}/hiddenDiagnosis/${diagnosisId}/addPermission`, professionalIds)
    }
    
    deleteHiddenDiagnosisPermission(patientId: number, diagnosisId: number, professionalIds: number[]) {
        const httpOptions = {
            headers: new HttpHeaders({ 'Content-Type': 'application/json' }), 
            body: professionalIds
        };
        return this.http.delete(`${constants.URL_RM_PREFIX}patient/${patientId}/hiddenDiagnosis/${diagnosisId}/removePermission`, httpOptions)
    }

}