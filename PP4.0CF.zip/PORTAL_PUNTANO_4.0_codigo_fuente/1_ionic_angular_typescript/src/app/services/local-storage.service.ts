import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {

constructor(
  private storage: Storage,
  ) { }

  getUserData() {
    return this.storage.get("userData")
  }

}
