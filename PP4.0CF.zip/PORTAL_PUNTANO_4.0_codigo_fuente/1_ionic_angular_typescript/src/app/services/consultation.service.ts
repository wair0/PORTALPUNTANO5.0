
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { constants } from 'src/app/utils/constants';
import { BusConsultationDto } from '../core/models/BusConsultationDto';
import { BusConsultationGroupDto } from '../core/models/BusConsultationGroupDto';
 
interface ConsultationsPaginatedDto {
    patientId: number
    dateFrom?: string
    specialtyId?: number
    size?: number
}
@Injectable()
export class ConsultationService {

    constructor(
        private http: HttpClient,
    ) {}

    getConsultationsByPatientId(parameters: ConsultationsPaginatedDto){
        let params = ""
        if(parameters.specialtyId)
            params += "specialtyId=" + parameters.specialtyId + "&"
        if(parameters.size)
            params += "size=" + parameters.size + "&"
        if(parameters.dateFrom)
            params += "dateFrom=" + parameters.dateFrom + "&"

        return this.http.get<BusConsultationDto[]>(`${constants.URL_RM_PREFIX}consultations/patient/${parameters.patientId}/?${params}`);
    }
    
    getConsultation(id: number) {
        return this.http.get<BusConsultationGroupDto>(`${constants.URL_RM_PREFIX}consultation/${id}`);
    }
    
    getConsultationPdf(pathName: string){
        return this.http.get<string>(`${constants.URL_RM_PREFIX}patient/pdf/${pathName}`);
    }

    getConsultationsWithStudiesByPatientId(patientId: number) {
        let code = "P"
        return this.http.get<BusConsultationDto[]>(`${constants.URL_RM_PREFIX}consultations/patient/${patientId}/code/${code}`);
    }
    
    getConsultationsWithPrescriptionsByPatientId(patientId: number) {
        let code = "M"
        return this.http.get<BusConsultationDto[]>(`${constants.URL_RM_PREFIX}consultations/patient/${patientId}/code/${code}`);
    }
}