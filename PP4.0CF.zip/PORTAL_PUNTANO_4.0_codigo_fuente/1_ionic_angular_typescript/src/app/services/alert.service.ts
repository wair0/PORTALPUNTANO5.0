
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { constants } from 'src/app/utils/constants';
import { AlertController, NavParams } from '@ionic/angular';

interface showAlertDto {
  header?: string,
  message?: string,
  buttons?: string[]
}


@Injectable()
export class AlertService {

  constructor(
    private alertController: AlertController
  ) { }

  async showCustomAlert(params: showAlertDto) {
    const alert = await this.alertController.create({
      header: params.header ? params.header : "Portal Puntano",
      message: params.message,
      buttons: params.buttons ? params.buttons : ["OK"]
    });
    await alert.present();
  }

  async showErrorAlert(message?: string) {
    const alert = await this.alertController.create({
      header: "Portal Puntano",
      message: message ? message : "¡Ups! Ha ocurrido un problema.",
      buttons: ["OK"]
    });
    await alert.present();
  }


}