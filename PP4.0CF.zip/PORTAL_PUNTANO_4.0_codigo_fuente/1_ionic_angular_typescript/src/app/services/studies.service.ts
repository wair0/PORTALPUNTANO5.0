
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { constants } from 'src/app/utils/constants';
import { BusConsultationDto } from '../core/models/BusConsultationDto';
import { BusConsultationGroupDto } from '../core/models/BusConsultationGroupDto';
import { BusComplementaryStudiesDto } from '../core/models/BusComplementaryStudiesDto';
 
@Injectable()
export class StudiesService {

    constructor(
        private http: HttpClient,
    ) {
        
    }

    getStudiesByConsultationId(consultationId: number) {
      return this.http.get<BusComplementaryStudiesDto[]>(`${constants.URL_RM_PREFIX}studies/consultationId/${consultationId}`);
    }
    

   
}