import { Injectable } from '@angular/core';
import { LocalNotifications , ILocalNotificationActionType } from '@ionic-native/local-notifications/ngx';
import {AlertController, LoadingController} from '@ionic/angular';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {constants} from '../utils/constants';
import { Storage } from '@ionic/storage';
import {NavigationExtras, Router} from '@angular/router';
//import {LocationService} from '../location/location.service';
declare var SockJS;
declare var Stomp;
@Injectable({
  providedIn: 'root'
})
export class MessageService {
  constructor(
      private localNotifications: LocalNotifications,
      private alertController: AlertController,
      private storage: Storage,
      private http: HttpClient,
      private router: Router,
      private loadingController: LoadingController) {
    // Verifico la existencia del token y traigo el id del driver
    this.storage.get('token').then((val3) => {
      this.token = val3;
      this.getDriver();
    });
    // Quedo a la escucha del evento de click sobre la notificación
    this.localNotifications.on('click').subscribe(data => {
         
       });
  }
  clickSub: any;
  token: any;
  driverID: any;
  travelID: any;
  NotificationID: any;

  public stompClient;
  public msg = [];
  // SOCKETS 
  initializeWebSocketConnection() {
    const serverUrl = constants.URL_BASE_PORTAL + 'socket';
    const ws = new SockJS(serverUrl);

    this.stompClient = Stomp.over(ws);

    this.stompClient.heartbeat.outgoing = 30000;
    this.stompClient.heartbeat.incoming = 120000;
    const that = this;
    // tslint:disable-next-line:only-arrow-functions
    if ( this.driverID ) {
      this.stompClient.connect({}
          // tslint:disable-next-line:only-arrow-functions
          , function(
              frame: any) {
            console.log(' Conectado ');
            that.stompClient.subscribe('/topic/driver/' + that.driverID, (message) => {
              console.log('Llegó la push');
              if (message.body) {
                that.simpleNotif((JSON.parse(message.body)));
              }
            });
          }
          // En caso de que se desconecte
          , (message: any) => {
            console.log('Reconectando en 60 segundos...');
            setTimeout(
                () => {
                  this.initializeWebSocketConnection();
                }
                , 60000);
          }
      );
      // En caso de que no tenga id de Driver
    } else {
      console.log('Reconectando en 60 segundos...');
      setTimeout(
          () => {
            this.initializeWebSocketConnection();
          }
          , 60000);
    }
  }
  // NOTIFICATION
  simpleNotif(message) {
    // Elimino antigua notificacion y dejo solo la última
    if ( this.travelID ) {
      this.localNotifications.cancel(this.travelID);
    }

    this.travelID =  message.travelId;

    this.localNotifications.schedule([{
      id: message.travelId ,
      text: message.largeMessage,
      data: { info: message.largeMessage },
      icon: 'res://icon.png',
      smallIcon: 'res://icon.png'
    }]);

  }
  // NAVIGATION
  async navigateTravels(travels: any) {

    const navigationExtras: NavigationExtras = {
      replaceUrl: true,
      state: {
        token: this.token,
        travels
      }
    };
    this.storage.set('update-travels-list',  (this.router.url === '/travels') );
    // this.storage.set('update-travels-list',  true );
    await this.router.navigateByUrl('/splash');
    this.router.navigateByUrl('/travels', navigationExtras);
    this.loadingController.dismiss();

  }
  // // REQUEST HTTP
  async getTravels() {

    setTimeout(() => {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json',
          Authorization: 'Bearer ' + this.token
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json'
          }),
        })
      };

      this.http.get(constants.URL_BASE_PORTAL + 'mobile/travel/currentDriverUser', httpOptions)
          .subscribe((data: any) => {
            console.log(data);
            this.loadingController.dismiss();
            this.navigateTravels(data);
          }, error => {
            console.log('Error!!!!!');
            console.log(JSON.stringify(error));
            this.loadingController.dismiss();
            if (error.status === 409) {
              this.alert(error.error.message);
            } else {
              this.alert(constants.GENERIC_ERROR);
            }
          });
    }, 1000);
  }
  async getDriver() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: 'Bearer ' + this.token
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };
    const that = this;
    this.http.get(constants.URL_BASE_PORTAL + 'user/currentUser' , httpOptions)
        .subscribe((data: any) => {
          console.log(data.id);
          that.driverID = data.id;
          that.initializeWebSocketConnection();
        }, error => {
          console.log('Error!!!!!');
          console.log(JSON.stringify(error));
        });
  }
  // // PLUGINS
  async loading() {
    this.loadingController.dismiss();
    const loading = await this.loadingController.create({
      message: 'Cargando',
    });
    await loading.present();
    setTimeout(() => loading.dismiss(), 3000 );

  }
  async alert(messageText: string) {
    this.loadingController.dismiss();
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }
  async presentAlert(data) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: data,
      buttons: ['OK']
    });
    await alert.present();
  }
  unsub() {
    this.clickSub.unsubscribe();
  }

}
