import { HttpClient } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { constants } from "../utils/constants";

@Injectable()
export class HealthCertificateApiService {

  constructor(
    private http: HttpClient,
  ) { }


  getByPatientParams(docNumber: string, sex: string) {
    let path: string = `${constants.URL_RM_PREFIX}health-certificate/patient/${docNumber}/sex/${sex}`;
    return this.http.get<any>(path);
  }
}
