
import { Injectable } from '@angular/core';
import { HttpClient, } from '@angular/common/http';
import { LoadingController } from '@ionic/angular';
import { constants } from 'src/app/utils/constants';
import { UserDto } from "../core/models/UserDto";
import { HealthCenterDto } from "../core/models/HealthCenterDto";

@Injectable()
export class ShiftService {

    constructor(
        private http: HttpClient,
        private loadingController: LoadingController,
    ) { }

    async loading() {
        const loading = await this.loadingController.create({
            message: 'Cargando',
        });
        await loading.present();
    }

    getSpecialty(param: any, header: any) {
        if (param) {
            return this.http.get(constants.URL_BASE_PORTAL + `secure/specialty${param}`, header);
        } else {
            return this.http.get(constants.URL_BASE_PORTAL + 'secure/specialty', header);
        }
    }


    getService(header: any, param: String) {
        return this.http.get(constants.URL_BASE_PORTAL + `secure/services/${param}`, header);
    }


    getDependents(header: any) {
        return this.http.get(constants.URL_BASE_PORTAL + `secure/dependents`, header);
    }

    getShifts(header: any, param: any) {
        return this.http.get(constants.URL_BASE_PORTAL + `secure/services/${param}`, header);
    }

    assignShifts(header: any, model: any) {
        return this.http.post(constants.URL_BASE_PORTAL + `secure/appointment/assign`, model, header);
    }

    getAppointmentsRM(header: any, param: any) {
        if (param) {
            return this.http.get(constants.URL_BASE_PORTAL + `secure/appointments/rm/${param}`, header);
        } else {
            return this.http.get(constants.URL_BASE_PORTAL + `secure/appointments/rm`, header);
        }
    }

    getAppointmentsRC(header: any) {

        return this.http.get(constants.URL_BASE_PORTAL + `secure/appointments/rc`, header);

    }

    updateAppointmentCancel(header: any, appointmentId: any) {
        return this.http.delete(constants.URL_BASE_PORTAL + `/secure/appointment/${appointmentId}/cancel`, header);
    }

    getHealthCenterByPersonData(personData: UserDto, header) {
        return this.http.get(constants.URL_RM_PREFIX + `externalPersonHealthCenters/${personData.docNumber}/${personData.sex}/${personData.docType}`, header);
    }

    getProfessionalsBySpecialtyCode(specialtyCode: string, healthCenterId: string, header) {
        return this.http.get(constants.URL_RM_PREFIX + `professionals/${specialtyCode}/${healthCenterId}`, header)
    }

}