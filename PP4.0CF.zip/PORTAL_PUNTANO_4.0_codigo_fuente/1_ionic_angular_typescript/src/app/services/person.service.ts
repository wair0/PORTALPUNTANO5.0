import { HttpClient, HttpHeaders, HttpResponse } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import { RemotePersonDto } from "../core/models/RemotePersonDto";
import { constants } from "../utils/constants";


@Injectable({
  providedIn: 'root'
})
export class PersonService {

  token: any;
  userId: any;

  constructor(
    private http: HttpClient,
    private storage: Storage,
  ) {
    this.storage.get('token').then((val) => {
      if (val) {
        this.token = val;
      }
    })
    this.storage.get('userId').then((val2) => {
      if (val2) {
        this.userId = val2
      }
    })
  }

  searchPerson(docNumber: number, sex: string, birthDate: string) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.token
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };
    
    let extraParams = ''
    if (birthDate) {
      extraParams += `birthDate=${birthDate}`;
    }

    return this.http.get<RemotePersonDto>(`${constants.URL_BASE_PORTAL}secure/person/${docNumber}/${sex}?${extraParams}`, httpOptions)
  }

  getCodeValidation(phoneNumber: number) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.token
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };
    return this.http.get<number>(`${constants.URL_BASE_PORTAL}secure/person/${this.userId}/sms/${phoneNumber}`, httpOptions)

  }
}
