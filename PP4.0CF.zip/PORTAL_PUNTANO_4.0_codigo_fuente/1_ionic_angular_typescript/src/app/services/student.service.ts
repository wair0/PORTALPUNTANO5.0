
import { Injectable } from '@angular/core';
import { map,catchError } from "rxjs/operators";
import { HttpClient, HttpHeaders, HttpResponse, } from '@angular/common/http';


//import {constants} from '../utils/constants';
//import { AppSettings } from '../app.settings';
//import { LoadingService } from './util/loading.service';
import { LoadingController, AlertController,NavController } from '@ionic/angular';

import { Storage } from '@ionic/storage';
import { constants } from 'src/app/utils/constants';
//import { NgProgress } from 'ngx-progressbar';
 
@Injectable()
export class StudentService {
    httpOptions: { headers: HttpHeaders; response: HttpResponse<unknown>; };

    constructor(private http: HttpClient,
        private loadingController: LoadingController,
        private storage: Storage,
        private alertController: AlertController,
         ) {
        
    }

    async loading(){
        const loading = await this.loadingController.create({
          message: 'Cargando',
        });
        await loading.present();
    }

    getStudents(options:any){
        return this.http.get(constants.URL_BASE_PORTAL + `secure/education/student/tutor`, options);
    }
    getStudentsWithMap(options:any){
        return this.http.get(constants.URL_BASE_PORTAL + `secure/sportMap/maps`, options);
    }

    getRegistrationByStudent(studentId:any, schoolCycleId:any, options:any){
        return this.http.get(constants.URL_BASE_PORTAL + `/secure/education/studentId/${studentId}/schoolCycle/${schoolCycleId}`, options);
    }

    getSchoolCycleByPersonId(personId:any, options:any){     
      return this.http.get(constants.URL_BASE_PORTAL + `secure/education/schoolCycle/person/${personId}`, options);       
    }

    getSportMap(docNumber: any , sex: any , options: any){
        return this.http.get(constants.URL_BASE_PORTAL + `secure/sportMap/person/docNumber/${docNumber}/sex/${sex}`, options);  
    }
        
    getResultTest(studentId:any, schoolCycleId:any, param:any, options:any){
        if(param){
            return this.http.get(constants.URL_BASE_PORTAL + `secure/education/test/studentId/${studentId}/schoolCycle/${schoolCycleId}${param}`, options);  
        }
        // else{
        //     return this.http.get(constants.URL_BASE_PORTAL + `secure/education/test/studentId/${studentId}/schoolCycle/${schoolCycleId}`, options);  
        // }              
    }

    getSubjects(studentId ,schoolCycleId, options){
        return this.http.get(constants.URL_BASE_PORTAL + `secure/education/subjects/studentId/${studentId}/schoolCycle/${schoolCycleId}`, options);   
    }

    getAssistanceOfStudent(studentId , dateFrom , dateTo , param , options) {
        return this.http.get(constants.URL_BASE_PORTAL + `secure/education/studentId/${studentId}/concurrence/dateFrom/${dateFrom}/dateTo/${dateTo}${param}`, options); 
    }

    getReportCardByStudentAndCicle(studentId:any, schoolCycleId:any, httpOption:any){
        return this.http.get(constants.URL_BASE_PORTAL + `secure/education/studentId/${studentId}/schoolCycle/${schoolCycleId}/reportCard`,httpOption);
    }

    getAnalytics(docNumber: any, httpOption: any) {
        return this.http.get(constants.URL_BASE_PORTAL + `secure/education/analyticalCertificate/docNumber/${docNumber}`,httpOption);
    }
}