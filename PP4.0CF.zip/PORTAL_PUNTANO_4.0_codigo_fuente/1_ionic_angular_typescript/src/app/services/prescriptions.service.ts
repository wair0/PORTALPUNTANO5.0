
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { constants } from 'src/app/utils/constants';
import { BusPrescriptionDto } from '../core/models/BusPrescriptionDto';
 
@Injectable()
export class PrescriptionsService {

    constructor(
        private http: HttpClient,
    ) {
        
    }

    getPrescriptionByConsultationId(consultationId: number) {
      return this.http.get<BusPrescriptionDto[]>(`${constants.URL_RM_PREFIX}prescriptions/consultation/${consultationId}?benefitType=M`);
    }
    
}