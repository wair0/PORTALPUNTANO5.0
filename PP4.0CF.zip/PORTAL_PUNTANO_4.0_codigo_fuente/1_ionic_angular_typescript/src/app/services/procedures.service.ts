import { HttpClient, HttpHeaders, HttpResponse } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { constants } from "../utils/constants";
import { Storage } from '@ionic/storage';
import { ProcedureType } from "../core/models/ProcedureType";
import { ProcedureTypeAttr } from "../core/models/ProcedureTypeAttr";

@Injectable({
  providedIn: 'root'
})
export class ProceduresService {

  token: any;
  userId: any;

  constructor(
    private http: HttpClient,
    private storage: Storage,
  ) {
    this.storage.get('token').then((val) => {
      if (val) {
        this.token = val;
      }
    })
    this.storage.get('userId').then((val2) => {
      if (val2) {
        this.userId = val2
      }
    })
  }


  getCurrentProcedures(status: string, size?: number) {
    let sizeLocal = size ? size : ''

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.token
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };
    return this.http.get<any>(`${constants.URL_BASE_PORTAL}secure/procedure/user/${this.userId}?status=${status}&search=&page=0&size=${sizeLocal}&sort=dateCreated,desc`, httpOptions)
  }

  getDetailsProcedures(procedureId: number) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.token
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };
    return this.http.get<any>(`${constants.URL_BASE_PORTAL}secure/procedure/${procedureId}`, httpOptions)
  }

  generateNewProcedure(proceduretypeId: number) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.token
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };
    return this.http.get<ProcedureType>(`${constants.URL_BASE_PORTAL}secure/proceduretype/${proceduretypeId}/user/${this.userId}`, httpOptions)
  }

  getProcedureAttrs(procedureTypeId: number, group: number, step: number) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.token
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };
    return this.http.get<ProcedureTypeAttr[]>(`${constants.URL_BASE_PORTAL}secure/proceduretypeattr/${procedureTypeId}/step/${step}/group/${group + 1}?userId=${this.userId}`, httpOptions);
  }

  createProcedure(body: ProcedureType) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.token
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    return this.http.post(`${constants.URL_BASE_PORTAL}secure/procedure/`, JSON.stringify(body), httpOptions)
  }
}
