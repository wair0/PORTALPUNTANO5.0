
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { constants } from 'src/app/utils/constants';
import { BusSpecialtyDto } from '../core/models/BusSpecialtyDto';
import { BusProfessionalDto } from '../core/models/BusProfessionalDto';

@Injectable()
export class PatientService {

  constructor(
    private http: HttpClient,
  ) { }

  getPatientIdByDocNumberAndSex(docNumber: number, sex: string) {
    const documentType: string = "DNI"
    return this.http.get<number>(`${constants.URL_RM_PREFIX}patient/${docNumber}/${sex}/${documentType}`);
  }
  
  getSpecialtiesByPatientId(patientId: number) {
    return this.http.get<BusSpecialtyDto[]>(`${constants.URL_RM_PREFIX}specialties/${patientId}`);
  }
  
  getProfessionalsByPatientId(patientId: number){
    return this.http.get<BusProfessionalDto[]>(`${constants.URL_RM_PREFIX}patient/${patientId}/professionals`);
  }

}