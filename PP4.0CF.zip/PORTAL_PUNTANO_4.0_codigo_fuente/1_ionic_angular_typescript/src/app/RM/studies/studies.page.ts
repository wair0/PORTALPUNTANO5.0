import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { Storage } from '@ionic/storage';
import { RefreshUtils } from '../../utils/refreshUtils';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { PatientService } from 'src/app/services/patient.service';
import { AlertService } from 'src/app/services/alert.service';
import { ConsultationService } from 'src/app/services/consultation.service';
import { BusConsultationDto } from 'src/app/core/models/BusConsultationDto';

@Component({
  selector: 'app-studies',
  templateUrl: 'studies.page.html',
  styleUrls: ['studies.page.scss'],
})
export class StudiesPage implements OnInit {

  //TODO: tipar userData
  userData: any
  patientId: number
  consultations: BusConsultationDto[]


  constructor(
    private statusBar: StatusBar,
    private route: ActivatedRoute,
    private router: Router,
    private screenOrientation: ScreenOrientation,
    private navController: NavController,
    private refreshUtils: RefreshUtils,
    private consultationService: ConsultationService,
    private localStorageService: LocalStorageService,
    private patientService: PatientService,
    private alertService: AlertService,
  ) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.consultations = this.router.getCurrentNavigation().extras.state.studies;
      }
    });
  }

  ionViewWillEnter(){
    this.statusBar.backgroundColorByHexString('#EC272F');
  }

  ngOnInit() {
    this.localStorageService.getUserData().then(userData => {
      this.userData = userData
      this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(patientId => {
        this.patientId = patientId
        this.consultationService.getConsultationsWithStudiesByPatientId(patientId).subscribe(response => {
          this.consultations = response
        }, error => {
          if (error.message)
            this.alertService.showErrorAlert(error.message)
          else
            this.alertService.showErrorAlert()
        })
      })
    })
  }

  goToStudy(consultation: any) {
    let navigationExtras: NavigationExtras = {
      state: {
        consultation: consultation,
      }
    };
    this.router.navigate(['study'], navigationExtras)
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

}