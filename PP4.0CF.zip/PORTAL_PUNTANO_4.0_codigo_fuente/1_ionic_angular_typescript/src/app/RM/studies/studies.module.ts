import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { StudiesPage } from './studies.page';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {RefreshUtils} from '../../utils/refreshUtils';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { AlertService } from 'src/app/services/alert.service';
import { StudiesService } from 'src/app/services/studies.service';
import { PatientService } from 'src/app/services/patient.service';
import { InterceptorRm } from 'src/app/core/interceptors/interceptor-rm.service';
import { ConsultationService } from 'src/app/services/consultation.service';


@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      HttpClientModule,
      RouterModule.forChild([
        {
          path: '',
          component: StudiesPage
        }
      ])
    ],
    providers: [
      HttpClient,
      RefreshUtils,
      LocalStorageService,
      AlertService,
      PatientService,
      ConsultationService,
      {
        provide: HTTP_INTERCEPTORS,
        useClass: InterceptorRm,
        multi: true
      }
    ],
    declarations: [StudiesPage]
  })
  
  export class StudiesModule {}