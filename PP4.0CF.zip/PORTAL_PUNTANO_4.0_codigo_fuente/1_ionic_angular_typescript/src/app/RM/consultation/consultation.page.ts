import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import { Router, ActivatedRoute } from '@angular/router';
import { Storage } from '@ionic/storage';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { constants } from '../../utils/constants';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Platform } from '@ionic/angular';
import { DeviceDetailsService } from '../../device/device.service';
import { ConsultationService } from 'src/app/services/consultation.service';
import { BusConsultationGroupDto } from 'src/app/core/models/BusConsultationGroupDto';

@Component({
  selector: 'app-consultation',
  templateUrl: 'consultation.page.html',
  styleUrls: ['consultation.page.scss'],
})
export class ConsultationPage implements OnInit {

  consultation: BusConsultationGroupDto;
  public token: String;
  public fileTransfer: FileTransferObject;
  consultationId: number

  constructor(
    private alertController: AlertController,
    private loadingController: LoadingController,
    private storage: Storage,
    private route: ActivatedRoute,
    private router: Router,
    private transfer: FileTransfer,
    private file: File,
    private fileOpener: FileOpener,
    private deviceDetailsService: DeviceDetailsService,
    private screenOrientation: ScreenOrientation,
    private statusBar: StatusBar,
    private navController: NavController,
    private platform: Platform,
    private consultationService: ConsultationService,
  ) {
    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
  }

  ionViewWillEnter(){
    this.statusBar.backgroundColorByHexString('#EC272F');
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.consultationId = this.router.getCurrentNavigation().extras.state.consultationId;
        this.consultationService.getConsultation(this.consultationId).subscribe(response => {
          this.consultation = response
        })
      }
    });
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

  async download(path: any) {
    this.loadingWithMessage("Descargando")
    this.storage.get('token').then((val) => {
      if (val) {
        this.token = val;

        let fileName = "Consulta_" + this.consultationId + ".pdf";

        let filePath = `${constants.URL_RM_PREFIX}patient/pdf/${path}`;
        // let filePath = constants.URL_RM + "secure/external/mobile/files/download/pdf/consultation/" + this.consultationId;
        
        let url = encodeURI(filePath);
        this.fileTransfer = this.transfer.create();

        let options = {
          headers: {
            "X-Authorization": "Bearer " + this.token
          }
        };

        let directory = this.file.documentsDirectory;

        // if (this.platform.is("android")) {
        //   if(this.file.externalRootDirectory){
        //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
        //     }else{
        //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
        //     }
        // }

        if (this.platform.is("android")) {
          let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
          //if(this.file.externalRootDirectory){
          console.log("[HOME] OS VERSION: " + soVersion);
          if (soVersion < 11) {
            if(this.file.externalRootDirectory){
              directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
            }else{
              directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
            }
          }else{
            directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
          }
        }

        this.fileTransfer.download(url, directory + fileName, true, options).then((entry) => {
          this.loadingController.dismiss();
          //here logging our success downloaded file path in mobile. 
          console.log('download completed: ' + entry.toURL());

          this.file.resolveDirectoryUrl(directory).then((rootDir) => {
            this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
              fileEntry.getMetadata(metadata => {
                if (metadata.size != 0) {
                  // open downloaded file 
                  this.openFileHandler(entry.toURL());

                  if (this.platform.is("android")) {
                    let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                    if (soVersion < 11) {
                      if(this.file.externalRootDirectory){
                        this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + constants.FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                      }
                    }
                  }

                } else {
                  this.alert(constants.FILE_SIZE_0_ERROR);
                }
              })

            });

          });

        }).catch((error) => {
          this.loadingController.dismiss();
          if (error != null && error.http_status != null && error.http_status == 409) {
            this.alert(JSON.parse(error.body).message);
          } else {
            this.processErrorRM(error).then(value => {
              this.alert(constants.GENERIC_ERROR);
            });
          }
          
        });

      }
      else {
        this.loadingController.dismiss();
        this.alert(constants.GENERIC_ERROR);
      }
    });
  }

  async alert(messageText: string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }


  async loading() {
    const loading = await this.loadingController.create({
      message: 'Cargando',
    });
    await loading.present();
  }

  async loadingWithMessage(messageText: string) {
    const loading = await this.loadingController.create({
      message: messageText,
    });
    await loading.present();
  }

  openFileHandler(path: any) {
    this.fileOpener.open(path, "")
      .then(() => console.log('File is opened'))
      .catch(e => console.log('Error opening file', e));
  }

  async deleteDataAndExitToLogin() {

    this.storage.clear().then(() => {
      this.navController.navigateRoot("/login");
    });

  }


  processErrorRM = function (error: any) {
    return new Promise<any>((resolve, reject) => {
      console.log("Error!!!!!");
      console.log(JSON.stringify(error));
      this.loadingController.dismiss();

      this.storage.get('token').then((val: any) => {
        if (val) {
          this.loadingWithMessage("Descargando");
          this.refreshUtils.refreshTokenRM(val).then((value: any) => {
            this.loadingController.dismiss();
            resolve(value);
          }).catch((errorRefresh: { status: number; }) => {
            this.loadingController.dismiss();
            if (errorRefresh.status == 401) {
              this.alert(constants.GENERIC_ERROR);
            } else {
              this.alert(constants.GENERIC_ERROR);
            }
          });
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });

    });

  }


}
