import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ConsultationPage } from './consultation.page';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx'; 
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import {RefreshUtils} from '../../utils/refreshUtils';
import { DocumentViewer } from '@ionic-native/document-viewer/ngx';
import { ConsultationService } from 'src/app/services/consultation.service';
import { InterceptorRm } from 'src/app/core/interceptors/interceptor-rm.service';


@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      HttpClientModule,
      RouterModule.forChild([
        {
          path: '',
          component: ConsultationPage
        }
      ])
    ],
    providers: [
      HttpClient
      ,
       FileTransfer,
       FileTransferObject,
       File,
       RefreshUtils,
       FileOpener,
       DocumentViewer,
       ConsultationService,
       {
        provide: HTTP_INTERCEPTORS,
        useClass: InterceptorRm,
        multi: true
      }
    ],
    declarations: [ConsultationPage]
  })
  
  export class ConsultationModule {}