import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { BusConsultationDto } from 'src/app/core/models/BusConsultationDto';
import { BusSpecialtyDto } from 'src/app/core/models/BusSpecialtyDto';
import { AlertService } from 'src/app/services/alert.service';
import { ConsultationService } from 'src/app/services/consultation.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { PatientService } from 'src/app/services/patient.service';

@Component({
  selector: 'app-all-consultations',
  templateUrl: './all-consultations.component.html',
  styleUrls: ['./all-consultations.component.scss']
})
export class AllConsultationsComponent implements OnInit {

  consultations: BusConsultationDto[] = []
  patientId: number
  dateFrom?: any
  userData: any
  specialties: BusSpecialtyDto[]

  constructor(
    private router: Router,
    private localStorageService: LocalStorageService,
    private patientService: PatientService,
    private consultationService: ConsultationService,
    private alertService: AlertService
  ) { }

  ngOnInit() {
    this.localStorageService.getUserData().then(userData => {
      this.userData = userData
      this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(patientId => {
        this.patientId = patientId
        //TODO: DateFrom deberia ser opcional en el back?
        this.consultationService.getConsultationsByPatientId(
          {
            patientId,
            size: 999,
            dateFrom: "1900-01-01"
          }
        ).subscribe(response => {
          this.consultations = response
        }, error => {
          if (error.message)
            this.alertService.showErrorAlert(error.message)
          else
            this.alertService.showErrorAlert()
        })
        this.patientService.getSpecialtiesByPatientId(patientId).subscribe(response => {
          this.specialties = response
        })
      })
    })
  }

  goToConsultation(id: number) {
    let navigationExtras: NavigationExtras = {
      state: {
        consultationId: id,
      }
    };
    this.router.navigate(['consultation'], navigationExtras)
  }

}
