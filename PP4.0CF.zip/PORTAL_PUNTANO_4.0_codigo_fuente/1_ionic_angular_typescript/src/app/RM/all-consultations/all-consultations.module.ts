import { CommonModule } from "@angular/common";
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { IonicModule } from "@ionic/angular";
import { InterceptorRm } from "src/app/core/interceptors/interceptor-rm.service";
import { AlertService } from "src/app/services/alert.service";
import { ConsultationService } from "src/app/services/consultation.service";
import { PatientService } from "src/app/services/patient.service";
import { RefreshUtils } from "src/app/utils/refreshUtils";
import { AllConsultationsComponent } from "./all-consultations.component";

@NgModule({

  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HttpClientModule,
    RouterModule.forChild([
      {
        path: '',
        component: AllConsultationsComponent
      }
    ])
  ],
  providers: [
    HttpClient,
    RefreshUtils,
    ConsultationService,
    PatientService,
    AlertService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorRm,
      multi: true
    }
  ],
  declarations: [AllConsultationsComponent],
})

export class AllConsultationsModule { }