import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
@Component({
  selector: 'app-rm',
  templateUrl: 'rm.page.html',
  styleUrls: ['rm.page.scss'],
})
export class RmPage implements OnInit {

  constructor(
    private router: Router, 
    private screenOrientation: ScreenOrientation,
    private navController: NavController, 
  ) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
  
  }

  ngOnInit() {
  }
  
  goToDiagnosis() {
    this.router.navigate(['diagnosis'])
  }

  goToConsultations() {
    this.router.navigate(['consultations'])
  }

  goToPrescriptions() {
    this.router.navigate(['prescriptions'])
  }

  goToStudies() {
    this.router.navigate(['studies'])
  }

  goToBack() {
    this.navController.navigateBack("/health");
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

  goToHealthCertificates() {
    this.navController.navigateRoot(['health-certificate']);
  }


}