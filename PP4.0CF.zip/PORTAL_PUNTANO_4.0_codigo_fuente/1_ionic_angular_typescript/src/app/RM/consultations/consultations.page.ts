import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';
import { Storage } from '@ionic/storage';
import { constants } from '../../utils/constants';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { ConsultationService } from 'src/app/services/consultation.service';
import { PatientService } from 'src/app/services/patient.service';
import { BusConsultationDto } from 'src/app/core/models/BusConsultationDto';
import { AlertService } from 'src/app/services/alert.service';
import * as moment from 'moment';
import { BusSpecialtyDto } from 'src/app/core/models/BusSpecialtyDto';

@Component({
  selector: 'app-consultations',
  templateUrl: 'consultations.page.html',
  styleUrls: ['consultations.page.scss'],
})
export class ConsultationsPage implements OnInit {

  token: String;
  
  consultations: BusConsultationDto[] = []
  patientId: number
  dateFrom?: any
  userData: any
  specialties: BusSpecialtyDto[]

  specialtyIdSelected?: number

  constructor(
    private alertController: AlertController,
    private loadingController: LoadingController,
    private storage: Storage,
    private router: Router,
    private screenOrientation: ScreenOrientation,
    private statusBar: StatusBar,
    private navController: NavController,
    private localStorageService: LocalStorageService,
    private consultationService: ConsultationService,
    private patientService: PatientService,
    private alertService: AlertService
  ) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);

  }

  ionViewWillEnter() {
    this.statusBar.backgroundColorByHexString('#EC272F');
  }


  ngOnInit() {
    this.localStorageService.getUserData().then(userData => {
      this.userData = userData
      this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(patientId => {
        this.patientId = patientId
        //TODO: DateFrom deberia ser opcional en el back
        this.consultationService.getConsultationsByPatientId(
          {
            patientId,
            size: 3,
            dateFrom: "2000-01-01"
          }
        ).subscribe(response => {
          this.consultations = response
        }, error => {
          if (error.message)
            this.alertService.showErrorAlert(error.message)
          else
            this.alertService.showErrorAlert()
        })
        this.patientService.getSpecialtiesByPatientId(patientId).subscribe(response => {
          this.specialties = response
        })
      })
    })
  }

  search() {
    if (!this.dateFrom) {
      this.alertService.showCustomAlert({ message: "Debe seleccionar una fecha" })
      return
    }
    let dateFrom = moment(this.dateFrom).format("YYYY-MM-DD")
    this.consultationService.getConsultationsByPatientId(
      {
        patientId: this.patientId,
        dateFrom,
        specialtyId: this.specialtyIdSelected
      }).subscribe(response => {
        this.consultations = response
      })
  }

  async deleteDataAndExitToLogin() {
    this.storage.clear().then(() => {
      this.navController.navigateRoot("/login");
    });

  }

  async alert(messageText: string) {
    this.loadingController.dismiss();
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
          }
        }
      ]
    });

    await alert.present();
  }


  async loading() {
    this.loadingController.dismiss();
    const loading = await this.loadingController.create({
      message: 'Cargando',
    });
    await loading.present();
  }

  async loadingWithMessage(messageText: string) {
    this.loadingController.dismiss();
    const loading = await this.loadingController.create({
      message: messageText,
    });
    await loading.present();
  }

  goToConsultation(id: number) {
    let navigationExtras: NavigationExtras = {
      state: {
        consultationId: id,
      }
    };
    this.router.navigate(['consultation'], navigationExtras)
  }

  processError = function (error: any) {
    return new Promise<any>((resolve, reject) => {
      // this.loadingController.dismiss();
      if (error.status == 500) {
        if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
          this.storage.get('psw').then((val: any) => {
            if (val) {
              // this.loading();
              this.refreshUtils.refreshToken(val).then((value: any) => {
                this.loadingController.dismiss();
                resolve(value);
              }).catch((errorRefresh: { status: number; }) => {
                this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();
                } else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            }
            else {
              this.alert(constants.GENERIC_ERROR);
            }
          });

        } else {
          this.alert(constants.GENERIC_ERROR);
        }
      } else if (error.status == 401) {
        this.deleteDataAndExitToLogin();
      } else if (error.status == 409) {
        this.alert(error.error.message);
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  }

  processErrorRM = function (error: any) {
    return new Promise<any>((resolve, reject) => {
      // this.loadingController.dismiss();
      if (error.status == 500) {

        if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
          this.storage.get('token').then((val: any) => {
            if (val) {
              // this.loading();
              this.refreshUtils.refreshTokenRM(val).then((value: any) => {
                //  this.loadingController.dismiss();
                resolve(value);
              }).catch((errorRefresh: { status: number; }) => {
                this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.alert(constants.GENERIC_ERROR);
                } else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            }
            else {
              this.alert(constants.GENERIC_ERROR);
            }
          });

        } else {
          this.alert(constants.GENERIC_ERROR);
        }
      } else if (error.status == 401) {
        this.alert(constants.GENERIC_ERROR);
      } else if (error.status == 409) {
        this.alert(error.error.message);
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

}