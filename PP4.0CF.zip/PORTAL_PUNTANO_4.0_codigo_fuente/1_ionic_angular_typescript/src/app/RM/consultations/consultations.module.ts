import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ConsultationsPage } from './consultations.page';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RefreshUtils } from '../../utils/refreshUtils';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { ConsultationService } from 'src/app/services/consultation.service';
import { PatientService } from 'src/app/services/patient.service';
import { InterceptorRm } from 'src/app/core/interceptors/interceptor-rm.service';
import { AlertService } from 'src/app/services/alert.service';


@NgModule({

  imports: [
    HttpClientModule,
    CommonModule,
    FormsModule,
    IonicModule,
    MatFormFieldModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    MatInputModule,
    MatNativeDateModule,
    MatMomentDateModule,
    RouterModule.forChild([
      {
        path: '',
        component: ConsultationsPage
      }
    ])
  ],
  providers: [
    HttpClient,
    RefreshUtils,
    ConsultationService,
    PatientService,
    AlertService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorRm,
      multi: true
    }
  ],
  declarations: [ConsultationsPage],
  entryComponents: []
})

export class ConsultationsModule { }