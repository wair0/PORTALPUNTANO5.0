import { Injectable } from '@angular/core';
import { BusConsultationHasHealthCertificateDto } from "src/app/core/models/BusConsultationHasHealthCertificateDto";
import * as moment from 'moment';


@Injectable({
  providedIn: 'root'
})
export class HealthCertificateService {

  /**
   * Debe tener todos los certificados en memoria
   */
  private _healthCertificates: BusConsultationHasHealthCertificateDto[] = [];
  private _filteredCertificates: BusConsultationHasHealthCertificateDto[] = [];
  private _currentCertificate?: BusConsultationHasHealthCertificateDto;
  private _dateFrom?: Date;
  private _currentSpecialty?: string;

  constructor() { }

  set healthCertificates(healthCertificates: BusConsultationHasHealthCertificateDto[]) {
    this.clearStates();
    this._healthCertificates = healthCertificates
    // Si existen certificados, voy a mostrar los ultimos 3
    this._filteredCertificates = [ ... this._healthCertificates.slice(0, 3) ];
  }

  get hasCertificates(): boolean {
    return this._healthCertificates != null && this._healthCertificates.length > 0;
  }

  get currentCertificate() {
    return this._currentCertificate
  }

  set currentCertificate(certificate: BusConsultationHasHealthCertificateDto) {
    this._currentCertificate = certificate
  }

  get dateFrom(): Date {
    return this._dateFrom ? this._dateFrom : null;
  }

  set dateFrom(date: Date) {
    this._dateFrom = date;
  }

  get specialties(): Set<string> {
    let specialties = new Set(this._healthCertificates.map(c => c.consultation.specialty));
    return specialties
  }

  get currentSpecialty(): string {
    return this._currentSpecialty
  }

  set currentSpecialty(specialty: string) {
    this._currentSpecialty = specialty
  }

  get canCleanFilter(): boolean {
    return this._dateFrom != null || this._currentSpecialty != null
  }

  get canSearch(): boolean {
    return this._dateFrom != null;
  }

  get filteredCertificates(): BusConsultationHasHealthCertificateDto[] {
    return this._filteredCertificates;
  }

  clearStates() {
    this._healthCertificates = [];
    this._currentCertificate = null;
    this._dateFrom = null;
    this._currentSpecialty = null;
    this._filteredCertificates = []
  }

  clearCurrentFilterStates(){
    this._dateFrom = null;
    this._currentSpecialty = null;
    // Al darle a limpiar filtros vuelvo a mostrar los ultimos 3 certificados
    this._filteredCertificates = [ ... this._healthCertificates.slice(0, 3) ];
  }

  /**
   * Tengo que filtrar los certificados por fecha y especialidad
   */
  filterCertificates(){
    this._filteredCertificates = this._healthCertificates.filter(c => {
      let dateConsultation = moment(c.consultation.dateCreated, "DD-MM-YYYY HH:mm:ss");
      let dateFrom = moment(this._dateFrom)
      let compareDates = dateConsultation.isSameOrAfter(dateFrom.startOf('day'))
      // Si tiene especialidad seleccionada entonces tengo que compararlo, caso contrario siempre cumple
      debugger
      let compareSpecialty = this._currentSpecialty ? this._currentSpecialty === c.consultation.specialty : true
      return compareDates && compareSpecialty
    })
  }
}
