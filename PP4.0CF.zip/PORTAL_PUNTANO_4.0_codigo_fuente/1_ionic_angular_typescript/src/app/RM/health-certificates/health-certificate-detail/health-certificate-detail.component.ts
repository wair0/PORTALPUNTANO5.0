import { Component, OnInit } from '@angular/core';
import { FileOpener } from "@ionic-native/file-opener/ngx";
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { AlertController, LoadingController, NavController, Platform } from "@ionic/angular";
import { BusConsultationHasHealthCertificateDto } from "src/app/core/models/BusConsultationHasHealthCertificateDto";
import { DeviceDetailsService } from "src/app/device/device.service";
import { constants } from "src/app/utils/constants";
import { HealthCertificateService } from "../health-certificate.service";
import { Storage } from '@ionic/storage';
import { Router } from "@angular/router";

@Component({
  selector: 'app-health-certificate-detail',
  templateUrl: './health-certificate-detail.component.html',
  styleUrls: ['./health-certificate-detail.component.scss'],
})
export class HealthCertificateDetailComponent implements OnInit {

  public fileTransfer: FileTransferObject;

  constructor(
    private navController: NavController,
    private healthCertificateService: HealthCertificateService,
    private loadingController: LoadingController,
    private storage: Storage,
    private transfer: FileTransfer,
    private file: File,
    private platform: Platform,
    private deviceDetailsService: DeviceDetailsService,
    private fileOpener: FileOpener,
    private alertController: AlertController,
  ) { }

  ngOnInit() {
    // Cuando no tenga certificado actual lo devuelvo a la vista  general asi vuelve a pedir los datos al backend
    if(!this.healthCertificateService.currentCertificate)
      this.navController.navigateRoot("/health-certificate");

  }

  async loadingWithMessage(messageText: string) {
    const loading = await this.loadingController.create({
      message: messageText,
    });
    await loading.present();
  }

  goToHome() {
    this.navController.navigateRoot("/home");
    this.healthCertificateService.clearStates();
  }

  get currentCertificate(): BusConsultationHasHealthCertificateDto {
    return this.healthCertificateService.currentCertificate
  }

  async download() {
    this.loadingWithMessage("Descargando")
    this.storage.get('token').then((token) => {
      if (token) {
        let fileName = "Certificado_" + this.currentCertificate.id + ".pdf";

        let filePath = `${constants.URL_RM_PREFIX}patient/pdf/${this.currentCertificate.pdfPathName}`;

        let url = encodeURI(filePath);
        this.fileTransfer = this.transfer.create();

        let options = {
          headers: {
            "X-Authorization": "Bearer " + token
          }
        };

        let directory = this.file.documentsDirectory;

        if (this.platform.is("android")) {
          let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[ 0 ]);
          //if(this.file.externalRootDirectory){
          console.log("[HOME] OS VERSION: " + soVersion);
          if (soVersion < 11) {
            if (this.file.externalRootDirectory) {
              directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
            } else {
              directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
            }
          } else {
            directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
          }
        }

        this.fileTransfer.download(url, directory + fileName, true, options).then((entry) => {
          this.loadingController.dismiss();
          //here logging our success downloaded file path in mobile. 
          console.log('download completed: ' + entry.toURL());

          this.file.resolveDirectoryUrl(directory).then((rootDir) => {
            this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
              fileEntry.getMetadata(metadata => {
                if (metadata.size != 0) {
                  // open downloaded file 
                  this.openFileHandler(entry.toURL());

                  if (this.platform.is("android")) {
                    let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[ 0 ]);
                    if (soVersion < 11) {
                      if (this.file.externalRootDirectory) {
                        this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + constants.FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                      }
                    }
                  }

                } else {
                  this.alert(constants.FILE_SIZE_0_ERROR);
                }
              })

            });

          });

        }).catch((error) => {
          this.loadingController.dismiss();
          if (error != null && error.http_status != null && error.http_status == 409) {
            this.alert(JSON.parse(error.body).message);
          } else {
            this.processErrorRM(error).then(value => {
              this.alert(constants.GENERIC_ERROR);
            });
          }

        });

      }
      else {
        this.loadingController.dismiss();
        this.alert(constants.GENERIC_ERROR);
      }
    });
  }

  openFileHandler(path: any) {
    this.fileOpener.open(path, "")
      .then(() => console.log('File is opened'))
      .catch(e => console.log('Error opening file', e));
  }


  async alert(messageText: string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }

  processErrorRM = function (error: any) {
    return new Promise<any>((resolve, reject) => {
      console.log("Error!!!!!");
      console.log(JSON.stringify(error));
      this.loadingController.dismiss();

      this.storage.get('token').then((val: any) => {
        if (val) {
          this.loadingWithMessage("Descargando");
          this.refreshUtils.refreshTokenRM(val).then((value: any) => {
            this.loadingController.dismiss();
            resolve(value);
          }).catch((errorRefresh: { status: number; }) => {
            this.loadingController.dismiss();
            if (errorRefresh.status == 401) {
              this.alert(constants.GENERIC_ERROR);
            } else {
              this.alert(constants.GENERIC_ERROR);
            }
          });
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });

    });

  }
}
