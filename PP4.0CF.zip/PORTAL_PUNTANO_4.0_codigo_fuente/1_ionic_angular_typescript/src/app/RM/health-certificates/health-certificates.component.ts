import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ScreenOrientation } from "@ionic-native/screen-orientation/ngx";
import { NavController } from "@ionic/angular";
import { BusConsultationHasHealthCertificateDto } from "src/app/core/models/BusConsultationHasHealthCertificateDto";
import { HealthCertificateApiService } from "src/app/services/health-certificate-api.service";
import { LocalStorageService } from "src/app/services/local-storage.service";
import { HealthCertificateService } from "./health-certificate.service";

@Component({
  selector: 'app-health-certificates',
  templateUrl: './health-certificates.component.html',
  styleUrls: [ './health-certificates.component.scss' ],
})
export class HealthCertificatesComponent implements OnInit {
  constructor(
    private navController: NavController,
    private router: Router,
    private healthCertificateApiService: HealthCertificateApiService,
    private healthCertificateService: HealthCertificateService,
    private localStorageService: LocalStorageService,
    private screenOrientation: ScreenOrientation,
  ) {
    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
  }

  ngOnInit() {
    this.getPatientData()
  }

  goToBack() {
    this.navController.navigateBack("/rm");
    this.healthCertificateService.clearStates();
  }

  goToHome() {
    this.navController.navigateRoot("/home");
    this.healthCertificateService.clearStates();
  }

  openCertificateDetail(certificate: BusConsultationHasHealthCertificateDto) {
    this.healthCertificateService.currentCertificate = certificate
    this.router.navigate([ 'health-certificate/details' ])
  }

  /**
   * Busca todos los certificados del paciente
   */
  getPatientData() {
    this.localStorageService.getUserData().then(
      userData => {
        this.healthCertificateApiService.getByPatientParams(userData.docNumber, userData.sex).subscribe(
          response => {
            this.healthCertificateService.healthCertificates = response
          }
        );
      })
  }

  /**
   * Hace el filtrado de certificados en base a los que tiene en memoria
   */
  filterCertificates() {
    if (this.canSearch)
      this.healthCertificateService.filterCertificates();
  }

  cleanFilters() {
    if (this.canCleanFilter)
      this.healthCertificateService.clearCurrentFilterStates();
  }

  get healthCertificates(): BusConsultationHasHealthCertificateDto[] {
    return this.healthCertificateService.filteredCertificates;
  }

  get hasCertificates(): boolean {
    return this.healthCertificateService.hasCertificates
  }

  get specialties(): Set<string> {
    return this.healthCertificateService.specialties
  }

  get currentSpecialty(): string {
    return this.healthCertificateService.currentSpecialty
  }

  set currentSpecialty(specialty: string) {
    this.healthCertificateService.currentSpecialty = specialty
  }

  get canCleanFilter(): boolean {
    return this.healthCertificateService.canCleanFilter;
  }

  set dateFrom(date: Date) {
    this.healthCertificateService.dateFrom = date
  }

  get dateFrom(): Date {
    return this.healthCertificateService.dateFrom
  }

  get canSearch(): boolean {
    return this.healthCertificateService.canSearch
  }

}
