import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HealthCertificatesComponent } from "./health-certificates.component";
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { RouterModule } from "@angular/router";
import { InterceptorRm } from "src/app/core/interceptors/interceptor-rm.service";
import { IonicModule } from '@ionic/angular';
import { HealthCertificateDetailComponent } from "./health-certificate-detail/health-certificate-detail.component";
import { HealthCertificateApiService } from "src/app/services/health-certificate-api.service";
import { LocalStorageService } from "src/app/services/local-storage.service";
import { RefreshUtils } from "src/app/utils/refreshUtils";
import { AlertService } from "src/app/services/alert.service";
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { FileOpener } from "@ionic-native/file-opener/ngx";
import { File } from "@ionic-native/file/ngx";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatInputModule } from "@angular/material/input";
import { MatNativeDateModule } from "@angular/material/core";
import { MatMomentDateModule } from "@angular/material-moment-adapter";


@NgModule({
  imports: [
    HttpClientModule,
    CommonModule,
    FormsModule,
    IonicModule,
    MatFormFieldModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    MatInputModule,
    MatNativeDateModule,
    MatMomentDateModule,
    RouterModule.forChild([
      {
        path: '',
        component: HealthCertificatesComponent
      },
      {
        path: 'details',
        component: HealthCertificateDetailComponent
      }
    ])
  ],
  providers: [
    HttpClient,
    LocalStorageService,
    RefreshUtils,
    AlertService,
    HealthCertificateApiService,
    FileTransfer,
    FileTransferObject,
    File,
    FileOpener,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorRm,
      multi: true
    }
  ],
  declarations: [
    HealthCertificatesComponent,
    HealthCertificateDetailComponent
  ],
  entryComponents: []
})

export class HealthCertificatesModule { }
