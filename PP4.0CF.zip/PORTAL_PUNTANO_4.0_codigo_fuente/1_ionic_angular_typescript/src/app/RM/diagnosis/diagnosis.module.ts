import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {RefreshUtils} from '../../utils/refreshUtils';
import { DiagnosisComponent } from './diagnosis.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { DiagnosisService } from 'src/app/services/diagnosis.service';
import { AlertService } from 'src/app/services/alert.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { PatientService } from 'src/app/services/patient.service';
import { InterceptorRm } from 'src/app/core/interceptors/interceptor-rm.service';


@NgModule({
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  entryComponents: [
  ],
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      HttpClientModule,
      MatExpansionModule,
      RouterModule.forChild([
        {
          path: '',
          component: DiagnosisComponent
        }
      ])
    ],
    providers: [
      HttpClient,
      RefreshUtils,
      DiagnosisService,
      AlertService,
      LocalStorageService,
      PatientService,
      {
        provide: HTTP_INTERCEPTORS,
        useClass: InterceptorRm,
        multi: true
      }
    ],
    declarations: [
      DiagnosisComponent
    ]
  })
  
  export class DiagnosisModule {}