import { Component, OnInit } from '@angular/core';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { AlertController, NavController } from '@ionic/angular';
import { BusDiagnosisDto } from 'src/app/core/models/BusDiagnosisDto';
import { BusProfessionalDto } from 'src/app/core/models/BusProfessionalDto';
import { AlertService } from 'src/app/services/alert.service';
import { DiagnosisService } from 'src/app/services/diagnosis.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { PatientService } from 'src/app/services/patient.service';

@Component({
  selector: 'app-diagnosis',
  templateUrl: './diagnosis.component.html',
  styleUrls: ['./diagnosis.component.scss']
})
export class DiagnosisComponent implements OnInit {

  userData: any
  patientId: number
  diagnoses: BusDiagnosisDto[] = []
  professionalsAttendedPatient: BusProfessionalDto[]
  hasHiddenDiagnosis: boolean = false

  constructor(
    private statusBar: StatusBar,
    private screenOrientation: ScreenOrientation,
    private navController: NavController,
    private alertController: AlertController,
    private diagnosisService: DiagnosisService,
    private patientService: PatientService,
    private localStorageService: LocalStorageService,
    private alertService: AlertService
  ) {
    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
  }

  ionViewWillEnter() {
    this.statusBar.backgroundColorByHexString('#EC272F');
  }

  ngOnInit() {
    this.localStorageService.getUserData().then(userData => {
      this.userData = userData
      this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(patientId => {
        this.patientId = patientId
        this.diagnosisService.getDiagnosisByPatientId(patientId).subscribe(response => {
          this.diagnoses = response
          this.verifyIfhasHiddenDiagnosis()
          this.orderDiagnosesList(this.diagnoses)
        }, error => {
          if (error.message)
            this.alertService.showErrorAlert(error.message)
          else
            this.alertService.showErrorAlert()
        })
      })
    })
  }

  openDiagnosisDetail(diagnosis: BusDiagnosisDto) {
    // Si diagnosis ya cargó sus diagnosisEvolution, no se cargarán nuevamente:
    if (diagnosis.diagnosisEvolution && diagnosis.diagnosisEvolution.length > 0) {
      return
    }

    this.diagnosisService.getDiagnosisEvolutionByDiagnosisIdAndPatientId(diagnosis.diagnosisEvolutionId, this.patientId).subscribe(response => {
      this.diagnoses.forEach(diag => {
        if (diag.id === diagnosis.id) {
          diag.diagnosisEvolution = response
        }
      })
    })
  }

  presentAlertToSelectProfessional(diagnosis: BusDiagnosisDto) {
    if (this.professionalsAttendedPatient) {
      let professionalsAttendedPatientFiltered = this.filterProfessionalsWithAccess(diagnosis)
      this.presentAlertRadio(professionalsAttendedPatientFiltered, diagnosis)
    }
    else {
      this.patientService.getProfessionalsByPatientId(this.patientId).subscribe(response => {
        this.professionalsAttendedPatient = response
        let professionalsAttendedPatientFiltered = this.filterProfessionalsWithAccess(diagnosis)
        this.presentAlertRadio(professionalsAttendedPatientFiltered, diagnosis)
      })
    }
  }

  async presentAlertRadio(professionalsList: BusProfessionalDto[], diagnosis: BusDiagnosisDto) {

    let professionalsListInAlert = []
    professionalsList.forEach(professional => {
      let input = {
        name: professional.fullName,
        type: "radio",
        label: professional.fullName,
        value: professional.id,
      }
      professionalsListInAlert.push(input)
    });

    const alert = await this.alertController.create({
      header: 'Autorizar visualización a Profesionales',
      inputs: professionalsListInAlert,
      message: professionalsListInAlert.length === 0 ? "No hay profesionales disponibles" : "",
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'primary',
        }, {
          text: 'Aceptar',
          handler: (elementSelected) => {
            let professionalSelected: BusProfessionalDto = professionalsList.find(el => el.id == elementSelected)
            // Se pasa una lista de ids de profesionales porque posiblemente se pida mas adelante
            let professionalIds = []
            professionalIds.push(elementSelected)
            this.diagnosisService.postHiddenDiagnosisPermission(this.patientId, diagnosis.id, professionalIds).subscribe(response => {
              this.addProfessionalSelectedWithAccess(professionalSelected, diagnosis.id)
              this.alertService.showCustomAlert({
                message: `Se ha autorizado el acceso en el diagnóstico ${diagnosis.description} al profesional ${professionalSelected.fullName}`
              })
            }, error => {
              this.alertService.showErrorAlert()
            })
          }
        }
      ]
    });

    await alert.present();
  }

  async presentAlertToDeleteProfessional(diagnosis: BusDiagnosisDto, professional: BusProfessionalDto) {
    const alert = await this.alertController.create({
      header: `¿Desea revocar el permiso de visualización al profesional ${professional.fullName} ?`,
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'primary',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        }, {
          text: 'Aceptar',
          handler: () => {
            //TODO: El back deberia recibir un id unico en vez de una lista
            let professionalIds = []
            professionalIds.push(professional.id)

            this.diagnosisService.deleteHiddenDiagnosisPermission(this.patientId, diagnosis.id, professionalIds).subscribe(response => {
              this.deleteProfessionalWithAccess(professional, diagnosis.id)
              this.alertService.showCustomAlert({ message: `Se le ha removido el permiso de acceso al profesional ${professional.fullName}` })
            }, error => {
              this.alertService.showErrorAlert()
            })
          }
        }
      ]
    });

    await alert.present();
  }

  deleteProfessionalWithAccess(professional: BusProfessionalDto, diagnosisId: number) {
    this.diagnoses.forEach(diagnosis => {
      if (diagnosis.id === diagnosisId) {
        diagnosis.professionalWithPermission = diagnosis.professionalWithPermission.filter(prof => prof.id !== professional.id)
      }
    })
  }

  addProfessionalSelectedWithAccess(professional: BusProfessionalDto, diagnosisId: number) {
    this.diagnoses.forEach(diagnosis => {
      if (diagnosis.id === diagnosisId) {
        diagnosis.professionalWithPermission.push(professional)
      }
    })
  }

  filterProfessionalsWithAccess(diagnosis: BusDiagnosisDto): BusProfessionalDto[] {
    //Elimina los profesionales que ya tienen acceso en el diagnostico seleccionado
    let professionalsAttendedPatientFiltered = this.professionalsAttendedPatient
    if (diagnosis.professionalWithPermission && diagnosis.professionalWithPermission.length > 0) {
      diagnosis.professionalWithPermission.forEach(prof => {

        professionalsAttendedPatientFiltered = professionalsAttendedPatientFiltered.filter(profToFilter => prof.id !== profToFilter.id)
      });
    }
    return professionalsAttendedPatientFiltered
  }

  orderDiagnosesList(list: BusDiagnosisDto[]) {
    list.sort((a, b) =>
      Number(b.hiddenDiagnosis) - Number(a.hiddenDiagnosis)
    )
  }

  verifyIfhasHiddenDiagnosis() {
    this.diagnoses.forEach(element => {
      if(element.hiddenDiagnosis)
        this.hasHiddenDiagnosis = true
      });
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

}
