import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PrescriptionsPage } from './prescriptions.page';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {RefreshUtils} from '../../utils/refreshUtils';
import { PatientService } from 'src/app/services/patient.service';
import { ConsultationService } from 'src/app/services/consultation.service';
import { AlertService } from 'src/app/services/alert.service';
import { InterceptorRm } from 'src/app/core/interceptors/interceptor-rm.service';


@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      HttpClientModule,
      RouterModule.forChild([
        {
          path: '',
          component: PrescriptionsPage
        }
      ])
    ],
    providers: [
      HttpClient,
      RefreshUtils,
      PatientService,
      ConsultationService,
      AlertService,
      {
        provide: HTTP_INTERCEPTORS,
        useClass: InterceptorRm,
        multi: true
      }
    ],
    declarations: [PrescriptionsPage]
  })
  
  export class PrescriptionsModule {}