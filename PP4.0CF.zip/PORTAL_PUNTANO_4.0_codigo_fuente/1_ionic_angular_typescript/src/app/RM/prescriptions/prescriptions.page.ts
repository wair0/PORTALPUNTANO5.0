import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { Storage } from '@ionic/storage';
import { RefreshUtils } from '../../utils/refreshUtils';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { ConsultationService } from 'src/app/services/consultation.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { BusConsultationDto } from 'src/app/core/models/BusConsultationDto';
import { PatientService } from 'src/app/services/patient.service';
import { AlertService } from 'src/app/services/alert.service';

@Component({
  selector: 'app-prescriptions',
  templateUrl: 'prescriptions.page.html',
  styleUrls: ['prescriptions.page.scss'],
})
export class PrescriptionsPage implements OnInit {

  userData: any
  patientId: number
  consultations: BusConsultationDto[]

  constructor(
    private router: Router,
    private screenOrientation: ScreenOrientation,
    private statusBar: StatusBar,
    private navController: NavController,
    private refreshUtils: RefreshUtils,
    private consultationService: ConsultationService,
    private localStorageService: LocalStorageService,
    private patientService: PatientService,
    private alertService: AlertService
  ) {
    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
  }

  ionViewWillEnter(){
    this.statusBar.backgroundColorByHexString('#EC272F');
  }

  ngOnInit() {
    this.localStorageService.getUserData().then(userData => {
      this.userData = userData
      this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(patientId => {
        this.patientId = patientId
        this.consultationService.getConsultationsWithPrescriptionsByPatientId(patientId).subscribe(response => {
          this.consultations = response
        }, error => {
          if (error.message)
            this.alertService.showErrorAlert(error.message)
          else
            this.alertService.showErrorAlert()
        })
      })
    })
  }

  goToPrescription(consultation: BusConsultationDto) {
    let navigationExtras: NavigationExtras = {
      state: {
        consultation
      }
    };
    this.router.navigate(['prescription'], navigationExtras)
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

}