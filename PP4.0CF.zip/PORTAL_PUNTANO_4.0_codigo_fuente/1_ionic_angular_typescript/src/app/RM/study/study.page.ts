import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController, NavController, Platform } from '@ionic/angular';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { log } from 'util';
import { Alert } from 'selenium-webdriver';
import { Storage } from '@ionic/storage';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';

import { constants } from '../../utils/constants';

import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';

import { StatusBar } from '@ionic-native/status-bar/ngx';
import { StudiesService } from 'src/app/services/studies.service';
import { BusConsultationDto } from 'src/app/core/models/BusConsultationDto';
import { TOUCH_BUFFER_MS } from '@angular/cdk/a11y';
import { BusComplementaryStudiesDto } from 'src/app/core/models/BusComplementaryStudiesDto';
import { DeviceDetailsService } from 'src/app/device/device.service';


@Component({
  selector: 'app-study',
  templateUrl: 'study.page.html',
  styleUrls: ['study.page.scss'],
})
export class StudyPage implements OnInit {

  public token: String;

  studies: BusComplementaryStudiesDto[];
  consultation: BusConsultationDto
  requiredStudies: BusComplementaryStudiesDto[] = []
  requiredStudiesInfo: BusComplementaryStudiesDto = {
    professionalNameRequired: "",
    dateRequired: undefined,
    pdfPathName: ""
  }
  completedStudies: BusComplementaryStudiesDto[] = []
  completedStudiesInfo: BusComplementaryStudiesDto = {
    pdfPathName: ""
  }
  fileTransfer: FileTransferObject;

  constructor(
    private deviceDetailsService: DeviceDetailsService,
    private alertController: AlertController,
    private loadingController: LoadingController,
    private storage: Storage,
    private route: ActivatedRoute,
    private router: Router,
    private transfer: FileTransfer,
    private file: File,
    private fileOpener: FileOpener,
    private screenOrientation: ScreenOrientation,
    private statusBar: StatusBar,
    private navController: NavController,
    private studiesService: StudiesService,
    private platform: Platform,

  ) {

    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);

  }
  ionViewWillEnter(){
    this.statusBar.backgroundColorByHexString('#EC272F');
  }

  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.consultation = this.router.getCurrentNavigation().extras.state.consultation;
        this.studiesService.getStudiesByConsultationId(this.consultation.consultationId).subscribe(response => {
          this.studies = response
          this.studies.forEach(study => {
            if (study.status === "REQ") {
              this.requiredStudies.push(study)
              this.requiredStudiesInfo.professionalNameRequired = study.professionalNameRequired
              this.requiredStudiesInfo.dateRequired = study.dateRequired
              if (study.pdfPathName)
                this.requiredStudiesInfo.pdfPathName = study.pdfPathName
            }
            else {
              this.completedStudies.push(study)
              if (study.pdfPathName)
                this.completedStudiesInfo.pdfPathName = study.pdfPathName
            }
          });
        })
      }
    });

  }

  async download(path: any) {

    this.storage.get('token').then((val) => {
      if (val) {
        this.token = val;
        let fileName = "Estudios_" + this.consultation.consultationId + ".pdf";

        let filePath = `${constants.URL_RM_PREFIX}patient/pdf/${path}`;
        let url = encodeURI(filePath);
        this.fileTransfer = this.transfer.create();

        let options = {
          headers: {
            "X-Authorization": "Bearer " + this.token
          }
        };

        let directory = this.file.documentsDirectory;

        // if (this.platform.is("android")) {
        //   if(this.file.externalRootDirectory){
        //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
        //     }else{
        //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
        //     }
        // }

        if (this.platform.is("android")) {
          let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
          //if(this.file.externalRootDirectory){
          console.log("[HOME] OS VERSION: " + soVersion);
          if (soVersion < 11) {
            if(this.file.externalRootDirectory){
              directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
            }else{
              directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
            }
          }else{
            directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
          }
        }

        this.fileTransfer.download(url, directory + fileName, true, options).then((entry) => {
          this.loadingController.dismiss();
          //here logging our success downloaded file path in mobile. 
          console.log('download completed: ' + entry.toURL());

          this.file.resolveDirectoryUrl(directory).then((rootDir) => {
            this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
              fileEntry.getMetadata(metadata => {
                if (metadata.size != 0) {
                  // open downloaded file 
                  this.openFileHandler(entry.toURL());

                  if (this.platform.is("android")) {
                    let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                    if (soVersion < 11) {
                      if(this.file.externalRootDirectory){
                        this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + constants.FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                      }
                    }
                  }

                } else {
                  this.alert(constants.FILE_SIZE_0_ERROR);
                }
              })

            });

          });

        }).catch((error) => {
          this.loadingController.dismiss();
          if (error != null && error.http_status != null && error.http_status == 409) {
            this.alert(JSON.parse(error.body).message);
          } else {
              this.alert(constants.GENERIC_ERROR);
          }
          
        });

      }
      else {
        this.loadingController.dismiss();
        this.alert(constants.GENERIC_ERROR);
      }
    });
  }

  
  openFileHandler(path: any) {
    this.fileOpener.open(path, '')
      .then(() => console.log('File is opened'))
      .catch(e => console.log('Error opening file', e));
  }

  goToHome() {
    this.navController.navigateRoot("/home");
  }

  
  async alert(messageText: string) {
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
            console.log('OK pressed!!');
          }
        }
      ]
    });

    await alert.present();
  }

}