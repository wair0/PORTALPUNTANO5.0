import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { StudyPage } from './study.page';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx'; 
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { StudiesService } from 'src/app/services/studies.service';
import { InterceptorRm } from 'src/app/core/interceptors/interceptor-rm.service';


@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      HttpClientModule,
      RouterModule.forChild([
        {
          path: '',
          component: StudyPage
        }
      ])
    ],
    providers: [
      HttpClient
      ,
       FileTransfer,
       FileTransferObject,
       File,
       FileOpener,
       StudiesService,
       {
        provide: HTTP_INTERCEPTORS,
        useClass: InterceptorRm,
        multi: true
      }
    ],
    declarations: [StudyPage]
  })
  
  export class StudyModule {}