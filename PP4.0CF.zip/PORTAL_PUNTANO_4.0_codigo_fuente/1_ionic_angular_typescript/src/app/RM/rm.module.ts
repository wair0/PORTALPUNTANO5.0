import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { RmPage } from './rm.page';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {RefreshUtils} from '../utils/refreshUtils';
import { InterceptorRm } from '../core/interceptors/interceptor-rm.service';
import { MatExpansionModule } from '@angular/material/expansion';

@NgModule({
    schemas: [
      CUSTOM_ELEMENTS_SCHEMA
    ],
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      HttpClientModule,
      MatExpansionModule,
      RouterModule.forChild([
        {
          path: '',
          component: RmPage
        }
      ])
    ],
    providers: [
      HttpClient,
      RefreshUtils,
      {
        provide: HTTP_INTERCEPTORS,
        useClass: InterceptorRm,
        multi: true
      }
    ],
    declarations: [RmPage]
  })
  
  export class RmModule {}