import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { AlertController, LoadingController } from '@ionic/angular';
import { constants } from '../utils/constants';
import { RefreshUtils } from '../utils/refreshUtils';
import { Storage } from '@ionic/storage';
import { StudentService } from '../services/student.service';
import { LoadingService } from '../services/loading.service';

@Component({
  selector: 'app-health',
  templateUrl: './health.component.html',
  styleUrls: [ './health.component.scss' ],
})
export class HealthComponent implements OnInit {
  studentsList: any = [];
  mapDisabledBoolean: boolean = false;
  token: any;
  sportMaps: any;

  constructor(
    private alertController: AlertController,
    private loadingController: LoadingController,
    private storage: Storage,
    private router: Router,
    private http: HttpClient,
    private refreshUtils: RefreshUtils,
    private studentService: StudentService,
    public load: LoadingService,
  ) { }

  public data = {
    token: '',
    iduser: 0,
    dni: 0,
    liquidations: [],
    judicialExpedients: [],
    proceduresAct: [],
    proceduresFin: [],
    procedures: [],
    totalProceduresAct: 0,
    totalProceduresFin: 0
  };
  httpOptions: any = null;
  public dataRm = {
    token: '',
    consultations: [],
    prescriptions: [],
    studies: []

  };

  ngOnInit() {
    // TODO: DESCOMENTAR CUADNO ESTEMOS POR ENTREGAR
    // this.getStudentsByUser()
  }

  goToHome() {
    this.router.navigate([ '/home' ]);
  }

  goToSportMap() {
    if (!this.mapDisabledBoolean) {
      let navigationExtras: NavigationExtras = {
        state: {
          content: this.studentsList,
          token: this.token
        }
      };
      this.router.navigate([ '/sportMap' ], navigationExtras);
      // this.navController.navigateRoot("/student-options");
    }
  }

  // Consulto si el usuario tiene alumnos a cargo //(GE)
  getStudentsByUser() {
    this.load.present();
    this.getToken().then(value => {
      this.studentService.getStudentsWithMap(this.httpOptions).subscribe((response: any) => {
        if (response) {
          this.studentsList = response
          if (this.studentsList.length === 0) {
            let mapDisabled
            this.mapDisabledBoolean = true
            mapDisabled = document.getElementById('map')
            mapDisabled.classList.remove('map')
            mapDisabled.classList.add('logoMapaDepDisabled')
          }
          this.load.dismiss();
        }
      }, error => {
        this.load.dismiss();
        if (error.status === 409) {
          this.alert(error.error.message);
        }
        else {
          this.alert(constants.GENERIC_ERROR);
        }
      });
    })
  }

  async getToken() {
    await this.storage.get('token').then(value => {
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
    })
  }

  async loading() {
    this.loadingController.dismiss();
    const loading = await this.loadingController.create({
      message: 'Cargando',
      duration: 5000,
    });
    await loading.present();
  }

  // RM
  async checkPasswordRM() {

    this.loading();
    this.storage.get('token').then((val) => {
      if (val) {
        this.data.token = val;


        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'X-Authorization': 'Bearer ' + this.data.token,
          }),
          response: new HttpResponse({
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            }),
          })
        };

        this.http.get(constants.URL_BASE_PORTAL + 'secure/mobile/check/password', httpOptions)
          .subscribe((data: any) => {

            this.getDataRm();

          }, error => {
            this.processError(error).then(value => {
              this.checkPasswordRM();
            });
          });
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });
  }

  async getPrescriptions() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.dataRm.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    this.http.get(constants.URL_RECIPE + 'secure/external/mobile/prescriptions?benefitType=M&specialtyId=0&dateFrom=&dateTo=&size=2', httpOptions)
      .subscribe((data: any) => {
        this.dataRm.prescriptions = data.content;
        this.getStudies();
      }, error => {
        this.dataRm.prescriptions = [];
        this.getStudies();

      });
  }


  async getStudies() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.dataRm.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };
    this.http.get(constants.URL_RECIPE + 'secure/external/mobile/prescriptions?benefitType=P&specialtyId=0&dateFrom=&dateTo=&size=2', httpOptions)
      .subscribe((data: any) => {
        this.loadingController.dismiss();
        this.dataRm.studies = data.content;
        this.goToRm();

      }, error => {
        this.dataRm.studies = [];
        this.goToRm();
      });
  }

  goToRm() {
    this.loadingController.dismiss();
    if (this.dataRm.consultations.length > 0 || this.dataRm.prescriptions.length > 0 || this.dataRm.studies.length > 0) {
      const navigationExtras: NavigationExtras = {
        state: {
          consultations: this.dataRm.consultations,
          prescriptions: this.dataRm.prescriptions,
          studies: this.dataRm.studies,
          token: this.dataRm.token
        }
      };
      this.router.navigate([ 'rm' ], navigationExtras);
    } else {
      this.alert('No se encontraron datos');
    }
  }

  async getConsultations() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Authorization': 'Bearer ' + this.dataRm.token,
      }),
      response: new HttpResponse({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Accept: 'application/json'
        }),
      })
    };

    this.http.get(constants.URL_RM + 'secure/external/mobile/consultation/person?specialtyId=0&dateFrom=&dateTo=&size=2', httpOptions)
      .subscribe((data: any) => {
        this.dataRm.consultations = data.content;
        this.getPrescriptions();

      }, error => {
        if (error.status == 500) {
          if (error.error.exception === 'io.jsonwebtoken.ExpiredJwtException') {
            this.storage.get('token').then((val) => {
              if (val) {
                this.refreshUtils.refreshTokenRM(val).then(value => {
                  this.getDataRm();
                }).catch(error => {
                  this.alert('Ocurrió un problema, intente nuevamente');
                });
              } else {
                this.alert('Ocurrió un problema, intente nuevamente');
              }
            });
          } else {
            this.dataRm.consultations = [];
            this.getPrescriptions();
          }
        } else {
          this.dataRm.consultations = [];
          this.getPrescriptions();

        }

      });
  }

  async getDataRm() {
    this.storage.get('tokenRM').then((val) => {
      if (val) {
        this.dataRm.token = val;
        this.getConsultations();
      } else {
        this.storage.get('token').then((val) => {
          if (val) {
            this.refreshUtils.refreshTokenRM(val).then(value => {
              this.getDataRm();
            }).catch(error => {
              if (error && error.status && error.status === 409 && error.error && error.error.message) {
                this.alert(error.error.message);
              } else {
                this.alert(constants.GENERIC_ERROR);
              }
            });

          } else {
            this.alert(constants.GENERIC_ERROR);
          }
        });

      }
    });

  }


  // error managers
  processError = function (error: any) {
    return new Promise<any>((resolve, reject) => {
      // this.loadingController.dismiss();
      if (error.status === 500) {
        if (error.error.exception === 'io.jsonwebtoken.ExpiredJwtException') {
          this.storage.get('psw').then((val: any) => {
            if (val) {
              // this.loading();
              this.refreshUtils.refreshToken(val).then((value: any) => {
                resolve(value);
              }).catch((errorRefresh: { status: number; }) => {
                // this.loadingController.dismiss();
                if (errorRefresh.status == 401) {
                  this.deleteDataAndExitToLogin();
                } else {
                  this.alert(constants.GENERIC_ERROR);
                }
              });
            } else {
              this.alert(constants.GENERIC_ERROR);
            }
          });

        } else {
          this.alert(constants.GENERIC_ERROR);
        }
      } else if (error.status == 401) {
        this.deleteDataAndExitToLogin();
      } else if (error.status == 409) {
        this.alert(error.error.message);
      } else {
        this.alert(constants.GENERIC_ERROR);
      }
    });

  };


  async alert(messageText: string) {
    this.loadingController.dismiss();
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
          }
        }
      ]
    });

    await alert.present();
  }
}
