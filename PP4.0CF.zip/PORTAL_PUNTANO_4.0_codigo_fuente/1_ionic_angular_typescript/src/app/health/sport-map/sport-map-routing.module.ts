import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SportMapComponent } from './sport-map.component';


const routes: Routes = [
  {
    path: '',
    component: SportMapComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SportMapRoutingModule {}
