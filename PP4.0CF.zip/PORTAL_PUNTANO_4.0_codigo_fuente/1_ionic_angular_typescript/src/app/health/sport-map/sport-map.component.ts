import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { AlertController, NavController } from '@ionic/angular';
import { LoadingService } from 'src/app/services/loading.service';
import { StudentService } from 'src/app/services/student.service';
import {Storage} from '@ionic/storage';

@Component({
  selector: 'app-sport-map',
  templateUrl: './sport-map.component.html',
  styleUrls: ['./sport-map.component.scss'],
})
export class SportMapComponent implements OnInit {
  user: string;
  httpOptions: { headers: HttpHeaders; response: HttpResponse<unknown>; };
  studentsList: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private navController: NavController,
    public load: LoadingService,
    private studentService: StudentService,
    private alertController: AlertController,
    private storage: Storage
  ) { }
  studentList: any;

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.studentList = this.router.getCurrentNavigation().extras.state.content;
      }else{
      }
    })
  }


  goToSportMapOfPerson(student: any) {
    let navigationExtras: NavigationExtras = {
      state: {
        content: student,
      }
    }
    this.router.navigate(['/studentSportMap'], navigationExtras);
  }


  async getToken() {
    await this.storage.get('token').then(value => {
      
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
    })
  }

  async alert(messageText: string) {
    this.load.dismiss();
    const alert = await this.alertController.create({
      header: 'Portal puntano',
      message: messageText,
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
          cssClass: 'primary',
          handler: () => {
          }
        }
      ]
    });

    await alert.present();
  }
}
