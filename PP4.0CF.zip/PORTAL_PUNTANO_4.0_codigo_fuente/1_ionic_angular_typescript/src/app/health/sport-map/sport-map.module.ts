import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SportMapComponent } from './sport-map.component';
import { SportMapRoutingModule } from './sport-map-routing.module';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { StudentService } from 'src/app/services/student.service';



@NgModule({
  declarations: [SportMapComponent],
  imports: [
    CommonModule,
    SportMapRoutingModule,
    FormsModule,
    IonicModule,
  ],
  providers:[
    StudentService
  ]
})
export class SportMapModule { }
