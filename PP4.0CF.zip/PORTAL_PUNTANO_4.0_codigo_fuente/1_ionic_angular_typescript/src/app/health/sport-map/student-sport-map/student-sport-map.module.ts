import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentSportMapComponent } from './student-sport-map.component';
import { StudentSportMapRoutingModule } from './student-sport-map-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { MatExpansionModule } from '@angular/material/expansion';
import { SportMapDetailsComponent } from 'src/app/components/sport-map-details/sport-map-details.component';
import { StudentService } from 'src/app/services/student.service';
import { HttpClient } from '@angular/common/http';
import { LoadingService } from 'src/app/services/loading.service';



@NgModule({
  declarations: [
    StudentSportMapComponent,
    SportMapDetailsComponent],
  imports: [
    CommonModule,
    StudentSportMapRoutingModule,
    FormsModule,
    IonicModule,
    MatExpansionModule,
  ],
  providers: [
    StudentService,
    HttpClient,
    LoadingService,
  ]
})
export class StudentSportMapModule { }
