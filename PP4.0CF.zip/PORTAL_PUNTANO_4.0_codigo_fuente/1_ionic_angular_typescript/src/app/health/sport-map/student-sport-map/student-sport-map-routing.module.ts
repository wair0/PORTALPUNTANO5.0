import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentSportMapComponent } from './student-sport-map.component';


const routes: Routes = [
  {
    path: '',
    component: StudentSportMapComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StudentSportMapRoutingModule {}
