import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { StudentService } from 'src/app/services/student.service';
import {Storage} from '@ionic/storage';
import { LoadingService } from 'src/app/services/loading.service';

@Component({
  selector: 'app-student-sport-map',
  templateUrl: './student-sport-map.component.html',
  styleUrls: ['./student-sport-map.component.scss'],
})
export class StudentSportMapComponent implements OnInit {
  student: any;
  step = 0;
  httpOptions: { headers: HttpHeaders; response: HttpResponse<unknown>; };
  sportMaps: any;
  description = '';
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private navController: NavController,
    private studentService: StudentService,
    private storage: Storage,
    public loading: LoadingService,
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.student = this.router.getCurrentNavigation().extras.state.content;
        if(!this.student){
          this.navController.navigateRoot("/health");
        }else{
          // this.getSportMap();
          this.sportMaps = this.student.map
        }
      }else{
        this.navController.navigateRoot("/health");
      }
    })
  }


  // schoolCycleChange(){
  //   if(this.schoolCycle){
  //     this.getToken().then(value => {    
  //       this.studentService.getRegistrationByStudent(this.student.studentId, this.schoolCycle.id, this.httpOptions).subscribe((response:any) =>{
  //         this.matriculations = response;
  //       },error =>{
  //         if (error.status === 409) {
  //           this.alert(error.error.message);
  //         }
  //         else{
  //           this.alert(constants.GENERIC_ERROR);
  //         }  
  //       })
  //     })       
  //   };
  // }

  async getToken() {
    await this.storage.get('token').then(value => {
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Authorization': 'Bearer ' + value,
        }),
        response: new HttpResponse({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }),
        })
      };

      this.httpOptions = httpOptions;
    })
  }

  getSportMap(){
    this.loading.present();
    this.getToken().then(value => {
      this.studentService.getSportMap(this.student.docNumber , this.student.sex , this.httpOptions).subscribe((response:any) =>{
        if(response){
          this.sportMaps = response
          this.loading.dismiss();
        }
      })
    })
  }

  setStep(index: number) {
    this.step = index;
  }

}
