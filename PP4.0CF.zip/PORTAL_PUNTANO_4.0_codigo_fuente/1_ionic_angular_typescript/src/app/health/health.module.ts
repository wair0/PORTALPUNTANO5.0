import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HealthRoutingModule } from './health-routing.module';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { HealthComponent } from './health.component';
import { StudentService } from '../services/student.service';



@NgModule({
  declarations: [HealthComponent],
  imports: [
    CommonModule,
    HealthRoutingModule,
    FormsModule,
    IonicModule,
  ],
  providers:[
    StudentService
  ]
})
export class HealthModule { }
