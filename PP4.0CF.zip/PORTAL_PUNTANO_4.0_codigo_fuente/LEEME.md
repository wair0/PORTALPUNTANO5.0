# Portal Puntano 4.0 – código fuente recuperado
App: com.gpsl.st.portalpuntanomultiplataforma · versión 1.0.12 (code 52) · Ionic/Angular + Cordova (Android).

- `1_ionic_angular_typescript/` – TypeScript/HTML/SCSS originales (src/app: páginas, servicios, módulos), recuperados de los source maps del bundle web (sourcesContent). Es el código real de la app, no decompilado.
- `2_android_nativo_java/` – Java decompilado con jadx (MainActivity, plugins Cordova, etc.). Se omitieron kotlin/androidx/Google libs. Puede tener construcciones aproximadas por ser decompilación.
- `3_recursos_android/` – AndroidManifest.xml, res/ y assets (www compilado sin .map, imágenes, estilos).

Notas: faltan package.json/angular.json/config.xml originales (no vienen en el APK); las dependencias de node_modules no se incluyen.
