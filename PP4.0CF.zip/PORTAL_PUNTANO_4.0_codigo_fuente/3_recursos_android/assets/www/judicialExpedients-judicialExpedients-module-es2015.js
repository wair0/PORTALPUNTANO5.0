(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["judicialExpedients-judicialExpedients-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/judicialExpedients/judicialExpedients.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/judicialExpedients/judicialExpedients.page.html ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>EXPEDIENTES JUDICIALES</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list *ngFor=\"let item of judicialExpedients\">\r\n    <ion-list-header class=\"header-text\" (click)=\"expandOrCollapse(item)\">\r\n      <h2 style=\"margin-top: 0px; margin-bottom: 0px;\"><b>{{item.year}}</b></h2>\r\n      <svg *ngIf=\"!item.expanded\" xmlns='http://www.w3.org/2000/svg'  height='50' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='112 184 256 328 400 184' style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg>\r\n      <svg *ngIf=\"item.expanded\" xmlns='http://www.w3.org/2000/svg' height='50' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='112 328 256 184 400 328' style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg>\r\n    </ion-list-header>\r\n    <div *ngIf=\"item.expanded\">\r\n    <div *ngFor=\"let expedient of item.expedients; let i = index\">\r\n    <ion-item class=\"border-red\" *ngIf=\"2>i\" (click)=\"getjudicialExpedientDetail(expedient)\">\r\n      <ion-list >\r\n      <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n        <ion-label class=\"ion-text-wrap\">\r\n          <ion-text class=\"red\">\r\n            <h3 style=\"display: inline;\">{{expedient.name}}</h3>\r\n          </ion-text>\r\n        </ion-label>\r\n\r\n      </ion-item>\r\n\r\n      <!-- <ion-item lines=\"none\" (click)=\"download(liquidation)\">\r\n        <ion-card text-center style=\"padding: 0px; margin: 0px;\">\r\n          <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n          width=\"30%\" height=\"30%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n       <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#003F79\" d=\"M862.973,656.11h-89.835v148.416\r\n         c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n         c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n         c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n         c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n         C840.518,409.458,840.518,415.762,837.57,419.12\"/>\r\n       </svg>\r\n        </ion-card>\r\n      </ion-item> -->\r\n    </ion-list>\r\n\r\n    </ion-item>\r\n\r\n    </div>\r\n\r\n    <!-- <ion-item lines=\"none\" (click)=\"goToJudicialExpedientsAll(item)\">\r\n      <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:20px; border-radius:6px; background-color: #e6e6e6; width: 100%;\">\r\n          <h5 style=\"display: inline;\"> Mostrar todos</h5>\r\n          <ion-icon style=\"align-content: flex-end; align-self:rigth; vertical-align: middle; margin: 0px !important;\" name=\"ios-arrow-forward\"></ion-icon>\r\n          </ion-text>\r\n  </ion-item> -->\r\n  <ion-item class=\"show-all\" lines=\"none\" (click)=\"goToJudicialExpedientsAll(item)\">\r\n    <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n        <h4 style=\"display: inline;\"><b>Mostrar todos</b></h4>\r\n        </ion-text>\r\n        <svg xmlns='http://www.w3.org/2000/svg'  height='25' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='184 112 328 256 184 400' style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg>\r\n</ion-item>\r\n</div>\r\n\r\n  </ion-list>\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n      <ion-buttons>\r\n        <ion-button (click)=\"goToHome()\">\r\n          <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\" ></ion-icon>\r\n        </ion-button>\r\n        </ion-buttons>\r\n      </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/judicialExpedients/judicialExpedients.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/judicialExpedients/judicialExpedients.module.ts ***!
  \*****************************************************************/
/*! exports provided: JudicialExpedientsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JudicialExpedientsModule", function() { return JudicialExpedientsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _judicialExpedients_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./judicialExpedients.page */ "./src/app/judicialExpedients/judicialExpedients.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");












let JudicialExpedientsModule = class JudicialExpedientsModule {
};
JudicialExpedientsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _judicialExpedients_page__WEBPACK_IMPORTED_MODULE_6__["JudicialExpedientsPage"]
                }
            ])
        ],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__["RefreshUtils"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__["FileOpener"]],
        declarations: [_judicialExpedients_page__WEBPACK_IMPORTED_MODULE_6__["JudicialExpedientsPage"]]
    })
], JudicialExpedientsModule);



/***/ }),

/***/ "./src/app/judicialExpedients/judicialExpedients.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/judicialExpedients/judicialExpedients.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #003F79;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 4.5vw;\n  text-align: center;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #003F79;\n}\n\n.header-text {\n  padding-left: 10px;\n  width: 95%;\n  margin: 10px;\n  background-color: #003F79;\n  color: #FFFFFF;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #003F79;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\n.show-all {\n  --min-height: 20px;\n  border-radius: 6px;\n  background-color: #e6e6e6;\n  --ion-background-color: #e6e6e6;\n  margin-top: 2%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvanVkaWNpYWxFeHBlZGllbnRzL0Q6XFxSZXBvc2l0b3Jpb3NcXHBvcnRhbC1pb25pYy9zcmNcXGFwcFxcanVkaWNpYWxFeHBlZGllbnRzXFxqdWRpY2lhbEV4cGVkaWVudHMucGFnZS5zY3NzIiwic3JjL2FwcC9qdWRpY2lhbEV4cGVkaWVudHMvanVkaWNpYWxFeHBlZGllbnRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7QUNDSjs7QURFQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSxnQ0FBQTtBQ0NKOztBREVHO0VBR0Esa0JBQUE7RUFDQSxVQUFBO0VBR0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDhCQUFBO0FDSEg7O0FETUc7RUFDQyxlQUFBO0VBQ0EsZ0JBQUE7QUNISjs7QURNRztFQUNJLG1CQUFBO0VBQ0Esa0JBQUE7QUNIUDs7QURNRztFQUNDLHFCQUFBO0FDSEo7O0FETUc7RUFDQyxjQUFBO0FDSEo7O0FETUE7RUFDSSx5QkFBQTtBQ0hKOztBRE1HO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0FDSFA7O0FET0c7RUFDQyxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQ0pKOztBRE9BO0VBQ0ksMkJBQUE7RUFDQSxpQ0FBQTtBQ0pKOztBRE9BO0VBQ0ksMkJBQUE7QUNKSjs7QURPQTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLCtCQUFBO0VBQ0EsY0FBQTtBQ0pKIiwiZmlsZSI6InNyYy9hcHAvanVkaWNpYWxFeHBlZGllbnRzL2p1ZGljaWFsRXhwZWRpZW50cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVke1xyXG4gICAgY29sb3I6ICMwMDNGNzlcclxufVxyXG5cclxuaW9uLXRpdGxle1xyXG4gICAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xyXG4gICAgZm9udC1zaXplOiA0LjV2dztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XHJcbiAgICBib3JkZXItYm90dG9tOjFweCBzb2xpZCAjMDAzRjc5O1xyXG4gICB9XHJcblxyXG4gICAuaGVhZGVyLXRleHR7XHJcbiAgICAvLyBib3JkZXItYm90dG9tOjJweCBzb2xpZCAjNTM1MzUzO1xyXG4gICAvLyBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgIHdpZHRoOiA5NSU7XHJcbiAgIC8vIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAvLyBwYWRkaW5nLXRvcDogMTBweDtcclxuICAgbWFyZ2luOiAxMHB4O1xyXG4gICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAzRjc5O1xyXG4gICBjb2xvcjogI0ZGRkZGRjtcclxuICAgYm9yZGVyLXJhZGl1czogMTBweCAhaW1wb3J0YW50O1xyXG4gICB9XHJcblxyXG4gICBpb24taXRlbXtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgIH1cclxuXHJcbiAgIGlvbi1saXN0e1xyXG4gICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgIG1hcmdpbi1ib3R0b206MHB4O1xyXG4gICB9XHJcblxyXG4gICBpb24taGVhZGVyIGlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMDAzRjc5O1xyXG4gICAgXHJcbiAgIH1cclxuICAgaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGV7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgfVxyXG5cclxuLndoaXRle1xyXG4gICAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcclxufVxyXG5cclxuICAgaW9uLWxhYmVse1xyXG4gICAgICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gICAgICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICB9XHJcblxyXG5cclxuICAgaW9uLWNvbnRlbnQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLnNjLWlvbi1jYXJkLW1kLWgge1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OlwiXCIgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWNhcmR7XHJcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zaG93LWFsbCB7XHJcbiAgICAtLW1pbi1oZWlnaHQ6IDIwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcclxuICAgIG1hcmdpbi10b3A6IDIlO1xyXG4gIH1cclxuIiwiLnJlZCB7XG4gIGNvbG9yOiAjMDAzRjc5O1xufVxuXG5pb24tdGl0bGUge1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgZm9udC1zaXplOiA0LjV2dztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pb24taXRlbS5ib3JkZXItcmVkIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwMDNGNzk7XG59XG5cbi5oZWFkZXItdGV4dCB7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgd2lkdGg6IDk1JTtcbiAgbWFyZ2luOiAxMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAzRjc5O1xuICBjb2xvcjogI0ZGRkZGRjtcbiAgYm9yZGVyLXJhZGl1czogMTBweCAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuaW9uLWxpc3Qge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICMwMDNGNzk7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xufVxuXG5pb24tY29udGVudCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uc2MtaW9uLWNhcmQtbWQtaCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBcIlwiICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG4uc2hvdy1hbGwge1xuICAtLW1pbi1oZWlnaHQ6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbiAgbWFyZ2luLXRvcDogMiU7XG59Il19 */"

/***/ }),

/***/ "./src/app/judicialExpedients/judicialExpedients.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/judicialExpedients/judicialExpedients.page.ts ***!
  \***************************************************************/
/*! exports provided: JudicialExpedientsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JudicialExpedientsPage", function() { return JudicialExpedientsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");













let JudicialExpedientsPage = class JudicialExpedientsPage {
    constructor(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, screenOrientation, statusBar, navController, refreshUtils) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.refreshUtils = refreshUtils;
        this.processError = function (error) {
            return new Promise((resolve, reject) => {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        this.storage.get('psw').then((val) => {
                            if (val) {
                                this.loading();
                                this.refreshUtils.refreshToken(val).then((value) => {
                                    this.loadingController.dismiss();
                                    resolve(value);
                                }).catch((errorRefresh) => {
                                    this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.judicialExpedients = this.router.getCurrentNavigation().extras.state.judicialExpedients;
                this.token = this.router.getCurrentNavigation().extras.state.token;
                this.makeExpedientsCollapse();
            }
        });
    }
    makeExpedientsCollapse() {
        let expedientsTemporal = [];
        let firstTime = true;
        this.judicialExpedients.forEach(element => {
            let elementTemporal = {
                year: element.year,
                expedients: element.expedients,
                expanded: firstTime,
            };
            expedientsTemporal.push(elementTemporal);
            firstTime = false;
        });
        console.log("EXPEDIENTS COLLAPSE!!!!");
        console.log(expedientsTemporal);
        this.judicialExpedients = expedientsTemporal;
    }
    expandOrCollapse(item) {
        item.expanded = !item.expanded;
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#003F79');
    }
    ngOnInit() {
    }
    deleteDataAndExitToLogin() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storage.clear().then(() => {
                this.navController.navigateRoot("/login");
            });
        });
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                            console.log('OK pressed!!');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loadingController.dismiss();
            const loading = yield this.loadingController.create({
                message: 'Cargando',
            });
            yield loading.present();
        });
    }
    loadingWithMessage(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: messageText,
            });
            yield loading.present();
        });
    }
    goToJudicialExpedientsAll(judicialExpedient) {
        let navigationExtras = {
            state: {
                content: judicialExpedient,
                token: this.token
            }
        };
        this.router.navigate(['judicialExpedientsAll'], navigationExtras);
    }
    getjudicialExpedientDetail(judicialExpedient) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loading();
            this.storage.get('token').then((val) => {
                if (val) {
                    this.token = val;
                    const httpOptions = {
                        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-Authorization': 'Bearer ' + this.token,
                        }),
                        response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                'Content-Type': 'application/json',
                                'Accept': 'application/json'
                            }),
                        })
                    };
                    console.log("URL: " + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/actions/expedient/" + judicialExpedient.id); //"secure/liquidations/"+this.data.iduser);
                    console.log("TOKEN: " + 'Bearer ' + this.token);
                    this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/actions/expedient/" + judicialExpedient.id, httpOptions)
                        .subscribe((data) => {
                        console.log("RESPONSE GET JUDICIAL EXPEDIENT DETAIL!: ");
                        //HARDCODING!!!!!!!!
                        // data = {"id":null,"name":"1077275","actions":[{"nroAction":"16857016","dateSign":"2019-12-23 12:32:49","extract":"CONSTANCIA DE ENTREGA DE EDICTOS"},{"nroAction":"16391024","dateSign":"2019-11-04 12:57:30","extract":"ACUMULESE OFR"},{"nroAction":"16100175","dateSign":"2019-10-04 11:14:15","extract":"VERONICA VIVIAN CUELLO LAPETINA"},{"nroAction":"16068414","dateSign":"2019-09-30 11:56:22","extract":"COMPROBANTE CEDULA RUSSO ADELA AURORA"},{"nroAction":"16068413","dateSign":"2019-09-30 11:56:22","extract":"COMPROBANTE CEDULA RUSSO ADELA AURORA"},{"nroAction":"16031395","dateSign":"2019-09-30 11:56:22","extract":"VERONICA CUELLO LAPETINA"},{"nroAction":"16022798","dateSign":"2019-09-30 11:56:22","extract":"CEDULA RUSSO ADELA AURORA"},{"nroAction":"16022860","dateSign":"2019-09-30 11:56:22","extract":"CEDULA POSTAL CUELLO LAPETINA VERONICA VIVIAN"},{"nroAction":"16022856","dateSign":"2019-09-30 11:56:22","extract":"CEDULA POSTAL CUELLO SUAREZ PABLO MARTIN"},{"nroAction":"16022921","dateSign":"2019-09-30 11:56:22","extract":"CEDULA POSTAL CUELLO SUAREZ ALEJANDRO HERNAN"},{"nroAction":"16044865","dateSign":"2019-09-30 08:25:14","extract":"ALEJANDRO HERNAN CUELLO SUAREZ"},{"nroAction":"16022740","dateSign":"2019-09-26 13:06:27","extract":"RECTIFICA"},{"nroAction":"15982402","dateSign":"2019-09-23 12:55:03","extract":"EDICTO"},{"nroAction":"16004378","dateSign":"2019-09-23 10:39:04","extract":"ADVIERTE ERROR - NUEVA CEDULA"},{"nroAction":"15943796","dateSign":"2019-09-20 10:38:11","extract":"CEDULA POSTAL CUELLO LAPETINA VERONICA VIVIAN"},{"nroAction":"15943794","dateSign":"2019-09-20 10:38:11","extract":"CEDULA POSTAL CUELLO SUAREZ PABLO MARTIN"},{"nroAction":"15987299","dateSign":"2019-09-20 10:38:11","extract":"COMPROBANTE CEDULA RUSSO ADELA AURORA"},{"nroAction":"15943755","dateSign":"2019-09-20 10:38:11","extract":"CEDULA RUSSO ADELA AURORA"},{"nroAction":"15943795","dateSign":"2019-09-20 10:38:11","extract":"CEDULA POSTAL CUELLO SUAREZ ALEJANDRO HERNAN"},{"nroAction":"15943325","dateSign":"2019-09-19 09:41:56","extract":"ABRE PROCESO SUCESORIO Y ORDENA MEDIDAS"},{"nroAction":"15812995","dateSign":"2019-09-04 12:51:58","extract":"CONTESTA VISTA"},{"nroAction":"15740804","dateSign":"2019-08-29 13:41:54","extract":"CORRASE VISTA FISCAL"},{"nroAction":"15602252","dateSign":"2019-08-15 12:41:45","extract":"OFICIO RJU VISTA FISCAL"},{"nroAction":"15553684","dateSign":"2019-08-07 11:05:12","extract":"ADJUNTA ESCRITO FIRMADO PROMOVIENTE"},{"nroAction":"15410980","dateSign":"2019-07-30 11:46:24","extract":"INFORME COLEGIO DE ESCRIBANOS "},{"nroAction":"15410991","dateSign":"2019-07-30 11:46:24","extract":"DECRETO-AGREGUESE "},{"nroAction":"15337404","dateSign":"2019-07-04 12:54:59","extract":"POR ACOMPA?ADO APORTE- POR CONSTITUIDO DOMICILIO PROCESAL"},{"nroAction":"15202957","dateSign":"2019-06-19 07:55:44","extract":"Cumplimenta-Aclara"},{"nroAction":"15170693","dateSign":"2019-06-14 11:47:26","extract":"ACLARE- POR PRESENTADOS HEREDEROS- CONSTITUYA DOMICILIO "},{"nroAction":"15035013","dateSign":"2019-05-31 09:54:11","extract":"ADJUNTA OFICIO CONTROL"},{"nroAction":"15034894","dateSign":"2019-05-31 07:34:19","extract":"Se notifican personalmente. Rectifican domicilio"},{"nroAction":"14984753","dateSign":"2019-05-29 11:11:32","extract":"CONSTANCIA DE COTEJO SE CONDICE"},{"nroAction":"14985147","dateSign":"2019-05-29 10:42:32","extract":"LIBRAR OFICIO COLEGIO DE ESCRIBANOS"},{"nroAction":"14951184","dateSign":"2019-05-23 10:49:44","extract":"ADJUNTA ESCRITO SUSCRIPTO PROMOVIENTE"},{"nroAction":"14919505","dateSign":"2019-05-22 07:25:43","extract":"CONSTANCIA DE RECEPCION DE DOCUMENTAL"},{"nroAction":"14882338","dateSign":"2019-05-20 12:18:41","extract":"DECRETO SIMPLE "},{"nroAction":"14840047","dateSign":"2019-05-14 09:17:06","extract":"DEMANDA DE IOL"}]};
                        console.log(JSON.stringify(data));
                        if (data != null) {
                            data.name = judicialExpedient.name;
                            // this.data.judicialExpedients = data;
                            console.log("JUDICIAL EXPEDIENT DETAIL!!!!");
                            console.log(JSON.stringify(data));
                            this.goToExpedientDetail(data);
                        }
                        else {
                            this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                        }
                        this.loadingController.dismiss();
                    }, error => {
                        this.processError(error).then(value => {
                            this.getjudicialExpedientDetail(judicialExpedient);
                        });
                    });
                }
                else {
                    this.alert("Ocurrió un problema, intente nuevamente");
                }
            });
        });
    }
    goToExpedientDetail(judicialExpedient) {
        let navigationExtras = {
            state: {
                content: judicialExpedient,
                token: this.token
            }
        };
        this.router.navigate(['judicialExpedientDetail'], navigationExtras);
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
};
JudicialExpedientsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_10__["ScreenOrientation"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_12__["RefreshUtils"] }
];
JudicialExpedientsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-judicialExpedients',
        template: __webpack_require__(/*! raw-loader!./judicialExpedients.page.html */ "./node_modules/raw-loader/index.js!./src/app/judicialExpedients/judicialExpedients.page.html"),
        styles: [__webpack_require__(/*! ./judicialExpedients.page.scss */ "./src/app/judicialExpedients/judicialExpedients.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"],
        _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
        _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_10__["ScreenOrientation"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_12__["RefreshUtils"]])
], JudicialExpedientsPage);



/***/ })

}]);
//# sourceMappingURL=judicialExpedients-judicialExpedients-module-es2015.js.map