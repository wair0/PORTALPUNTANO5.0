(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["health-credential-health-credential-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/health-credential/health-credential.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/health-credential/health-credential.page.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\">\r\n      </ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>CREDENCIAL PERSONAL DE SALUD</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"cardText\" *ngIf=\"data\">\r\n  <ion-card>  \r\n    <ion-card-content>\r\n      <ion-label class=\"labelBlock\"><b>Matricula: {{data.matricula}} </b></ion-label>  \r\n      <ion-label class=\"labelBlock\"><b>PROFESION: {{data.titulo}} </b></ion-label>\r\n      <ion-label class=\"labelBlock\"><b>Nombre y Apellido: {{data.nombre}} {{data.apellido}}</b></ion-label> \r\n      <ion-label class=\"labelBlock\"><b>DNI: {{data.dni}}</b></ion-label> \r\n      <ion-label class=\"labelBlock\"><b>INSCRIPCION: {{data.fecha_inscripcionString}}</b></ion-label> \r\n      <ion-label class=\"labelBlock\"><b>VENCIMIENTO: {{data.fecha_vencimientoString}}</b></ion-label> \r\n      <ion-label class=\"labelBlock\"><b>Autoridad de Inscripcion: {{data.autoridad}} </b></ion-label>\r\n    </ion-card-content>    \r\n  </ion-card> \r\n  <ion-img class=\"imgPhoto\" src=\"{{displayImage}}\"></ion-img>\r\n  <div class=\"labelMsj\">\r\n    <ion-label ><b>{{data.aviso}}</b></ion-label>\r\n  </div>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>  \r\n      <!-- TODO error al compilar con '--prod'-->\r\n      <!-- <ion-button (click)=\"goToHome()\"> -->\r\n      <ion-button>\r\n        <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n"

/***/ }),

/***/ "./src/app/health-credential/health-credential-routing.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/health-credential/health-credential-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: HealthCredentialPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HealthCredentialPageRoutingModule", function() { return HealthCredentialPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _health_credential_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./health-credential.page */ "./src/app/health-credential/health-credential.page.ts");




const routes = [
    {
        path: '',
        component: _health_credential_page__WEBPACK_IMPORTED_MODULE_3__["HealthCredentialPage"]
    }
];
let HealthCredentialPageRoutingModule = class HealthCredentialPageRoutingModule {
};
HealthCredentialPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], HealthCredentialPageRoutingModule);



/***/ }),

/***/ "./src/app/health-credential/health-credential.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/health-credential/health-credential.module.ts ***!
  \***************************************************************/
/*! exports provided: HealthCredentialPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HealthCredentialPageModule", function() { return HealthCredentialPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _health_credential_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./health-credential-routing.module */ "./src/app/health-credential/health-credential-routing.module.ts");
/* harmony import */ var _health_credential_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./health-credential.page */ "./src/app/health-credential/health-credential.page.ts");







let HealthCredentialPageModule = class HealthCredentialPageModule {
};
HealthCredentialPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _health_credential_routing_module__WEBPACK_IMPORTED_MODULE_5__["HealthCredentialPageRoutingModule"]
        ],
        declarations: [_health_credential_page__WEBPACK_IMPORTED_MODULE_6__["HealthCredentialPage"]]
    })
], HealthCredentialPageModule);



/***/ }),

/***/ "./src/app/health-credential/health-credential.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/health-credential/health-credential.page.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #971C74;\n}\n\n.white {\n  color: #ffffff !important;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #971C74;\n}\n\n.header-text {\n  padding-left: 10px;\n  width: 95%;\n  margin-bottom: 10px;\n  margin-top: 5px;\n  margin-left: 10px;\n  margin-right: 10px;\n  background-color: #971C74;\n  color: #ffffff;\n  border-radius: 10px !important;\n}\n\nion-header ion-toolbar {\n  --background: #971C74;\n}\n\nion-header ion-toolbar ion-title {\n  color: #ffffff;\n}\n\n.cardText {\n  text-align: center;\n  margin-top: 1rem;\n}\n\n.labelBlock {\n  display: block;\n  margin-top: 5px;\n}\n\n.imgPhoto {\n  margin: auto;\n  width: 50%;\n}\n\n.labelMsj {\n  margin-top: 1rem;\n  margin-left: 1rem;\n  margin-right: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhbHRoLWNyZWRlbnRpYWwvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxoZWFsdGgtY3JlZGVudGlhbFxcaGVhbHRoLWNyZWRlbnRpYWwucGFnZS5zY3NzIiwic3JjL2FwcC9oZWFsdGgtY3JlZGVudGlhbC9oZWFsdGgtY3JlZGVudGlhbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FDQ0o7O0FERUE7RUFDSSx5QkFBQTtBQ0NKOztBREVBO0VBQ0UsZ0NBQUE7QUNDRjs7QURHQTtFQUdFLGtCQUFBO0VBQ0EsVUFBQTtFQUdBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSw4QkFBQTtBQ0pGOztBRE9BO0VBQ0kscUJBQUE7QUNKSjs7QURPQTtFQUNFLGNBQUE7QUNKRjs7QURPQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7QUNKRjs7QURPQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FDSkY7O0FET0E7RUFDRSxZQUFBO0VBQ0EsVUFBQTtBQ0pGOztBRE9BO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDSkYiLCJmaWxlIjoic3JjL2FwcC9oZWFsdGgtY3JlZGVudGlhbC9oZWFsdGgtY3JlZGVudGlhbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVkIHtcclxuICAgIGNvbG9yOiAjOTcxQzc0O1xyXG4gIH1cclxuXHJcbi53aGl0ZSB7XHJcbiAgICBjb2xvcjogI2ZmZmZmZiAhaW1wb3J0YW50O1xyXG4gIH1cclxuIFxyXG5pb24taXRlbS5ib3JkZXItcmVkIHtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzk3MUM3NDtcclxufVxyXG5cclxuICBcclxuLmhlYWRlci10ZXh0IHtcclxuICAvLyBib3JkZXItYm90dG9tOjJweCBzb2xpZCAjNTM1MzUzO1xyXG4gIC8vIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gIHdpZHRoOiA5NSU7XHJcbiAgLy8gcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgLy8gcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM5NzFDNzQ7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogIzk3MUM3NDtcclxuICB9XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbn1cclxuXHJcbi5jYXJkVGV4dHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbWFyZ2luLXRvcDogMXJlbTtcclxufVxyXG5cclxuLmxhYmVsQmxvY2t7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLXRvcDogNXB4O1xyXG59XHJcblxyXG4uaW1nUGhvdG97XHJcbiAgbWFyZ2luOiBhdXRvO1xyXG4gIHdpZHRoOiA1MCU7XHJcbn1cclxuXHJcbi5sYWJlbE1zantcclxuICBtYXJnaW4tdG9wOiAxcmVtO1xyXG4gIG1hcmdpbi1sZWZ0OiAxcmVtO1xyXG4gIG1hcmdpbi1yaWdodDogMXJlbTtcclxufSIsIi5yZWQge1xuICBjb2xvcjogIzk3MUM3NDtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNmZmZmZmYgIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjOTcxQzc0O1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHdpZHRoOiA5NSU7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzk3MUM3NDtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzk3MUM3NDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI2ZmZmZmZjtcbn1cblxuLmNhcmRUZXh0IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAxcmVtO1xufVxuXG4ubGFiZWxCbG9jayB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW4tdG9wOiA1cHg7XG59XG5cbi5pbWdQaG90byB7XG4gIG1hcmdpbjogYXV0bztcbiAgd2lkdGg6IDUwJTtcbn1cblxuLmxhYmVsTXNqIHtcbiAgbWFyZ2luLXRvcDogMXJlbTtcbiAgbWFyZ2luLWxlZnQ6IDFyZW07XG4gIG1hcmdpbi1yaWdodDogMXJlbTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/health-credential/health-credential.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/health-credential/health-credential.page.ts ***!
  \*************************************************************/
/*! exports provided: HealthCredentialPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HealthCredentialPage", function() { return HealthCredentialPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");







let HealthCredentialPage = class HealthCredentialPage {
    constructor(route, http, alertController, sanitizer, router) {
        this.route = route;
        this.http = http;
        this.alertController = alertController;
        this.sanitizer = sanitizer;
        this.router = router;
        this.processError = function (error) {
            return new Promise((resolve, reject) => {
                // this.loadingController.dismiss();
                if (error.status === 500) {
                    if (error.error.exception === 'io.jsonwebtoken.ExpiredJwtException') {
                        this.storage.get('psw').then((val) => {
                            if (val) {
                                // this.loading();
                                this.refreshUtils.refreshToken(val).then((value) => {
                                    resolve(value);
                                }).catch((errorRefresh) => {
                                    // this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].GENERIC_ERROR);
                }
            });
        };
    }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                // this.shifts = this.router.getCurrentNavigation().extras.state.shifts;
                this.token = this.router.getCurrentNavigation().extras.state.token;
                this.data = this.router.getCurrentNavigation().extras.state.data;
                this.displayImage = 'data:image/jpeg;base64,' + this.data.photoBase64;
                //this.makeLiquidationsCollapse();
            }
        });
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
HealthCredentialPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
HealthCredentialPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-health-credential',
        template: __webpack_require__(/*! raw-loader!./health-credential.page.html */ "./node_modules/raw-loader/index.js!./src/app/health-credential/health-credential.page.html"),
        styles: [__webpack_require__(/*! ./health-credential.page.scss */ "./src/app/health-credential/health-credential.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"],
        _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
], HealthCredentialPage);



/***/ })

}]);
//# sourceMappingURL=health-credential-health-credential-module-es2015.js.map