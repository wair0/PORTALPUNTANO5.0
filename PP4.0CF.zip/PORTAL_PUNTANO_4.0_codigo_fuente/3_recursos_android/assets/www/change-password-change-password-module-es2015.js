(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["change-password-change-password-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/change-password/change-password.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/change-password/change-password.page.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border style=\"background-color: #932a7e;\">\r\n  <ion-toolbar style=\"background-color: #932a7e;\">\r\n    <div justify-content-center\r\n         style=\"background-color: #932a7e; width: 100%; display:flex; margin-bottom: 0%; margin-top: 5%;\">\r\n      <div style=\"background-color: #932a7e; width: fit-content; text-align: left;\">\r\n        <h1 style=\"color: #ffffff; font-size: 15vw; font-weight: 300;line-height: 5px\">PORTAL </h1>\r\n        <h1 style=\"font-weight: 800;color: white; font-size: 15vw\">PUNTANO</h1>\r\n      </div>\r\n    </div>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div style=\"background-color: #932a7e; width: 100%; height: 100%;\r\n flex-wrap: wrap;\r\n align-content: center;\r\n text-align: center;\r\n display: block\">\r\n\r\n\r\n    <ion-list lines=\"full\">\r\n\r\n      <ng-container>\r\n\r\n        <ion-item class=\"border\" *ngIf=\"fromHome\">\r\n          <ion-input [(ngModel)]=\"oldPassword\" name=\"password\"  type=\"{{oldPasswordType}}\" placeholder=\"Contraseña actual\">\r\n          </ion-input>\r\n          <ion-button style=\"margin-top: 0%; margin-bottom: 0%; --box-shadow:none; margin-right: 0%\"\r\n                      (click)=\"changeHideOldPassword()\">\r\n            <svg *ngIf=\"!hideOldPassword\" xmlns='http://www.w3.org/2000/svg'\r\n                 height='90%' viewBox='0 0 512 512'>\r\n              <path d='M255.66,112c-77.94,0-157.89,45.11-220.83,135.33a16,16,0,0,0-.27,17.77C82.92,340.8,161.8,400,255.66,400,348.5,400,429,340.62,477.45,264.75a16.14,16.14,0,0,0,0-17.47C428.89,172.28,347.8,112,255.66,112Z'\r\n                    style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px'/>\r\n              <circle cx='256' cy='256' r='80'\r\n                      style='fill:none;stroke:#FFF;stroke-miterlimit:10;stroke-width:32px'/>\r\n            </svg>\r\n            <svg *ngIf=\"hideOldPassword\" xmlns='http://www.w3.org/2000/svg'\r\n                 height='90%' fill=\"#FFF\" viewBox='0 0 512 512'>\r\n              <path d='M432,448a15.92,15.92,0,0,1-11.31-4.69l-352-352A16,16,0,0,1,91.31,68.69l352,352A16,16,0,0,1,432,448Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M255.66,384c-41.49,0-81.5-12.28-118.92-36.5-34.07-22-64.74-53.51-88.7-91l0-.08c19.94-28.57,41.78-52.73,65.24-72.21a2,2,0,0,0,.14-2.94L93.5,161.38a2,2,0,0,0-2.71-.12c-24.92,21-48.05,46.76-69.08,76.92a31.92,31.92,0,0,0-.64,35.54c26.41,41.33,60.4,76.14,98.28,100.65C162,402,207.9,416,255.66,416a239.13,239.13,0,0,0,75.8-12.58,2,2,0,0,0,.77-3.31l-21.58-21.58a4,4,0,0,0-3.83-1A204.8,204.8,0,0,1,255.66,384Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M490.84,238.6c-26.46-40.92-60.79-75.68-99.27-100.53C349,110.55,302,96,255.66,96a227.34,227.34,0,0,0-74.89,12.83,2,2,0,0,0-.75,3.31l21.55,21.55a4,4,0,0,0,3.88,1A192.82,192.82,0,0,1,255.66,128c40.69,0,80.58,12.43,118.55,37,34.71,22.4,65.74,53.88,89.76,91a.13.13,0,0,1,0,.16,310.72,310.72,0,0,1-64.12,72.73,2,2,0,0,0-.15,2.95l19.9,19.89a2,2,0,0,0,2.7.13,343.49,343.49,0,0,0,68.64-78.48A32.2,32.2,0,0,0,490.84,238.6Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M256,160a95.88,95.88,0,0,0-21.37,2.4,2,2,0,0,0-1,3.38L346.22,278.34a2,2,0,0,0,3.38-1A96,96,0,0,0,256,160Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M165.78,233.66a2,2,0,0,0-3.38,1,96,96,0,0,0,115,115,2,2,0,0,0,1-3.38Z'\r\n                    style='stroke:#FFF;'/>\r\n            </svg>\r\n          </ion-button>\r\n        </ion-item>\r\n\r\n\r\n        <ion-item class=\"border\">\r\n          <ion-input [(ngModel)]=\"password\" name=\"password\" type=\"{{passwordType}}\" placeholder=\"{{fromHome?'Nueva contraseña':'Contraseña'}}\">\r\n          </ion-input>\r\n          <ion-button style=\"margin-top: 0%; margin-bottom: 0%; --box-shadow:none; margin-right: 0%\"\r\n                      (click)=\"changeHidePassword()\">\r\n            <svg *ngIf=\"!hidePassword\" xmlns='http://www.w3.org/2000/svg'\r\n                 height='90%' viewBox='0 0 512 512'>\r\n              <path d='M255.66,112c-77.94,0-157.89,45.11-220.83,135.33a16,16,0,0,0-.27,17.77C82.92,340.8,161.8,400,255.66,400,348.5,400,429,340.62,477.45,264.75a16.14,16.14,0,0,0,0-17.47C428.89,172.28,347.8,112,255.66,112Z'\r\n                    style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px'/>\r\n              <circle cx='256' cy='256' r='80'\r\n                      style='fill:none;stroke:#FFF;stroke-miterlimit:10;stroke-width:32px'/>\r\n            </svg>\r\n            <svg *ngIf=\"hidePassword\" xmlns='http://www.w3.org/2000/svg'\r\n                 height='90%' fill=\"#FFF\" viewBox='0 0 512 512'>\r\n              <path d='M432,448a15.92,15.92,0,0,1-11.31-4.69l-352-352A16,16,0,0,1,91.31,68.69l352,352A16,16,0,0,1,432,448Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M255.66,384c-41.49,0-81.5-12.28-118.92-36.5-34.07-22-64.74-53.51-88.7-91l0-.08c19.94-28.57,41.78-52.73,65.24-72.21a2,2,0,0,0,.14-2.94L93.5,161.38a2,2,0,0,0-2.71-.12c-24.92,21-48.05,46.76-69.08,76.92a31.92,31.92,0,0,0-.64,35.54c26.41,41.33,60.4,76.14,98.28,100.65C162,402,207.9,416,255.66,416a239.13,239.13,0,0,0,75.8-12.58,2,2,0,0,0,.77-3.31l-21.58-21.58a4,4,0,0,0-3.83-1A204.8,204.8,0,0,1,255.66,384Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M490.84,238.6c-26.46-40.92-60.79-75.68-99.27-100.53C349,110.55,302,96,255.66,96a227.34,227.34,0,0,0-74.89,12.83,2,2,0,0,0-.75,3.31l21.55,21.55a4,4,0,0,0,3.88,1A192.82,192.82,0,0,1,255.66,128c40.69,0,80.58,12.43,118.55,37,34.71,22.4,65.74,53.88,89.76,91a.13.13,0,0,1,0,.16,310.72,310.72,0,0,1-64.12,72.73,2,2,0,0,0-.15,2.95l19.9,19.89a2,2,0,0,0,2.7.13,343.49,343.49,0,0,0,68.64-78.48A32.2,32.2,0,0,0,490.84,238.6Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M256,160a95.88,95.88,0,0,0-21.37,2.4,2,2,0,0,0-1,3.38L346.22,278.34a2,2,0,0,0,3.38-1A96,96,0,0,0,256,160Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M165.78,233.66a2,2,0,0,0-3.38,1,96,96,0,0,0,115,115,2,2,0,0,0,1-3.38Z'\r\n                    style='stroke:#FFF;'/>\r\n            </svg>\r\n          </ion-button>\r\n        </ion-item>\r\n\r\n        <ion-item class=\"border\">\r\n          <ion-input [(ngModel)]=\"passwordRepeat\" name=\"password\" type=\"{{passwordTypeRepeat}}\" placeholder=\"{{fromHome?'Confirmar nueva contraseña':'Reiterar contraseña'}}\">\r\n          </ion-input>\r\n          <ion-button style=\"margin-top: 0%; margin-bottom: 0%; --box-shadow:none; margin-right: 0%\"\r\n                      (click)=\"changeHidePasswordRepeat()\">\r\n            <svg *ngIf=\"!hidePasswordRepeat\" xmlns='http://www.w3.org/2000/svg'\r\n                 height='90%' viewBox='0 0 512 512'>\r\n              <path d='M255.66,112c-77.94,0-157.89,45.11-220.83,135.33a16,16,0,0,0-.27,17.77C82.92,340.8,161.8,400,255.66,400,348.5,400,429,340.62,477.45,264.75a16.14,16.14,0,0,0,0-17.47C428.89,172.28,347.8,112,255.66,112Z'\r\n                    style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px'/>\r\n              <circle cx='256' cy='256' r='80'\r\n                      style='fill:none;stroke:#FFF;stroke-miterlimit:10;stroke-width:32px'/>\r\n            </svg>\r\n            <svg *ngIf=\"hidePasswordRepeat\" xmlns='http://www.w3.org/2000/svg'\r\n                 height='90%' fill=\"#FFF\" viewBox='0 0 512 512'>\r\n              <path d='M432,448a15.92,15.92,0,0,1-11.31-4.69l-352-352A16,16,0,0,1,91.31,68.69l352,352A16,16,0,0,1,432,448Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M255.66,384c-41.49,0-81.5-12.28-118.92-36.5-34.07-22-64.74-53.51-88.7-91l0-.08c19.94-28.57,41.78-52.73,65.24-72.21a2,2,0,0,0,.14-2.94L93.5,161.38a2,2,0,0,0-2.71-.12c-24.92,21-48.05,46.76-69.08,76.92a31.92,31.92,0,0,0-.64,35.54c26.41,41.33,60.4,76.14,98.28,100.65C162,402,207.9,416,255.66,416a239.13,239.13,0,0,0,75.8-12.58,2,2,0,0,0,.77-3.31l-21.58-21.58a4,4,0,0,0-3.83-1A204.8,204.8,0,0,1,255.66,384Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M490.84,238.6c-26.46-40.92-60.79-75.68-99.27-100.53C349,110.55,302,96,255.66,96a227.34,227.34,0,0,0-74.89,12.83,2,2,0,0,0-.75,3.31l21.55,21.55a4,4,0,0,0,3.88,1A192.82,192.82,0,0,1,255.66,128c40.69,0,80.58,12.43,118.55,37,34.71,22.4,65.74,53.88,89.76,91a.13.13,0,0,1,0,.16,310.72,310.72,0,0,1-64.12,72.73,2,2,0,0,0-.15,2.95l19.9,19.89a2,2,0,0,0,2.7.13,343.49,343.49,0,0,0,68.64-78.48A32.2,32.2,0,0,0,490.84,238.6Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M256,160a95.88,95.88,0,0,0-21.37,2.4,2,2,0,0,0-1,3.38L346.22,278.34a2,2,0,0,0,3.38-1A96,96,0,0,0,256,160Z'\r\n                    style='stroke:#FFF;'/>\r\n              <path d='M165.78,233.66a2,2,0,0,0-3.38,1,96,96,0,0,0,115,115,2,2,0,0,0,1-3.38Z'\r\n                    style='stroke:#FFF;'/>\r\n            </svg>\r\n          </ion-button>\r\n        </ion-item>\r\n\r\n\r\n        <ion-button color=\"light\" (click)=\"passwordAction()\">MODIFICAR CONTRASEÑA</ion-button>\r\n\r\n\r\n      </ng-container>\r\n\r\n    </ion-list>\r\n\r\n  </div>\r\n\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/change-password/change-password-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/change-password/change-password-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: ChangePasswordPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePasswordPageRoutingModule", function() { return ChangePasswordPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _change_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./change-password.page */ "./src/app/change-password/change-password.page.ts");




const routes = [
    {
        path: '',
        component: _change_password_page__WEBPACK_IMPORTED_MODULE_3__["ChangePasswordPage"]
    }
];
let ChangePasswordPageRoutingModule = class ChangePasswordPageRoutingModule {
};
ChangePasswordPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ChangePasswordPageRoutingModule);



/***/ }),

/***/ "./src/app/change-password/change-password.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/change-password/change-password.module.ts ***!
  \***********************************************************/
/*! exports provided: ChangePasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePasswordPageModule", function() { return ChangePasswordPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _change_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./change-password-routing.module */ "./src/app/change-password/change-password-routing.module.ts");
/* harmony import */ var _change_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./change-password.page */ "./src/app/change-password/change-password.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");








let ChangePasswordPageModule = class ChangePasswordPageModule {
};
ChangePasswordPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _change_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChangePasswordPageRoutingModule"]
        ],
        providers: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"]
        ],
        declarations: [_change_password_page__WEBPACK_IMPORTED_MODULE_6__["ChangePasswordPage"]]
    })
], ChangePasswordPageModule);



/***/ }),

/***/ "./src/app/change-password/change-password.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/change-password/change-password.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: #932a7e;\n}\n\nion-buttons {\n  background: #932a7e !important;\n  --background: #932a7e !important;\n  --background-color: #932a7e !important;\n}\n\nion-tab-button {\n  --padding: 0px !important;\n  background: #932a7e !important;\n  --background: #932a7e !important;\n  --background-color: #932a7e !important;\n}\n\nion-tab-bar {\n  background: #932a7e !important;\n  --background: #932a7e !important;\n  --background-color: #932a7e !important;\n}\n\nion-footer {\n  background: #932a7e !important;\n  --background: #932a7e !important;\n  --background-color: #932a7e !important;\n}\n\nion-toolbar {\n  background: #932a7e !important;\n  --background: #932a7e !important;\n  --background-color: #932a7e !important;\n}\n\nion-list {\n  background-color: #932a7e !important;\n  padding-left: 10%;\n  padding-right: 10%;\n  width: 100%;\n  text-align: center;\n}\n\nion-item.border {\n  background-color: #932a7e !important;\n  --border-color: #932a7e;\n  color: #932a7e !important;\n  padding: 0%;\n  border-radius: 17px;\n  border: 2px solid white;\n  margin-top: 3%;\n  align-items: center;\n  justify-content: center;\n  --min-height:5vh !important;\n}\n\nion-item.borderCenter {\n  background-color: #932a7e !important;\n  --border-color: #932a7e;\n  color: #932a7e !important;\n  padding: 0%;\n  border-radius: 17px;\n  border: 2px solid white;\n  margin-top: 1vh;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  vertical-align: middle;\n  --min-height:5vh !important;\n}\n\n.borderLetter {\n  color: green;\n  -webkit-text-fill-color: green;\n  /* Will override color (regardless of order) */\n  -webkit-text-stroke-width: 0.5px;\n  -webkit-text-stroke-color: white;\n  margin: 0%;\n  text-align: center;\n}\n\nion-select {\n  color: white !important;\n}\n\n.white {\n  color: white !important;\n}\n\nion-label {\n  color: white !important;\n  padding: 0%;\n}\n\nion-input {\n  background-color: #932a7e !important;\n  color: white;\n}\n\nion-button {\n  background-color: #932a7e;\n  -webkit-text-fill-color: #932a7e;\n  font-weight: bold;\n  margin-top: 10%;\n}\n\nion-content {\n  --ion-background-color:#932a7e;\n}\n\nion-item {\n  --ion-background-color:#932a7e;\n}\n\n.btn-1 {\n  margin: 0%;\n  float: left;\n  padding: 0px 0px 0px 0px;\n  align-self: center;\n}\n\n.btn-2 {\n  margin: 0%;\n  float: right;\n  padding: 0px 0px 0px 0px;\n  align-self: center;\n}\n\n.disabled {\n  opacity: 0.5;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hhbmdlLXBhc3N3b3JkL0Q6XFxSZXBvc2l0b3Jpb3NcXHBvcnRhbC1pb25pYy9zcmNcXGFwcFxcY2hhbmdlLXBhc3N3b3JkXFxjaGFuZ2UtcGFzc3dvcmQucGFnZS5zY3NzIiwic3JjL2FwcC9jaGFuZ2UtcGFzc3dvcmQvY2hhbmdlLXBhc3N3b3JkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FDQ0Y7O0FER0E7RUFDRSw4QkFBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7QUNBRjs7QURFQTtFQUNFLHlCQUFBO0VBQ0EsOEJBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0FDQ0Y7O0FERUE7RUFDRSw4QkFBQTtFQUNBLGdDQUFBO0VBQ0Esc0NBQUE7QUNDRjs7QURFQTtFQUNFLDhCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxzQ0FBQTtBQ0NGOztBRElBO0VBQ0UsOEJBQUE7RUFDQSxnQ0FBQTtFQUNBLHNDQUFBO0FDREY7O0FESUE7RUFDRSxvQ0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNERjs7QURJQTtFQUNFLG9DQUFBO0VBQ0EsdUJBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSwyQkFBQTtBQ0RGOztBREtBO0VBQ0Usb0NBQUE7RUFDQSx1QkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSwyQkFBQTtBQ0ZGOztBREtBO0VBQ0UsWUFBQTtFQUNBLDhCQUFBO0VBQWdDLDhDQUFBO0VBQ2hDLGdDQUFBO0VBQ0EsZ0NBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7QUNERjs7QURJQTtFQUVFLHVCQUFBO0FDRkY7O0FES0E7RUFDRSx1QkFBQTtBQ0ZGOztBREtBO0VBRUUsdUJBQUE7RUFDQSxXQUFBO0FDSEY7O0FETUE7RUFDRSxvQ0FBQTtFQUNBLFlBQUE7QUNIRjs7QURRQTtFQUNFLHlCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNMRjs7QURRQTtFQUNFLDhCQUFBO0FDTEY7O0FEUUE7RUFDRSw4QkFBQTtBQ0xGOztBRFFBO0VBQ0UsVUFBQTtFQUNBLFdBQUE7RUFDQSx3QkFBQTtFQUNBLGtCQUFBO0FDTEY7O0FET0E7RUFDRSxVQUFBO0VBQ0EsWUFBQTtFQUNBLHdCQUFBO0VBQ0Esa0JBQUE7QUNKRjs7QURPQTtFQUNFLFlBQUE7QUNKRiIsImZpbGUiOiJzcmMvYXBwL2NoYW5nZS1wYXNzd29yZC9jaGFuZ2UtcGFzc3dvcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciBpb24tdG9vbGJhcntcclxuICAtLWJhY2tncm91bmQ6ICM5MzJhN2U7XHJcblxyXG59XHJcblxyXG5pb24tYnV0dG9uc3tcclxuICBiYWNrZ3JvdW5kOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbiAgLS1iYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbn1cclxuaW9uLXRhYi1idXR0b257XHJcbiAgLS1wYWRkaW5nOiAwcHggIWltcG9ydGFudDtcclxuICBiYWNrZ3JvdW5kOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbiAgLS1iYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi10YWItYmFye1xyXG4gIGJhY2tncm91bmQ6ICM5MzJhN2UgIWltcG9ydGFudDtcclxuICAtLWJhY2tncm91bmQ6ICM5MzJhN2UgIWltcG9ydGFudDtcclxuICAtLWJhY2tncm91bmQtY29sb3I6ICM5MzJhN2UgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWZvb3RlcntcclxuICBiYWNrZ3JvdW5kOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbiAgLS1iYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcblxyXG5cclxuaW9uLXRvb2xiYXJ7XHJcbiAgYmFja2dyb3VuZDogIzkzMmE3ZSAhaW1wb3J0YW50O1xyXG4gIC0tYmFja2dyb3VuZDogIzkzMmE3ZSAhaW1wb3J0YW50O1xyXG4gIC0tYmFja2dyb3VuZC1jb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tbGlzdHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbiAgcGFkZGluZy1sZWZ0OiAxMCU7XHJcbiAgcGFkZGluZy1yaWdodDogMTAlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuaW9uLWl0ZW0uYm9yZGVye1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM5MzJhN2UgIWltcG9ydGFudDtcclxuICAtLWJvcmRlci1jb2xvcjogIzkzMmE3ZTtcclxuICBjb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmc6IDAlO1xyXG4gIGJvcmRlci1yYWRpdXM6MTdweDtcclxuICBib3JkZXI6MnB4IHNvbGlkIHdoaXRlO1xyXG4gIG1hcmdpbi10b3A6IDMlO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgLS1taW4taGVpZ2h0OjV2aCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5cclxuaW9uLWl0ZW0uYm9yZGVyQ2VudGVye1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM5MzJhN2UgIWltcG9ydGFudDtcclxuICAtLWJvcmRlci1jb2xvcjogIzkzMmE3ZTtcclxuICBjb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmc6IDAlO1xyXG4gIGJvcmRlci1yYWRpdXM6MTdweDtcclxuICBib3JkZXI6MnB4IHNvbGlkIHdoaXRlO1xyXG4gIG1hcmdpbi10b3A6IDF2aDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gIC0tbWluLWhlaWdodDo1dmggIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvcmRlckxldHRlcntcclxuICBjb2xvcjogZ3JlZW47XHJcbiAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IGdyZWVuOyAvKiBXaWxsIG92ZXJyaWRlIGNvbG9yIChyZWdhcmRsZXNzIG9mIG9yZGVyKSAqL1xyXG4gIC13ZWJraXQtdGV4dC1zdHJva2Utd2lkdGg6IDAuNXB4O1xyXG4gIC13ZWJraXQtdGV4dC1zdHJva2UtY29sb3I6IHdoaXRlO1xyXG4gIG1hcmdpbjowJTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbmlvbi1zZWxlY3R7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xyXG4gIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ud2hpdGV7XHJcbiAgY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1sYWJlbHtcclxuICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbiAgY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XHJcbiAgcGFkZGluZzogMCU7XHJcbn1cclxuXHJcbmlvbi1pbnB1dHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG5cclxuXHJcbn1cclxuXHJcbmlvbi1idXR0b257XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzkzMmE3ZTtcclxuICAtd2Via2l0LXRleHQtZmlsbC1jb2xvcjogIzkzMmE3ZTtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBtYXJnaW4tdG9wOiAxMCU7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50e1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IzkzMmE3ZTtcclxufVxyXG5cclxuaW9uLWl0ZW17XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojOTMyYTdlO1xyXG59XHJcblxyXG4uYnRuLTF7XHJcbiAgbWFyZ2luOiAwJTtcclxuICBmbG9hdDpsZWZ0O1xyXG4gIHBhZGRpbmc6MHB4IDBweCAwcHggMHB4O1xyXG4gIGFsaWduLXNlbGY6IGNlbnRlcjtcclxufVxyXG4uYnRuLTJ7XHJcbiAgbWFyZ2luOiAwJTtcclxuICBmbG9hdDpyaWdodDtcclxuICBwYWRkaW5nOjBweCAwcHggMHB4IDBweDtcclxuICBhbGlnbi1zZWxmOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5kaXNhYmxlZHtcclxuICBvcGFjaXR5OiAuNTtcclxufVxyXG4iLCJpb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjOTMyYTdlO1xufVxuXG5pb24tYnV0dG9ucyB7XG4gIGJhY2tncm91bmQ6ICM5MzJhN2UgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiAjOTMyYTdlICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1jb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tdGFiLWJ1dHRvbiB7XG4gIC0tcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6ICM5MzJhN2UgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiAjOTMyYTdlICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1jb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tdGFiLWJhciB7XG4gIGJhY2tncm91bmQ6ICM5MzJhN2UgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiAjOTMyYTdlICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZC1jb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tZm9vdGVyIHtcbiAgYmFja2dyb3VuZDogIzkzMmE3ZSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6ICM5MzJhN2UgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgYmFja2dyb3VuZDogIzkzMmE3ZSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6ICM5MzJhN2UgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1saXN0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWxlZnQ6IDEwJTtcbiAgcGFkZGluZy1yaWdodDogMTAlO1xuICB3aWR0aDogMTAwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pb24taXRlbS5ib3JkZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XG4gIC0tYm9yZGVyLWNvbG9yOiAjOTMyYTdlO1xuICBjb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiAwJTtcbiAgYm9yZGVyLXJhZGl1czogMTdweDtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XG4gIG1hcmdpbi10b3A6IDMlO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgLS1taW4taGVpZ2h0OjV2aCAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbS5ib3JkZXJDZW50ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlICFpbXBvcnRhbnQ7XG4gIC0tYm9yZGVyLWNvbG9yOiAjOTMyYTdlO1xuICBjb2xvcjogIzkzMmE3ZSAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiAwJTtcbiAgYm9yZGVyLXJhZGl1czogMTdweDtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XG4gIG1hcmdpbi10b3A6IDF2aDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgLS1taW4taGVpZ2h0OjV2aCAhaW1wb3J0YW50O1xufVxuXG4uYm9yZGVyTGV0dGVyIHtcbiAgY29sb3I6IGdyZWVuO1xuICAtd2Via2l0LXRleHQtZmlsbC1jb2xvcjogZ3JlZW47XG4gIC8qIFdpbGwgb3ZlcnJpZGUgY29sb3IgKHJlZ2FyZGxlc3Mgb2Ygb3JkZXIpICovXG4gIC13ZWJraXQtdGV4dC1zdHJva2Utd2lkdGg6IDAuNXB4O1xuICAtd2Via2l0LXRleHQtc3Ryb2tlLWNvbG9yOiB3aGl0ZTtcbiAgbWFyZ2luOiAwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pb24tc2VsZWN0IHtcbiAgY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tbGFiZWwge1xuICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgcGFkZGluZzogMCU7XG59XG5cbmlvbi1pbnB1dCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5MzJhN2UgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG5pb24tYnV0dG9uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzkzMmE3ZTtcbiAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6ICM5MzJhN2U7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW4tdG9wOiAxMCU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojOTMyYTdlO1xufVxuXG5pb24taXRlbSB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IzkzMmE3ZTtcbn1cblxuLmJ0bi0xIHtcbiAgbWFyZ2luOiAwJTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIHBhZGRpbmc6IDBweCAwcHggMHB4IDBweDtcbiAgYWxpZ24tc2VsZjogY2VudGVyO1xufVxuXG4uYnRuLTIge1xuICBtYXJnaW46IDAlO1xuICBmbG9hdDogcmlnaHQ7XG4gIHBhZGRpbmc6IDBweCAwcHggMHB4IDBweDtcbiAgYWxpZ24tc2VsZjogY2VudGVyO1xufVxuXG4uZGlzYWJsZWQge1xuICBvcGFjaXR5OiAwLjU7XG59Il19 */"

/***/ }),

/***/ "./src/app/change-password/change-password.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/change-password/change-password.page.ts ***!
  \*********************************************************/
/*! exports provided: ChangePasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePasswordPage", function() { return ChangePasswordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");








let ChangePasswordPage = class ChangePasswordPage {
    constructor(location, loadingController, router, navController, storage, http, alertController) {
        this.location = location;
        this.loadingController = loadingController;
        this.router = router;
        this.navController = navController;
        this.storage = storage;
        this.http = http;
        this.alertController = alertController;
        this.hideOldPassword = true;
        this.oldPasswordType = 'password';
        this.hidePassword = true;
        this.passwordType = 'password';
        this.hidePasswordRepeat = true;
        this.passwordTypeRepeat = 'password';
        this.fromHome = false;
        if (this.router.getCurrentNavigation().extras.state) {
            if (this.router.getCurrentNavigation().extras.state.height) {
                this.height = this.router.getCurrentNavigation().extras.state.height;
            }
            if (this.router.getCurrentNavigation().extras.state.width) {
                this.width = this.router.getCurrentNavigation().extras.state.width;
            }
            if (this.router.getCurrentNavigation().extras.state.password) {
                this.passwordParam = this.router.getCurrentNavigation().extras.state.password;
            }
            if (this.router.getCurrentNavigation().extras.state.token) {
                this.token = this.router.getCurrentNavigation().extras.state.token;
            }
            if (this.router.getCurrentNavigation().extras.state.dni) {
                this.dni = this.router.getCurrentNavigation().extras.state.dni;
            }
            if (this.router.getCurrentNavigation().extras.state.sex) {
                this.sex = this.router.getCurrentNavigation().extras.state.sex;
            }
            if (this.router.getCurrentNavigation().extras.state.fromHome) {
                this.fromHome = this.router.getCurrentNavigation().extras.state.fromHome;
            }
        }
    }
    ngOnInit() {
    }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando',
            });
            yield loading.present();
        });
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loadingController.dismiss();
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    alertChangePassword(messageText, data) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loadingController.dismiss();
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                        }
                    },
                    {
                        text: 'Aceptar',
                        cssClass: 'primary',
                        handler: () => {
                            this.loading();
                            this.sendPassword(data);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    changeHidePassword() {
        if (!this.hidePassword) {
            this.passwordType = 'password';
        }
        else {
            this.passwordType = 'text';
        }
        this.hidePassword = !this.hidePassword;
    }
    changePassword() {
        this.location.back();
    }
    changeHidePasswordRepeat() {
        if (!this.hidePasswordRepeat) {
            this.passwordTypeRepeat = 'password';
        }
        else {
            this.passwordTypeRepeat = 'text';
        }
        this.hidePasswordRepeat = !this.hidePasswordRepeat;
    }
    changeHideOldPassword() {
        if (!this.hideOldPassword) {
            this.oldPasswordType = 'password';
        }
        else {
            this.oldPasswordType = 'text';
        }
        this.hideOldPassword = !this.hideOldPassword;
    }
    passwordAction() {
        if (this.password && this.passwordRepeat
            && this.password === this.passwordRepeat && _utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].REGEX_PASSWORD.test(this.password)) {
            const data = {
                oldPassword: this.fromHome ? this.oldPassword : this.passwordParam,
                password: this.password
            };
            if (this.fromHome) {
                this.alertChangePassword('Al modificar su contraseña se cerrarán todas las sesiones que se encuentren abiertas en éste y/o en otros dispositivos', data);
            }
            else {
                this.loading();
                this.sendPassword(data);
            }
        }
        else {
            if (!this.password) {
                this.alert('Debe escribir una contraseña');
            }
            else if (!this.passwordRepeat) {
                this.alert('Debe repetir la contraseña');
            }
            else if (this.password !== this.passwordRepeat) {
                this.alert('Las contraseñas no coinciden');
            }
            else if (!_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].REGEX_PASSWORD.test(this.password)) {
                this.alert('La contraseña debe tener entre 8 y 16 caracteres, contener al menos un número, al menos una letra mayúscula y no contener espacios');
            }
        }
    }
    sendPassword(passwordObject) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storage.get('token').then((val) => {
                if (val) {
                    this.token = val;
                    const httpOptions = {
                        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                            'Content-Type': 'application/json',
                            Accept: 'application/json',
                            'X-Authorization': 'Bearer ' + this.token,
                        }),
                        observe: 'response',
                        response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                'Content-Type': 'application/json',
                                Accept: 'application/json'
                            })
                        })
                    };
                    this.http.put(_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + 'secure/user/password', passwordObject, httpOptions)
                        .subscribe((data) => {
                        if (this.fromHome) {
                            this.storage.remove('psw');
                            this.navigateLogin();
                        }
                        else {
                            this.login();
                        }
                    }, error => {
                        this.loadingController.dismiss();
                        if (error.status === 409) {
                            this.alert(error.error.message);
                        }
                        else if (error.status === 401) {
                            this.alert(error.error.message);
                        }
                        else {
                            this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].GENERIC_ERROR);
                        }
                    });
                }
                else {
                    this.loadingController.dismiss();
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].GENERIC_ERROR);
                }
            });
        });
    }
    login() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storage.remove('token');
            this.storage.remove('tokenRM');
            setTimeout(() => {
                const httpOptions = {
                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                        'Content-Type': 'application/json',
                        Accept: 'application/json'
                    }),
                    response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                            'Content-Type': 'application/json',
                            Accept: 'application/json'
                        }),
                    })
                };
                const postData = {
                    docType: 'DNI',
                    docNumber: this.dni,
                    sex: this.sex,
                    password: this.password
                };
                this.http.post(_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + 'token/mobile/login', postData, httpOptions)
                    .subscribe((data) => {
                    this.storage.set('psw', postData);
                    this.storage.set('token', data.authToken.token);
                    this.storage.set('userId', data.user.userId);
                    this.storage.set('liquidations', data.liquidations);
                    this.storage.set('externalDocument', data.externalDocument);
                    this.storage.set('judicialExpedient', data.judicialExpedient);
                    this.token = data.authToken.token;
                    this.navigate();
                }, error => {
                    console.log('Error!!!!!');
                    console.log(error);
                    // this.loadingController.dismiss();
                    if (error.status === 409) {
                        this.alert(error.error.message);
                    }
                    else if (error.status === 401) {
                        this.alert(error.error.message);
                    }
                    else {
                        this.alert('Ocurrió un problema al autenticarse, por favor intente nuevamente');
                    }
                    this.storage.clear();
                });
            }, 1000);
        });
    }
    navigate() {
        this.loadingController.dismiss();
        const navigationExtras = {
            state: {
                height: this.height,
                width: this.width,
            }
        };
        this.navController.navigateRoot('/home', navigationExtras);
    }
    navigateLogin() {
        this.loadingController.dismiss();
        const navigationExtras = {
            state: {
                height: this.height,
                width: this.width,
            }
        };
        this.navController.navigateRoot('/login', navigationExtras);
    }
};
ChangePasswordPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] }
];
ChangePasswordPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-change-password',
        template: __webpack_require__(/*! raw-loader!./change-password.page.html */ "./node_modules/raw-loader/index.js!./src/app/change-password/change-password.page.html"),
        styles: [__webpack_require__(/*! ./change-password.page.scss */ "./src/app/change-password/change-password.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"], _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"]])
], ChangePasswordPage);



/***/ })

}]);
//# sourceMappingURL=change-password-change-password-module-es2015.js.map