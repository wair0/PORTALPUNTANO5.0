(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["judicialExpedientDetail-judicialExpedientDetail-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/judicialExpedientDetail/judicialExpedientDetail.page.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/judicialExpedientDetail/judicialExpedientDetail.page.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>ACTUACIONES</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-list-header>\r\n        <h2 class=\"header-text\"><b>{{judicialExpedient.name}}</b></h2>\r\n      </ion-list-header>\r\n  <ion-list *ngFor=\"let item of judicialExpedient.actions\">\r\n    <!-- <div *ngFor=\"let expedient of item.expedients; let i = index\"> -->\r\n    <ion-item class=\"border-red\" >\r\n      <ion-list >\r\n      <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n        <ion-label class=\"ion-text-wrap\">\r\n          <ion-text class=\"red\">\r\n            <h3 style=\"display: block;\">Nro. Actuación: {{item.nroAction}}</h3>\r\n            <h3 style=\"display: block;\">Fecha de Firma: {{item.dateSign}}</h3>\r\n            <h3 style=\"display: block;\">Extracto: {{item.extract}}</h3>\r\n          </ion-text>\r\n        </ion-label>\r\n\r\n      </ion-item>\r\n\r\n      <ion-item lines=\"none\" (click)=\"checkPassword(item)\">\r\n        <ion-card text-center style=\"padding: 0px; margin: 0px;\">\r\n          <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n          width=\"30%\" height=\"30%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n       <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#003F79\" d=\"M862.973,656.11h-89.835v148.416\r\n         c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n         c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n         c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n         c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n         C840.518,409.458,840.518,415.762,837.57,419.12\"/>\r\n       </svg>\r\n        </ion-card>\r\n      </ion-item>\r\n    </ion-list>\r\n\r\n    </ion-item>\r\n\r\n    <!-- </div> -->\r\n\r\n    <!-- <ion-item lines=\"none\" (click)=\"goToJudicialExpedientsAll(item)\">\r\n      <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:20px; border-radius:6px; background-color: #e6e6e6; width: 100%;\">\r\n          <h5 style=\"display: inline;\"> Mostrar todos</h5>\r\n          <ion-icon style=\"align-content: flex-end; align-self:rigth; vertical-align: middle; margin: 0px !important;\" name=\"ios-arrow-forward\"></ion-icon>\r\n          </ion-text>\r\n  </ion-item> -->\r\n\r\n\r\n  </ion-list>\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n      <ion-buttons>\r\n        <ion-button (click)=\"goToHome()\">\r\n          <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\" ></ion-icon>\r\n        </ion-button>\r\n        </ion-buttons>\r\n      </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/judicialExpedientDetail/judicialExpedientDetail.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/judicialExpedientDetail/judicialExpedientDetail.module.ts ***!
  \***************************************************************************/
/*! exports provided: JudicialExpedientDetailModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JudicialExpedientDetailModule", function() { return JudicialExpedientDetailModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _judicialExpedientDetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./judicialExpedientDetail.page */ "./src/app/judicialExpedientDetail/judicialExpedientDetail.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");












let JudicialExpedientDetailModule = class JudicialExpedientDetailModule {
};
JudicialExpedientDetailModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _judicialExpedientDetail_page__WEBPACK_IMPORTED_MODULE_6__["JudicialExpedientDetailPage"]
                }
            ])
        ],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__["RefreshUtils"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__["FileOpener"]],
        declarations: [_judicialExpedientDetail_page__WEBPACK_IMPORTED_MODULE_6__["JudicialExpedientDetailPage"]]
    })
], JudicialExpedientDetailModule);



/***/ }),

/***/ "./src/app/judicialExpedientDetail/judicialExpedientDetail.page.scss":
/*!***************************************************************************!*\
  !*** ./src/app/judicialExpedientDetail/judicialExpedientDetail.page.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #003F79;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #003F79;\n}\n\n.header-text {\n  margin-right: 5%;\n  padding-left: 20px;\n  width: 100%;\n  padding-bottom: 10px;\n  padding-top: 10px;\n  color: #003F79;\n  background-color: #FFFFFF;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #003F79;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvanVkaWNpYWxFeHBlZGllbnREZXRhaWwvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxqdWRpY2lhbEV4cGVkaWVudERldGFpbFxcanVkaWNpYWxFeHBlZGllbnREZXRhaWwucGFnZS5zY3NzIiwic3JjL2FwcC9qdWRpY2lhbEV4cGVkaWVudERldGFpbC9qdWRpY2lhbEV4cGVkaWVudERldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FDQ0o7O0FER0E7RUFDSSxnQ0FBQTtBQ0FKOztBREdHO0VBRUMsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLHlCQUFBO0VBQ0EsOEJBQUE7QUNESjs7QURJRztFQUNDLGVBQUE7RUFDQSxnQkFBQTtBQ0RKOztBRElHO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtBQ0RQOztBRElHO0VBQ0MscUJBQUE7QUNESjs7QURJRztFQUNDLGNBQUE7QUNESjs7QURJQTtFQUNJLHlCQUFBO0FDREo7O0FESUc7RUFDSSxrQkFBQTtFQUNBLGVBQUE7QUNEUDs7QURLRztFQUNDLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FDRko7O0FES0E7RUFDSSwyQkFBQTtFQUNBLGlDQUFBO0FDRko7O0FES0E7RUFDSSwyQkFBQTtBQ0ZKOztBREtBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0ZKIiwiZmlsZSI6InNyYy9hcHAvanVkaWNpYWxFeHBlZGllbnREZXRhaWwvanVkaWNpYWxFeHBlZGllbnREZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJlZHtcclxuICAgIGNvbG9yOiAjMDAzRjc5XHJcbn1cclxuXHJcblxyXG5pb24taXRlbS5ib3JkZXItcmVkIHtcclxuICAgIGJvcmRlci1ib3R0b206MXB4IHNvbGlkICMwMDNGNzk7XHJcbiAgIH1cclxuXHJcbiAgIC5oZWFkZXItdGV4dHtcclxuICAgIC8vIGJvcmRlci1ib3R0b206MnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyMHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gICAgY29sb3I6ICMwMDNGNzk7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkZGRkZGO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweCAhaW1wb3J0YW50O1xyXG4gICB9XHJcblxyXG4gICBpb24taXRlbXtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgIH1cclxuXHJcbiAgIGlvbi1saXN0e1xyXG4gICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgIG1hcmdpbi1ib3R0b206MHB4O1xyXG4gICB9XHJcblxyXG4gICBpb24taGVhZGVyIGlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMDAzRjc5O1xyXG4gICAgXHJcbiAgIH1cclxuICAgaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGV7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgfVxyXG5cclxuLndoaXRle1xyXG4gICAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcclxufVxyXG5cclxuICAgaW9uLWxhYmVse1xyXG4gICAgICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gICAgICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICB9XHJcblxyXG5cclxuICAgaW9uLWNvbnRlbnQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLnNjLWlvbi1jYXJkLW1kLWgge1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OlwiXCIgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWNhcmR7XHJcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi10aXRsZXtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIGZvbnQtc2l6ZTogNXZ3O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbiIsIi5yZWQge1xuICBjb2xvcjogIzAwM0Y3OTtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDAzRjc5O1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG4gIGNvbG9yOiAjMDAzRjc5O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkZGRkZGO1xuICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG5pb24tbGlzdCB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzAwM0Y3OTtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI0ZGRkZGRjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5zYy1pb24tY2FyZC1tZC1oIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAtd2Via2l0LWJveC1zaGFkb3c6IFwiXCIgIWltcG9ydGFudDtcbn1cblxuaW9uLWNhcmQge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10aXRsZSB7XG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDUlO1xuICBmb250LXNpemU6IDV2dztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/judicialExpedientDetail/judicialExpedientDetail.page.ts":
/*!*************************************************************************!*\
  !*** ./src/app/judicialExpedientDetail/judicialExpedientDetail.page.ts ***!
  \*************************************************************************/
/*! exports provided: JudicialExpedientDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JudicialExpedientDetailPage", function() { return JudicialExpedientDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _device_device_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../device/device.service */ "./src/app/device/device.service.ts");














let JudicialExpedientDetailPage = class JudicialExpedientDetailPage {
    constructor(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, deviceDetailsService, screenOrientation, statusBar, navController, refreshUtils, platform) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.deviceDetailsService = deviceDetailsService;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.refreshUtils = refreshUtils;
        this.platform = platform;
        this.processError = function (error) {
            return new Promise((resolve, reject) => {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        this.storage.get('psw').then((val) => {
                            if (val) {
                                this.loading("Descargando");
                                this.refreshUtils.refreshToken(val).then((value) => {
                                    this.loadingController.dismiss();
                                    resolve(value);
                                }).catch((errorRefresh) => {
                                    this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.judicialExpedient = this.router.getCurrentNavigation().extras.state.content;
                this.token = this.router.getCurrentNavigation().extras.state.token;
            }
        });
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#003F79');
    }
    ngOnInit() {
    }
    deleteDataAndExitToLogin() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storage.clear().then(() => {
                this.navController.navigateRoot("/login");
            });
        });
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                            console.log('OK pressed!!');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    loading(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: messageText,
            });
            yield loading.present();
        });
    }
    checkPassword(liquidation) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loading("Descargando");
            this.storage.get('token').then((val) => {
                if (val) {
                    this.token = val;
                    const httpOptions = {
                        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-Authorization': 'Bearer ' + this.token,
                        }),
                        response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                'Content-Type': 'application/json',
                                'Accept': 'application/json'
                            }),
                        })
                    };
                    console.log("URL: " + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/mobile/check/password");
                    console.log("TOKEN: " + 'Bearer ' + this.token);
                    this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/mobile/check/password", httpOptions)
                        .subscribe((data) => {
                        this.download(liquidation);
                    }, error => {
                        this.processError(error).then(value => {
                            this.checkPassword(liquidation);
                        });
                    });
                }
                else {
                    this.loadingController.dismiss();
                    this.alert("Ocurrió un problema, intente nuevamente");
                }
            });
        });
    }
    download(action) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let fileName = action.nroAction + ".pdf";
            let filePath = _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/files/download/action/" + action.nroAction;
            let url = encodeURI(filePath);
            this.fileTransfer = this.transfer.create();
            let options = {
                headers: {
                    "X-Authorization": "Bearer " + this.token
                }
            };
            let directory = this.file.documentsDirectory;
            // if (this.platform.is("android")) {
            //   if(this.file.externalRootDirectory){
            //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
            //     }else{
            //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
            //     }
            // }
            if (this.platform.is("android")) {
                let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                //if(this.file.externalRootDirectory){
                console.log("[HOME] OS VERSION: " + soVersion);
                if (soVersion < 11) {
                    if (this.file.externalRootDirectory) {
                        directory = this.file.externalRootDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD;
                    }
                    else {
                        directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD;
                    }
                }
                else {
                    directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD;
                }
            }
            this.fileTransfer.download(url, directory + fileName, true, options).then((entry) => {
                this.loadingController.dismiss();
                //here logging our success downloaded file path in mobile. 
                console.log('download completed: ' + entry.toURL());
                this.file.resolveDirectoryUrl(directory).then((rootDir) => {
                    this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
                        fileEntry.getMetadata(metadata => {
                            if (metadata.size != 0) {
                                // open downloaded file 
                                this.openFileHandler(entry.toURL());
                                if (this.platform.is("android")) {
                                    let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                                    if (soVersion < 11) {
                                        if (this.file.externalRootDirectory) {
                                            this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                                        }
                                    }
                                }
                            }
                            else {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FILE_SIZE_0_ERROR);
                            }
                        });
                    });
                });
            }).catch((error) => {
                this.loadingController.dismiss();
                if (error != null && error.http_status != null && error.http_status == 409) {
                    this.alert(JSON.parse(error.body).message);
                }
                else {
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                }
                //here logging an error. 
                console.log('download failed: ' + JSON.stringify(error));
            });
        });
    }
    openFileHandler(path) {
        this.fileOpener.open(path, '')
            .then(() => console.log('File is opened'))
            .catch(e => console.log('Error opening file', e));
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
};
JudicialExpedientDetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
    { type: _device_device_service__WEBPACK_IMPORTED_MODULE_13__["DeviceDetailsService"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_11__["ScreenOrientation"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] }
];
JudicialExpedientDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-judicialExpedientDetail',
        template: __webpack_require__(/*! raw-loader!./judicialExpedientDetail.page.html */ "./node_modules/raw-loader/index.js!./src/app/judicialExpedientDetail/judicialExpedientDetail.page.html"),
        styles: [__webpack_require__(/*! ./judicialExpedientDetail.page.scss */ "./src/app/judicialExpedientDetail/judicialExpedientDetail.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"],
        _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
        _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
        _device_device_service__WEBPACK_IMPORTED_MODULE_13__["DeviceDetailsService"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_11__["ScreenOrientation"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__["StatusBar"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]])
], JudicialExpedientDetailPage);



/***/ })

}]);
//# sourceMappingURL=judicialExpedientDetail-judicialExpedientDetail-module-es2015.js.map