(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["liquidations-liquidations-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/liquidations/liquidations.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/liquidations/liquidations.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\">\r\n        <!-- <svg xmlns='http://www.w3.org/2000/svg'  height='50' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='328 112 184 256 328 400' style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg> -->\r\n      </ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>RECIBOS DE SUELDO</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list *ngFor=\"let item of liquidations\">\r\n    <ion-list-header class=\"header-text\" (click)=\"expandOrCollapse(item)\">\r\n      <h2 style=\"margin-top: 0px; margin-bottom: 0px;\"><b>{{item.year}}</b></h2>\r\n      <svg *ngIf=\"!item.expanded\" xmlns='http://www.w3.org/2000/svg'  height='50' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='112 184 256 328 400 184' style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg>\r\n      <svg *ngIf=\"item.expanded\" xmlns='http://www.w3.org/2000/svg' height='50' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='112 328 256 184 400 328' style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg>\r\n    </ion-list-header>\r\n    <div *ngIf=\"item.expanded\">\r\n    <div *ngFor=\"let liquidation of item.liquidation; let i = index\">\r\n    <ion-item class=\"border-red\" *ngIf=\"2>i\">\r\n      <ion-list >\r\n      <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n        <ion-label class=\"ion-text-wrap\">\r\n          <ion-text class=\"red\">\r\n            <h2 style=\"display: inline;\">{{liquidation.name}}</h2>\r\n          </ion-text>\r\n        </ion-label>\r\n\r\n      </ion-item>\r\n\r\n      <ion-item lines=\"none\" (click)=\"checkPassword(liquidation)\">\r\n        <ion-card text-center style=\"padding: 0px; margin: 0px;\">\r\n          <!-- <ion-icon src=\"../../assets/download-outline_blue.svg\" style=\"margin: 0px; padding: 0px; width: 30%; height: 30%;\"></ion-icon> -->\r\n          <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n          width=\"30%\" height=\"30%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n       <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#003F79\" d=\"M862.973,656.11h-89.835v148.416\r\n         c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n         c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n         c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n         c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n         C840.518,409.458,840.518,415.762,837.57,419.12\"/>\r\n       </svg>\r\n        </ion-card>\r\n      </ion-item>\r\n    </ion-list>\r\n\r\n    </ion-item>\r\n\r\n    </div>\r\n\r\n    <ion-item class=\"show-all\" lines=\"none\" (click)=\"goToLiquidation(item)\">\r\n      <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n          <h4 style=\"display: inline;\"><b>Mostrar todos</b></h4>\r\n          </ion-text>\r\n          <svg xmlns='http://www.w3.org/2000/svg'  height='25' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='184 112 328 256 184 400' style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg>\r\n  </ion-item>\r\n\r\n  </div>\r\n\r\n\r\n  </ion-list>\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n      <ion-buttons>\r\n        <ion-button (click)=\"goToHome()\">\r\n          <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\" ></ion-icon>\r\n        </ion-button>\r\n        </ion-buttons>\r\n      </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/liquidations/liquidations.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/liquidations/liquidations.module.ts ***!
  \*****************************************************/
/*! exports provided: LiquidationsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LiquidationsModule", function() { return LiquidationsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _liquidations_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./liquidations.page */ "./src/app/liquidations/liquidations.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");












var LiquidationsModule = /** @class */ (function () {
    function LiquidationsModule() {
    }
    LiquidationsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _liquidations_page__WEBPACK_IMPORTED_MODULE_6__["LiquidationsPage"]
                    }
                ])
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
                _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
                _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__["RefreshUtils"],
                _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__["FileOpener"]],
            declarations: [_liquidations_page__WEBPACK_IMPORTED_MODULE_6__["LiquidationsPage"]]
        })
    ], LiquidationsModule);
    return LiquidationsModule;
}());



/***/ }),

/***/ "./src/app/liquidations/liquidations.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/liquidations/liquidations.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #003f79;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #003f79;\n}\n\n.header-text {\n  padding-left: 10px;\n  width: 95%;\n  margin: 10px;\n  background-color: #003f79;\n  color: #ffffff;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #003f79;\n}\n\nion-header ion-toolbar ion-title {\n  color: #ffffff;\n}\n\n.white {\n  color: #ffffff !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\n.show-all {\n  --min-height: 20px;\n  border-radius: 6px;\n  background-color: #e6e6e6;\n  --ion-background-color: #e6e6e6;\n  margin-top: 2%;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGlxdWlkYXRpb25zL0Q6XFxSZXBvc2l0b3Jpb3NcXHBvcnRhbC1pb25pYy9zcmNcXGFwcFxcbGlxdWlkYXRpb25zXFxsaXF1aWRhdGlvbnMucGFnZS5zY3NzIiwic3JjL2FwcC9saXF1aWRhdGlvbnMvbGlxdWlkYXRpb25zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUNDRjs7QURJQTtFQUNFLGdDQUFBO0FDREY7O0FESUE7RUFHRSxrQkFBQTtFQUNBLFVBQUE7RUFHQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsOEJBQUE7QUNMRjs7QURRQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQ0xGOztBRFFBO0VBQ0UsbUJBQUE7RUFDQSxrQkFBQTtBQ0xGOztBRFFBO0VBQ0UscUJBQUE7QUNMRjs7QURPQTtFQUNFLGNBQUE7QUNKRjs7QURPQTtFQUNFLHlCQUFBO0FDSkY7O0FET0E7RUFDRSxrQkFBQTtFQUNBLGVBQUE7QUNKRjs7QURPQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FDSkY7O0FET0E7RUFDRSwyQkFBQTtFQUNBLGlDQUFBO0FDSkY7O0FET0E7RUFDRSwyQkFBQTtBQ0pGOztBRE1BO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsK0JBQUE7RUFDQSxjQUFBO0FDSEY7O0FETUE7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDSEYiLCJmaWxlIjoic3JjL2FwcC9saXF1aWRhdGlvbnMvbGlxdWlkYXRpb25zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZWQge1xyXG4gIGNvbG9yOiAjMDAzZjc5O1xyXG59XHJcblxyXG5cclxuXHJcbmlvbi1pdGVtLmJvcmRlci1yZWQge1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDAzZjc5O1xyXG59XHJcblxyXG4uaGVhZGVyLXRleHQge1xyXG4gIC8vIGJvcmRlci1ib3R0b206MnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgLy8gbWFyZ2luLXJpZ2h0OiA1JTtcclxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgd2lkdGg6IDk1JTtcclxuICAvLyBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICAvLyBwYWRkaW5nLXRvcDogMTBweDtcclxuICBtYXJnaW46IDEwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwM2Y3OTtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcclxuICAtLWJhY2tncm91bmQ6ICMwMDNmNzk7XHJcbn1cclxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG59XHJcblxyXG4ud2hpdGUge1xyXG4gIGNvbG9yOiAjZmZmZmZmICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1sYWJlbCB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIG1hcmdpbi10b3A6IDBweDtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLnNjLWlvbi1jYXJkLW1kLWgge1xyXG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICAtd2Via2l0LWJveC1zaGFkb3c6IFwiXCIgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWNhcmQge1xyXG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxufVxyXG4uc2hvdy1hbGwge1xyXG4gIC0tbWluLWhlaWdodDogMjBweDtcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xyXG4gIG1hcmdpbi10b3A6IDIlO1xyXG59XHJcblxyXG5pb24tdGl0bGV7XHJcbiAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICBmb250LXNpemU6IDV2dztcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuIiwiLnJlZCB7XG4gIGNvbG9yOiAjMDAzZjc5O1xufVxuXG5pb24taXRlbS5ib3JkZXItcmVkIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwMDNmNzk7XG59XG5cbi5oZWFkZXItdGV4dCB7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgd2lkdGg6IDk1JTtcbiAgbWFyZ2luOiAxMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAzZjc5O1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgYm9yZGVyLXJhZGl1czogMTBweCAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuaW9uLWxpc3Qge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICMwMDNmNzk7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNmZmZmZmY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjZmZmZmZmICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xufVxuXG5pb24tY29udGVudCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uc2MtaW9uLWNhcmQtbWQtaCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBcIlwiICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG4uc2hvdy1hbGwge1xuICAtLW1pbi1oZWlnaHQ6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbiAgbWFyZ2luLXRvcDogMiU7XG59XG5cbmlvbi10aXRsZSB7XG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDUlO1xuICBmb250LXNpemU6IDV2dztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/liquidations/liquidations.page.ts":
/*!***************************************************!*\
  !*** ./src/app/liquidations/liquidations.page.ts ***!
  \***************************************************/
/*! exports provided: LiquidationsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LiquidationsPage", function() { return LiquidationsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _device_device_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../device/device.service */ "./src/app/device/device.service.ts");














var LiquidationsPage = /** @class */ (function () {
    function LiquidationsPage(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, deviceDetailsService, screenOrientation, navController, refreshUtils, statusBar, platform) {
        var _this = this;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.deviceDetailsService = deviceDetailsService;
        this.screenOrientation = screenOrientation;
        this.navController = navController;
        this.refreshUtils = refreshUtils;
        this.statusBar = statusBar;
        this.platform = platform;
        this.processError = function (error) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                _this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        _this.storage.get('psw').then(function (val) {
                            if (val) {
                                _this.loading("Descargando");
                                _this.refreshUtils.refreshToken(val).then(function (value) {
                                    _this.loadingController.dismiss();
                                    resolve(value);
                                }).catch(function (errorRefresh) {
                                    _this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        _this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    _this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(function (params) {
            if (_this.router.getCurrentNavigation().extras.state) {
                _this.liquidations = _this.router.getCurrentNavigation().extras.state.liquidations;
                _this.token = _this.router.getCurrentNavigation().extras.state.token;
                _this.makeLiquidationsCollapse();
            }
        });
    }
    LiquidationsPage.prototype.makeLiquidationsCollapse = function () {
        var liquidationsTemporal = [];
        var firstTime = true;
        this.liquidations.forEach(function (element) {
            var elementTemporal = {
                year: element.year,
                liquidation: element.liquidation,
                expanded: firstTime,
            };
            liquidationsTemporal.push(elementTemporal);
            firstTime = false;
        });
        console.log("LIQUIDATIONS COLLAPSE!!!!");
        console.log(liquidationsTemporal);
        this.liquidations = liquidationsTemporal;
    };
    LiquidationsPage.prototype.expandOrCollapse = function (item) {
        item.expanded = !item.expanded;
    };
    LiquidationsPage.prototype.ionViewWillEnter = function () {
        this.statusBar.backgroundColorByHexString('#003F79');
    };
    LiquidationsPage.prototype.ngOnInit = function () {
    };
    LiquidationsPage.prototype.deleteDataAndExitToLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.storage.clear().then(function () {
                    _this.navController.navigateRoot("/login");
                });
                return [2 /*return*/];
            });
        });
    };
    LiquidationsPage.prototype.alert = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Portal puntano',
                            message: messageText,
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel',
                                    cssClass: 'primary',
                                    handler: function () {
                                        console.log('OK pressed!!');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LiquidationsPage.prototype.loading = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: messageText,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LiquidationsPage.prototype.checkPassword = function (liquidation) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loading("Descargando");
                this.storage.get('token').then(function (val) {
                    if (val) {
                        _this.token = val;
                        var httpOptions = {
                            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                'Content-Type': 'application/json',
                                'Accept': 'application/json',
                                'X-Authorization': 'Bearer ' + _this.token,
                            }),
                            response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                    'Content-Type': 'application/json',
                                    'Accept': 'application/json'
                                }),
                            })
                        };
                        console.log("URL: " + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/mobile/check/password");
                        console.log("TOKEN: " + 'Bearer ' + _this.token);
                        _this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/mobile/check/password", httpOptions)
                            .subscribe(function (data) {
                            _this.download(liquidation);
                        }, function (error) {
                            _this.processError(error).then(function (value) {
                                _this.checkPassword(liquidation);
                            });
                        });
                    }
                    else {
                        _this.loadingController.dismiss();
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                    }
                });
                return [2 /*return*/];
            });
        });
    };
    LiquidationsPage.prototype.download = function (liquidation) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var fileName, filePath, url, options, directory, soVersion;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                fileName = liquidation.name + ".pdf";
                filePath = _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/files/download/Liquidation/id/" + liquidation.id + "/name/" + liquidation.name;
                url = encodeURI(filePath);
                this.fileTransfer = this.transfer.create();
                options = {
                    headers: {
                        "X-Authorization": "Bearer " + this.token
                    }
                };
                directory = this.file.documentsDirectory;
                // if (this.platform.is("android")) {
                //   if(this.file.externalRootDirectory){
                //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
                //     }else{
                //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
                //     }
                // }
                if (this.platform.is("android")) {
                    soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                    //if(this.file.externalRootDirectory){
                    console.log("[HOME] OS VERSION: " + soVersion);
                    if (soVersion < 11) {
                        if (this.file.externalRootDirectory) {
                            directory = this.file.externalRootDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD;
                        }
                        else {
                            directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD;
                        }
                    }
                    else {
                        directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD;
                    }
                }
                this.fileTransfer.download(url, directory + fileName, true, options).then(function (entry) {
                    _this.loadingController.dismiss();
                    //here logging our success downloaded file path in mobile. 
                    console.log('download completed: ' + entry.toURL());
                    _this.file.resolveDirectoryUrl(directory).then(function (rootDir) {
                        _this.file.getFile(rootDir, fileName, { create: false }).then(function (fileEntry) {
                            fileEntry.getMetadata(function (metadata) {
                                if (metadata.size != 0) {
                                    // open downloaded file 
                                    _this.openFileHandler(entry.toURL());
                                    if (_this.platform.is("android")) {
                                        var soVersion = parseFloat(_this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                                        if (soVersion < 11) {
                                            if (_this.file.externalRootDirectory) {
                                                _this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                                            }
                                        }
                                    }
                                }
                                else {
                                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FILE_SIZE_0_ERROR);
                                }
                            });
                        });
                    });
                }).catch(function (error) {
                    _this.loadingController.dismiss();
                    if (error != null && error.http_status != null && error.http_status == 409) {
                        _this.alert(JSON.parse(error.body).message);
                    }
                    else if (error.status == 401) {
                        _this.deleteDataAndExitToLogin();
                    }
                    else if (error.status == 500) {
                        if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                            _this.storage.get('psw').then(function (val) {
                                if (val) {
                                    _this.loading('Descargando');
                                    _this.refreshUtils.refreshToken(val).then(function (value) {
                                        _this.loadingController.dismiss();
                                        _this.download(liquidation);
                                    }).catch(function (error) {
                                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                                    });
                                }
                                else {
                                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                                }
                            });
                        }
                        else {
                            _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                        }
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                    }
                    //here logging an error. 
                    console.log('download failed: ' + JSON.stringify(error));
                });
                return [2 /*return*/];
            });
        });
    };
    LiquidationsPage.prototype.openFileHandler = function (path) {
        this.fileOpener.open(path, '')
            .then(function () { return console.log('File is opened'); })
            .catch(function (e) { return console.log('Error opening file', e); });
    };
    LiquidationsPage.prototype.goToLiquidation = function (liquidation) {
        var navigationExtras = {
            state: {
                content: liquidation,
                token: this.token
            }
        };
        this.router.navigate(['liquidation'], navigationExtras);
    };
    LiquidationsPage.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
    };
    LiquidationsPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"] },
        { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
        { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
        { type: _device_device_service__WEBPACK_IMPORTED_MODULE_13__["DeviceDetailsService"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_11__["ScreenOrientation"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__["StatusBar"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] }
    ]; };
    LiquidationsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-liquidations',
            template: __webpack_require__(/*! raw-loader!./liquidations.page.html */ "./node_modules/raw-loader/index.js!./src/app/liquidations/liquidations.page.html"),
            styles: [__webpack_require__(/*! ./liquidations.page.scss */ "./src/app/liquidations/liquidations.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
            _device_device_service__WEBPACK_IMPORTED_MODULE_13__["DeviceDetailsService"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_11__["ScreenOrientation"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__["StatusBar"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]])
    ], LiquidationsPage);
    return LiquidationsPage;
}());



/***/ })

}]);
//# sourceMappingURL=liquidations-liquidations-module-es5.js.map