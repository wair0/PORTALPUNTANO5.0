(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["RM-studies-studies-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/RM/studies/studies.page.html":
/*!************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RM/studies/studies.page.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTROS MÉDICOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-list>\r\n    <ion-list-header>\r\n      <h2 class=\"header-text\"><b>MIS ESTUDIOS</b></h2>\r\n    </ion-list-header>\r\n\r\n    <div class=\"studies\">\r\n      <div class=\"studies__item\" *ngFor=\"let consultation of consultations\" (click)=\"goToStudy(consultation)\">\r\n        <p class=\"studies__item-text-date\">{{consultation.dateCreated}}</p>\r\n        <p class=\"studies__item-text\">{{consultation.professionalName}}</p>\r\n        <p class=\"studies__item-text\">{{consultation.specialty}}</p>\r\n      </div>\r\n    </div>\r\n\r\n  </ion-list>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" name=\"home\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/RM/studies/studies.module.ts":
/*!**********************************************!*\
  !*** ./src/app/RM/studies/studies.module.ts ***!
  \**********************************************/
/*! exports provided: StudiesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudiesModule", function() { return StudiesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _studies_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./studies.page */ "./src/app/RM/studies/studies.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");
/* harmony import */ var src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/interceptors/interceptor-rm.service */ "./src/app/core/interceptors/interceptor-rm.service.ts");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");














let StudiesModule = class StudiesModule {
};
StudiesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _studies_page__WEBPACK_IMPORTED_MODULE_6__["StudiesPage"]
                }
            ])
        ],
        providers: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__["RefreshUtils"],
            src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_9__["LocalStorageService"],
            src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_10__["AlertService"],
            src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_11__["PatientService"],
            src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_13__["ConsultationService"],
            {
                provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HTTP_INTERCEPTORS"],
                useClass: src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_12__["InterceptorRm"],
                multi: true
            }
        ],
        declarations: [_studies_page__WEBPACK_IMPORTED_MODULE_6__["StudiesPage"]]
    })
], StudiesModule);



/***/ }),

/***/ "./src/app/RM/studies/studies.page.scss":
/*!**********************************************!*\
  !*** ./src/app/RM/studies/studies.page.scss ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #EC272F;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #EC272F;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #EC272F;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.studies {\n  padding-left: 1rem;\n  padding-right: 1rem;\n}\n\n.studies__item {\n  border-bottom: 1px solid #ff9898;\n  margin-top: 1.5rem;\n  padding-bottom: 1rem;\n}\n\n.studies__item-text-date {\n  margin-bottom: 1rem;\n}\n\n.studies__item-text {\n  margin: 0.5rem 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUk0vc3R1ZGllcy9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXFJNXFxzdHVkaWVzXFxzdHVkaWVzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvUk0vc3R1ZGllcy9zdHVkaWVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7QUNDSjs7QURJQTtFQUNJLGdDQUFBO0FDREo7O0FESUc7RUFDQyxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0FDREo7O0FESUc7RUFDQyxlQUFBO0VBQ0EsZ0JBQUE7QUNESjs7QURJRztFQUNJLG1CQUFBO0VBQ0Esa0JBQUE7QUNEUDs7QURJRztFQUNDLHFCQUFBO0FDREo7O0FESUc7RUFDQyxjQUFBO0FDREo7O0FESUE7RUFDSSx5QkFBQTtBQ0RKOztBRElBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0RKOztBRElBO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtBQ0RKOztBRElBO0VBQ0ksZ0NBQUE7RUFDQSxrQkFBQTtFQUNBLG9CQUFBO0FDREo7O0FESUE7RUFDSSxtQkFBQTtBQ0RKOztBRElBO0VBQ0ksZ0JBQUE7QUNESiIsImZpbGUiOiJzcmMvYXBwL1JNL3N0dWRpZXMvc3R1ZGllcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVke1xyXG4gICAgY29sb3I6ICNFQzI3MkZcclxufVxyXG5cclxuXHJcblxyXG5pb24taXRlbS5ib3JkZXItcmVkIHtcclxuICAgIGJvcmRlci1ib3R0b206MXB4IHNvbGlkICNFQzI3MkY7XHJcbiAgIH1cclxuXHJcbiAgIC5oZWFkZXItdGV4dHtcclxuICAgIGJvcmRlci1ib3R0b206MnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICAgfVxyXG5cclxuICAgaW9uLWl0ZW17XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICB9XHJcblxyXG4gICBpb24tbGlzdHtcclxuICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICBtYXJnaW4tYm90dG9tOjBweDtcclxuICAgfVxyXG5cclxuICAgaW9uLWhlYWRlciBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogI0VDMjcyRjtcclxuICAgIFxyXG4gICB9XHJcbiAgIGlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxle1xyXG4gICAgY29sb3I6ICNGRkZGRkY7XHJcbiAgIH1cclxuXHJcbi53aGl0ZXtcclxuICAgIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi10aXRsZXtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIGZvbnQtc2l6ZTogNXZ3O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uc3R1ZGllcyB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDFyZW07XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxcmVtO1xyXG59XHJcblxyXG4uc3R1ZGllc19faXRlbSB7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2ZmOTg5ODtcclxuICAgIG1hcmdpbi10b3A6IDEuNXJlbTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxcmVtO1xyXG59XHJcblxyXG4uc3R1ZGllc19faXRlbS10ZXh0LWRhdGUge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxufVxyXG5cclxuLnN0dWRpZXNfX2l0ZW0tdGV4dCB7XHJcbiAgICBtYXJnaW46IC41cmVtIDA7XHJcbn0iLCIucmVkIHtcbiAgY29sb3I6ICNFQzI3MkY7XG59XG5cbmlvbi1pdGVtLmJvcmRlci1yZWQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI0VDMjcyRjtcbn1cblxuLmhlYWRlci10ZXh0IHtcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICM1MzUzNTM7XG4gIG1hcmdpbi1yaWdodDogNSU7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cblxuaW9uLWl0ZW0ge1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIG1hcmdpbi1yaWdodDogNSU7XG59XG5cbmlvbi1saXN0IHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjRUMyNzJGO1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuXG4ud2hpdGUge1xuICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xufVxuXG5pb24tdGl0bGUge1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgZm9udC1zaXplOiA1dnc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnN0dWRpZXMge1xuICBwYWRkaW5nLWxlZnQ6IDFyZW07XG4gIHBhZGRpbmctcmlnaHQ6IDFyZW07XG59XG5cbi5zdHVkaWVzX19pdGVtIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZjk4OTg7XG4gIG1hcmdpbi10b3A6IDEuNXJlbTtcbiAgcGFkZGluZy1ib3R0b206IDFyZW07XG59XG5cbi5zdHVkaWVzX19pdGVtLXRleHQtZGF0ZSB7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG5cbi5zdHVkaWVzX19pdGVtLXRleHQge1xuICBtYXJnaW46IDAuNXJlbSAwO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/RM/studies/studies.page.ts":
/*!********************************************!*\
  !*** ./src/app/RM/studies/studies.page.ts ***!
  \********************************************/
/*! exports provided: StudiesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudiesPage", function() { return StudiesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");











let StudiesPage = class StudiesPage {
    constructor(statusBar, route, router, screenOrientation, navController, refreshUtils, consultationService, localStorageService, patientService, alertService) {
        this.statusBar = statusBar;
        this.route = route;
        this.router = router;
        this.screenOrientation = screenOrientation;
        this.navController = navController;
        this.refreshUtils = refreshUtils;
        this.consultationService = consultationService;
        this.localStorageService = localStorageService;
        this.patientService = patientService;
        this.alertService = alertService;
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.consultations = this.router.getCurrentNavigation().extras.state.studies;
            }
        });
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#EC272F');
    }
    ngOnInit() {
        this.localStorageService.getUserData().then(userData => {
            this.userData = userData;
            this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(patientId => {
                this.patientId = patientId;
                this.consultationService.getConsultationsWithStudiesByPatientId(patientId).subscribe(response => {
                    this.consultations = response;
                }, error => {
                    if (error.message)
                        this.alertService.showErrorAlert(error.message);
                    else
                        this.alertService.showErrorAlert();
                });
            });
        });
    }
    goToStudy(consultation) {
        let navigationExtras = {
            state: {
                consultation: consultation,
            }
        };
        this.router.navigate(['study'], navigationExtras);
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
};
StudiesPage.ctorParameters = () => [
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__["ScreenOrientation"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_4__["RefreshUtils"] },
    { type: src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_10__["ConsultationService"] },
    { type: src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_7__["LocalStorageService"] },
    { type: src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_8__["PatientService"] },
    { type: src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_9__["AlertService"] }
];
StudiesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-studies',
        template: __webpack_require__(/*! raw-loader!./studies.page.html */ "./node_modules/raw-loader/index.js!./src/app/RM/studies/studies.page.html"),
        styles: [__webpack_require__(/*! ./studies.page.scss */ "./src/app/RM/studies/studies.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__["ScreenOrientation"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_4__["RefreshUtils"],
        src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_10__["ConsultationService"],
        src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_7__["LocalStorageService"],
        src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_8__["PatientService"],
        src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_9__["AlertService"]])
], StudiesPage);



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let LoadingService = class LoadingService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    present() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController.create({
                message: '...Cargando',
                duration: 7500,
            }).then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss().then(() => console.log('dismissed'));
        });
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
], LoadingService);



/***/ })

}]);
//# sourceMappingURL=RM-studies-studies-module-es2015.js.map