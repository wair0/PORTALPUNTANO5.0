(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["RM-consultation-consultation-module"],{

/***/ "./node_modules/@ionic-native/document-viewer/ngx/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@ionic-native/document-viewer/ngx/index.js ***!
  \*****************************************************************/
/*! exports provided: DocumentViewer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DocumentViewer", function() { return DocumentViewer; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_native_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic-native/core */ "./node_modules/@ionic-native/core/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");



var DocumentViewer = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(DocumentViewer, _super);
    function DocumentViewer() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DocumentViewer.prototype.getSupportInfo = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "getSupportInfo", {}, arguments); };
    DocumentViewer.prototype.canViewDocument = function (url, contentType, options, onPossible, onMissingApp, onImpossible, onError) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "canViewDocument", { "sync": true }, arguments); };
    DocumentViewer.prototype.viewDocument = function (url, contentType, options, onShow, onClose, onMissingApp, onError) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "viewDocument", { "sync": true }, arguments); };
    DocumentViewer.pluginName = "Document Viewer";
    DocumentViewer.plugin = "cordova-plugin-document-viewer";
    DocumentViewer.pluginRef = "SitewaertsDocumentViewer";
    DocumentViewer.repo = "https://github.com/sitewaerts/cordova-plugin-document-viewer";
    DocumentViewer.platforms = ["Android", "iOS", "Windows"];
    DocumentViewer.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"] }
    ];
    return DocumentViewer;
}(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["IonicNativePlugin"]));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2RvY3VtZW50LXZpZXdlci9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sOEJBQXNDLE1BQU0sb0JBQW9CLENBQUM7QUFDeEUsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7SUE4RFAsa0NBQWlCOzs7O0lBT25ELHVDQUFjO0lBZ0JkLHdDQUFlLGFBQ2IsR0FBVyxFQUNYLFdBQW1CLEVBQ25CLE9BQThCLEVBQzlCLFVBQXFCLEVBQ3JCLFlBQXVCLEVBQ3ZCLFlBQXVCLEVBQ3ZCLE9BQWtCO0lBZXBCLHFDQUFZLGFBQ1YsR0FBVyxFQUNYLFdBQW1CLEVBQ25CLE9BQThCLEVBQzlCLE1BQWlCLEVBQ2pCLE9BQWtCLEVBQ2xCLFlBQXVCLEVBQ3ZCLE9BQWtCOzs7Ozs7O2dCQXJEckIsVUFBVTs7eUJBOURYO0VBK0RvQyxpQkFBaUI7U0FBeEMsY0FBYyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvcmRvdmEsIElvbmljTmF0aXZlUGx1Z2luLCBQbHVnaW4gfSBmcm9tICdAaW9uaWMtbmF0aXZlL2NvcmUnO1xuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5leHBvcnQgaW50ZXJmYWNlIERvY3VtZW50Vmlld2VyT3B0aW9ucyB7XG4gIHRpdGxlPzogc3RyaW5nO1xuICBkb2N1bWVudFZpZXc/OiB7XG4gICAgY2xvc2VMYWJlbDogc3RyaW5nO1xuICB9O1xuICBuYXZpZ2F0aW9uVmlldz86IHtcbiAgICBjbG9zZUxhYmVsOiBzdHJpbmc7XG4gIH07XG4gIGVtYWlsPzoge1xuICAgIGVuYWJsZWQ6IGJvb2xlYW47XG4gIH07XG4gIHByaW50Pzoge1xuICAgIGVuYWJsZWQ6IGJvb2xlYW47XG4gIH07XG4gIG9wZW5XaXRoPzoge1xuICAgIGVuYWJsZWQ6IGJvb2xlYW47XG4gIH07XG4gIGJvb2ttYXJrcz86IHtcbiAgICBlbmFibGVkOiBib29sZWFuO1xuICB9O1xuICBzZWFyY2g/OiB7XG4gICAgZW5hYmxlZDogYm9vbGVhbjtcbiAgfTtcbiAgYXV0b0Nsb3NlPzoge1xuICAgIG9uUGF1c2U6IGJvb2xlYW47XG4gIH07XG59XG5cbi8qKlxuICogQG5hbWUgRG9jdW1lbnQgVmlld2VyXG4gKiBAZGVzY3JpcHRpb25cbiAqIFRoaXMgcGx1Z2luIG9mZmVycyBhIHNsaW0gQVBJIHRvIHZpZXcgUERGIGZpbGVzIHdoaWNoIGFyZSBlaXRoZXIgc3RvcmVkIGluIHRoZSBhcHBzIGFzc2V0cyBmb2xkZXIgKC93d3cvKikgb3IgaW4gYW55IG90aGVyIGZpbGUgc3lzdGVtIGRpcmVjdG9yeSBhdmFpbGFibGUgdmlhIHRoZSBjb3Jkb3ZhIGZpbGUgcGx1Z2luLlxuICpcbiAqIEB1c2FnZVxuICogYGBgdHlwZXNjcmlwdFxuICogaW1wb3J0IHsgRG9jdW1lbnRWaWV3ZXIgfSBmcm9tICdAaW9uaWMtbmF0aXZlL2RvY3VtZW50LXZpZXdlci9uZ3gnO1xuICpcbiAqXG4gKiBjb25zdHJ1Y3Rvcihwcml2YXRlIGRvY3VtZW50OiBEb2N1bWVudFZpZXdlcikgeyB9XG4gKlxuICogLi4uXG4gKiBjb25zdCBvcHRpb25zOiBEb2N1bWVudFZpZXdlck9wdGlvbnMgPSB7XG4gKiAgIHRpdGxlOiAnTXkgUERGJ1xuICogfVxuICpcbiAqIHRoaXMuZG9jdW1lbnQudmlld0RvY3VtZW50KCdhc3NldHMvbXlGaWxlLnBkZicsICdhcHBsaWNhdGlvbi9wZGYnLCBvcHRpb25zKVxuICpcbiAqIGBgYFxuICpcbiAqIEBpbnRlcmZhY2VzXG4gKiBEb2N1bWVudFZpZXdlck9wdGlvbnNcbiAqL1xuQFBsdWdpbih7XG4gIHBsdWdpbk5hbWU6ICdEb2N1bWVudCBWaWV3ZXInLFxuICBwbHVnaW46ICdjb3Jkb3ZhLXBsdWdpbi1kb2N1bWVudC12aWV3ZXInLFxuICBwbHVnaW5SZWY6ICdTaXRld2FlcnRzRG9jdW1lbnRWaWV3ZXInLFxuICByZXBvOiAnaHR0cHM6Ly9naXRodWIuY29tL3NpdGV3YWVydHMvY29yZG92YS1wbHVnaW4tZG9jdW1lbnQtdmlld2VyJyxcbiAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnLCAnaU9TJywgJ1dpbmRvd3MnXSxcbn0pXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgRG9jdW1lbnRWaWV3ZXIgZXh0ZW5kcyBJb25pY05hdGl2ZVBsdWdpbiB7XG4gIC8qKlxuICAgKiBEaXNwbGF5cyB0aGUgZW1haWwgY29tcG9zZXIgcHJlLWZpbGxlZCB3aXRoIGRhdGEuXG4gICAqXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59IFJlc29sdmVzIHByb21pc2Ugd2hlbiB0aGUgRW1haWxDb21wb3NlciBoYXMgYmVlbiBvcGVuZWRcbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgZ2V0U3VwcG9ydEluZm8oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgaWYgdGhlIGRvY3VtZW50IGNhbiBiZSBzaG93blxuICAgKlxuICAgKiBAcGFyYW0gdXJsIHtzdHJpbmd9IFVybCB0byB0aGUgZmlsZVxuICAgKiBAcGFyYW0gY29udGVudFR5cGUge3N0cmluZ30gQ29udGVudCB0eXBlIG9mIHRoZSBmaWxlXG4gICAqIEBwYXJhbSBvcHRpb25zIHtEb2N1bWVudFZpZXdlck9wdGlvbnN9IG9wdGlvbnNcbiAgICogQHBhcmFtIFtvblBvc3NpYmxlXSB7RnVuY3Rpb259XG4gICAqIEBwYXJhbSBbb25NaXNzaW5nQXBwXSB7RnVuY3Rpb259XG4gICAqIEBwYXJhbSBbb25JbXBvc3NpYmxlXSB7RnVuY3Rpb259XG4gICAqIEBwYXJhbSBbb25FcnJvcl0ge0Z1bmN0aW9ufVxuICAgKi9cbiAgQENvcmRvdmEoeyBzeW5jOiB0cnVlIH0pXG4gIGNhblZpZXdEb2N1bWVudChcbiAgICB1cmw6IHN0cmluZyxcbiAgICBjb250ZW50VHlwZTogc3RyaW5nLFxuICAgIG9wdGlvbnM6IERvY3VtZW50Vmlld2VyT3B0aW9ucyxcbiAgICBvblBvc3NpYmxlPzogRnVuY3Rpb24sXG4gICAgb25NaXNzaW5nQXBwPzogRnVuY3Rpb24sXG4gICAgb25JbXBvc3NpYmxlPzogRnVuY3Rpb24sXG4gICAgb25FcnJvcj86IEZ1bmN0aW9uXG4gICk6IHZvaWQge31cblxuICAvKipcbiAgICogT3BlbnMgdGhlIGZpbGVcbiAgICpcbiAgICogQHBhcmFtIHVybCB7c3RyaW5nfSBVcmwgdG8gdGhlIGZpbGVcbiAgICogQHBhcmFtIGNvbnRlbnRUeXBlIHtzdHJpbmd9IENvbnRlbnQgdHlwZSBvZiB0aGUgZmlsZVxuICAgKiBAcGFyYW0gb3B0aW9ucyB7RG9jdW1lbnRWaWV3ZXJPcHRpb25zfSBvcHRpb25zXG4gICAqIEBwYXJhbSBbb25TaG93XSB7RnVuY3Rpb259XG4gICAqIEBwYXJhbSBbb25DbG9zZV0ge0Z1bmN0aW9ufVxuICAgKiBAcGFyYW0gW29uTWlzc2luZ0FwcF0ge0Z1bmN0aW9ufVxuICAgKiBAcGFyYW0gW29uRXJyb3JdIHtGdW5jdGlvbn1cbiAgICovXG4gIEBDb3Jkb3ZhKHsgc3luYzogdHJ1ZSB9KVxuICB2aWV3RG9jdW1lbnQoXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgY29udGVudFR5cGU6IHN0cmluZyxcbiAgICBvcHRpb25zOiBEb2N1bWVudFZpZXdlck9wdGlvbnMsXG4gICAgb25TaG93PzogRnVuY3Rpb24sXG4gICAgb25DbG9zZT86IEZ1bmN0aW9uLFxuICAgIG9uTWlzc2luZ0FwcD86IEZ1bmN0aW9uLFxuICAgIG9uRXJyb3I/OiBGdW5jdGlvblxuICApOiB2b2lkIHt9XG59XG4iXX0=

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/RM/consultation/consultation.page.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RM/consultation/consultation.page.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTROS MÉDICOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"consultation\">\r\n\r\n    <div *ngIf=\"consultation && consultation.consultation\">\r\n      <div class=\"consultation__header\">\r\n        <h2 class=\"header-text\"><b>Datos de la consulta</b></h2>\r\n      </div>\r\n      <div class=\"consultation__content\">\r\n        <p>Profesional: <b>{{consultation.consultation.professionalName}}</b></p>\r\n        <p>Matricula: <b>{{consultation.consultation.license}}</b></p>\r\n        <p>Fecha y hora: <b>{{consultation.consultation.dateCreated}}</b></p>\r\n        <p>Especialidad: <b>{{consultation.consultation.specialty}}</b></p>\r\n        <p>Centro de salud: <b>{{consultation.consultation.healthCenterName}}</b></p>\r\n      </div>\r\n    </div>\r\n    \r\n    <div *ngIf=\"consultation && consultation.diagnosis\">\r\n      <div class=\"consultation__header\">\r\n        <h2 class=\"header-text\"><b>Diagnóstico</b></h2>\r\n      </div>\r\n      <div class=\"consultation__content\" *ngFor=\"let diagnosis of consultation.diagnosis\">\r\n        <p class=\"diagnosis__name\">{{diagnosis.description}}</p>\r\n      </div>\r\n    </div>\r\n\r\n    <div *ngIf=\"consultation && consultation.prescritions\">\r\n      <div class=\"consultation__header\">\r\n        <h2 class=\"header-text\"><b>Prescripciones solicitadas</b></h2>\r\n      </div>\r\n      <div class=\"consultation__content\" *ngFor=\"let prescription of consultation.prescritions\">\r\n        <p>{{prescription.vademecum.description}}</p>\r\n      </div>\r\n    </div>\r\n\r\n    <div *ngIf=\"consultation && consultation.cabinetComplementaryStudies\">\r\n      <div class=\"consultation__header\">\r\n        <h2 class=\"header-text\"><b>Estudios solicitados</b></h2>\r\n      </div>\r\n      <div class=\"consultation__content\" *ngFor=\"let study of consultation.cabinetComplementaryStudies\">\r\n        <p>{{study.study.description}}</p>\r\n      </div>\r\n      <div class=\"consultation__content\" *ngFor=\"let study of consultation.laboratoryComplementaryStudies\">\r\n        <p>{{study.study.description}}</p>\r\n      </div>\r\n    </div>\r\n\r\n    <div *ngIf=\"consultation && consultation.careAndEducationDescription\">\r\n      <div class=\"consultation__header\">\r\n        <h2 class=\"header-text\"><b>Cuidados y educación</b></h2>\r\n      </div>\r\n      <div class=\"consultation__content\">\r\n        <p>{{consultation.careAndEducationDescription}}</p>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"consultation__download-button\" *ngIf=\"consultation && consultation.consultation.pdfPathName\">\r\n      <button class=\"download-button\" (click)=\"download(consultation.consultation.pdfPathName)\">\r\n        <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n          width=\"100%\" height=\"100%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#EC1C24\" d=\"M862.973,656.11h-89.835v148.416\r\n          c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n          c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n          c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n          c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n          C840.518,409.458,840.518,415.762,837.57,419.12\"/>\r\n        </svg>\r\n      </button>\r\n    </div>\r\n\r\n  </div>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" name=\"home\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/RM/consultation/consultation.module.ts":
/*!********************************************************!*\
  !*** ./src/app/RM/consultation/consultation.module.ts ***!
  \********************************************************/
/*! exports provided: ConsultationModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConsultationModule", function() { return ConsultationModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _consultation_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./consultation.page */ "./src/app/RM/consultation/consultation.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/document-viewer/ngx */ "./node_modules/@ionic-native/document-viewer/ngx/index.js");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");
/* harmony import */ var src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/interceptors/interceptor-rm.service */ "./src/app/core/interceptors/interceptor-rm.service.ts");















let ConsultationModule = class ConsultationModule {
};
ConsultationModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _consultation_page__WEBPACK_IMPORTED_MODULE_6__["ConsultationPage"]
                }
            ])
        ],
        providers: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__["RefreshUtils"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__["FileOpener"],
            _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_12__["DocumentViewer"],
            src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_13__["ConsultationService"],
            {
                provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HTTP_INTERCEPTORS"],
                useClass: src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_14__["InterceptorRm"],
                multi: true
            }
        ],
        declarations: [_consultation_page__WEBPACK_IMPORTED_MODULE_6__["ConsultationPage"]]
    })
], ConsultationModule);



/***/ }),

/***/ "./src/app/RM/consultation/consultation.page.scss":
/*!********************************************************!*\
  !*** ./src/app/RM/consultation/consultation.page.scss ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #EC272F;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #EC272F;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #EC272F;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.download-icon {\n  width: 30%;\n  height: 30%;\n  text-align: center;\n}\n\n.consultation {\n  padding-left: 1rem;\n  padding-right: 1rem;\n}\n\n.consultation__header {\n  margin-top: 1.8rem;\n}\n\n.consultation__data {\n  font-weight: 700;\n}\n\n.consultation__content {\n  padding-left: 0.5rem;\n  padding-right: 0.5rem;\n}\n\n.diagnosis__name {\n  font-size: 1.25rem;\n}\n\n.text-regular {\n  font-weight: 500;\n}\n\n.download-button {\n  background-color: transparent;\n}\n\n.consultation__download-button {\n  width: 100%;\n  display: flex;\n  justify-content: center;\n  margin-top: 2rem;\n}\n\n.download-button {\n  width: 35%;\n  background-color: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUk0vY29uc3VsdGF0aW9uL0Q6XFxSZXBvc2l0b3Jpb3NcXHBvcnRhbC1pb25pYy9zcmNcXGFwcFxcUk1cXGNvbnN1bHRhdGlvblxcY29uc3VsdGF0aW9uLnBhZ2Uuc2NzcyIsInNyYy9hcHAvUk0vY29uc3VsdGF0aW9uL2NvbnN1bHRhdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxjQUFBO0FDQUo7O0FER0E7RUFDSSxnQ0FBQTtBQ0FKOztBREdHO0VBQ0MsZ0NBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7QUNBSjs7QURHRztFQUNDLGVBQUE7RUFDQSxnQkFBQTtBQ0FKOztBREdHO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtBQ0FQOztBREdHO0VBQ0MscUJBQUE7QUNBSjs7QURHRztFQUNDLGNBQUE7QUNBSjs7QURHQTtFQUNJLHlCQUFBO0FDQUo7O0FER0c7RUFDSSxrQkFBQTtFQUNBLGVBQUE7QUNBUDs7QURJRztFQUNDLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FDREo7O0FESUE7RUFDSSwyQkFBQTtFQUNBLGlDQUFBO0FDREo7O0FESUE7RUFDSSwyQkFBQTtBQ0RKOztBRElBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0RKOztBRElBO0VBQ0ksVUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQ0RKOztBRElBO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtBQ0RKOztBRElBO0VBQ0ksa0JBQUE7QUNESjs7QURJQTtFQUNJLGdCQUFBO0FDREo7O0FESUE7RUFDSSxvQkFBQTtFQUNBLHFCQUFBO0FDREo7O0FESUE7RUFDSSxrQkFBQTtBQ0RKOztBRElBO0VBQ0ksZ0JBQUE7QUNESjs7QURJQTtFQUNJLDZCQUFBO0FDREo7O0FESUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7QUNESjs7QURJQTtFQUNJLFVBQUE7RUFDQSw2QkFBQTtBQ0RKIiwiZmlsZSI6InNyYy9hcHAvUk0vY29uc3VsdGF0aW9uL2NvbnN1bHRhdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLnJlZHtcclxuICAgIGNvbG9yOiAjRUMyNzJGXHJcbn1cclxuXHJcbmlvbi1pdGVtLmJvcmRlci1yZWQge1xyXG4gICAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgI0VDMjcyRjtcclxuICAgfVxyXG5cclxuICAgLmhlYWRlci10ZXh0e1xyXG4gICAgYm9yZGVyLWJvdHRvbToycHggc29saWQgIzUzNTM1MztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgIH1cclxuXHJcbiAgIGlvbi1pdGVte1xyXG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICAgfVxyXG5cclxuICAgaW9uLWxpc3R7XHJcbiAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgbWFyZ2luLWJvdHRvbTowcHg7XHJcbiAgIH1cclxuXHJcbiAgIGlvbi1oZWFkZXIgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNFQzI3MkY7XHJcbiAgICBcclxuICAgfVxyXG4gICBpb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZXtcclxuICAgIGNvbG9yOiAjRkZGRkZGO1xyXG4gICB9XHJcblxyXG4ud2hpdGV7XHJcbiAgICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4gICBpb24tbGFiZWx7XHJcbiAgICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgIH1cclxuXHJcblxyXG4gICBpb24tY29udGVudCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4uc2MtaW9uLWNhcmQtbWQtaCB7XHJcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAtd2Via2l0LWJveC1zaGFkb3c6XCJcIiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tY2FyZHtcclxuICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLXRpdGxle1xyXG4gICAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xyXG4gICAgZm9udC1zaXplOiA1dnc7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5kb3dubG9hZC1pY29uIHtcclxuICAgIHdpZHRoOiAzMCU7XHJcbiAgICBoZWlnaHQ6IDMwJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLmNvbnN1bHRhdGlvbiB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDFyZW07XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxcmVtO1xyXG59XHJcblxyXG4uY29uc3VsdGF0aW9uX19oZWFkZXIge1xyXG4gICAgbWFyZ2luLXRvcDogMS44cmVtO1xyXG59XHJcblxyXG4uY29uc3VsdGF0aW9uX19kYXRhIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbn1cclxuXHJcbi5jb25zdWx0YXRpb25fX2NvbnRlbnQge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAuNXJlbTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IC41cmVtO1xyXG59XHJcblxyXG4uZGlhZ25vc2lzX19uYW1lIHtcclxuICAgIGZvbnQtc2l6ZTogMS4yNXJlbTtcclxufVxyXG5cclxuLnRleHQtcmVndWxhciB7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcblxyXG4uZG93bmxvYWQtYnV0dG9uIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG59XHJcblxyXG4uY29uc3VsdGF0aW9uX19kb3dubG9hZC1idXR0b24ge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAycmVtO1xyXG59XHJcblxyXG4uZG93bmxvYWQtYnV0dG9uIHtcclxuICAgIHdpZHRoOiAzNSU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxufSIsIi5yZWQge1xuICBjb2xvcjogI0VDMjcyRjtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRUMyNzJGO1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzUzNTM1MztcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuaW9uLWxpc3Qge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICNFQzI3MkY7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xufVxuXG5pb24tY29udGVudCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uc2MtaW9uLWNhcmQtbWQtaCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBcIlwiICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG5pb24tdGl0bGUge1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgZm9udC1zaXplOiA1dnc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmRvd25sb2FkLWljb24ge1xuICB3aWR0aDogMzAlO1xuICBoZWlnaHQ6IDMwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29uc3VsdGF0aW9uIHtcbiAgcGFkZGluZy1sZWZ0OiAxcmVtO1xuICBwYWRkaW5nLXJpZ2h0OiAxcmVtO1xufVxuXG4uY29uc3VsdGF0aW9uX19oZWFkZXIge1xuICBtYXJnaW4tdG9wOiAxLjhyZW07XG59XG5cbi5jb25zdWx0YXRpb25fX2RhdGEge1xuICBmb250LXdlaWdodDogNzAwO1xufVxuXG4uY29uc3VsdGF0aW9uX19jb250ZW50IHtcbiAgcGFkZGluZy1sZWZ0OiAwLjVyZW07XG4gIHBhZGRpbmctcmlnaHQ6IDAuNXJlbTtcbn1cblxuLmRpYWdub3Npc19fbmFtZSB7XG4gIGZvbnQtc2l6ZTogMS4yNXJlbTtcbn1cblxuLnRleHQtcmVndWxhciB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5kb3dubG9hZC1idXR0b24ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmNvbnN1bHRhdGlvbl9fZG93bmxvYWQtYnV0dG9uIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAycmVtO1xufVxuXG4uZG93bmxvYWQtYnV0dG9uIHtcbiAgd2lkdGg6IDM1JTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/RM/consultation/consultation.page.ts":
/*!******************************************************!*\
  !*** ./src/app/RM/consultation/consultation.page.ts ***!
  \******************************************************/
/*! exports provided: ConsultationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConsultationPage", function() { return ConsultationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _device_device_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../device/device.service */ "./src/app/device/device.service.ts");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");














let ConsultationPage = class ConsultationPage {
    constructor(alertController, loadingController, storage, route, router, transfer, file, fileOpener, deviceDetailsService, screenOrientation, statusBar, navController, platform, consultationService) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.deviceDetailsService = deviceDetailsService;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.platform = platform;
        this.consultationService = consultationService;
        this.processErrorRM = function (error) {
            return new Promise((resolve, reject) => {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                this.loadingController.dismiss();
                this.storage.get('token').then((val) => {
                    if (val) {
                        this.loadingWithMessage("Descargando");
                        this.refreshUtils.refreshTokenRM(val).then((value) => {
                            this.loadingController.dismiss();
                            resolve(value);
                        }).catch((errorRefresh) => {
                            this.loadingController.dismiss();
                            if (errorRefresh.status == 401) {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                            }
                            else {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                    }
                });
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#EC272F');
    }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.consultationId = this.router.getCurrentNavigation().extras.state.consultationId;
                this.consultationService.getConsultation(this.consultationId).subscribe(response => {
                    this.consultation = response;
                });
            }
        });
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
    download(path) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loadingWithMessage("Descargando");
            this.storage.get('token').then((val) => {
                if (val) {
                    this.token = val;
                    let fileName = "Consulta_" + this.consultationId + ".pdf";
                    let filePath = `${_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].URL_RM_PREFIX}patient/pdf/${path}`;
                    // let filePath = constants.URL_RM + "secure/external/mobile/files/download/pdf/consultation/" + this.consultationId;
                    let url = encodeURI(filePath);
                    this.fileTransfer = this.transfer.create();
                    let options = {
                        headers: {
                            "X-Authorization": "Bearer " + this.token
                        }
                    };
                    let directory = this.file.documentsDirectory;
                    // if (this.platform.is("android")) {
                    //   if(this.file.externalRootDirectory){
                    //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
                    //     }else{
                    //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
                    //     }
                    // }
                    if (this.platform.is("android")) {
                        let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                        //if(this.file.externalRootDirectory){
                        console.log("[HOME] OS VERSION: " + soVersion);
                        if (soVersion < 11) {
                            if (this.file.externalRootDirectory) {
                                directory = this.file.externalRootDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FOLDER_DOWNLOAD;
                            }
                            else {
                                directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FOLDER_DOWNLOAD;
                            }
                        }
                        else {
                            directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FOLDER_DOWNLOAD;
                        }
                    }
                    this.fileTransfer.download(url, directory + fileName, true, options).then((entry) => {
                        this.loadingController.dismiss();
                        //here logging our success downloaded file path in mobile. 
                        console.log('download completed: ' + entry.toURL());
                        this.file.resolveDirectoryUrl(directory).then((rootDir) => {
                            this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
                                fileEntry.getMetadata(metadata => {
                                    if (metadata.size != 0) {
                                        // open downloaded file 
                                        this.openFileHandler(entry.toURL());
                                        if (this.platform.is("android")) {
                                            let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                                            if (soVersion < 11) {
                                                if (this.file.externalRootDirectory) {
                                                    this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + _utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                                                }
                                            }
                                        }
                                    }
                                    else {
                                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FILE_SIZE_0_ERROR);
                                    }
                                });
                            });
                        });
                    }).catch((error) => {
                        this.loadingController.dismiss();
                        if (error != null && error.http_status != null && error.http_status == 409) {
                            this.alert(JSON.parse(error.body).message);
                        }
                        else {
                            this.processErrorRM(error).then(value => {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                            });
                        }
                    });
                }
                else {
                    this.loadingController.dismiss();
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                }
            });
        });
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                            console.log('OK pressed!!');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando',
            });
            yield loading.present();
        });
    }
    loadingWithMessage(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: messageText,
            });
            yield loading.present();
        });
    }
    openFileHandler(path) {
        this.fileOpener.open(path, "")
            .then(() => console.log('File is opened'))
            .catch(e => console.log('Error opening file', e));
    }
    deleteDataAndExitToLogin() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storage.clear().then(() => {
                this.navController.navigateRoot("/login");
            });
        });
    }
};
ConsultationPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_5__["FileTransfer"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__["File"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_7__["FileOpener"] },
    { type: _device_device_service__WEBPACK_IMPORTED_MODULE_11__["DeviceDetailsService"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_12__["ConsultationService"] }
];
ConsultationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-consultation',
        template: __webpack_require__(/*! raw-loader!./consultation.page.html */ "./node_modules/raw-loader/index.js!./src/app/RM/consultation/consultation.page.html"),
        styles: [__webpack_require__(/*! ./consultation.page.scss */ "./src/app/RM/consultation/consultation.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_5__["FileTransfer"],
        _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__["File"],
        _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_7__["FileOpener"],
        _device_device_service__WEBPACK_IMPORTED_MODULE_11__["DeviceDetailsService"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
        src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_12__["ConsultationService"]])
], ConsultationPage);



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let LoadingService = class LoadingService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    present() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController.create({
                message: '...Cargando',
                duration: 7500,
            }).then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss().then(() => console.log('dismissed'));
        });
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
], LoadingService);



/***/ })

}]);
//# sourceMappingURL=RM-consultation-consultation-module-es2015.js.map