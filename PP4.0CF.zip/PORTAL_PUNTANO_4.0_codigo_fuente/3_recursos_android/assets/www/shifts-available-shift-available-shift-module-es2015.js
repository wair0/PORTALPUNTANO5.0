(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shifts-available-shift-available-shift-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/shifts/available-shift/available-shift.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shifts/available-shift/available-shift.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>TURNOS DISPONIBLES</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-card class=\"cardShift\">\r\n    <ion-card-content>\r\n      <h5> <B> Centro de Salud : </B> {{appointments.healthCenterName}} </h5>\r\n      <h5> <B> Especialidad :</B> {{appointments.specialtyNames}}</h5>\r\n      <h5> <B> Profesional :</B> {{appointments.professionalNames}}</h5>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n  <ion-item>\r\n    <h5 class=\"titleHour\"> <B> HORARIOS DISPONIBLES</B></h5>\r\n  </ion-item>\r\n\r\n  <ion-card *ngIf=\"!horarioSelected\">\r\n    <ion-card-content [@visibilityChanged]=\"showHrList\" style=\"opacity: 0\">\r\n      <ion-list *ngFor=\"let item of appointments.appointments\">\r\n          <ion-button size=\"large\" class=\"hourShift\" (click)=\"selectedHour(item)\" > <b> {{item.startDate}} - {{item.endDate}} </b> </ion-button>\r\n      </ion-list>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n  <ion-card  *ngIf=\"horarioSelected\">\r\n    <ion-card-content [@visibilityChanged]=\"showHrSelected\" style=\"opacity: 0\">\r\n        <ion-button size=\"large\" class=\"hourShiftSelected\" > <b> {{horarioSelected.startDate}} - {{horarioSelected.endDate}} </b> </ion-button>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n  <ion-card  *ngIf=\"horarioSelected\">\r\n    <ion-card-content [@visibilityChanged]=\"showHrSelected\" style=\"opacity: 0\">\r\n      <h5 style=\"margin-bottom: 1rem; text-align: center;\" > <B> Detalle del Turno </B> </h5>\r\n      <h5><B>Fecha del turno : </B>  {{appointmentDate}} </h5>\r\n      <h5><B> Hora desde : </B>  {{horarioSelected.startDate}}  </h5>\r\n      <h5><B> Hora hasta : </B>  {{horarioSelected.endDate}}  </h5>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n \r\n\r\n  <div [@visibilityChanged]=\"showHrSelected\">\r\n    <ion-item *ngIf=\"horarioSelected\">\r\n      <ion-button color=\"green\" class=\"sendHour\" (click)=\"send()\" >Enviar Solicitud de Turno</ion-button>\r\n    </ion-item>\r\n  \r\n    <ion-item *ngIf=\"horarioSelected\">\r\n      <ion-button color='medium' class=\"sendHour\" (click)=\"clearHrSelected()\">Volver</ion-button>\r\n    </ion-item>\r\n  </div>\r\n\r\n  \r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button  (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/shifts/available-shift/available-shift-routing.module.ts":
/*!**************************************************************************!*\
  !*** ./src/app/shifts/available-shift/available-shift-routing.module.ts ***!
  \**************************************************************************/
/*! exports provided: AvailableShiftRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvailableShiftRoutingModule", function() { return AvailableShiftRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _available_shift_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./available-shift.component */ "./src/app/shifts/available-shift/available-shift.component.ts");




const routes = [
    {
        path: '',
        component: _available_shift_component__WEBPACK_IMPORTED_MODULE_3__["AvailableShiftComponent"]
    }
];
let AvailableShiftRoutingModule = class AvailableShiftRoutingModule {
};
AvailableShiftRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AvailableShiftRoutingModule);



/***/ }),

/***/ "./src/app/shifts/available-shift/available-shift.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/shifts/available-shift/available-shift.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #20B572;\n}\n\n.white {\n  color: #ffffff !important;\n}\n\nion-header ion-toolbar {\n  --background: #20B572;\n}\n\nion-header ion-toolbar ion-title {\n  color: #ffffff;\n}\n\n.cardShift {\n  font-weight: 700;\n  --background: #20B572;\n  color: white;\n}\n\n.hourShift {\n  display: grid;\n  border-radius: 16px;\n  --background: #4992FF;\n}\n\n.titleHour {\n  width: 100%;\n  text-align: center;\n}\n\n.sendHour {\n  width: 100%;\n  height: 70%;\n  font-weight: 700;\n  font-size: small;\n  --background: #20B572;\n}\n\n.hourShiftSelected {\n  display: grid;\n  border-radius: 16px;\n  --background: #20B572;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hpZnRzL2F2YWlsYWJsZS1zaGlmdC9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXHNoaWZ0c1xcYXZhaWxhYmxlLXNoaWZ0XFxhdmFpbGFibGUtc2hpZnQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3NoaWZ0cy9hdmFpbGFibGUtc2hpZnQvYXZhaWxhYmxlLXNoaWZ0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBREVBO0VBQ0kseUJBQUE7QUNDSjs7QURFQTtFQUNJLHFCQUFBO0FDQ0o7O0FEQ0E7RUFDSSxjQUFBO0FDRUo7O0FEQ0E7RUFDSSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtBQ0VKOztBRENBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EscUJBQUE7QUNFSjs7QURBQTtFQUVJLFdBQUE7RUFDQSxrQkFBQTtBQ0VKOztBREFBO0VBQ0ksV0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7QUNHSjs7QUREQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0FDSUoiLCJmaWxlIjoic3JjL2FwcC9zaGlmdHMvYXZhaWxhYmxlLXNoaWZ0L2F2YWlsYWJsZS1zaGlmdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZWQge1xyXG4gICAgY29sb3I6ICMyMEI1NzI7XHJcbn1cclxuXHJcbi53aGl0ZSB7XHJcbiAgICBjb2xvcjogI2ZmZmZmZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogIzIwQjU3MjtcclxufVxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XHJcbiAgICBjb2xvcjogI2ZmZmZmZjtcclxufVxyXG5cclxuLmNhcmRTaGlmdHtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAtLWJhY2tncm91bmQ6ICMyMEI1NzI7XHJcbiAgICBjb2xvcjp3aGl0ZTtcclxuXHJcbn1cclxuLmhvdXJTaGlmdHtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNnB4O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjNDk5MkZGO1xyXG59XHJcbi50aXRsZUhvdXJcclxue1xyXG4gICAgd2lkdGg6IDEwMCU7ICAgIFxyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5zZW5kSG91cntcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA3MCU7XHJcbiAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgZm9udC1zaXplOiBzbWFsbDtcclxuICAgIC0tYmFja2dyb3VuZDogIzIwQjU3MjtcclxufVxyXG4uaG91clNoaWZ0U2VsZWN0ZWR7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTZweDtcclxuICAgIC0tYmFja2dyb3VuZDogIzIwQjU3MjtcclxufSIsIi5yZWQge1xuICBjb2xvcjogIzIwQjU3Mjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNmZmZmZmYgIWltcG9ydGFudDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzIwQjU3Mjtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI2ZmZmZmZjtcbn1cblxuLmNhcmRTaGlmdCB7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIC0tYmFja2dyb3VuZDogIzIwQjU3MjtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uaG91clNoaWZ0IHtcbiAgZGlzcGxheTogZ3JpZDtcbiAgYm9yZGVyLXJhZGl1czogMTZweDtcbiAgLS1iYWNrZ3JvdW5kOiAjNDk5MkZGO1xufVxuXG4udGl0bGVIb3VyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnNlbmRIb3VyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNzAlO1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LXNpemU6IHNtYWxsO1xuICAtLWJhY2tncm91bmQ6ICMyMEI1NzI7XG59XG5cbi5ob3VyU2hpZnRTZWxlY3RlZCB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGJvcmRlci1yYWRpdXM6IDE2cHg7XG4gIC0tYmFja2dyb3VuZDogIzIwQjU3Mjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/shifts/available-shift/available-shift.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/shifts/available-shift/available-shift.component.ts ***!
  \*********************************************************************/
/*! exports provided: AvailableShiftComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvailableShiftComponent", function() { return AvailableShiftComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm2015/animations.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/shift.service */ "./src/app/services/shift.service.ts");
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ "./node_modules/@ionic-native/local-notifications/ngx/index.js");
/* harmony import */ var src_app_utils_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/loading.service */ "./src/app/services/loading.service.ts");













let AvailableShiftComponent = class AvailableShiftComponent {
    constructor(storage, route, loadingController, router, alertController, toastController, shiftService, navController, loading, localNotifications) {
        this.storage = storage;
        this.route = route;
        this.loadingController = loadingController;
        this.router = router;
        this.alertController = alertController;
        this.toastController = toastController;
        this.shiftService = shiftService;
        this.navController = navController;
        this.loading = loading;
        this.localNotifications = localNotifications;
        this.appointments = {
            appointments: [],
            endTime: '',
            healthCenterName: '',
            initTime: '',
            professionalNames: '',
            specialtyNames: '',
        };
        this.appointment = {
            endDate: '',
            professionalPlanningId: null,
            startDate: '',
        };
        this.showHrList = 'shown';
        this.showHrSelected = 'hidden';
        this.horarioSelected = null;
        this.httpOptions = null;
        this.person = null;
    }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.data = this.router.getCurrentNavigation().extras.state.shift;
                this.appointments.endTime = this.data.endTime;
                this.appointments.healthCenterName = this.data.healthCenterName;
                this.appointments.initTime = this.data.initTime;
                this.appointments.professionalNames = this.data.professionalNames;
                this.appointments.specialtyNames = this.data.specialtyNames;
                this.data.appointments.forEach(element => {
                    let appointment = {
                        endDate: '',
                        professionalPlanningId: null,
                        startDate: '',
                    };
                    this.appointmentDate = moment__WEBPACK_IMPORTED_MODULE_7__(element.startDate).format('DD-MM-YYYY');
                    appointment.endDate = moment__WEBPACK_IMPORTED_MODULE_7__(element.endDate).format('HH:mm');
                    appointment.startDate = moment__WEBPACK_IMPORTED_MODULE_7__(element.startDate).format('HH:mm');
                    appointment.professionalPlanningId = element.professionalPlanningId;
                    this.appointments.appointments.push(appointment);
                });
                this.person = this.router.getCurrentNavigation().extras.state.person;
            }
        });
    }
    selectedHour(item) {
        this.horarioSelected = item;
        this.showHrList = 'hidden';
        this.showHrSelected = 'shown';
    }
    clearHrSelected() {
        this.horarioSelected = null;
        this.showHrList = 'shown';
        this.showHrSelected = 'hidden';
    }
    presentToast() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: 'TURNO SOLICITADO CON ÉXITO',
                duration: 5000
            });
            toast.present();
        });
    }
    send() {
        let model = null;
        let auxDate = moment__WEBPACK_IMPORTED_MODULE_7__(this.appointmentDate, 'DD-MM-YYYY').format('YYYY-MM-DD');
        let start = moment__WEBPACK_IMPORTED_MODULE_7__(auxDate + ' ' + this.horarioSelected.startDate).format('YYYY-MM-DD HH:mm:ss');
        let end = moment__WEBPACK_IMPORTED_MODULE_7__(auxDate + ' ' + this.horarioSelected.endDate).format('YYYY-MM-DD HH:mm:ss');
        if (this.person) {
            model = {
                dateFrom: start,
                dateTo: end,
                patient: {
                    sex: this.person.sex,
                    docNumber: this.person.docNumber,
                },
                professionalPlanning: {
                    id: this.horarioSelected.professionalPlanningId
                },
            };
        }
        else {
            model = {
                dateFrom: start,
                dateTo: end,
                professionalPlanning: {
                    id: this.horarioSelected.professionalPlanningId
                },
            };
        }
        this.loading.present();
        this.getToken().then(value => {
            this.shiftService.assignShifts(this.httpOptions, model).subscribe((response) => {
                this.presentToast();
                this.router.navigate(['shifts-details-rm']);
                // Se elimino debido a que en un dispositivo rompe la APP
                // this.localNotifications.schedule({ 
                //   text: 'Su turno ha sido asignado el día: '+response.dateFrom,
                //  // sound: isAndroid? 'file://sound.mp3': 'file://beep.caf',
                //  // data: { secret: key }
                // });
                this.loading.dismiss();
            }, error => {
                this.loading.dismiss();
                if (error.status === 409) {
                    sweetalert2__WEBPACK_IMPORTED_MODULE_8___default.a.fire({
                        text: error.error.message,
                        imageUrl: "../../assets/icon/GreenWarning.png",
                        imageWidth: 100,
                        imageHeight: 100,
                        confirmButtonText: 'Cerrar',
                        confirmButtonColor: '#A2A4AB'
                    });
                }
                else {
                    this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_11__["constants"].GENERIC_ERROR);
                }
            });
        });
    }
    getToken() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.storage.get('token').then(value => {
                let httpOptions = {
                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Authorization': 'Bearer ' + value,
                    }),
                    response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        }),
                    })
                };
                this.httpOptions = httpOptions;
            });
        });
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                            console.log('OK pressed!!');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
};
AvailableShiftComponent.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_9__["ShiftService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_12__["LoadingService"] },
    { type: _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_10__["LocalNotifications"] }
];
AvailableShiftComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-available-shift',
        template: __webpack_require__(/*! raw-loader!./available-shift.component.html */ "./node_modules/raw-loader/index.js!./src/app/shifts/available-shift/available-shift.component.html"),
        animations: [
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["trigger"])('visibilityChanged', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["state"])('shown', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["style"])({ opacity: 1 })),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["state"])('hidden', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["style"])({ opacity: 0 })),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["transition"])('* => *', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_4__["animate"])('500ms'))
            ])
        ],
        styles: [__webpack_require__(/*! ./available-shift.component.scss */ "./src/app/shifts/available-shift/available-shift.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"],
        src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_9__["ShiftService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"],
        src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_12__["LoadingService"],
        _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_10__["LocalNotifications"]])
], AvailableShiftComponent);



/***/ }),

/***/ "./src/app/shifts/available-shift/available-shift.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/shifts/available-shift/available-shift.module.ts ***!
  \******************************************************************/
/*! exports provided: AvailableShiftModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvailableShiftModule", function() { return AvailableShiftModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _available_shift_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./available-shift-routing.module */ "./src/app/shifts/available-shift/available-shift-routing.module.ts");
/* harmony import */ var _available_shift_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./available-shift.component */ "./src/app/shifts/available-shift/available-shift.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/shift.service */ "./src/app/services/shift.service.ts");









let AvailableShiftModule = class AvailableShiftModule {
};
AvailableShiftModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _available_shift_routing_module__WEBPACK_IMPORTED_MODULE_3__["AvailableShiftRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"]
        ],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"],
            src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_8__["ShiftService"]],
        declarations: [_available_shift_component__WEBPACK_IMPORTED_MODULE_4__["AvailableShiftComponent"]]
    })
], AvailableShiftModule);



/***/ })

}]);
//# sourceMappingURL=shifts-available-shift-available-shift-module-es2015.js.map