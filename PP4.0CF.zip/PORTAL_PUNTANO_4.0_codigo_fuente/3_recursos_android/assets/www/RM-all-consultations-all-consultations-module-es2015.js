(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["RM-all-consultations-all-consultations-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/RM/all-consultations/all-consultations.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RM/all-consultations/all-consultations.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTROS MÉDICOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  \r\n  <ion-list>\r\n    <ion-list-header>\r\n      <h2 class=\"header-text\"><b>TODAS MIS CONSULTAS</b></h2>\r\n    </ion-list-header>\r\n\r\n    <ion-item *ngIf=\"consultations.length === 0\">\r\n      <p>No se encontraron consultas</p>\r\n    </ion-item>\r\n\r\n    <ion-item class=\"border-red\" *ngFor=\"let item of consultations\" (click)=\"goToConsultation(item.consultationId)\">\r\n      <ion-label class=\"ion-text-wrap\">\r\n        <ion-text color=\"dark\">\r\n          <h2 style=\"display: inline;\"> {{item.dateCreated}}</h2>\r\n          <ion-icon style=\" vertical-align: middle; margin: 0px !important;\" name=\"ios-arrow-forward\"></ion-icon>\r\n        </ion-text>\r\n        <h2 class=\"red\">{{item.specialty}}</h2>\r\n        <h2 class=\"red\">{{item.professionalName}}</h2>\r\n        <h3 class=\"red\">{{item.healthCenterName}}</h3>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n  </ion-list>\r\n\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/RM/all-consultations/all-consultations.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/RM/all-consultations/all-consultations.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item.border-red {\n  border-bottom: 1px solid #ec272f;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #ec272f;\n}\n\nion-header ion-toolbar ion-title {\n  color: #ffffff;\n}\n\n.white {\n  color: #ffffff !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUk0vYWxsLWNvbnN1bHRhdGlvbnMvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxSTVxcYWxsLWNvbnN1bHRhdGlvbnNcXGFsbC1jb25zdWx0YXRpb25zLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9STS9hbGwtY29uc3VsdGF0aW9ucy9hbGwtY29uc3VsdGF0aW9ucy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdDQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUNDRjs7QURFQTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7QUNDRjs7QURFQTtFQUNFLHFCQUFBO0FDQ0Y7O0FEQ0E7RUFDRSxjQUFBO0FDRUY7O0FEQ0E7RUFDRSx5QkFBQTtBQ0VGOztBRENBO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0VGIiwiZmlsZSI6InNyYy9hcHAvUk0vYWxsLWNvbnN1bHRhdGlvbnMvYWxsLWNvbnN1bHRhdGlvbnMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taXRlbS5ib3JkZXItcmVkIHtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VjMjcyZjtcclxufVxyXG5cclxuLmhlYWRlci10ZXh0IHtcclxuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzUzNTM1MztcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gIG1hcmdpbi1yaWdodDogNSU7XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxufVxyXG5cclxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjZWMyNzJmO1xyXG59XHJcbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxufVxyXG5cclxuLndoaXRlIHtcclxuICBjb2xvcjogI2ZmZmZmZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tdGl0bGUge1xyXG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgZm9udC1zaXplOiA1dnc7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbiIsImlvbi1pdGVtLmJvcmRlci1yZWQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VjMjcyZjtcbn1cblxuLmhlYWRlci10ZXh0IHtcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICM1MzUzNTM7XG4gIG1hcmdpbi1yaWdodDogNSU7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cblxuaW9uLWl0ZW0ge1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIG1hcmdpbi1yaWdodDogNSU7XG59XG5cbmlvbi1saXN0IHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZWMyNzJmO1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XG4gIGNvbG9yOiAjZmZmZmZmO1xufVxuXG4ud2hpdGUge1xuICBjb2xvcjogI2ZmZmZmZiAhaW1wb3J0YW50O1xufVxuXG5pb24tdGl0bGUge1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgZm9udC1zaXplOiA1dnc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/RM/all-consultations/all-consultations.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/RM/all-consultations/all-consultations.component.ts ***!
  \*********************************************************************/
/*! exports provided: AllConsultationsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllConsultationsComponent", function() { return AllConsultationsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");







let AllConsultationsComponent = class AllConsultationsComponent {
    constructor(router, localStorageService, patientService, consultationService, alertService) {
        this.router = router;
        this.localStorageService = localStorageService;
        this.patientService = patientService;
        this.consultationService = consultationService;
        this.alertService = alertService;
        this.consultations = [];
    }
    ngOnInit() {
        this.localStorageService.getUserData().then(userData => {
            this.userData = userData;
            this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(patientId => {
                this.patientId = patientId;
                //TODO: DateFrom deberia ser opcional en el back?
                this.consultationService.getConsultationsByPatientId({
                    patientId,
                    size: 999,
                    dateFrom: "1900-01-01"
                }).subscribe(response => {
                    this.consultations = response;
                }, error => {
                    if (error.message)
                        this.alertService.showErrorAlert(error.message);
                    else
                        this.alertService.showErrorAlert();
                });
                this.patientService.getSpecialtiesByPatientId(patientId).subscribe(response => {
                    this.specialties = response;
                });
            });
        });
    }
    goToConsultation(id) {
        let navigationExtras = {
            state: {
                consultationId: id,
            }
        };
        this.router.navigate(['consultation'], navigationExtras);
    }
};
AllConsultationsComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_5__["LocalStorageService"] },
    { type: src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_6__["PatientService"] },
    { type: src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_4__["ConsultationService"] },
    { type: src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_3__["AlertService"] }
];
AllConsultationsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-all-consultations',
        template: __webpack_require__(/*! raw-loader!./all-consultations.component.html */ "./node_modules/raw-loader/index.js!./src/app/RM/all-consultations/all-consultations.component.html"),
        styles: [__webpack_require__(/*! ./all-consultations.component.scss */ "./src/app/RM/all-consultations/all-consultations.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_5__["LocalStorageService"],
        src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_6__["PatientService"],
        src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_4__["ConsultationService"],
        src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_3__["AlertService"]])
], AllConsultationsComponent);



/***/ }),

/***/ "./src/app/RM/all-consultations/all-consultations.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/RM/all-consultations/all-consultations.module.ts ***!
  \******************************************************************/
/*! exports provided: AllConsultationsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllConsultationsModule", function() { return AllConsultationsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/interceptors/interceptor-rm.service */ "./src/app/core/interceptors/interceptor-rm.service.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");
/* harmony import */ var src_app_utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _all_consultations_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./all-consultations.component */ "./src/app/RM/all-consultations/all-consultations.component.ts");













let AllConsultationsModule = class AllConsultationsModule {
};
AllConsultationsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _all_consultations_component__WEBPACK_IMPORTED_MODULE_12__["AllConsultationsComponent"]
                }
            ])
        ],
        providers: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            src_app_utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__["RefreshUtils"],
            src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_9__["ConsultationService"],
            src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_10__["PatientService"],
            src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_8__["AlertService"],
            {
                provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HTTP_INTERCEPTORS"],
                useClass: src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_7__["InterceptorRm"],
                multi: true
            }
        ],
        declarations: [_all_consultations_component__WEBPACK_IMPORTED_MODULE_12__["AllConsultationsComponent"]],
    })
], AllConsultationsModule);



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let LoadingService = class LoadingService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    present() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController.create({
                message: '...Cargando',
                duration: 7500,
            }).then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss().then(() => console.log('dismissed'));
        });
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
], LoadingService);



/***/ })

}]);
//# sourceMappingURL=RM-all-consultations-all-consultations-module-es2015.js.map