(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["screenError-screenError-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/screenError/screenError.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/screenError/screenError.page.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>PORTAL PUNTANO</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <h1 style=\"margin-top: 30%; margin-left: 5%; margin-right: 5%; white-space: pre-line\"><b>{{message}}</b></h1>\r\n    <!-- <ion-label class=\"ion-text-wrap\" >\r\n        <ion-text  >\r\n          <h1 class=\"title-big\"style=\"text-align: center\"><b>{{message}}</b></h1>\r\n        </ion-text>\r\n      </ion-label> -->\r\n\r\n\r\n    <!-- <ion-list >\r\n<ion-item lines=\"none\">\r\n      <ion-img [src]=\"'data:image/jpeg;base64,'+driverLicense.qrBase64\"></ion-img>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n        <ion-label class=\"ion-text-wrap\" >\r\n            <ion-text  >\r\n              <h1 class=\"title-big\"style=\"text-align: center\"><b>{{driverLicense.firstName}} {{driverLicense.lastName}}</b></h1>\r\n            </ion-text>\r\n          </ion-label>\r\n    </ion-item>\r\n    <ion-item lines=\"none\" *ngIf=\"1>=driverLicense.driverLicenseTypes.length\">\r\n        <ion-label class=\"ion-text-wrap\" style=\"text-align: center;\">\r\n            <ion-text  >\r\n              <h2 class=\"title\" style=\"text-align: center; margin-top: 5px\"><b>Categoría:</b></h2>\r\n              <div style=\"display: inline;\" *ngFor=\"let driverLicenseType of driverLicense.driverLicenseTypes; let i = index\">\r\n                  <h2 class=\"content\" style=\"display: inline; text-align: center\">{{driverLicenseType.name}}</h2>\r\n                  <h2 class=\"content\" style=\"display: inline; text-align: center\" *ngIf=\"driverLicense.driverLicenseTypes.length>i+1\">, </h2>\r\n              </div>\r\n            </ion-text>\r\n          </ion-label>\r\n    </ion-item>\r\n    <ion-item lines=\"none\" *ngIf=\"driverLicense.driverLicenseTypes.length>1\">\r\n        <ion-label class=\"ion-text-wrap\" style=\"text-align: center; \" >\r\n            <ion-text>\r\n              <h2 class=\"title\" style=\"text-align: center; margin-top: 5px\" ><b>Categorías:</b></h2>\r\n              <div style=\"display: inline; text-align: center;\" *ngFor=\"let driverLicenseType of driverLicense.driverLicenseTypes; let i = index\">\r\n                  <h2 class=\"content\" style=\"display: inline; text-align: center\">{{driverLicenseType.name}}</h2>\r\n                  <h2 class=\"content\" style=\"display: inline; text-align: center\" *ngIf=\"driverLicense.driverLicenseTypes.length>i+1\">, </h2>\r\n              </div>\r\n            </ion-text>\r\n          </ion-label>\r\n\r\n    </ion-item>\r\n\r\n\r\n    <ion-item lines=\"none\" >\r\n        <ion-label class=\"ion-text-wrap\" >\r\n            <ion-text  >\r\n              <h2 class=\"title\" style=\"text-align: center; margin-top: 10px\"><b>Fecha de vencimento: </b></h2>\r\n              <h2 class=\"content\" style=\"text-align: center\">{{driverLicense.dateTo}}</h2>\r\n            </ion-text>\r\n          </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item style=\"background-color: blue\" lines=\"none\" *ngIf=\"driverLicense.driverLicenseVisas!=null && driverLicense.driverLicenseVisas.length>0\">\r\n        <ion-label class=\"ion-text-wrap\">\r\n            <ion-text >\r\n              <h2 class=\"title\" style=\"text-align: center; margin-top: 10px\"><b>Visado:</b></h2>\r\n              <div  *ngFor=\"let driverLicenseVisa of driverLicense.driverLicenseVisas; let i = index\">\r\n                  <h2 class=\"content\" style=\"text-align: center\" >{{driverLicenseVisa.visaDate}}</h2>\r\n              </div>\r\n            </ion-text>\r\n          </ion-label>\r\n\r\n    </ion-item>\r\n\r\n    </ion-list> -->\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n      <ion-buttons>\r\n        <ion-button (click)=\"goToHome()\">\r\n          <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\" ></ion-icon>\r\n        </ion-button>\r\n        </ion-buttons>\r\n      </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/screenError/screenError.module.ts":
/*!***************************************************!*\
  !*** ./src/app/screenError/screenError.module.ts ***!
  \***************************************************/
/*! exports provided: ScreenErrorModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScreenErrorModule", function() { return ScreenErrorModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _screenError_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./screenError.page */ "./src/app/screenError/screenError.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");











let ScreenErrorModule = class ScreenErrorModule {
};
ScreenErrorModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _screenError_page__WEBPACK_IMPORTED_MODULE_6__["ScreenErrorPage"]
                }
            ])
        ],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__["FileOpener"]],
        declarations: [_screenError_page__WEBPACK_IMPORTED_MODULE_6__["ScreenErrorPage"]]
    })
], ScreenErrorModule);



/***/ }),

/***/ "./src/app/screenError/screenError.page.scss":
/*!***************************************************!*\
  !*** ./src/app/screenError/screenError.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #932a7e;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #932a7e;\n}\n\n.header-text {\n  margin-right: 5%;\n  padding-left: 20px;\n  width: 100%;\n  padding-bottom: 10px;\n  padding-top: 10px;\n  background-color: #932a7e;\n  color: #FFFFFF;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #932a7e;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2NyZWVuRXJyb3IvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxzY3JlZW5FcnJvclxcc2NyZWVuRXJyb3IucGFnZS5zY3NzIiwic3JjL2FwcC9zY3JlZW5FcnJvci9zY3JlZW5FcnJvci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FDQ0o7O0FET0E7RUFDSSxnQ0FBQTtBQ0pKOztBRE9HO0VBRUMsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsOEJBQUE7QUNMSjs7QURRRztFQUNDLGVBQUE7RUFDQSxnQkFBQTtBQ0xKOztBRFFHO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtBQ0xQOztBRFFHO0VBQ0MscUJBQUE7QUNMSjs7QURRRztFQUNDLGNBQUE7QUNMSjs7QURRQTtFQUNJLHlCQUFBO0FDTEo7O0FET0E7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDSkoiLCJmaWxlIjoic3JjL2FwcC9zY3JlZW5FcnJvci9zY3JlZW5FcnJvci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVke1xyXG4gICAgY29sb3I6ICM5MzJhN2VcclxufVxyXG5cclxuLy8gaW9uLWljb24ge1xyXG4vLyAgICAgY29sb3I6ICNGNzkzMUU7XHJcbi8vICAgfVxyXG5cclxuXHJcbmlvbi1pdGVtLmJvcmRlci1yZWQge1xyXG4gICAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgIzkzMmE3ZTtcclxuICAgfVxyXG5cclxuICAgLmhlYWRlci10ZXh0e1xyXG4gICAgLy8gYm9yZGVyLWJvdHRvbToycHggc29saWQgIzUzNTM1MztcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTMyYTdlO1xyXG4gICAgY29sb3I6ICNGRkZGRkY7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgIH1cclxuXHJcbiAgIGlvbi1pdGVte1xyXG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICAgfVxyXG5cclxuICAgaW9uLWxpc3R7XHJcbiAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgbWFyZ2luLWJvdHRvbTowcHg7XHJcbiAgIH1cclxuXHJcbiAgIGlvbi1oZWFkZXIgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6ICM5MzJhN2U7XHJcbiAgICBcclxuICAgfVxyXG4gICBpb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZXtcclxuICAgIGNvbG9yOiAjRkZGRkZGO1xyXG4gICB9XHJcblxyXG4ud2hpdGV7XHJcbiAgICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xyXG59XHJcbmlvbi10aXRsZXtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIGZvbnQtc2l6ZTogNXZ3O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4vLyAgICBpb24tbGFiZWx7XHJcbi8vICAgICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbi8vICAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbi8vICAgIH1cclxuXHJcblxyXG4vLyAgICBpb24tY29udGVudCB7XHJcbi8vICAgICBkaXNwbGF5OiBmbGV4O1xyXG4vLyAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuLy8gICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4vLyB9XHJcblxyXG4vLyAuc2MtaW9uLWNhcmQtbWQtaCB7XHJcbi8vICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbi8vICAgICAtd2Via2l0LWJveC1zaGFkb3c6XCJcIiAhaW1wb3J0YW50O1xyXG4vLyB9XHJcblxyXG4vLyBpb24tY2FyZHtcclxuLy8gICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuLy8gfVxyXG5cclxuLy8gLnRpdGxlLWJpZyB7XHJcbi8vICAgICBmb250LXNpemU6IDIuN2VtO1xyXG4vLyAgIH1cclxuXHJcbi8vICAgLnRpdGxlIHtcclxuLy8gICAgIGZvbnQtc2l6ZTogMmVtO1xyXG4vLyAgIH1cclxuXHJcbi8vICAgLmNvbnRlbnQge1xyXG4vLyAgICAgZm9udC1zaXplOiAxLjhlbTtcclxuLy8gICB9XHJcbiIsIi5yZWQge1xuICBjb2xvcjogIzkzMmE3ZTtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjOTMyYTdlO1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5MzJhN2U7XG4gIGNvbG9yOiAjRkZGRkZGO1xuICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG5pb24tbGlzdCB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzkzMmE3ZTtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI0ZGRkZGRjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cblxuaW9uLXRpdGxlIHtcbiAgcGFkZGluZy1yaWdodDogNSU7XG4gIHBhZGRpbmctbGVmdDogNSU7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il19 */"

/***/ }),

/***/ "./src/app/screenError/screenError.page.ts":
/*!*************************************************!*\
  !*** ./src/app/screenError/screenError.page.ts ***!
  \*************************************************/
/*! exports provided: ScreenErrorPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScreenErrorPage", function() { return ScreenErrorPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");











let ScreenErrorPage = class ScreenErrorPage {
    constructor(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, screenOrientation, statusBar, navController) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.message = this.router.getCurrentNavigation().extras.state.message;
            }
        });
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#932a7e');
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
    ngOnInit() {
    }
};
ScreenErrorPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
ScreenErrorPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-screenError',
        template: __webpack_require__(/*! raw-loader!./screenError.page.html */ "./node_modules/raw-loader/index.js!./src/app/screenError/screenError.page.html"),
        styles: [__webpack_require__(/*! ./screenError.page.scss */ "./src/app/screenError/screenError.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"],
        _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
        _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
], ScreenErrorPage);



/***/ })

}]);
//# sourceMappingURL=screenError-screenError-module-es2015.js.map