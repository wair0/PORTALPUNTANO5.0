(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["procedures-dynamic-form-dynamic-form-module"],{

/***/ "./node_modules/@angular/material/esm2015/icon.js":
/*!********************************************************!*\
  !*** ./node_modules/@angular/material/esm2015/icon.js ***!
  \********************************************************/
/*! exports provided: MatIconModule, MAT_ICON_LOCATION_FACTORY, MAT_ICON_LOCATION, MatIcon, getMatIconNameNotFoundError, getMatIconNoHttpProviderError, getMatIconFailedToSanitizeUrlError, getMatIconFailedToSanitizeLiteralError, ICON_REGISTRY_PROVIDER_FACTORY, MatIconRegistry, ICON_REGISTRY_PROVIDER */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MatIconModule", function() { return MatIconModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MAT_ICON_LOCATION_FACTORY", function() { return MAT_ICON_LOCATION_FACTORY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MAT_ICON_LOCATION", function() { return MAT_ICON_LOCATION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MatIcon", function() { return MatIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMatIconNameNotFoundError", function() { return getMatIconNameNotFoundError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMatIconNoHttpProviderError", function() { return getMatIconNoHttpProviderError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMatIconFailedToSanitizeUrlError", function() { return getMatIconFailedToSanitizeUrlError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMatIconFailedToSanitizeLiteralError", function() { return getMatIconFailedToSanitizeLiteralError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ICON_REGISTRY_PROVIDER_FACTORY", function() { return ICON_REGISTRY_PROVIDER_FACTORY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MatIconRegistry", function() { return MatIconRegistry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ICON_REGISTRY_PROVIDER", function() { return ICON_REGISTRY_PROVIDER; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/coercion */ "./node_modules/@angular/cdk/esm2015/coercion.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/esm2015/core.js");
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */









/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Returns an exception to be thrown in the case when attempting to
 * load an icon with a name that cannot be found.
 * \@docs-private
 * @param {?} iconName
 * @return {?}
 */
function getMatIconNameNotFoundError(iconName) {
    return Error(`Unable to find icon with the name "${iconName}"`);
}
/**
 * Returns an exception to be thrown when the consumer attempts to use
 * `<mat-icon>` without including \@angular/common/http.
 * \@docs-private
 * @return {?}
 */
function getMatIconNoHttpProviderError() {
    return Error('Could not find HttpClient provider for use with Angular Material icons. ' +
        'Please include the HttpClientModule from @angular/common/http in your ' +
        'app imports.');
}
/**
 * Returns an exception to be thrown when a URL couldn't be sanitized.
 * \@docs-private
 * @param {?} url URL that was attempted to be sanitized.
 * @return {?}
 */
function getMatIconFailedToSanitizeUrlError(url) {
    return Error(`The URL provided to MatIconRegistry was not trusted as a resource URL ` +
        `via Angular's DomSanitizer. Attempted URL was "${url}".`);
}
/**
 * Returns an exception to be thrown when a HTML string couldn't be sanitized.
 * \@docs-private
 * @param {?} literal HTML that was attempted to be sanitized.
 * @return {?}
 */
function getMatIconFailedToSanitizeLiteralError(literal) {
    return Error(`The literal provided to MatIconRegistry was not trusted as safe HTML by ` +
        `Angular's DomSanitizer. Attempted literal was "${literal}".`);
}
/**
 * Configuration for an icon, including the URL and possibly the cached SVG element.
 * \@docs-private
 */
class SvgIconConfig {
    /**
     * @param {?} data
     * @param {?=} options
     */
    constructor(data, options) {
        this.options = options;
        // Note that we can't use `instanceof SVGElement` here,
        // because it'll break during server-side rendering.
        if (!!((/** @type {?} */ (data))).nodeName) {
            this.svgElement = (/** @type {?} */ (data));
        }
        else {
            this.url = (/** @type {?} */ (data));
        }
    }
}
/**
 * Service to register and display icons used by the `<mat-icon>` component.
 * - Registers icon URLs by namespace and name.
 * - Registers icon set URLs by namespace.
 * - Registers aliases for CSS classes, for use with icon fonts.
 * - Loads icons from URLs and extracts individual icons from icon sets.
 */
class MatIconRegistry {
    /**
     * @param {?} _httpClient
     * @param {?} _sanitizer
     * @param {?} document
     * @param {?=} _errorHandler
     */
    constructor(_httpClient, _sanitizer, document, _errorHandler) {
        this._httpClient = _httpClient;
        this._sanitizer = _sanitizer;
        this._errorHandler = _errorHandler;
        /**
         * URLs and cached SVG elements for individual icons. Keys are of the format "[namespace]:[icon]".
         */
        this._svgIconConfigs = new Map();
        /**
         * SvgIconConfig objects and cached SVG elements for icon sets, keyed by namespace.
         * Multiple icon sets can be registered under the same namespace.
         */
        this._iconSetConfigs = new Map();
        /**
         * Cache for icons loaded by direct URLs.
         */
        this._cachedIconsByUrl = new Map();
        /**
         * In-progress icon fetches. Used to coalesce multiple requests to the same URL.
         */
        this._inProgressUrlFetches = new Map();
        /**
         * Map from font identifiers to their CSS class names. Used for icon fonts.
         */
        this._fontCssClassesByAlias = new Map();
        /**
         * The CSS class to apply when an `<mat-icon>` component has no icon name, url, or font specified.
         * The default 'material-icons' value assumes that the material icon font has been loaded as
         * described at http://google.github.io/material-design-icons/#icon-font-for-the-web
         */
        this._defaultFontSetClass = 'material-icons';
        this._document = document;
    }
    /**
     * Registers an icon by URL in the default namespace.
     * @template THIS
     * @this {THIS}
     * @param {?} iconName Name under which the icon should be registered.
     * @param {?} url
     * @param {?=} options
     * @return {THIS}
     */
    addSvgIcon(iconName, url, options) {
        return (/** @type {?} */ (this)).addSvgIconInNamespace('', iconName, url, options);
    }
    /**
     * Registers an icon using an HTML string in the default namespace.
     * @template THIS
     * @this {THIS}
     * @param {?} iconName Name under which the icon should be registered.
     * @param {?} literal SVG source of the icon.
     * @param {?=} options
     * @return {THIS}
     */
    addSvgIconLiteral(iconName, literal, options) {
        return (/** @type {?} */ (this)).addSvgIconLiteralInNamespace('', iconName, literal, options);
    }
    /**
     * Registers an icon by URL in the specified namespace.
     * @template THIS
     * @this {THIS}
     * @param {?} namespace Namespace in which the icon should be registered.
     * @param {?} iconName Name under which the icon should be registered.
     * @param {?} url
     * @param {?=} options
     * @return {THIS}
     */
    addSvgIconInNamespace(namespace, iconName, url, options) {
        return (/** @type {?} */ (this))._addSvgIconConfig(namespace, iconName, new SvgIconConfig(url, options));
    }
    /**
     * Registers an icon using an HTML string in the specified namespace.
     * @template THIS
     * @this {THIS}
     * @param {?} namespace Namespace in which the icon should be registered.
     * @param {?} iconName Name under which the icon should be registered.
     * @param {?} literal SVG source of the icon.
     * @param {?=} options
     * @return {THIS}
     */
    addSvgIconLiteralInNamespace(namespace, iconName, literal, options) {
        /** @type {?} */
        const sanitizedLiteral = (/** @type {?} */ (this))._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_2__["SecurityContext"].HTML, literal);
        if (!sanitizedLiteral) {
            throw getMatIconFailedToSanitizeLiteralError(literal);
        }
        /** @type {?} */
        const svgElement = (/** @type {?} */ (this))._createSvgElementForSingleIcon(sanitizedLiteral, options);
        return (/** @type {?} */ (this))._addSvgIconConfig(namespace, iconName, new SvgIconConfig(svgElement, options));
    }
    /**
     * Registers an icon set by URL in the default namespace.
     * @template THIS
     * @this {THIS}
     * @param {?} url
     * @param {?=} options
     * @return {THIS}
     */
    addSvgIconSet(url, options) {
        return (/** @type {?} */ (this)).addSvgIconSetInNamespace('', url, options);
    }
    /**
     * Registers an icon set using an HTML string in the default namespace.
     * @template THIS
     * @this {THIS}
     * @param {?} literal SVG source of the icon set.
     * @param {?=} options
     * @return {THIS}
     */
    addSvgIconSetLiteral(literal, options) {
        return (/** @type {?} */ (this)).addSvgIconSetLiteralInNamespace('', literal, options);
    }
    /**
     * Registers an icon set by URL in the specified namespace.
     * @template THIS
     * @this {THIS}
     * @param {?} namespace Namespace in which to register the icon set.
     * @param {?} url
     * @param {?=} options
     * @return {THIS}
     */
    addSvgIconSetInNamespace(namespace, url, options) {
        return (/** @type {?} */ (this))._addSvgIconSetConfig(namespace, new SvgIconConfig(url, options));
    }
    /**
     * Registers an icon set using an HTML string in the specified namespace.
     * @template THIS
     * @this {THIS}
     * @param {?} namespace Namespace in which to register the icon set.
     * @param {?} literal SVG source of the icon set.
     * @param {?=} options
     * @return {THIS}
     */
    addSvgIconSetLiteralInNamespace(namespace, literal, options) {
        /** @type {?} */
        const sanitizedLiteral = (/** @type {?} */ (this))._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_2__["SecurityContext"].HTML, literal);
        if (!sanitizedLiteral) {
            throw getMatIconFailedToSanitizeLiteralError(literal);
        }
        /** @type {?} */
        const svgElement = (/** @type {?} */ (this))._svgElementFromString(sanitizedLiteral);
        return (/** @type {?} */ (this))._addSvgIconSetConfig(namespace, new SvgIconConfig(svgElement, options));
    }
    /**
     * Defines an alias for a CSS class name to be used for icon fonts. Creating an matIcon
     * component with the alias as the fontSet input will cause the class name to be applied
     * to the `<mat-icon>` element.
     *
     * @template THIS
     * @this {THIS}
     * @param {?} alias Alias for the font.
     * @param {?=} className Class name override to be used instead of the alias.
     * @return {THIS}
     */
    registerFontClassAlias(alias, className = alias) {
        (/** @type {?} */ (this))._fontCssClassesByAlias.set(alias, className);
        return (/** @type {?} */ (this));
    }
    /**
     * Returns the CSS class name associated with the alias by a previous call to
     * registerFontClassAlias. If no CSS class has been associated, returns the alias unmodified.
     * @param {?} alias
     * @return {?}
     */
    classNameForFontAlias(alias) {
        return this._fontCssClassesByAlias.get(alias) || alias;
    }
    /**
     * Sets the CSS class name to be used for icon fonts when an `<mat-icon>` component does not
     * have a fontSet input value, and is not loading an icon by name or URL.
     *
     * @template THIS
     * @this {THIS}
     * @param {?} className
     * @return {THIS}
     */
    setDefaultFontSetClass(className) {
        (/** @type {?} */ (this))._defaultFontSetClass = className;
        return (/** @type {?} */ (this));
    }
    /**
     * Returns the CSS class name to be used for icon fonts when an `<mat-icon>` component does not
     * have a fontSet input value, and is not loading an icon by name or URL.
     * @return {?}
     */
    getDefaultFontSetClass() {
        return this._defaultFontSetClass;
    }
    /**
     * Returns an Observable that produces the icon (as an `<svg>` DOM element) from the given URL.
     * The response from the URL may be cached so this will not always cause an HTTP request, but
     * the produced element will always be a new copy of the originally fetched icon. (That is,
     * it will not contain any modifications made to elements previously returned).
     *
     * @param {?} safeUrl URL from which to fetch the SVG icon.
     * @return {?}
     */
    getSvgIconFromUrl(safeUrl) {
        /** @type {?} */
        const url = this._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_2__["SecurityContext"].RESOURCE_URL, safeUrl);
        if (!url) {
            throw getMatIconFailedToSanitizeUrlError(safeUrl);
        }
        /** @type {?} */
        const cachedIcon = this._cachedIconsByUrl.get(url);
        if (cachedIcon) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(cloneSvg(cachedIcon));
        }
        return this._loadSvgIconFromConfig(new SvgIconConfig(safeUrl)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])((/**
         * @param {?} svg
         * @return {?}
         */
        svg => this._cachedIconsByUrl.set((/** @type {?} */ (url)), svg))), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((/**
         * @param {?} svg
         * @return {?}
         */
        svg => cloneSvg(svg))));
    }
    /**
     * Returns an Observable that produces the icon (as an `<svg>` DOM element) with the given name
     * and namespace. The icon must have been previously registered with addIcon or addIconSet;
     * if not, the Observable will throw an error.
     *
     * @param {?} name Name of the icon to be retrieved.
     * @param {?=} namespace Namespace in which to look for the icon.
     * @return {?}
     */
    getNamedSvgIcon(name, namespace = '') {
        // Return (copy of) cached icon if possible.
        /** @type {?} */
        const key = iconKey(namespace, name);
        /** @type {?} */
        const config = this._svgIconConfigs.get(key);
        if (config) {
            return this._getSvgFromConfig(config);
        }
        // See if we have any icon sets registered for the namespace.
        /** @type {?} */
        const iconSetConfigs = this._iconSetConfigs.get(namespace);
        if (iconSetConfigs) {
            return this._getSvgFromIconSetConfigs(name, iconSetConfigs);
        }
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(getMatIconNameNotFoundError(key));
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this._svgIconConfigs.clear();
        this._iconSetConfigs.clear();
        this._cachedIconsByUrl.clear();
    }
    /**
     * Returns the cached icon for a SvgIconConfig if available, or fetches it from its URL if not.
     * @private
     * @param {?} config
     * @return {?}
     */
    _getSvgFromConfig(config) {
        if (config.svgElement) {
            // We already have the SVG element for this icon, return a copy.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(cloneSvg(config.svgElement));
        }
        else {
            // Fetch the icon from the config's URL, cache it, and return a copy.
            return this._loadSvgIconFromConfig(config).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])((/**
             * @param {?} svg
             * @return {?}
             */
            svg => config.svgElement = svg)), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((/**
             * @param {?} svg
             * @return {?}
             */
            svg => cloneSvg(svg))));
        }
    }
    /**
     * Attempts to find an icon with the specified name in any of the SVG icon sets.
     * First searches the available cached icons for a nested element with a matching name, and
     * if found copies the element to a new `<svg>` element. If not found, fetches all icon sets
     * that have not been cached, and searches again after all fetches are completed.
     * The returned Observable produces the SVG element if possible, and throws
     * an error if no icon with the specified name can be found.
     * @private
     * @param {?} name
     * @param {?} iconSetConfigs
     * @return {?}
     */
    _getSvgFromIconSetConfigs(name, iconSetConfigs) {
        // For all the icon set SVG elements we've fetched, see if any contain an icon with the
        // requested name.
        /** @type {?} */
        const namedIcon = this._extractIconWithNameFromAnySet(name, iconSetConfigs);
        if (namedIcon) {
            // We could cache namedIcon in _svgIconConfigs, but since we have to make a copy every
            // time anyway, there's probably not much advantage compared to just always extracting
            // it from the icon set.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(namedIcon);
        }
        // Not found in any cached icon sets. If there are icon sets with URLs that we haven't
        // fetched, fetch them now and look for iconName in the results.
        /** @type {?} */
        const iconSetFetchRequests = iconSetConfigs
            .filter((/**
         * @param {?} iconSetConfig
         * @return {?}
         */
        iconSetConfig => !iconSetConfig.svgElement))
            .map((/**
         * @param {?} iconSetConfig
         * @return {?}
         */
        iconSetConfig => {
            return this._loadSvgIconSetFromConfig(iconSetConfig).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])((/**
             * @param {?} err
             * @return {?}
             */
            (err) => {
                /** @type {?} */
                const url = this._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_2__["SecurityContext"].RESOURCE_URL, iconSetConfig.url);
                // Swallow errors fetching individual URLs so the
                // combined Observable won't necessarily fail.
                /** @type {?} */
                const errorMessage = `Loading icon set URL: ${url} failed: ${err.message}`;
                // @breaking-change 9.0.0 _errorHandler parameter to be made required
                if (this._errorHandler) {
                    this._errorHandler.handleError(new Error(errorMessage));
                }
                else {
                    console.error(errorMessage);
                }
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(null);
            })));
        }));
        // Fetch all the icon set URLs. When the requests complete, every IconSet should have a
        // cached SVG element (unless the request failed), and we can check again for the icon.
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["forkJoin"])(iconSetFetchRequests).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const foundIcon = this._extractIconWithNameFromAnySet(name, iconSetConfigs);
            if (!foundIcon) {
                throw getMatIconNameNotFoundError(name);
            }
            return foundIcon;
        })));
    }
    /**
     * Searches the cached SVG elements for the given icon sets for a nested icon element whose "id"
     * tag matches the specified name. If found, copies the nested element to a new SVG element and
     * returns it. Returns null if no matching element is found.
     * @private
     * @param {?} iconName
     * @param {?} iconSetConfigs
     * @return {?}
     */
    _extractIconWithNameFromAnySet(iconName, iconSetConfigs) {
        // Iterate backwards, so icon sets added later have precedence.
        for (let i = iconSetConfigs.length - 1; i >= 0; i--) {
            /** @type {?} */
            const config = iconSetConfigs[i];
            if (config.svgElement) {
                /** @type {?} */
                const foundIcon = this._extractSvgIconFromSet(config.svgElement, iconName, config.options);
                if (foundIcon) {
                    return foundIcon;
                }
            }
        }
        return null;
    }
    /**
     * Loads the content of the icon URL specified in the SvgIconConfig and creates an SVG element
     * from it.
     * @private
     * @param {?} config
     * @return {?}
     */
    _loadSvgIconFromConfig(config) {
        return this._fetchUrl(config.url)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((/**
         * @param {?} svgText
         * @return {?}
         */
        svgText => this._createSvgElementForSingleIcon(svgText, config.options))));
    }
    /**
     * Loads the content of the icon set URL specified in the SvgIconConfig and creates an SVG element
     * from it.
     * @private
     * @param {?} config
     * @return {?}
     */
    _loadSvgIconSetFromConfig(config) {
        // If the SVG for this icon set has already been parsed, do nothing.
        if (config.svgElement) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(config.svgElement);
        }
        return this._fetchUrl(config.url).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((/**
         * @param {?} svgText
         * @return {?}
         */
        svgText => {
            // It is possible that the icon set was parsed and cached by an earlier request, so parsing
            // only needs to occur if the cache is yet unset.
            if (!config.svgElement) {
                config.svgElement = this._svgElementFromString(svgText);
            }
            return config.svgElement;
        })));
    }
    /**
     * Creates a DOM element from the given SVG string, and adds default attributes.
     * @private
     * @param {?} responseText
     * @param {?=} options
     * @return {?}
     */
    _createSvgElementForSingleIcon(responseText, options) {
        /** @type {?} */
        const svg = this._svgElementFromString(responseText);
        this._setSvgAttributes(svg, options);
        return svg;
    }
    /**
     * Searches the cached element of the given SvgIconConfig for a nested icon element whose "id"
     * tag matches the specified name. If found, copies the nested element to a new SVG element and
     * returns it. Returns null if no matching element is found.
     * @private
     * @param {?} iconSet
     * @param {?} iconName
     * @param {?=} options
     * @return {?}
     */
    _extractSvgIconFromSet(iconSet, iconName, options) {
        // Use the `id="iconName"` syntax in order to escape special
        // characters in the ID (versus using the #iconName syntax).
        /** @type {?} */
        const iconSource = iconSet.querySelector(`[id="${iconName}"]`);
        if (!iconSource) {
            return null;
        }
        // Clone the element and remove the ID to prevent multiple elements from being added
        // to the page with the same ID.
        /** @type {?} */
        const iconElement = (/** @type {?} */ (iconSource.cloneNode(true)));
        iconElement.removeAttribute('id');
        // If the icon node is itself an <svg> node, clone and return it directly. If not, set it as
        // the content of a new <svg> node.
        if (iconElement.nodeName.toLowerCase() === 'svg') {
            return this._setSvgAttributes((/** @type {?} */ (iconElement)), options);
        }
        // If the node is a <symbol>, it won't be rendered so we have to convert it into <svg>. Note
        // that the same could be achieved by referring to it via <use href="#id">, however the <use>
        // tag is problematic on Firefox, because it needs to include the current page path.
        if (iconElement.nodeName.toLowerCase() === 'symbol') {
            return this._setSvgAttributes(this._toSvgElement(iconElement), options);
        }
        // createElement('SVG') doesn't work as expected; the DOM ends up with
        // the correct nodes, but the SVG content doesn't render. Instead we
        // have to create an empty SVG node using innerHTML and append its content.
        // Elements created using DOMParser.parseFromString have the same problem.
        // http://stackoverflow.com/questions/23003278/svg-innerhtml-in-firefox-can-not-display
        /** @type {?} */
        const svg = this._svgElementFromString('<svg></svg>');
        // Clone the node so we don't remove it from the parent icon set element.
        svg.appendChild(iconElement);
        return this._setSvgAttributes(svg, options);
    }
    /**
     * Creates a DOM element from the given SVG string.
     * @private
     * @param {?} str
     * @return {?}
     */
    _svgElementFromString(str) {
        /** @type {?} */
        const div = this._document.createElement('DIV');
        div.innerHTML = str;
        /** @type {?} */
        const svg = (/** @type {?} */ (div.querySelector('svg')));
        if (!svg) {
            throw Error('<svg> tag not found');
        }
        return svg;
    }
    /**
     * Converts an element into an SVG node by cloning all of its children.
     * @private
     * @param {?} element
     * @return {?}
     */
    _toSvgElement(element) {
        /** @type {?} */
        const svg = this._svgElementFromString('<svg></svg>');
        /** @type {?} */
        const attributes = element.attributes;
        // Copy over all the attributes from the `symbol` to the new SVG, except the id.
        for (let i = 0; i < attributes.length; i++) {
            const { name, value } = attributes[i];
            if (name !== 'id') {
                svg.setAttribute(name, value);
            }
        }
        for (let i = 0; i < element.childNodes.length; i++) {
            if (element.childNodes[i].nodeType === this._document.ELEMENT_NODE) {
                svg.appendChild(element.childNodes[i].cloneNode(true));
            }
        }
        return svg;
    }
    /**
     * Sets the default attributes for an SVG element to be used as an icon.
     * @private
     * @param {?} svg
     * @param {?=} options
     * @return {?}
     */
    _setSvgAttributes(svg, options) {
        svg.setAttribute('fit', '');
        svg.setAttribute('height', '100%');
        svg.setAttribute('width', '100%');
        svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
        svg.setAttribute('focusable', 'false'); // Disable IE11 default behavior to make SVGs focusable.
        if (options && options.viewBox) {
            svg.setAttribute('viewBox', options.viewBox);
        }
        return svg;
    }
    /**
     * Returns an Observable which produces the string contents of the given URL. Results may be
     * cached, so future calls with the same URL may not cause another HTTP request.
     * @private
     * @param {?} safeUrl
     * @return {?}
     */
    _fetchUrl(safeUrl) {
        if (!this._httpClient) {
            throw getMatIconNoHttpProviderError();
        }
        if (safeUrl == null) {
            throw Error(`Cannot fetch icon from URL "${safeUrl}".`);
        }
        /** @type {?} */
        const url = this._sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_2__["SecurityContext"].RESOURCE_URL, safeUrl);
        if (!url) {
            throw getMatIconFailedToSanitizeUrlError(safeUrl);
        }
        // Store in-progress fetches to avoid sending a duplicate request for a URL when there is
        // already a request in progress for that URL. It's necessary to call share() on the
        // Observable returned by http.get() so that multiple subscribers don't cause multiple XHRs.
        /** @type {?} */
        const inProgressFetch = this._inProgressUrlFetches.get(url);
        if (inProgressFetch) {
            return inProgressFetch;
        }
        // TODO(jelbourn): for some reason, the `finalize` operator "loses" the generic type on the
        // Observable. Figure out why and fix it.
        /** @type {?} */
        const req = this._httpClient.get(url, { responseType: 'text' }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])((/**
         * @return {?}
         */
        () => this._inProgressUrlFetches.delete(url))), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["share"])());
        this._inProgressUrlFetches.set(url, req);
        return req;
    }
    /**
     * Registers an icon config by name in the specified namespace.
     * @private
     * @template THIS
     * @this {THIS}
     * @param {?} namespace Namespace in which to register the icon config.
     * @param {?} iconName Name under which to register the config.
     * @param {?} config Config to be registered.
     * @return {THIS}
     */
    _addSvgIconConfig(namespace, iconName, config) {
        (/** @type {?} */ (this))._svgIconConfigs.set(iconKey(namespace, iconName), config);
        return (/** @type {?} */ (this));
    }
    /**
     * Registers an icon set config in the specified namespace.
     * @private
     * @template THIS
     * @this {THIS}
     * @param {?} namespace Namespace in which to register the icon config.
     * @param {?} config Config to be registered.
     * @return {THIS}
     */
    _addSvgIconSetConfig(namespace, config) {
        /** @type {?} */
        const configNamespace = (/** @type {?} */ (this))._iconSetConfigs.get(namespace);
        if (configNamespace) {
            configNamespace.push(config);
        }
        else {
            (/** @type {?} */ (this))._iconSetConfigs.set(namespace, [config]);
        }
        return (/** @type {?} */ (this));
    }
}
MatIconRegistry.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"], args: [{ providedIn: 'root' },] },
];
/** @nocollapse */
MatIconRegistry.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"] }] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"], args: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["DOCUMENT"],] }] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ErrorHandler"], decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"] }] }
];
/** @nocollapse */ MatIconRegistry.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"])({ factory: function MatIconRegistry_Factory() { return new MatIconRegistry(Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"])(_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], 8), Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"])(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"])(_angular_common__WEBPACK_IMPORTED_MODULE_0__["DOCUMENT"], 8), Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ErrorHandler"], 8)); }, token: MatIconRegistry, providedIn: "root" });
/**
 * \@docs-private
 * @param {?} parentRegistry
 * @param {?} httpClient
 * @param {?} sanitizer
 * @param {?=} document
 * @param {?=} errorHandler
 * @return {?}
 */
function ICON_REGISTRY_PROVIDER_FACTORY(parentRegistry, httpClient, sanitizer, document, errorHandler) {
    return parentRegistry || new MatIconRegistry(httpClient, sanitizer, document, errorHandler);
}
/**
 * \@docs-private
 * @type {?}
 */
const ICON_REGISTRY_PROVIDER = {
    // If there is already an MatIconRegistry available, use that. Otherwise, provide a new one.
    provide: MatIconRegistry,
    deps: [
        [new _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"](), new _angular_core__WEBPACK_IMPORTED_MODULE_2__["SkipSelf"](), MatIconRegistry],
        [new _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"](), _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]],
        _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"],
        [new _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"](), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ErrorHandler"]],
        [new _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"](), (/** @type {?} */ (_angular_common__WEBPACK_IMPORTED_MODULE_0__["DOCUMENT"]))],
    ],
    useFactory: ICON_REGISTRY_PROVIDER_FACTORY,
};
/**
 * Clones an SVGElement while preserving type information.
 * @param {?} svg
 * @return {?}
 */
function cloneSvg(svg) {
    return (/** @type {?} */ (svg.cloneNode(true)));
}
/**
 * Returns the cache key to use for an icon namespace and name.
 * @param {?} namespace
 * @param {?} name
 * @return {?}
 */
function iconKey(namespace, name) {
    return namespace + ':' + name;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// Boilerplate for applying mixins to MatIcon.
/**
 * \@docs-private
 */
class MatIconBase {
    /**
     * @param {?} _elementRef
     */
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
}
/** @type {?} */
const _MatIconMixinBase = Object(_angular_material_core__WEBPACK_IMPORTED_MODULE_7__["mixinColor"])(MatIconBase);
/**
 * Injection token used to provide the current location to `MatIcon`.
 * Used to handle server-side rendering and to stub out during unit tests.
 * \@docs-private
 * @type {?}
 */
const MAT_ICON_LOCATION = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["InjectionToken"]('mat-icon-location', {
    providedIn: 'root',
    factory: MAT_ICON_LOCATION_FACTORY
});
/**
 * \@docs-private
 * @return {?}
 */
function MAT_ICON_LOCATION_FACTORY() {
    /** @type {?} */
    const _document = Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_0__["DOCUMENT"]);
    /** @type {?} */
    const _location = _document ? _document.location : null;
    return {
        // Note that this needs to be a function, rather than a property, because Angular
        // will only resolve it once, but we want the current path on each call.
        getPathname: (/**
         * @return {?}
         */
        () => _location ? (_location.pathname + _location.search) : '')
    };
}
/**
 * SVG attributes that accept a FuncIRI (e.g. `url(<something>)`).
 * @type {?}
 */
const funcIriAttributes = [
    'clip-path',
    'color-profile',
    'src',
    'cursor',
    'fill',
    'filter',
    'marker',
    'marker-start',
    'marker-mid',
    'marker-end',
    'mask',
    'stroke'
];
const ɵ0 = /**
 * @param {?} attr
 * @return {?}
 */
attr => `[${attr}]`;
/**
 * Selector that can be used to find all elements that are using a `FuncIRI`.
 * @type {?}
 */
const funcIriAttributeSelector = funcIriAttributes.map((ɵ0)).join(', ');
/**
 * Regex that can be used to extract the id out of a FuncIRI.
 * @type {?}
 */
const funcIriPattern = /^url\(['"]?#(.*?)['"]?\)$/;
/**
 * Component to display an icon. It can be used in the following ways:
 *
 * - Specify the svgIcon input to load an SVG icon from a URL previously registered with the
 *   addSvgIcon, addSvgIconInNamespace, addSvgIconSet, or addSvgIconSetInNamespace methods of
 *   MatIconRegistry. If the svgIcon value contains a colon it is assumed to be in the format
 *   "[namespace]:[name]", if not the value will be the name of an icon in the default namespace.
 *   Examples:
 *     `<mat-icon svgIcon="left-arrow"></mat-icon>
 *     <mat-icon svgIcon="animals:cat"></mat-icon>`
 *
 * - Use a font ligature as an icon by putting the ligature text in the content of the `<mat-icon>`
 *   component. By default the Material icons font is used as described at
 *   http://google.github.io/material-design-icons/#icon-font-for-the-web. You can specify an
 *   alternate font by setting the fontSet input to either the CSS class to apply to use the
 *   desired font, or to an alias previously registered with MatIconRegistry.registerFontClassAlias.
 *   Examples:
 *     `<mat-icon>home</mat-icon>
 *     <mat-icon fontSet="myfont">sun</mat-icon>`
 *
 * - Specify a font glyph to be included via CSS rules by setting the fontSet input to specify the
 *   font, and the fontIcon input to specify the icon. Typically the fontIcon will specify a
 *   CSS class which causes the glyph to be displayed via a :before selector, as in
 *   https://fortawesome.github.io/Font-Awesome/examples/
 *   Example:
 *     `<mat-icon fontSet="fa" fontIcon="alarm"></mat-icon>`
 */
class MatIcon extends _MatIconMixinBase {
    /**
     * @param {?} elementRef
     * @param {?} _iconRegistry
     * @param {?} ariaHidden
     * @param {?=} _location
     * @param {?=} _errorHandler
     */
    constructor(elementRef, _iconRegistry, ariaHidden, _location, _errorHandler) {
        super(elementRef);
        this._iconRegistry = _iconRegistry;
        this._location = _location;
        this._errorHandler = _errorHandler;
        this._inline = false;
        // If the user has not explicitly set aria-hidden, mark the icon as hidden, as this is
        // the right thing to do for the majority of icon use-cases.
        if (!ariaHidden) {
            elementRef.nativeElement.setAttribute('aria-hidden', 'true');
        }
    }
    /**
     * Whether the icon should be inlined, automatically sizing the icon to match the font size of
     * the element the icon is contained in.
     * @return {?}
     */
    get inline() {
        return this._inline;
    }
    /**
     * @param {?} inline
     * @return {?}
     */
    set inline(inline) {
        this._inline = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_6__["coerceBooleanProperty"])(inline);
    }
    /**
     * Font set that the icon is a part of.
     * @return {?}
     */
    get fontSet() { return this._fontSet; }
    /**
     * @param {?} value
     * @return {?}
     */
    set fontSet(value) {
        this._fontSet = this._cleanupFontValue(value);
    }
    /**
     * Name of an icon within a font set.
     * @return {?}
     */
    get fontIcon() { return this._fontIcon; }
    /**
     * @param {?} value
     * @return {?}
     */
    set fontIcon(value) {
        this._fontIcon = this._cleanupFontValue(value);
    }
    /**
     * Splits an svgIcon binding value into its icon set and icon name components.
     * Returns a 2-element array of [(icon set), (icon name)].
     * The separator for the two fields is ':'. If there is no separator, an empty
     * string is returned for the icon set and the entire value is returned for
     * the icon name. If the argument is falsy, returns an array of two empty strings.
     * Throws an error if the name contains two or more ':' separators.
     * Examples:
     *   `'social:cake' -> ['social', 'cake']
     *   'penguin' -> ['', 'penguin']
     *   null -> ['', '']
     *   'a:b:c' -> (throws Error)`
     * @private
     * @param {?} iconName
     * @return {?}
     */
    _splitIconName(iconName) {
        if (!iconName) {
            return ['', ''];
        }
        /** @type {?} */
        const parts = iconName.split(':');
        switch (parts.length) {
            case 1: return ['', parts[0]]; // Use default namespace.
            case 2: return (/** @type {?} */ (parts));
            default: throw Error(`Invalid icon name: "${iconName}"`);
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        // Only update the inline SVG icon if the inputs changed, to avoid unnecessary DOM operations.
        /** @type {?} */
        const svgIconChanges = changes['svgIcon'];
        if (svgIconChanges) {
            if (this.svgIcon) {
                const [namespace, iconName] = this._splitIconName(this.svgIcon);
                this._iconRegistry.getNamedSvgIcon(iconName, namespace)
                    .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1))
                    .subscribe((/**
                 * @param {?} svg
                 * @return {?}
                 */
                svg => this._setSvgElement(svg)), (/**
                 * @param {?} err
                 * @return {?}
                 */
                (err) => {
                    /** @type {?} */
                    const errorMessage = `Error retrieving icon ${namespace}:${iconName}! ${err.message}`;
                    // @breaking-change 9.0.0 _errorHandler parameter to be made required.
                    if (this._errorHandler) {
                        this._errorHandler.handleError(new Error(errorMessage));
                    }
                    else {
                        console.error(errorMessage);
                    }
                }));
            }
            else if (svgIconChanges.previousValue) {
                this._clearSvgElement();
            }
        }
        if (this._usingFontIcon()) {
            this._updateFontIconClasses();
        }
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        // Update font classes because ngOnChanges won't be called if none of the inputs are present,
        // e.g. <mat-icon>arrow</mat-icon> In this case we need to add a CSS class for the default font.
        if (this._usingFontIcon()) {
            this._updateFontIconClasses();
        }
    }
    /**
     * @return {?}
     */
    ngAfterViewChecked() {
        /** @type {?} */
        const cachedElements = this._elementsWithExternalReferences;
        if (cachedElements && this._location && cachedElements.size) {
            /** @type {?} */
            const newPath = this._location.getPathname();
            // We need to check whether the URL has changed on each change detection since
            // the browser doesn't have an API that will let us react on link clicks and
            // we can't depend on the Angular router. The references need to be updated,
            // because while most browsers don't care whether the URL is correct after
            // the first render, Safari will break if the user navigates to a different
            // page and the SVG isn't re-rendered.
            if (newPath !== this._previousPath) {
                this._previousPath = newPath;
                this._prependPathToReferences(newPath);
            }
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this._elementsWithExternalReferences) {
            this._elementsWithExternalReferences.clear();
        }
    }
    /**
     * @private
     * @return {?}
     */
    _usingFontIcon() {
        return !this.svgIcon;
    }
    /**
     * @private
     * @param {?} svg
     * @return {?}
     */
    _setSvgElement(svg) {
        this._clearSvgElement();
        // Workaround for IE11 and Edge ignoring `style` tags inside dynamically-created SVGs.
        // See: https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/10898469/
        // Do this before inserting the element into the DOM, in order to avoid a style recalculation.
        /** @type {?} */
        const styleTags = (/** @type {?} */ (svg.querySelectorAll('style')));
        for (let i = 0; i < styleTags.length; i++) {
            styleTags[i].textContent += ' ';
        }
        // Note: we do this fix here, rather than the icon registry, because the
        // references have to point to the URL at the time that the icon was created.
        if (this._location) {
            /** @type {?} */
            const path = this._location.getPathname();
            this._previousPath = path;
            this._cacheChildrenWithExternalReferences(svg);
            this._prependPathToReferences(path);
        }
        this._elementRef.nativeElement.appendChild(svg);
    }
    /**
     * @private
     * @return {?}
     */
    _clearSvgElement() {
        /** @type {?} */
        const layoutElement = this._elementRef.nativeElement;
        /** @type {?} */
        let childCount = layoutElement.childNodes.length;
        if (this._elementsWithExternalReferences) {
            this._elementsWithExternalReferences.clear();
        }
        // Remove existing non-element child nodes and SVGs, and add the new SVG element. Note that
        // we can't use innerHTML, because IE will throw if the element has a data binding.
        while (childCount--) {
            /** @type {?} */
            const child = layoutElement.childNodes[childCount];
            // 1 corresponds to Node.ELEMENT_NODE. We remove all non-element nodes in order to get rid
            // of any loose text nodes, as well as any SVG elements in order to remove any old icons.
            if (child.nodeType !== 1 || child.nodeName.toLowerCase() === 'svg') {
                layoutElement.removeChild(child);
            }
        }
    }
    /**
     * @private
     * @return {?}
     */
    _updateFontIconClasses() {
        if (!this._usingFontIcon()) {
            return;
        }
        /** @type {?} */
        const elem = this._elementRef.nativeElement;
        /** @type {?} */
        const fontSetClass = this.fontSet ?
            this._iconRegistry.classNameForFontAlias(this.fontSet) :
            this._iconRegistry.getDefaultFontSetClass();
        if (fontSetClass != this._previousFontSetClass) {
            if (this._previousFontSetClass) {
                elem.classList.remove(this._previousFontSetClass);
            }
            if (fontSetClass) {
                elem.classList.add(fontSetClass);
            }
            this._previousFontSetClass = fontSetClass;
        }
        if (this.fontIcon != this._previousFontIconClass) {
            if (this._previousFontIconClass) {
                elem.classList.remove(this._previousFontIconClass);
            }
            if (this.fontIcon) {
                elem.classList.add(this.fontIcon);
            }
            this._previousFontIconClass = this.fontIcon;
        }
    }
    /**
     * Cleans up a value to be used as a fontIcon or fontSet.
     * Since the value ends up being assigned as a CSS class, we
     * have to trim the value and omit space-separated values.
     * @private
     * @param {?} value
     * @return {?}
     */
    _cleanupFontValue(value) {
        return typeof value === 'string' ? value.trim().split(' ')[0] : value;
    }
    /**
     * Prepends the current path to all elements that have an attribute pointing to a `FuncIRI`
     * reference. This is required because WebKit browsers require references to be prefixed with
     * the current path, if the page has a `base` tag.
     * @private
     * @param {?} path
     * @return {?}
     */
    _prependPathToReferences(path) {
        /** @type {?} */
        const elements = this._elementsWithExternalReferences;
        if (elements) {
            elements.forEach((/**
             * @param {?} attrs
             * @param {?} element
             * @return {?}
             */
            (attrs, element) => {
                attrs.forEach((/**
                 * @param {?} attr
                 * @return {?}
                 */
                attr => {
                    element.setAttribute(attr.name, `url('${path}#${attr.value}')`);
                }));
            }));
        }
    }
    /**
     * Caches the children of an SVG element that have `url()`
     * references that we need to prefix with the current path.
     * @private
     * @param {?} element
     * @return {?}
     */
    _cacheChildrenWithExternalReferences(element) {
        /** @type {?} */
        const elementsWithFuncIri = element.querySelectorAll(funcIriAttributeSelector);
        /** @type {?} */
        const elements = this._elementsWithExternalReferences =
            this._elementsWithExternalReferences || new Map();
        for (let i = 0; i < elementsWithFuncIri.length; i++) {
            funcIriAttributes.forEach((/**
             * @param {?} attr
             * @return {?}
             */
            attr => {
                /** @type {?} */
                const elementWithReference = elementsWithFuncIri[i];
                /** @type {?} */
                const value = elementWithReference.getAttribute(attr);
                /** @type {?} */
                const match = value ? value.match(funcIriPattern) : null;
                if (match) {
                    /** @type {?} */
                    let attributes = elements.get(elementWithReference);
                    if (!attributes) {
                        attributes = [];
                        elements.set(elementWithReference, attributes);
                    }
                    (/** @type {?} */ (attributes)).push({ name: attr, value: match[1] });
                }
            }));
        }
    }
}
MatIcon.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"], args: [{template: '<ng-content></ng-content>',
                selector: 'mat-icon',
                exportAs: 'matIcon',
                styles: [".mat-icon{background-repeat:no-repeat;display:inline-block;fill:currentColor;height:24px;width:24px}.mat-icon.mat-icon-inline{font-size:inherit;height:inherit;line-height:inherit;width:inherit}[dir=rtl] .mat-icon-rtl-mirror{transform:scale(-1,1)}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon{display:block}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon-button .mat-icon,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon-button .mat-icon{margin:auto}"],
                inputs: ['color'],
                host: {
                    'role': 'img',
                    'class': 'mat-icon notranslate',
                    '[class.mat-icon-inline]': 'inline',
                    '[class.mat-icon-no-color]': 'color !== "primary" && color !== "accent" && color !== "warn"',
                },
                encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewEncapsulation"].None,
                changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ChangeDetectionStrategy"].OnPush,
            },] },
];
/** @nocollapse */
MatIcon.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"] },
    { type: MatIconRegistry },
    { type: String, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Attribute"], args: ['aria-hidden',] }] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"], args: [MAT_ICON_LOCATION,] }] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ErrorHandler"], decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Optional"] }] }
];
MatIcon.propDecorators = {
    inline: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }],
    svgIcon: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }],
    fontSet: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }],
    fontIcon: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class MatIconModule {
}
MatIconModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"], args: [{
                imports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_7__["MatCommonModule"]],
                exports: [MatIcon, _angular_material_core__WEBPACK_IMPORTED_MODULE_7__["MatCommonModule"]],
                declarations: [MatIcon],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */


//# sourceMappingURL=icon.js.map


/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/procedures/dynamic-form/dynamic-form-item/dynamic-form-item.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/procedures/dynamic-form/dynamic-form-item/dynamic-form-item.component.html ***!
  \**********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [ngSwitch]=\"stepInput.tipo\">\r\n  <div *ngSwitchCase=\"'READONLY'\">\r\n    <ion-item>\r\n      <ion-label position=\"floating\">{{stepInput.name}}\r\n        <ion-text color=\"danger\" *ngIf=\"stepInput.required && !stepInput.dataValue\">*</ion-text>\r\n      </ion-label>\r\n      <ion-input required type=\"text\" [placeholder]='stepInput.name' readonly fill=\"outline\"\r\n        [value]='stepInput.dataValue' [(ngModel)]=\"stepInput.dataValue\"></ion-input>\r\n    </ion-item>\r\n  </div>\r\n  <div *ngSwitchCase=\"'DATETIME'\">\r\n    <mat-form-field class=\"matDate\" appearance=\"outline\">\r\n      <mat-label>Fecha de nacimiento:</mat-label>\r\n      <input matInput [matDatepicker]=\"picker\" [(ngModel)]=\"stepInput.dataValue\">\r\n      <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n      <mat-datepicker #picker></mat-datepicker>\r\n    </mat-form-field>\r\n  </div>\r\n  <div *ngSwitchCase=\"'STRING'\">\r\n    <ion-item>\r\n      <ion-label position=\"floating\">{{stepInput.name}}\r\n        <ion-text color=\"danger\" *ngIf=\"stepInput.required && !stepInput.dataValue\">*</ion-text>\r\n      </ion-label>\r\n      <ion-input required type=\"text\" [placeholder]='stepInput.name' [value]='stepInput.dataValue'\r\n        [(ngModel)]=\"stepInput.dataValue\" clearInput fill=\"outline\">\r\n      </ion-input>\r\n    </ion-item>\r\n  </div>\r\n  <div *ngSwitchCase=\"'TEXTAREA'\">\r\n    <ion-item>\r\n      <ion-label position=\"floating\">{{stepInput.name}}\r\n        <ion-text color=\"danger\" *ngIf=\"stepInput.required && !stepInput.dataValue\">*</ion-text>\r\n      </ion-label>\r\n      <ion-textarea required type=\"text\" rows=\"6\" cols=\"20\" [placeholder]='stepInput.name' [value]='stepInput.dataValue'\r\n        [(ngModel)]=\"stepInput.dataValue\"  maxLength=\"2000\"   fill=\"outline\">\r\n      </ion-textarea>\r\n    </ion-item>\r\n  </div>\r\n  <div *ngSwitchCase=\"'CUIL/CUIT'\">\r\n    <ion-item>\r\n      <ion-label position=\"stacked\">{{stepInput.name}}\r\n        <ion-text color=\"danger\" *ngIf=\"stepInput.required && !stepInput.dataValue\">*</ion-text>\r\n      </ion-label>\r\n      <ion-input type=\"text\" maxlength=\"11\" [placeholder]='stepInput.name' [value]='stepInput.dataValue'\r\n        [(ngModel)]=\"stepInput.dataValue\" clearInput fill=\"outline\">\r\n      </ion-input>\r\n    </ion-item>\r\n  </div>\r\n  <div *ngSwitchCase=\"'LIST'\">\r\n    <ion-list>\r\n      <ion-item>\r\n        <ion-label position=\"floating\">{{stepInput.name}}\r\n          <ion-text color=\"danger\" *ngIf=\"stepInput.required && !stepInput.dataValue\">*</ion-text>\r\n        </ion-label>\r\n        <ion-select okText=\"Aceptar\" cancelText=\"Cancelar\" [(ngModel)]=\"stepInput.dataValue\">\r\n          <ion-select-option *ngFor=\"let item of stepInput?.proceduretypeAttrAttrList\" [value]='item.valor'>\r\n            {{item.proceduretypeAttrList?.valor}}\r\n          </ion-select-option>\r\n        </ion-select>\r\n      </ion-item>\r\n    </ion-list>\r\n  </div>\r\n  <div *ngSwitchCase=\"'CHECKBOX'\">\r\n    <ion-item>\r\n      <ion-label>{{stepInput.name}} </ion-label>\r\n      <ion-toggle [(ngModel)]=\"stepInput.dataValue\" (ngModelChange)='checkboxChange(stepInput)'></ion-toggle>\r\n    </ion-item>\r\n  </div>\r\n  <div *ngSwitchCase=\"'FILE'\" class='file-container'>\r\n    <label>{{stepInput.name}}\r\n      <span style='color: red;' *ngIf=\"stepInput.required && !stepInput.dataValue\">*</span>\r\n    </label>\r\n    <input type='file' (change)='setFilesEmitter($event)' [id]='stepInput.id' [(ngModel)]=\"stepInput.dataValue\">\r\n  </div>\r\n  <div *ngSwitchCase=\"'SEARCH_PERSON'\">\r\n    <search-person (person)='personSearchFn($event)'></search-person>\r\n  </div>\r\n  <div *ngSwitchCase=\"'VALIDATION_CODE'\">\r\n    <ion-label position=\"floating\">\r\n      Te enviaremos un código por SMS, presiona el botón para obtenerlo.\r\n    </ion-label>\r\n    <div class='align-btn-validationCode'>\r\n      <div>\r\n        <ion-input maxlength='15' type=\"tel\" fill=\"outline\" placeholder='Número de teléfono' inputmode='number'\r\n          clearInput [(ngModel)]=\"phoneNumber\">\r\n        </ion-input>\r\n      </div>\r\n      <ion-button shape=\"round\" (click)='getCode()'>Obtener Código</ion-button>\r\n    </div>\r\n    <ion-row>\r\n      <ion-col size=\"12\">\r\n        <div class='align-btn-validationCode'>\r\n          <div>\r\n            <ion-input maxlength='4' type=\"tel\" fill=\"outline\" placeholder='Insertar código de validación'\r\n              inputmode='number' clearInput [(ngModel)]=\"stepInput.dataValue\">\r\n            </ion-input>\r\n          </div>\r\n        </div>\r\n      </ion-col>\r\n    </ion-row>\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/procedures/dynamic-form/dynamic-form.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/procedures/dynamic-form/dynamic-form.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" (click)='goToBack()' text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>NUEVO TRÁMITE</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n  <div class=\"stepwizard col-md-offset-3\">\r\n    <div class=\"stepwizard-row setup-panel\">\r\n      <div class=\"stepwizard-step\" *ngFor=\"let step of steps; let i = index;\">\r\n        <ion-badge [ngClass]=\"{'active-step': i === currentPage}\">{{i + 1}}</ion-badge>\r\n        <p *ngIf=\"i === currentPage\">{{step.title}}</p>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div *ngIf=\"groupsModel && groupsModel.quantityOfGroups && groupsModel.quantityOfGroups.length <=0; else group\">\r\n    <div *ngFor=\"let item of currentsAttrs;let i = index\">\r\n      <dynamic-form-item [stepInput]='item' (personResult)='personResultFn($event, null)' (genericEmitter)='emitterFn($event)'\r\n        (addPersonEmitter)='addPersonEmitterFn()' (sendFilesEmitter)='setFilesFn($event)'>\r\n      </dynamic-form-item>\r\n    </div>\r\n    <div *ngIf=\"filesStep && filesStep.length > 0\">\r\n      <div *ngFor=\"let file of filesStep\">\r\n        <div *ngIf=\"file.step == currentStep.step\" class='container-files' (click)='deleteFile(file.id, file.step)'>\r\n          <span>\r\n            {{file.label}}\r\n          </span>\r\n          <span>\r\n            <ion-icon ios=\"close-circle\" md=\"close-circle\"></ion-icon>\r\n          </span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <ng-template #group>\r\n    <div>\r\n      <mat-accordion>\r\n        <mat-expansion-panel class=\"accordion\" *ngFor=\"let item of quantityGroupsLocal;let i = index\">\r\n          <mat-expansion-panel-header class=\"accordionHeader\" (click)='addProcedureAttrs(i)'>\r\n            <mat-panel-title>\r\n              <div class='d-flex'>\r\n                <b class=\"accordionTitle\">{{groupsModel.nameGroup}} {{i+1}}</b>\r\n                <ion-col size=\"1\" size-xs (click)='deleteGroup(i, \"Debe agregar por lo menos una persona.\")'>\r\n                  <ion-icon ios=\"close-circle\" md=\"close-circle\"></ion-icon>\r\n                </ion-col>\r\n              </div>\r\n            </mat-panel-title>\r\n          </mat-expansion-panel-header>\r\n          <div *ngFor=\"let item of currentsAttrs | attrGroupFilter: i\">\r\n            <dynamic-form-item [stepInput]='item' (personResult)='personResultFn($event, i)'\r\n              (genericEmitter)='emitterFn($event)' (addPersonEmitter)='addPersonEmitterFn()'>\r\n            </dynamic-form-item>\r\n          </div>\r\n        </mat-expansion-panel>\r\n      </mat-accordion>\r\n      <ion-col size=\"12\">\r\n        <ion-button (click)=\"addNewGroup('Persona')\" expand=\"block\" fill=\"solid\" shape=\"round\">\r\n          Agregar nueva persona\r\n        </ion-button>\r\n      </ion-col>\r\n    </div>\r\n  </ng-template>\r\n  <ion-row class='container-btn-clean'>\r\n    <ion-col size=\"4\">\r\n      <ion-button (click)='cleanCurrentAttr()' expand=\"block\" fill=\"solid\" shape=\"round\">\r\n        Limpiar\r\n      </ion-button>\r\n    </ion-col>\r\n  </ion-row>\r\n  <ion-row class='previousAndNextPageContainer'>\r\n    <ion-col size=\"4\">\r\n      <ion-button (click)=\"goToBackStep()\" [disabled]='currentPage === 0' expand=\"block\" fill=\"solid\" shape=\"round\">\r\n        Atrás\r\n      </ion-button>\r\n    </ion-col>\r\n    <ion-col size=\"4\">\r\n      <ion-button (click)=\"currentPage === form.procedureSteps.length - 1 ? sendForm() : goToNextStep()\" expand=\"block\"\r\n        fill=\"solid\" shape=\"round\">\r\n        {{currentPage === form.procedureSteps.length - 1 ? 'Enviar' : 'Siguiente'}}\r\n      </ion-button>\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-content>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/shared/search-person/search-person.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shared/search-person/search-person.component.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <ion-row>\r\n    <ion-col size=\"10\">\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Número de documento</ion-label>\r\n        <ion-input type=\"number\" [(ngModel)]=\"docNumber\" fill=\"outline\">\r\n        </ion-input>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-label>Género</ion-label>\r\n        <ion-select okText=\"Aceptar\" cancelText=\"Cancelar\" [(ngModel)]=\"genderSelected\">\r\n          <ion-select-option *ngFor=\"let item of genders\" [value]='item.value'>\r\n            {{item.name}}\r\n          </ion-select-option>\r\n        </ion-select>\r\n      </ion-item>\r\n      <div class=\"w-100 input-date\">\r\n        <mat-form-field class=\"matDate\" appearance=\"outline\">\r\n          <mat-label>Fecha de nacimiento:</mat-label>\r\n          <input matInput [matDatepicker]=\"picker\" [(ngModel)]=\"birthDate\">\r\n          <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n          <mat-datepicker #picker></mat-datepicker>\r\n        </mat-form-field>\r\n      </div>\r\n    </ion-col>\r\n    <ion-col class='btn-container' size=\"2\">\r\n      <div>\r\n        <button mat-mini-fab color='secondary' (click)='searchPerson()'>\r\n          <mat-icon>search</mat-icon>\r\n        </button>\r\n      </div>\r\n    </ion-col>\r\n  </ion-row>\r\n</div>"

/***/ }),

/***/ "./src/app/core/pipes/attr-group-filter.pipe.ts":
/*!******************************************************!*\
  !*** ./src/app/core/pipes/attr-group-filter.pipe.ts ***!
  \******************************************************/
/*! exports provided: AttrGroupFilterPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AttrGroupFilterPipe", function() { return AttrGroupFilterPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AttrGroupFilterPipe = class AttrGroupFilterPipe {
    transform(value, ...args) {
        return value.filter((attr) => attr.idgroup === args[0]);
    }
};
AttrGroupFilterPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'attrGroupFilter'
    })
], AttrGroupFilterPipe);



/***/ }),

/***/ "./src/app/procedures/dynamic-form/InputsNames.ts":
/*!********************************************************!*\
  !*** ./src/app/procedures/dynamic-form/InputsNames.ts ***!
  \********************************************************/
/*! exports provided: InputsNames */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputsNames", function() { return InputsNames; });
const InputsNames = {
    PROVINCIA: 'Provincia',
    CUILCUIT: 'CUIL/CUIT',
    DNI: 'Tipo y Nro DU',
    GENERO: 'Género',
    PEDIDOXTERCERO: 'El pedido lo hace un tercero',
    APELLIDOYNOMBRE: 'Apellido y Nombre',
    DOMICILIO: 'Domicilio',
    PHONE_NUMBER: 'Número de teléfono',
    ADDPERSON: 'ADD_PERSON',
};


/***/ }),

/***/ "./src/app/procedures/dynamic-form/dynamic-form-item/dynamic-form-item.component.scss":
/*!********************************************************************************************!*\
  !*** ./src/app/procedures/dynamic-form/dynamic-form-item/dynamic-form-item.component.scss ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".d-flex {\n  display: flex;\n}\n\n.list-ios {\n  margin: 0;\n}\n\n.align-btn-validationCode {\n  display: flex;\n  justify-content: center;\n}\n\n.file-container {\n  display: grid;\n  padding: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvY2VkdXJlcy9keW5hbWljLWZvcm0vZHluYW1pYy1mb3JtLWl0ZW0vRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxwcm9jZWR1cmVzXFxkeW5hbWljLWZvcm1cXGR5bmFtaWMtZm9ybS1pdGVtXFxkeW5hbWljLWZvcm0taXRlbS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcHJvY2VkdXJlcy9keW5hbWljLWZvcm0vZHluYW1pYy1mb3JtLWl0ZW0vZHluYW1pYy1mb3JtLWl0ZW0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0FDQ0o7O0FERUE7RUFDSSxTQUFBO0FDQ0o7O0FERUE7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7RUFDQSxhQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wcm9jZWR1cmVzL2R5bmFtaWMtZm9ybS9keW5hbWljLWZvcm0taXRlbS9keW5hbWljLWZvcm0taXRlbS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kLWZsZXgge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxufVxyXG5cclxuLmxpc3QtaW9zIHtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG5cclxuLmFsaWduLWJ0bi12YWxpZGF0aW9uQ29kZSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5maWxlLWNvbnRhaW5lciB7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgcGFkZGluZzogMXJlbTtcclxufSIsIi5kLWZsZXgge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG4ubGlzdC1pb3Mge1xuICBtYXJnaW46IDA7XG59XG5cbi5hbGlnbi1idG4tdmFsaWRhdGlvbkNvZGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLmZpbGUtY29udGFpbmVyIHtcbiAgZGlzcGxheTogZ3JpZDtcbiAgcGFkZGluZzogMXJlbTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/procedures/dynamic-form/dynamic-form-item/dynamic-form-item.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/procedures/dynamic-form/dynamic-form-item/dynamic-form-item.component.ts ***!
  \******************************************************************************************/
/*! exports provided: DynamicFormItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DynamicFormItemComponent", function() { return DynamicFormItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_person_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/person.service */ "./src/app/services/person.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");






let DynamicFormItemComponent = class DynamicFormItemComponent {
    constructor(personService, storage, alertService, loadingController) {
        this.personService = personService;
        this.storage = storage;
        this.alertService = alertService;
        this.loadingController = loadingController;
        this.personResult = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.genericEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.addPersonEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.sendFilesEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    ngOnInit() { }
    personSearchFn($event) {
        this.personResult.emit($event);
    }
    checkboxChange(procedureTypeAttrs) {
        this.genericEmitter.emit(procedureTypeAttrs);
    }
    addPerson() {
        this.addPersonEmitter.emit();
    }
    validatePhone(telefono) {
        const patternPhoneNumber = /^\d{10}$/;
        return patternPhoneNumber.test(telefono);
    }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando',
            });
            yield loading.present();
        });
    }
    setFilesEmitter($event) {
        this.sendFilesEmitter.emit($event);
    }
    getCode() {
        let isValidCode = this.validatePhone(this.phoneNumber);
        if (!isValidCode) {
            this.alertService.showErrorAlert("Debe ingresar un número de telefóno válido.");
            return;
        }
        try {
            this.personService.getCodeValidation(this.phoneNumber).subscribe((respon) => {
                this.alertService.showCustomAlert({
                    message: 'Enviamos su código de verifcación por SMS'
                });
                this.validationCode = respon;
                this.storage.set('validationCode', this.validationCode);
            }, (error) => {
                this.alertService.showErrorAlert(error.error.message);
            });
        }
        catch (error) {
            this.alertService.showErrorAlert(error);
        }
    }
};
DynamicFormItemComponent.ctorParameters = () => [
    { type: src_app_services_person_service__WEBPACK_IMPORTED_MODULE_2__["PersonService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"] },
    { type: src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DynamicFormItemComponent.prototype, "stepInput", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
], DynamicFormItemComponent.prototype, "groupId", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], DynamicFormItemComponent.prototype, "personResult", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], DynamicFormItemComponent.prototype, "genericEmitter", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], DynamicFormItemComponent.prototype, "addPersonEmitter", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], DynamicFormItemComponent.prototype, "sendFilesEmitter", void 0);
DynamicFormItemComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'dynamic-form-item',
        template: __webpack_require__(/*! raw-loader!./dynamic-form-item.component.html */ "./node_modules/raw-loader/index.js!./src/app/procedures/dynamic-form/dynamic-form-item/dynamic-form-item.component.html"),
        styles: [__webpack_require__(/*! ./dynamic-form-item.component.scss */ "./src/app/procedures/dynamic-form/dynamic-form-item/dynamic-form-item.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_person_service__WEBPACK_IMPORTED_MODULE_2__["PersonService"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"],
        src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"]])
], DynamicFormItemComponent);



/***/ }),

/***/ "./src/app/procedures/dynamic-form/dynamic-form.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/procedures/dynamic-form/dynamic-form.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: #FF0067;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\n.stepwizard-step p {\n  margin-top: 10px;\n}\n\n.stepwizard-row {\n  display: table-row;\n}\n\n.stepwizard {\n  position: relative;\n  margin-top: 0.3rem;\n  margin-left: 0.5rem;\n  margin-right: 0.5rem;\n  margin-bottom: 0.3rem;\n}\n\n.stepwizard-step button[disabled] {\n  opacity: 1 !important;\n  filter: alpha(opacity=100) !important;\n}\n\n.stepwizard-row:before {\n  top: 23px;\n  bottom: 0;\n  position: absolute;\n  content: \" \";\n  width: 100%;\n  height: 1px;\n  background-color: #ccc;\n}\n\n.stepwizard-step {\n  display: table-cell;\n  text-align: center;\n  position: relative;\n}\n\n.btn-circle {\n  width: 30px;\n  height: 30px;\n  text-align: center;\n  padding: 6px 0;\n  font-size: 12px;\n  line-height: 1.428571429;\n  border-radius: 15px;\n}\n\n.previousAndNextPageContainer {\n  display: flex;\n  justify-content: space-between;\n}\n\n.container-btn-clean {\n  display: flex;\n  justify-content: end;\n}\n\n.active-step {\n  background-color: #FF0067;\n}\n\n.d-flex {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.container-files {\n  display: flex;\n  justify-content: space-between;\n  margin: 0 1rem;\n  padding-top: 0.5rem;\n  border-top: 1px solid black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvY2VkdXJlcy9keW5hbWljLWZvcm0vRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxwcm9jZWR1cmVzXFxkeW5hbWljLWZvcm1cXGR5bmFtaWMtZm9ybS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcHJvY2VkdXJlcy9keW5hbWljLWZvcm0vZHluYW1pYy1mb3JtLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUNDSjs7QURHQTtFQUNJLGNBQUE7QUNBSjs7QURHQTtFQUNJLHlCQUFBO0FDQUo7O0FER0E7RUFDSSxnQkFBQTtBQ0FKOztBREdBO0VBQ0ksa0JBQUE7QUNBSjs7QURHQTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7QUNBSjs7QURHQTtFQUNJLHFCQUFBO0VBQ0EscUNBQUE7QUNBSjs7QURHQTtFQUNJLFNBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtBQ0FKOztBREdBO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDQUo7O0FER0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSx3QkFBQTtFQUNBLG1CQUFBO0FDQUo7O0FER0E7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7QUNBSjs7QURHQTtFQUNJLGFBQUE7RUFDQSxvQkFBQTtBQ0FKOztBREdBO0VBQ0kseUJBQUE7QUNBSjs7QURHQTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDQUo7O0FER0E7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcHJvY2VkdXJlcy9keW5hbWljLWZvcm0vZHluYW1pYy1mb3JtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNGRjAwNjc7XHJcblxyXG59XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxufVxyXG5cclxuLndoaXRlIHtcclxuICAgIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zdGVwd2l6YXJkLXN0ZXAgcCB7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG4uc3RlcHdpemFyZC1yb3cge1xyXG4gICAgZGlzcGxheTogdGFibGUtcm93O1xyXG59XHJcblxyXG4uc3RlcHdpemFyZCB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBtYXJnaW4tdG9wOiAwLjNyZW07XHJcbiAgICBtYXJnaW4tbGVmdDogMC41cmVtO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwLjVyZW07XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwLjNyZW07XHJcbn1cclxuXHJcbi5zdGVwd2l6YXJkLXN0ZXAgYnV0dG9uW2Rpc2FibGVkXSB7XHJcbiAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XHJcbiAgICBmaWx0ZXI6IGFscGhhKG9wYWNpdHk9MTAwKSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uc3RlcHdpemFyZC1yb3c6YmVmb3JlIHtcclxuICAgIHRvcDogMjNweDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGNvbnRlbnQ6IFwiIFwiO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDFweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNjY2M7XHJcbn1cclxuXHJcbi5zdGVwd2l6YXJkLXN0ZXAge1xyXG4gICAgZGlzcGxheTogdGFibGUtY2VsbDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLmJ0bi1jaXJjbGUge1xyXG4gICAgd2lkdGg6IDMwcHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nOiA2cHggMDtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxLjQyODU3MTQyOTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbn1cclxuXHJcbi5wcmV2aW91c0FuZE5leHRQYWdlQ29udGFpbmVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuXHJcbi5jb250YWluZXItYnRuLWNsZWFuIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGVuZDtcclxufVxyXG5cclxuLmFjdGl2ZS1zdGVwIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGRjAwNjc7XHJcbn1cclxuXHJcbi5kLWZsZXgge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmNvbnRhaW5lci1maWxlcyB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgbWFyZ2luOiAwIDFyZW07XHJcbiAgICBwYWRkaW5nLXRvcDogMC41cmVtO1xyXG4gICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIGJsYWNrO1xyXG59IiwiaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogI0ZGMDA2Nztcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI0ZGRkZGRjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cblxuLnN0ZXB3aXphcmQtc3RlcCBwIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLnN0ZXB3aXphcmQtcm93IHtcbiAgZGlzcGxheTogdGFibGUtcm93O1xufVxuXG4uc3RlcHdpemFyZCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbWFyZ2luLXRvcDogMC4zcmVtO1xuICBtYXJnaW4tbGVmdDogMC41cmVtO1xuICBtYXJnaW4tcmlnaHQ6IDAuNXJlbTtcbiAgbWFyZ2luLWJvdHRvbTogMC4zcmVtO1xufVxuXG4uc3RlcHdpemFyZC1zdGVwIGJ1dHRvbltkaXNhYmxlZF0ge1xuICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XG4gIGZpbHRlcjogYWxwaGEob3BhY2l0eT0xMDApICFpbXBvcnRhbnQ7XG59XG5cbi5zdGVwd2l6YXJkLXJvdzpiZWZvcmUge1xuICB0b3A6IDIzcHg7XG4gIGJvdHRvbTogMDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBjb250ZW50OiBcIiBcIjtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMXB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjY2NjO1xufVxuXG4uc3RlcHdpemFyZC1zdGVwIHtcbiAgZGlzcGxheTogdGFibGUtY2VsbDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi5idG4tY2lyY2xlIHtcbiAgd2lkdGg6IDMwcHg7XG4gIGhlaWdodDogMzBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA2cHggMDtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBsaW5lLWhlaWdodDogMS40Mjg1NzE0Mjk7XG4gIGJvcmRlci1yYWRpdXM6IDE1cHg7XG59XG5cbi5wcmV2aW91c0FuZE5leHRQYWdlQ29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuXG4uY29udGFpbmVyLWJ0bi1jbGVhbiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogZW5kO1xufVxuXG4uYWN0aXZlLXN0ZXAge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkYwMDY3O1xufVxuXG4uZC1mbGV4IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5jb250YWluZXItZmlsZXMge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIG1hcmdpbjogMCAxcmVtO1xuICBwYWRkaW5nLXRvcDogMC41cmVtO1xuICBib3JkZXItdG9wOiAxcHggc29saWQgYmxhY2s7XG59Il19 */"

/***/ }),

/***/ "./src/app/procedures/dynamic-form/dynamic-form.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/procedures/dynamic-form/dynamic-form.component.ts ***!
  \*******************************************************************/
/*! exports provided: DynamicFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DynamicFormComponent", function() { return DynamicFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/procedures.service */ "./src/app/services/procedures.service.ts");
/* harmony import */ var _InputsNames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./InputsNames */ "./src/app/procedures/dynamic-form/InputsNames.ts");








let DynamicFormComponent = class DynamicFormComponent {
    constructor(route, router, storage, alertService, procedureService, loadingController) {
        this.route = route;
        this.router = router;
        this.storage = storage;
        this.alertService = alertService;
        this.procedureService = procedureService;
        this.loadingController = loadingController;
        this.steps = [];
        this.currentsAttrs = [];
        this.currentUser = {
            docNumber: "",
            docType: "",
            sex: ""
        };
        this.nextPage = 0;
        this.currentPage = 0;
        this.omitNextPage = true;
        this.groupsModel = {
            nameGroup: '',
        };
        this.lastIndex = [0];
        this.promises = [];
        // ARCHIVOS CONVERTIDOS A BASE64 QUE SE ENVIARÁN AL BACK
        this.filesToPost = [];
        // VARIABLE PARA MANEJAR LOS ARCHIVOS QUE CORRESPONDAN A CADA STEP
        this.filesStep = [];
        this.quantityGroupsLocal = [1];
        this.isValidateCode = false;
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.form = this.router.getCurrentNavigation().extras.state.procedureType;
                this.procedureId = this.form.id;
            }
        });
    }
    ngOnInit() {
        if (this.form.id) {
            this.getUser();
            this.getPhoneNumber();
        }
    }
    getPhoneNumber() {
        this.storage.get('phoneNumber').then((phoneNumber) => {
            this.phoneNumber = phoneNumber;
            this.buildForm();
        });
    }
    getUser() {
        this.storage.get('psw').then((user) => {
            this.currentUser = user;
            this.getPhoneNumber();
            this.buildForm();
        });
    }
    goToBack() {
        this.router.navigate(['/newProcedure']);
    }
    // FUNCIONES PARA ASIGNAR LOS ATRIBUTOS A LOS GRUPOS
    addProcedureAttrs(index) {
        if (this.currentsAttrs.filter((attr) => attr.idgroup === index).length === 0) {
            this.procedureService.getProcedureAttrs(this.procedureId, index, this.currentStep.step).subscribe((response) => {
                response.forEach((attr) => {
                    attr.idgroup = index;
                });
                this.currentsAttrs = this.currentsAttrs.concat(response);
                if (this.groupsModel.quantityOfGroups.length > 1) {
                    this.quantityGroupsLocal = this.groupsModel.quantityOfGroups;
                }
                this.setDataOnGroups();
            });
        }
    }
    // FUNCIONES PARA ASIGNAR LOS ATRIBUTOS A LOS GRUPOS
    getProcedureAttrs(index) {
        this.procedureService.getProcedureAttrs(this.procedureId, index, this.currentStep.step).subscribe((response) => {
            this.currentsAttrs = response;
        });
    }
    setDataOnGroups() {
        if ((this.currentsAttrs && this.currentsAttrs.length > 0) && (this.groups && this.groups.length > 0)) {
            this.currentsAttrs.forEach((currentAttr) => {
                this.groups.forEach((attrGroup) => {
                    if (attrGroup.idgroup === currentAttr.idgroup) {
                        if (!currentAttr.dataValue && attrGroup.id === currentAttr.id) {
                            currentAttr.dataValue = attrGroup.dataValue;
                        }
                    }
                });
            });
        }
    }
    buildForm(step = 0) {
        let form = this.form;
        this.groupsModel.quantityOfGroups = [];
        this.currentPage = step;
        // ASIGNAMOS LOS STEPS  MOSTRARLOS EN LA VISTA
        this.steps = form.procedureSteps;
        if (form.procedureSteps && step < form.procedureSteps.length) {
            // SI EL STEP TIENE GRUPOS, CREAMOS LOS GRUPOS
            if (form.procedureSteps[step].groups >= 1 && this.groupsModel.quantityOfGroups.length === 0) {
                this.createGroup(form.procedureSteps[step].groups, form.procedureSteps[step].name);
                this.currentStep = form.procedureSteps[step];
            }
            else {
                this.currentStep = form.procedureSteps[step];
                this.currentsAttrs = form.procedureTypeAttrs.filter((el) => {
                    if (el.tipo === 'VALIDATION_CODE') {
                        this.isValidateCode = true;
                    }
                    return el.step === this.currentStep.step;
                });
            }
            this.setDefaultValues(form.procedureTypeAttrs);
        }
    }
    setDefaultValues(procedureTypeAttrs) {
        procedureTypeAttrs.forEach((el) => {
            switch (el.name) {
                case _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].PROVINCIA:
                    if (!el.dataValue && el.tipo === 'READONLY') {
                        el.dataValue = 'San Luis';
                    }
                    break;
                case _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].GENERO:
                    if (el.tipo === 'READONLY') {
                        el.dataValue = this.currentUser.sex === 'M' ? 'Masculino' : 'Femenino';
                    }
                    break;
                case _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].PHONE_NUMBER:
                    if (el.tipo === 'READONLY') {
                        el.dataValue = this.phoneNumber ? this.phoneNumber : '';
                    }
            }
        });
    }
    // GUARDAMOS LA DATA DE LOS GRUPOS EN UNA VARIABLE DENTRO DEL COMPONENTE
    // PARA QUE AL IR A OTRO STEP NO SE PIERDA LA INFORMACIÓN.
    // porque currentsAttrs pisa los atributos cada vez q cambia los steps
    saveGroup() {
        if (!this.groups) {
            this.groups = this.currentsAttrs;
        }
        if (this.currentsAttrs.length > 0 && this.currentsAttrs.length >= this.groups.length) {
            this.groups = this.currentsAttrs;
        }
    }
    // CREAMOS LA CANTIDAD DE GRUPOS MÁXIMOS.
    createGroup(quantityOfGroups, name) {
        this.countOfGroups = quantityOfGroups;
        if (this.groupsModel.quantityOfGroups && this.groupsModel.quantityOfGroups.length === 0) {
            this.groupsModel.nameGroup = name;
            this.groupsModel.quantityOfGroups.push(1);
            this.getProcedureAttrs(this.groupsModel.quantityOfGroups.length);
        }
    }
    addNewGroup(name) {
        let quantityOfGroups = this.countOfGroups;
        while (this.groupsModel.quantityOfGroups.length < quantityOfGroups) {
            this.groupsModel.nameGroup = name;
            this.groupsModel.quantityOfGroups.push(this.groupsModel.quantityOfGroups.length);
            this.addProcedureAttrs(this.groupsModel.quantityOfGroups.length - 1);
            return;
        }
    }
    deleteGroup(index, error) {
        if (this.quantityGroupsLocal.length > 1) {
            this.quantityGroupsLocal.splice(index, 1);
            if (this.currentsAttrs && this.currentsAttrs.length > 0) {
                this.currentsAttrs = this.currentsAttrs.filter((attr) => attr.idgroup !== index);
            }
            if (this.groups && this.groups.length > 0) {
                this.groups = this.groups.filter((attr) => attr.idgroup !== index);
            }
        }
        else {
            this.alertService.showErrorAlert(error);
        }
    }
    // ESTA FUNCIÓN CONVIERTE A LOS DATOS DEL FORMULARIO 
    transformAttr() {
        let tramiteAttrs = [];
        // LO QUE TENEMOS GUARDADO EN LOS GRUPOS, SE LOS AGREGAMOS AL DTO
        // QUE ENVIAREMOS AL BACK-END
        if (this.groups && this.groups.length > 0) {
            this.groups.forEach((attr) => {
                let model = {
                    fieldName: '',
                    procedureTypeAttrId: null,
                    valor: '',
                };
                model.fieldName = attr.name ? attr.name : '';
                model.valor = attr.dataValue ? attr.dataValue : '';
                model.procedureTypeAttrId = attr.id ? attr.id : null;
                tramiteAttrs.push(model);
            });
        }
        this.form.procedureTypeAttrs.forEach((el) => {
            let model = {
                fieldName: '',
                procedureTypeAttrId: null,
                valor: '',
            };
            model.fieldName = el.name ? el.name : '';
            model.valor = el.dataValue ? el.dataValue : '';
            model.procedureTypeAttrId = el.id ? el.id : null;
            tramiteAttrs.push(model);
        });
        return tramiteAttrs;
    }
    // VALIDAMOS LOS CAMPOS OBLIGATORIOS
    validateForm() {
        let currentAttr = this.currentsAttrs;
        currentAttr.forEach((el) => {
            if (el.required && !el.dataValue) {
                throw new Error(`El campo ${el.name} es requerido`);
            }
        });
    }
    validateCode() {
        return new Promise((resolve, reject) => {
            this.storage.get('validationCode').then((val) => {
                if (val) {
                    let isValid = true;
                    this.currentsAttrs.forEach((el) => {
                        if (parseInt(el.dataValue) !== val) {
                            isValid = false;
                        }
                    });
                    resolve(isValid);
                }
                else {
                    resolve(false);
                }
            }).catch((error) => {
                reject(error);
            });
        });
    }
    sendForm() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                yield this.validateForm();
                let attrsParse = this.transformAttr();
                let model = {
                    comments: "",
                    userId: this.procedureService.userId,
                    procedureTypeId: this.form.id,
                    documentDtoList: this.filesToPost,
                    tramiteAttrs: attrsParse
                };
                // ESTO ESTÁ HECHO ASÍ PORQUE ME LO PIDIERON DOS DÍAS ANTES DE IRME
                // SEPA DISCULPAR, ES PARA EL TRÁMITE DE DEFENSORÍA DEL PUEBLO - RECLAMOS
                let isValidCode;
                if (!this.isValidateCode) {
                    isValidCode = true;
                }
                else {
                    isValidCode = yield this.validateCode();
                }
                if (isValidCode) {
                    this.loading();
                    this.procedureService.createProcedure(model).subscribe((response) => {
                        this.loadingController.dismiss(); // Ocultar el loader después de recibir la respuesta
                        this.router.navigateByUrl('/proceduresHome');
                    }, (error) => {
                        this.loadingController.dismiss(); // Ocultar el loader después de recibir la respuesta
                        this.alertService.showErrorAlert(error.error.message);
                    });
                }
                else {
                    this.alertService.showCustomAlert({
                        message: "El código de validación es distinto al que hemos enviado"
                    });
                }
            }
            catch (error) {
                this.alertService.showCustomAlert(error);
            }
        });
    }
    converToBase64(fileToUpload, attrId) {
        const reader = new FileReader();
        reader.readAsDataURL(fileToUpload);
        reader.onload = (event) => {
            if (event.target) {
                let fileConvert = {
                    id: attrId,
                    base64: reader.result,
                    mimeType: fileToUpload.type,
                    originalName: fileToUpload.name ? fileToUpload.name : '',
                };
                // EMITIMOS EL BASE64 AL CMP PADRE
                this.filesToPost.push(fileConvert);
            }
        };
    }
    // GUARDAMOS LOS ARCHIVOS EN UNA VARIABLE LOCAL
    // PARA NO PERDER LA INFORMACIÓN AL IR A OTRO STEP
    saveFileInStep($event, fileToUpload) {
        for (let file of this.filesStep) {
            if (file.id === parseInt($event.target.id)) {
                this.alertService.showErrorAlert("Ya cargó un archivo, elimine el actual y vuelva a cargar uno");
                return; // Detener la ejecución del método
            }
        }
        let file = {
            id: parseInt($event.target.id),
            step: this.currentStep.step,
            label: $event.target.files[0].name,
            file: $event.target.files[0]
        };
        this.filesStep.push(file);
        this.converToBase64(fileToUpload, parseInt($event.target.id));
    }
    deleteFile(fileId, step) {
        this.filesToPost.forEach((file, index) => {
            if (file.id === fileId) {
                this.filesToPost.splice(index, 1);
            }
        });
        this.filesStep.forEach((file, index) => {
            if (file.id === fileId) {
                this.filesStep.splice(index, 1);
            }
        });
    }
    cleanCurrentAttr() {
        this.currentsAttrs.forEach((attr) => {
            if (attr.tipo !== 'READONLY')
                attr.dataValue = null;
        });
        this.filesStep = [];
    }
    emitterFn($event) {
        if ($event.name === _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].PEDIDOXTERCERO) {
        }
    }
    // FUNCIÓN TRAE LOS ARCHIVOS DEL COMPONENTE HIJO
    setFilesFn($event) {
        let fileToUpload = $event.target.files.item(0);
        if (fileToUpload) {
            const allowedFileTypes = ['/pdf', '/png', '/jpg', '/jpeg'];
            const fileType = fileToUpload.type;
            const fileExtension = fileType.substring(fileType.lastIndexOf('/'));
            const fileSizeInMB = fileToUpload.size / (1024 * 1024); // Tamaño del archivo en MB
            // VALIDAMOS QUE EL TAMAÑO NO SUPERE LOS 10MB
            if (fileSizeInMB > 10) {
                this.alertService.showErrorAlert('El tamaño del archivo no puede ser mayor a 10MB.');
                return;
            }
            // VALIDAMOS LAS EXTENSIONES PERMITIDAS
            if (allowedFileTypes.includes(fileExtension)) {
                this.saveFileInStep($event, fileToUpload);
            }
            else {
                this.alertService.showErrorAlert('Tipo de archivo no válido. Por favor, selecciona un archivo .pdf, .png o .jpg.');
            }
        }
    }
    addPersonEmitterFn() {
        this.currentsAttrs.forEach((el) => {
            if (el.dataValue) {
                let model = [];
                if (el.name !== _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].ADDPERSON) {
                    model.push(el.dataValue);
                }
                else {
                    el.dataValue;
                }
            }
            else {
                this.alertService.showErrorAlert("Debe completar todos los campos del formulario.");
            }
        });
    }
    personResultFn($event, index) {
        if (index || (index !== null && index !== undefined)) {
            this.currentsAttrs.filter((attr) => attr.idgroup === index).forEach((el) => {
                switch (el.name) {
                    case _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].APELLIDOYNOMBRE:
                        el.dataValue = $event.lastName.toUpperCase() + ' ' + $event.name.toUpperCase();
                        break;
                    case _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].DOMICILIO:
                        el.dataValue = ($event.street ? $event.street.toUpperCase() + ' ' + ($event.number ? $event.number : '') : '');
                }
            });
        }
        else {
            this.currentsAttrs.forEach((el) => {
                switch (el.name) {
                    case _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].APELLIDOYNOMBRE:
                        el.dataValue = $event.lastName.toUpperCase() + ' ' + $event.name.toUpperCase();
                        break;
                    case _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].DOMICILIO:
                        el.dataValue = ($event.street ? $event.street.toUpperCase() + ' ' + ($event.number ? $event.number : '') : '');
                }
            });
        }
    }
    // MOVERME ENTRE LOS STEPS
    goToNextStep() {
        try {
            const nextStepIndex = this.currentPage + 1;
            if (this.steps[this.currentPage] && this.steps[this.currentPage].groups) {
                // funcion para guardar grupo y que no se pierda la información al ir a otro step.
                this.saveGroup();
            }
            this.currentsAttrs.forEach((el) => {
                if (el.name === _InputsNames__WEBPACK_IMPORTED_MODULE_7__["InputsNames"].PEDIDOXTERCERO && !el.dataValue) {
                    this.nextPage = nextStepIndex + 1;
                }
                else {
                    this.nextPage = nextStepIndex;
                }
            });
            this.validateForm();
            this.lastIndex.push(this.nextPage);
            this.buildForm(this.nextPage);
        }
        catch (error) {
            this.alertService.showCustomAlert(error);
        }
    }
    // MOVERME ENTRE LOS STEPS
    goToBackStep() {
        this.lastIndex.pop();
        let index = this.lastIndex[this.lastIndex.length - 1];
        this.buildForm(index);
    }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando',
            });
            yield loading.present();
        });
    }
};
DynamicFormComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] },
    { type: src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"] },
    { type: src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_6__["ProceduresService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] }
];
DynamicFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-dynamic-form',
        template: __webpack_require__(/*! raw-loader!./dynamic-form.component.html */ "./node_modules/raw-loader/index.js!./src/app/procedures/dynamic-form/dynamic-form.component.html"),
        styles: [__webpack_require__(/*! ./dynamic-form.component.scss */ "./src/app/procedures/dynamic-form/dynamic-form.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"],
        src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"],
        src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_6__["ProceduresService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]])
], DynamicFormComponent);



/***/ }),

/***/ "./src/app/procedures/dynamic-form/dynamic-form.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/procedures/dynamic-form/dynamic-form.module.ts ***!
  \****************************************************************/
/*! exports provided: DynamicFormModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DynamicFormModule", function() { return DynamicFormModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _dynamic_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dynamic-form.component */ "./src/app/procedures/dynamic-form/dynamic-form.component.ts");
/* harmony import */ var _dynamic_form_item_dynamic_form_item_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./dynamic-form-item/dynamic-form-item.component */ "./src/app/procedures/dynamic-form/dynamic-form-item/dynamic-form-item.component.ts");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/esm2015/expansion.js");
/* harmony import */ var src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/procedures.service */ "./src/app/services/procedures.service.ts");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/esm2015/datepicker.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/esm2015/form-field.js");
/* harmony import */ var src_app_core_pipes_attr_group_filter_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/pipes/attr-group-filter.pipe */ "./src/app/core/pipes/attr-group-filter.pipe.ts");















let DynamicFormModule = class DynamicFormModule {
};
DynamicFormModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__["SharedModule"],
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_10__["MatExpansionModule"],
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_13__["MatFormFieldModule"],
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_12__["MatDatepickerModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _dynamic_form_component__WEBPACK_IMPORTED_MODULE_6__["DynamicFormComponent"]
                }
            ])
        ],
        declarations: [
            _dynamic_form_component__WEBPACK_IMPORTED_MODULE_6__["DynamicFormComponent"],
            _dynamic_form_item_dynamic_form_item_component__WEBPACK_IMPORTED_MODULE_7__["DynamicFormItemComponent"],
            src_app_core_pipes_attr_group_filter_pipe__WEBPACK_IMPORTED_MODULE_14__["AttrGroupFilterPipe"]
        ],
        providers: [
            src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_9__["AlertService"],
            src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_11__["ProceduresService"]
        ]
    })
], DynamicFormModule);



/***/ }),

/***/ "./src/app/services/person.service.ts":
/*!********************************************!*\
  !*** ./src/app/services/person.service.ts ***!
  \********************************************/
/*! exports provided: PersonService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PersonService", function() { return PersonService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");





let PersonService = class PersonService {
    constructor(http, storage) {
        this.http = http;
        this.storage = storage;
        this.storage.get('token').then((val) => {
            if (val) {
                this.token = val;
            }
        });
        this.storage.get('userId').then((val2) => {
            if (val2) {
                this.userId = val2;
            }
        });
    }
    searchPerson(docNumber, sex, birthDate) {
        const httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Accept: 'application/json',
                'X-Authorization': 'Bearer ' + this.token
            }),
            response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpResponse"]({
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                }),
            })
        };
        let extraParams = '';
        if (birthDate) {
            extraParams += `birthDate=${birthDate}`;
        }
        return this.http.get(`${_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL}secure/person/${docNumber}/${sex}?${extraParams}`, httpOptions);
    }
    getCodeValidation(phoneNumber) {
        const httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Accept: 'application/json',
                'X-Authorization': 'Bearer ' + this.token
            }),
            response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpResponse"]({
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                }),
            })
        };
        return this.http.get(`${_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL}secure/person/${this.userId}/sms/${phoneNumber}`, httpOptions);
    }
};
PersonService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"] }
];
PersonService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"]])
], PersonService);



/***/ }),

/***/ "./src/app/shared/search-person/search-person.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/shared/search-person/search-person.component.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".d-flex {\n  display: flex;\n  justify-content: center;\n}\n\n.btn-container {\n  display: flex;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3NlYXJjaC1wZXJzb24vRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxzaGFyZWRcXHNlYXJjaC1wZXJzb25cXHNlYXJjaC1wZXJzb24uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3NoYXJlZC9zZWFyY2gtcGVyc29uL3NlYXJjaC1wZXJzb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL3NlYXJjaC1wZXJzb24vc2VhcmNoLXBlcnNvbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kLWZsZXgge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4uYnRuLWNvbnRhaW5lciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufSIsIi5kLWZsZXgge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLmJ0bi1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/shared/search-person/search-person.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/shared/search-person/search-person.component.ts ***!
  \*****************************************************************/
/*! exports provided: SearchPersonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchPersonComponent", function() { return SearchPersonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var src_app_services_person_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/person.service */ "./src/app/services/person.service.ts");






let SearchPersonComponent = class SearchPersonComponent {
    constructor(personService, datePipe, alertService, loadingController) {
        this.personService = personService;
        this.datePipe = datePipe;
        this.alertService = alertService;
        this.loadingController = loadingController;
        this.genders = [
            { name: 'Masculino', value: 'M' },
            { name: 'Femenino', value: 'F' },
            { name: 'No binario', value: 'X' }
        ];
        this.person = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
    }
    ngOnInit() { }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Buscando...',
            });
            yield loading.present();
        });
    }
    searchPerson() {
        this.loading(); // Mostrar el loader antes de la llamada al servicio
        let birthDate = this.datePipe.transform(this.birthDate, "yyyy-MM-dd");
        this.personService.searchPerson(this.docNumber, this.genderSelected, birthDate).subscribe((response) => {
            this.loadingController.dismiss(); // Ocultar el loader después de recibir la respuesta
            this.person.emit(response);
        }, (error) => {
            this.loadingController.dismiss();
            this.alertService.showErrorAlert(error.error.message);
        });
    }
};
SearchPersonComponent.ctorParameters = () => [
    { type: src_app_services_person_service__WEBPACK_IMPORTED_MODULE_5__["PersonService"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_1__["DatePipe"] },
    { type: src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"])
], SearchPersonComponent.prototype, "person", void 0);
SearchPersonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'search-person',
        template: __webpack_require__(/*! raw-loader!./search-person.component.html */ "./node_modules/raw-loader/index.js!./src/app/shared/search-person/search-person.component.html"),
        styles: [__webpack_require__(/*! ./search-person.component.scss */ "./src/app/shared/search-person/search-person.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_person_service__WEBPACK_IMPORTED_MODULE_5__["PersonService"],
        _angular_common__WEBPACK_IMPORTED_MODULE_1__["DatePipe"],
        src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]])
], SearchPersonComponent);



/***/ }),

/***/ "./src/app/shared/shared-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/shared/shared-routing.module.ts ***!
  \*************************************************/
/*! exports provided: SharedRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedRoutingModule", function() { return SharedRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



const routes = [];
let SharedRoutingModule = class SharedRoutingModule {
};
SharedRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], SharedRoutingModule);



/***/ }),

/***/ "./src/app/shared/shared.module.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _shared_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shared-routing.module */ "./src/app/shared/shared-routing.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _search_person_search_person_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./search-person/search-person.component */ "./src/app/shared/search-person/search-person.component.ts");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/esm2015/button.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/esm2015/icon.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/esm2015/datepicker.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/esm2015/form-field.js");
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm2015/material-moment-adapter.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm2015/input.js");













let SharedModule = class SharedModule {
};
SharedModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _search_person_search_person_component__WEBPACK_IMPORTED_MODULE_6__["SearchPersonComponent"],
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_routing_module__WEBPACK_IMPORTED_MODULE_3__["SharedRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatButtonModule"],
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__["MatIconModule"],
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatFormFieldModule"],
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_9__["MatDatepickerModule"],
            _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_11__["MatMomentDateModule"],
            _angular_material_input__WEBPACK_IMPORTED_MODULE_12__["MatInputModule"]
        ],
        exports: [
            _search_person_search_person_component__WEBPACK_IMPORTED_MODULE_6__["SearchPersonComponent"]
        ],
        providers: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"]
        ]
    })
], SharedModule);



/***/ })

}]);
//# sourceMappingURL=procedures-dynamic-form-dynamic-form-module-es2015.js.map