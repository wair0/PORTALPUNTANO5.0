(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shifts-details-shifts-details-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/shifts-details/shifts-details.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shifts-details/shifts-details.page.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>PORTAL PUNTANO</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list >\r\n    <ion-list-header >\r\n      <h4 class=\"header-text-2\"><b>MIS TURNOS {{content.type}}</b></h4>\r\n    </ion-list-header>\r\n    <ion-item class=\"border-red\" *ngFor=\"let liquidation of content.appointmentItemDtoList; let i = index\">\r\n      <ion-list style=\"display: contents\" >\r\n        <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n          <ion-label class=\"ion-text-wrap\">\r\n            <ion-text class=\"red\">\r\n              <div *ngFor=\"let file of liquidation.items\">\r\n                <h2 *ngIf=\"file.value\" style=\"display: block;\">{{file.name}}: {{file.value}}</h2>\r\n              </div>\r\n            </ion-text>\r\n          </ion-label>\r\n\r\n        </ion-item>\r\n\r\n      </ion-list>\r\n\r\n    </ion-item>\r\n\r\n  </ion-list>\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\" ></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n"

/***/ }),

/***/ "./src/app/shifts-details/shifts-details-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/shifts-details/shifts-details-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: ShiftsDetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftsDetailsPageRoutingModule", function() { return ShiftsDetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shifts_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shifts-details.page */ "./src/app/shifts-details/shifts-details.page.ts");




var routes = [
    {
        path: '',
        component: _shifts_details_page__WEBPACK_IMPORTED_MODULE_3__["ShiftsDetailsPage"]
    }
];
var ShiftsDetailsPageRoutingModule = /** @class */ (function () {
    function ShiftsDetailsPageRoutingModule() {
    }
    ShiftsDetailsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], ShiftsDetailsPageRoutingModule);
    return ShiftsDetailsPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/shifts-details/shifts-details.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/shifts-details/shifts-details.module.ts ***!
  \*********************************************************/
/*! exports provided: ShiftsDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftsDetailsPageModule", function() { return ShiftsDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _shifts_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./shifts-details-routing.module */ "./src/app/shifts-details/shifts-details-routing.module.ts");
/* harmony import */ var _shifts_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./shifts-details.page */ "./src/app/shifts-details/shifts-details.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");












var ShiftsDetailsPageModule = /** @class */ (function () {
    function ShiftsDetailsPageModule() {
    }
    ShiftsDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
                _shifts_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["ShiftsDetailsPageRoutingModule"]
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
                _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
                _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"],
                _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__["FileOpener"]],
            declarations: [_shifts_details_page__WEBPACK_IMPORTED_MODULE_6__["ShiftsDetailsPage"]]
        })
    ], ShiftsDetailsPageModule);
    return ShiftsDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/shifts-details/shifts-details.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/shifts-details/shifts-details.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #20B572;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #20B572;\n}\n\n.header-text {\n  margin-right: 5%;\n  padding-left: 20px;\n  width: 100%;\n  padding-bottom: 10px;\n  padding-top: 10px;\n  background-color: #20B572;\n  color: #FFFFFF;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #20B572;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.header-text-2 {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n  margin-bottom: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hpZnRzLWRldGFpbHMvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxzaGlmdHMtZGV0YWlsc1xcc2hpZnRzLWRldGFpbHMucGFnZS5zY3NzIiwic3JjL2FwcC9zaGlmdHMtZGV0YWlscy9zaGlmdHMtZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFBO0FDQ0Y7O0FESUE7RUFDRSxnQ0FBQTtBQ0RGOztBRElBO0VBRUUsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsOEJBQUE7QUNGRjs7QURLQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQ0ZGOztBREtBO0VBQ0UsbUJBQUE7RUFDQSxrQkFBQTtBQ0ZGOztBREtBO0VBQ0UscUJBQUE7QUNGRjs7QURLQTtFQUNFLGNBQUE7QUNGRjs7QURLQTtFQUNFLHlCQUFBO0FDRkY7O0FES0E7RUFDRSxrQkFBQTtFQUNBLGVBQUE7QUNGRjs7QURNQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FDSEY7O0FETUE7RUFDRSwyQkFBQTtFQUNBLGlDQUFBO0FDSEY7O0FETUE7RUFDRSwyQkFBQTtBQ0hGOztBRE1BO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0hGOztBRE1BO0VBQ0UsZ0NBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0FDSEYiLCJmaWxlIjoic3JjL2FwcC9zaGlmdHMtZGV0YWlscy9zaGlmdHMtZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVke1xyXG4gIGNvbG9yOiAjMjBCNTcyXHJcbn1cclxuXHJcblxyXG5cclxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XHJcbiAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgIzIwQjU3MjtcclxufVxyXG5cclxuLmhlYWRlci10ZXh0e1xyXG4gIC8vIGJvcmRlci1ib3R0b206MnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzIwQjU3MjtcclxuICBjb2xvcjogI0ZGRkZGRjtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1pdGVte1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG59XHJcblxyXG5pb24tbGlzdHtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIG1hcmdpbi1ib3R0b206MHB4O1xyXG59XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFye1xyXG4gIC0tYmFja2dyb3VuZDogIzIwQjU3MjtcclxuXHJcbn1cclxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGV7XHJcbiAgY29sb3I6ICNGRkZGRkY7XHJcbn1cclxuXHJcbi53aGl0ZXtcclxuICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tbGFiZWx7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIG1hcmdpbi10b3A6IDBweDtcclxufVxyXG5cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zYy1pb24tY2FyZC1tZC1oIHtcclxuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OlwiXCIgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWNhcmR7XHJcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tdGl0bGV7XHJcbiAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICBmb250LXNpemU6IDV2dztcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5oZWFkZXItdGV4dC0ye1xyXG4gIGJvcmRlci1ib3R0b206MnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbn1cclxuIiwiLnJlZCB7XG4gIGNvbG9yOiAjMjBCNTcyO1xufVxuXG5pb24taXRlbS5ib3JkZXItcmVkIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMyMEI1NzI7XG59XG5cbi5oZWFkZXItdGV4dCB7XG4gIG1hcmdpbi1yaWdodDogNSU7XG4gIHBhZGRpbmctbGVmdDogMjBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xuICBwYWRkaW5nLXRvcDogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzIwQjU3MjtcbiAgY29sb3I6ICNGRkZGRkY7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW0ge1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIG1hcmdpbi1yaWdodDogNSU7XG59XG5cbmlvbi1saXN0IHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMjBCNTcyO1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuXG4ud2hpdGUge1xuICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xufVxuXG5pb24tbGFiZWwge1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi10b3A6IDBweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLnNjLWlvbi1jYXJkLW1kLWgge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gIC13ZWJraXQtYm94LXNoYWRvdzogXCJcIiAhaW1wb3J0YW50O1xufVxuXG5pb24tY2FyZCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbn1cblxuaW9uLXRpdGxlIHtcbiAgcGFkZGluZy1yaWdodDogNSU7XG4gIHBhZGRpbmctbGVmdDogNSU7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5oZWFkZXItdGV4dC0yIHtcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICM1MzUzNTM7XG4gIG1hcmdpbi1yaWdodDogNSU7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/shifts-details/shifts-details.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/shifts-details/shifts-details.page.ts ***!
  \*******************************************************/
/*! exports provided: ShiftsDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftsDetailsPage", function() { return ShiftsDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");













var ShiftsDetailsPage = /** @class */ (function () {
    function ShiftsDetailsPage(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, screenOrientation, refreshUtils, navController, statusBar, platform) {
        var _this = this;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.screenOrientation = screenOrientation;
        this.refreshUtils = refreshUtils;
        this.navController = navController;
        this.statusBar = statusBar;
        this.platform = platform;
        this.processError = function (error) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                _this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        _this.storage.get('psw').then(function (val) {
                            if (val) {
                                _this.loading("Descargando");
                                _this.refreshUtils.refreshToken(val).then(function (value) {
                                    _this.loadingController.dismiss();
                                    resolve(value);
                                }).catch(function (errorRefresh) {
                                    _this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        _this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    _this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(function (params) {
            if (_this.router.getCurrentNavigation().extras.state) {
                _this.content = _this.router.getCurrentNavigation().extras.state.content;
                _this.token = _this.router.getCurrentNavigation().extras.state.token;
            }
        });
    }
    ShiftsDetailsPage.prototype.ionViewWillEnter = function () {
        this.statusBar.backgroundColorByHexString('#20B572');
    };
    ShiftsDetailsPage.prototype.ngOnInit = function () {
    };
    ShiftsDetailsPage.prototype.deleteDataAndExitToLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.storage.clear().then(function () {
                    _this.navController.navigateRoot("/login");
                });
                return [2 /*return*/];
            });
        });
    };
    ShiftsDetailsPage.prototype.alert = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Portal puntano',
                            message: messageText,
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel',
                                    cssClass: 'primary',
                                    handler: function () {
                                        console.log('OK pressed!!');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ShiftsDetailsPage.prototype.loading = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: messageText,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ShiftsDetailsPage.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
    };
    ShiftsDetailsPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
        { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__["FileTransfer"] },
        { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
        { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"] },
        { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] }
    ]; };
    ShiftsDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-shifts-details',
            template: __webpack_require__(/*! raw-loader!./shifts-details.page.html */ "./node_modules/raw-loader/index.js!./src/app/shifts-details/shifts-details.page.html"),
            styles: [__webpack_require__(/*! ./shifts-details.page.scss */ "./src/app/shifts-details/shifts-details.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__["FileTransfer"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]])
    ], ShiftsDetailsPage);
    return ShiftsDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=shifts-details-shifts-details-module-es5.js.map