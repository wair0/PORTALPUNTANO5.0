(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["driverLicense-driverLicense-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/driverLicense/driverLicense.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/driverLicense/driverLicense.page.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>LICENCIA DE CONDUCIR</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-list >\r\n      <ion-item lines=\"none\">\r\n        <!-- <ion-card> -->\r\n          <div style=\"width: 100%; text-align: center; text-align: -webkit-center;\">\r\n              <ion-img style=\"width: 75%;\" [src]=\"'data:image/jpeg;base64,'+driverLicense.qrBase64\"></ion-img>\r\n          </div>\r\n            <!-- </ion-card> -->\r\n            </ion-item>\r\n    <ion-item lines=\"none\">\r\n        <ion-label class=\"ion-text-wrap\" >\r\n            <ion-text  >\r\n              <h1 class=\"title-big\"style=\"text-align: center; font-size: 8vw;\"><b>{{driverLicense.firstName}} {{driverLicense.lastName}}</b></h1>\r\n            </ion-text>\r\n          </ion-label>\r\n    </ion-item>\r\n    <ion-item lines=\"none\" *ngIf=\"1>=driverLicense.driverLicenseTypes.length\">\r\n        <ion-label class=\"ion-text-wrap\" style=\"text-align: center;\">\r\n            <ion-text  >\r\n              <h2 class=\"title\" style=\"text-align: center; margin-top: 5px; font-size: 6vw;\"><b>Categoría:</b></h2>\r\n              <div style=\"display: inline;\" *ngFor=\"let driverLicenseType of driverLicense.driverLicenseTypes; let i = index\">\r\n                  <h2 class=\"content\" style=\"display: inline; text-align: center; font-size: 6vw;\">{{driverLicenseType.name}}</h2>\r\n                  <h2 class=\"content\" style=\"display: inline; text-align: center; font-size: 6vw;\" *ngIf=\"driverLicense.driverLicenseTypes.length>i+1\">, </h2>\r\n              </div>\r\n            </ion-text>\r\n          </ion-label>\r\n    </ion-item>\r\n    <ion-item lines=\"none\" *ngIf=\"driverLicense.driverLicenseTypes.length>1\">\r\n        <ion-label class=\"ion-text-wrap\" style=\"text-align: center; \" >\r\n            <ion-text>\r\n              <h2 class=\"title\" style=\"text-align: center; margin-top: 5px; font-size: 6vw;\" ><b>Categorías:</b></h2>\r\n              <div style=\"display: inline; text-align: center;\" *ngFor=\"let driverLicenseType of driverLicense.driverLicenseTypes; let i = index\">\r\n                  <h2 class=\"content\" style=\"display: inline; text-align: center; font-size: 6vw;\">{{driverLicenseType.name}}</h2>\r\n                  <h2 class=\"content\" style=\"display: inline; text-align: center; font-size: 6vw;\" *ngIf=\"driverLicense.driverLicenseTypes.length>i+1\">, </h2>\r\n              </div>\r\n            </ion-text>\r\n          </ion-label>\r\n\r\n    </ion-item>\r\n\r\n\r\n    <ion-item lines=\"none\" >\r\n        <ion-label class=\"ion-text-wrap\" >\r\n            <ion-text  >\r\n              <h2 class=\"title\" style=\"text-align: center; margin-top: 10px; font-size: 6vw;\"><b>Fecha de vencimiento: </b></h2>\r\n              <h2 class=\"content\" style=\"text-align: center; font-size: 6vw;\">{{driverLicense.dateTo}}</h2>\r\n            </ion-text>\r\n          </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item style=\"background-color: blue\" lines=\"none\" *ngIf=\"driverLicense.driverLicenseVisas!=null && driverLicense.driverLicenseVisas.length>0\">\r\n        <ion-label class=\"ion-text-wrap\">\r\n            <ion-text >\r\n              <h2 class=\"title\" style=\"text-align: center; margin-top: 10px; font-size: 6vw;\"><b>Visado:</b></h2>\r\n              <div  *ngFor=\"let driverLicenseVisa of driverLicense.driverLicenseVisas; let i = index\">\r\n                  <h2 class=\"content\" style=\"text-align: center; font-size: 6vw;\" >{{driverLicenseVisa.visaDate}}</h2>\r\n              </div>\r\n            </ion-text>\r\n          </ion-label>\r\n\r\n    </ion-item>\r\n\r\n    </ion-list>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n      <ion-buttons>\r\n        <ion-button (click)=\"goToHome()\">\r\n          <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\" ></ion-icon>\r\n        </ion-button>\r\n        </ion-buttons>\r\n      </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/driverLicense/driverLicense.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/driverLicense/driverLicense.module.ts ***!
  \*******************************************************/
/*! exports provided: DriverLicenseModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DriverLicenseModule", function() { return DriverLicenseModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _driverLicense_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./driverLicense.page */ "./src/app/driverLicense/driverLicense.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");











let DriverLicenseModule = class DriverLicenseModule {
};
DriverLicenseModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _driverLicense_page__WEBPACK_IMPORTED_MODULE_6__["DriverLicensePage"]
                }
            ])
        ],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__["FileOpener"]],
        declarations: [_driverLicense_page__WEBPACK_IMPORTED_MODULE_6__["DriverLicensePage"]]
    })
], DriverLicenseModule);



/***/ }),

/***/ "./src/app/driverLicense/driverLicense.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/driverLicense/driverLicense.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #F7931E;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #F7931E;\n}\n\n.header-text {\n  margin-right: 5%;\n  padding-left: 20px;\n  width: 100%;\n  padding-bottom: 10px;\n  padding-top: 10px;\n  background-color: #F7931E;\n  color: #FFFFFF;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #F7931E;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\n.title-big {\n  font-size: 2.7em;\n}\n\n.title {\n  font-size: 2em;\n}\n\n.content {\n  font-size: 1.8em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZHJpdmVyTGljZW5zZS9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXGRyaXZlckxpY2Vuc2VcXGRyaXZlckxpY2Vuc2UucGFnZS5zY3NzIiwic3JjL2FwcC9kcml2ZXJMaWNlbnNlL2RyaXZlckxpY2Vuc2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBRE1BO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0hKOztBRE1BO0VBQ0ksZ0NBQUE7QUNISjs7QURNRztFQUVDLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDhCQUFBO0FDSko7O0FET0c7RUFDQyxlQUFBO0VBQ0EsZ0JBQUE7QUNKSjs7QURPRztFQUNJLG1CQUFBO0VBQ0Esa0JBQUE7QUNKUDs7QURPRztFQUNDLHFCQUFBO0FDSko7O0FET0c7RUFDQyxjQUFBO0FDSko7O0FET0E7RUFDSSx5QkFBQTtBQ0pKOztBRE9HO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0FDSlA7O0FEUUc7RUFDQyxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQ0xKOztBRFFBO0VBQ0ksMkJBQUE7RUFDQSxpQ0FBQTtBQ0xKOztBRFFBO0VBQ0ksMkJBQUE7QUNMSjs7QURRQTtFQUNJLGdCQUFBO0FDTEo7O0FEUUU7RUFDRSxjQUFBO0FDTEo7O0FEUUU7RUFDRSxnQkFBQTtBQ0xKIiwiZmlsZSI6InNyYy9hcHAvZHJpdmVyTGljZW5zZS9kcml2ZXJMaWNlbnNlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZWR7XHJcbiAgICBjb2xvcjogI0Y3OTMxRVxyXG59XHJcblxyXG4vLyBpb24taWNvbiB7XHJcbi8vICAgICBjb2xvcjogI0Y3OTMxRTtcclxuLy8gICB9XHJcblxyXG5pb24tdGl0bGV7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA1JTtcclxuICAgIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgICBmb250LXNpemU6IDV2dztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XHJcbiAgICBib3JkZXItYm90dG9tOjFweCBzb2xpZCAjRjc5MzFFO1xyXG4gICB9XHJcblxyXG4gICAuaGVhZGVyLXRleHR7XHJcbiAgICAvLyBib3JkZXItYm90dG9tOjJweCBzb2xpZCAjNTM1MzUzO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICAgIHBhZGRpbmctbGVmdDogMjBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgICBwYWRkaW5nLXRvcDogMTBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGNzkzMUU7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHggIWltcG9ydGFudDtcclxuICAgfVxyXG5cclxuICAgaW9uLWl0ZW17XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICB9XHJcblxyXG4gICBpb24tbGlzdHtcclxuICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICBtYXJnaW4tYm90dG9tOjBweDtcclxuICAgfVxyXG5cclxuICAgaW9uLWhlYWRlciBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogI0Y3OTMxRTtcclxuICAgIFxyXG4gICB9XHJcbiAgIGlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxle1xyXG4gICAgY29sb3I6ICNGRkZGRkY7XHJcbiAgIH1cclxuXHJcbi53aGl0ZXtcclxuICAgIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbiAgIGlvbi1sYWJlbHtcclxuICAgICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgICAgIG1hcmdpbi10b3A6IDBweDtcclxuICAgfVxyXG5cclxuXHJcbiAgIGlvbi1jb250ZW50IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zYy1pb24tY2FyZC1tZC1oIHtcclxuICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICAgIC13ZWJraXQtYm94LXNoYWRvdzpcIlwiICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1jYXJke1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGl0bGUtYmlnIHtcclxuICAgIGZvbnQtc2l6ZTogMi43ZW07XHJcbiAgfVxyXG5cclxuICAudGl0bGUge1xyXG4gICAgZm9udC1zaXplOiAyZW07XHJcbiAgfVxyXG5cclxuICAuY29udGVudCB7XHJcbiAgICBmb250LXNpemU6IDEuOGVtO1xyXG4gIH1cclxuIiwiLnJlZCB7XG4gIGNvbG9yOiAjRjc5MzFFO1xufVxuXG5pb24tdGl0bGUge1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgZm9udC1zaXplOiA1dnc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRjc5MzFFO1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNGNzkzMUU7XG4gIGNvbG9yOiAjRkZGRkZGO1xuICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG5pb24tbGlzdCB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogI0Y3OTMxRTtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI0ZGRkZGRjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5zYy1pb24tY2FyZC1tZC1oIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAtd2Via2l0LWJveC1zaGFkb3c6IFwiXCIgIWltcG9ydGFudDtcbn1cblxuaW9uLWNhcmQge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbi50aXRsZS1iaWcge1xuICBmb250LXNpemU6IDIuN2VtO1xufVxuXG4udGl0bGUge1xuICBmb250LXNpemU6IDJlbTtcbn1cblxuLmNvbnRlbnQge1xuICBmb250LXNpemU6IDEuOGVtO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/driverLicense/driverLicense.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/driverLicense/driverLicense.page.ts ***!
  \*****************************************************/
/*! exports provided: DriverLicensePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DriverLicensePage", function() { return DriverLicensePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");











let DriverLicensePage = class DriverLicensePage {
    constructor(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, screenOrientation, statusBar, navController) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.driverLicense = this.router.getCurrentNavigation().extras.state.driverLicense;
                this.token = this.router.getCurrentNavigation().extras.state.token;
            }
        });
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#F7931E');
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
    ngOnInit() {
    }
};
DriverLicensePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
DriverLicensePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-driverLicense',
        template: __webpack_require__(/*! raw-loader!./driverLicense.page.html */ "./node_modules/raw-loader/index.js!./src/app/driverLicense/driverLicense.page.html"),
        styles: [__webpack_require__(/*! ./driverLicense.page.scss */ "./src/app/driverLicense/driverLicense.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"],
        _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
        _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
], DriverLicensePage);



/***/ })

}]);
//# sourceMappingURL=driverLicense-driverLicense-module-es2015.js.map