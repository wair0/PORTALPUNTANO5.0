(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["RM-health-certificates-health-certificates-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/RM/health-certificates/health-certificate-detail/health-certificate-detail.component.html":
/*!*************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RM/health-certificates/health-certificate-detail/health-certificate-detail.component.html ***!
  \*************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTROS MÉDICOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"consultation\" *ngIf=\"currentCertificate\">\r\n    <div class=\"consultation__header\">\r\n      <h2 class=\"header-text\"><b>Datos del Certificado</b></h2>\r\n    </div>\r\n    <div class=\"consultation__content\">\r\n      <p>Profesional: <b>{{currentCertificate.consultation.professionalName}}</b></p>\r\n        <p>Matricula: <b>{{currentCertificate.consultation.license}}</b></p>\r\n        <p>Fecha y Hora: <b>{{currentCertificate.consultation.dateCreated}}</b></p>\r\n        <p>Especialidad: <b>{{currentCertificate.consultation.specialty}}</b></p>\r\n        <p>Tipo de Certificado: <b>{{currentCertificate.type?.name}}</b></p>\r\n        <p>Diagnóstico: <b>{{currentCertificate.diagnosisDescription}}</b></p>\r\n        <p *ngIf=\"currentCertificate.timePeriod\">Tipo de Licencia: <b>{{currentCertificate.licenseType?.name}}</b></p>\r\n        <p *ngIf=\"currentCertificate.timePeriod\">Periodo: <b>{{currentCertificate.timePeriod}} {{currentCertificate.periodType?.name}}</b></p>\r\n        <p *ngIf=\"currentCertificate.restrictionsAndLimitations\">Restricciones y LImitaciones: <b>{{currentCertificate.restrictionsAndLimitations}}</b></p>\r\n    </div>\r\n\r\n    <div class=\"consultation__download-button\" *ngIf=\"currentCertificate.pdfPathName\">\r\n      <button class=\"download-button\" (click)=\"download(currentCertificate.pdfPathName)\">\r\n        <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"\r\n          x=\"0px\" y=\"0px\" width=\"100%\" height=\"100%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\"\r\n          xml:space=\"preserve\">\r\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#EC1C24\" d=\"M862.973,656.11h-89.835v148.416\r\n          c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n          c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n          c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n          c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n          C840.518,409.458,840.518,415.762,837.57,419.12\" />\r\n        </svg>\r\n      </button>\r\n    </div>\r\n\r\n  </div>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" name=\"home\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/RM/health-certificates/health-certificates.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RM/health-certificates/health-certificates.component.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-button icon=\"\" text=\"Atrás\" class=\"white\" (click)=\"goToBack()\">\r\n        Atras\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTROS MÉDICOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-list-header>\r\n      <h2 class=\"header-text\"><b>MIS CERTIFICADOS</b></h2>\r\n    </ion-list-header>\r\n  </ion-list>\r\n  <ion-item *ngIf=\"!hasCertificates\">\r\n    <p>No cuenta con certificados cargados.</p>\r\n  </ion-item>\r\n  <div *ngIf=\"hasCertificates\">\r\n    <div class=\"search\">\r\n      <ion-item class='w-100'>\r\n        <ion-label>Fecha Desde</ion-label>\r\n        <ion-datetime displayFormat=\"YYYY-MM-DD\" [(ngModel)]=\"dateFrom\" doneText=\"Aceptar\" cancelText=\"Cerrar\">\r\n        </ion-datetime>\r\n      </ion-item>\r\n\r\n      <ion-item class=\"w-100\">\r\n        <ion-label>Especialidad</ion-label>\r\n        <ion-select okText=\"Aceptar\" cancelText=\"Cerrar\" [(ngModel)]=\"currentSpecialty\">\r\n          <ion-select-option [value]=null>Todas las especialidades</ion-select-option>\r\n          <ion-content *ngFor=\"let item of specialties\">\r\n            <ion-select-option value={{item}}>{{item}}</ion-select-option>\r\n          </ion-content>\r\n        </ion-select>\r\n      </ion-item>\r\n      <div class=\"item-buttons\">\r\n        <div [ngClass]=\"canCleanFilter ? 'search__btn' : 'search__btn__disabled'\" (click)=\"cleanFilters()\">\r\n          Limpiar\r\n        </div>\r\n        <div [ngClass]=\"canSearch ? 'search__btn' : 'search__btn__disabled'\" (click)=\"filterCertificates()\">\r\n          Buscar\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <ion-list>\r\n      <ion-item *ngIf=\"healthCertificates.length === 0\">\r\n        <p>No se encontraron consultas</p>\r\n      </ion-item>\r\n\r\n      <ion-item *ngFor=\"let item of healthCertificates\" (click)=\"openCertificateDetail(item)\">\r\n        <ion-label *ngIf=\"item\">\r\n          <ion-item-divider>\r\n            <div class=\"item-header\">\r\n              <ion-text class='text-header'>\r\n                {{item.consultation.dateCreated | slice: 0:10}}\r\n              </ion-text>\r\n              <ion-text class='text-header'>\r\n                <b>{{item.type.name}}</b>\r\n              </ion-text>\r\n            </div>\r\n\r\n          </ion-item-divider>\r\n          <ion-text>\r\n            <h2 class='secondary'>{{item.diagnosisDescription}}</h2>\r\n          </ion-text>\r\n          <ion-text>\r\n            <h2 class='secondary'>{{item.timePeriod}} {{item.periodType.name}}</h2>\r\n          </ion-text>\r\n          <ion-text>\r\n            <h2 class='secondary'>{{item.consultation.professionalName}}</h2>\r\n          </ion-text>\r\n          <ion-text>\r\n            <h2 class='secondary'>{{item.consultation.healthCenterName}}</h2>\r\n          </ion-text>\r\n        </ion-label>\r\n      </ion-item>\r\n\r\n    </ion-list>\r\n\r\n  </div>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" name=\"home\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/RM/health-certificates/health-certificate-detail/health-certificate-detail.component.scss":
/*!***********************************************************************************************************!*\
  !*** ./src/app/RM/health-certificates/health-certificate-detail/health-certificate-detail.component.scss ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #EC272F;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #EC272F;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #EC272F;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.download-icon {\n  width: 30%;\n  height: 30%;\n  text-align: center;\n}\n\n.consultation {\n  padding-left: 1rem;\n  padding-right: 1rem;\n}\n\n.consultation__header {\n  margin-top: 1.8rem;\n}\n\n.consultation__data {\n  font-weight: 700;\n}\n\n.consultation__content {\n  padding-left: 0.5rem;\n  padding-right: 0.5rem;\n}\n\n.diagnosis__name {\n  font-size: 1.25rem;\n}\n\n.text-regular {\n  font-weight: 500;\n}\n\n.download-button {\n  background-color: transparent;\n}\n\n.consultation__download-button {\n  width: 100%;\n  display: flex;\n  justify-content: center;\n  margin-top: 2rem;\n}\n\n.download-button {\n  width: 35%;\n  background-color: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUk0vaGVhbHRoLWNlcnRpZmljYXRlcy9oZWFsdGgtY2VydGlmaWNhdGUtZGV0YWlsL0Q6XFxSZXBvc2l0b3Jpb3NcXHBvcnRhbC1pb25pYy9zcmNcXGFwcFxcUk1cXGhlYWx0aC1jZXJ0aWZpY2F0ZXNcXGhlYWx0aC1jZXJ0aWZpY2F0ZS1kZXRhaWxcXGhlYWx0aC1jZXJ0aWZpY2F0ZS1kZXRhaWwuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL1JNL2hlYWx0aC1jZXJ0aWZpY2F0ZXMvaGVhbHRoLWNlcnRpZmljYXRlLWRldGFpbC9oZWFsdGgtY2VydGlmaWNhdGUtZGV0YWlsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBREVBO0VBQ0ksZ0NBQUE7QUNDSjs7QURFQTtFQUNJLGdDQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7QUNDSjs7QURFQTtFQUNJLG1CQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFQTtFQUNJLHFCQUFBO0FDQ0o7O0FER0E7RUFDSSxjQUFBO0FDQUo7O0FER0E7RUFDSSx5QkFBQTtBQ0FKOztBREdBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0FDQUo7O0FESUE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQ0RKOztBRElBO0VBQ0ksMkJBQUE7RUFDQSxpQ0FBQTtBQ0RKOztBRElBO0VBQ0ksMkJBQUE7QUNESjs7QURJQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNESjs7QURJQTtFQUNJLFVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNESjs7QURJQTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7QUNESjs7QURJQTtFQUNJLGtCQUFBO0FDREo7O0FESUE7RUFDSSxnQkFBQTtBQ0RKOztBRElBO0VBQ0ksb0JBQUE7RUFDQSxxQkFBQTtBQ0RKOztBRElBO0VBQ0ksa0JBQUE7QUNESjs7QURJQTtFQUNJLGdCQUFBO0FDREo7O0FESUE7RUFDSSw2QkFBQTtBQ0RKOztBRElBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FDREo7O0FESUE7RUFDSSxVQUFBO0VBQ0EsNkJBQUE7QUNESiIsImZpbGUiOiJzcmMvYXBwL1JNL2hlYWx0aC1jZXJ0aWZpY2F0ZXMvaGVhbHRoLWNlcnRpZmljYXRlLWRldGFpbC9oZWFsdGgtY2VydGlmaWNhdGUtZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJlZCB7XHJcbiAgICBjb2xvcjogI0VDMjcyRlxyXG59XHJcblxyXG5pb24taXRlbS5ib3JkZXItcmVkIHtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRUMyNzJGO1xyXG59XHJcblxyXG4uaGVhZGVyLXRleHQge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG59XHJcblxyXG5pb24tbGlzdCB7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogI0VDMjcyRjtcclxuXHJcbn1cclxuXHJcbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcclxuICAgIGNvbG9yOiAjRkZGRkZGO1xyXG59XHJcblxyXG4ud2hpdGUge1xyXG4gICAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWxhYmVsIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgIG1hcmdpbi10b3A6IDBweDtcclxufVxyXG5cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zYy1pb24tY2FyZC1tZC1oIHtcclxuICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICAgIC13ZWJraXQtYm94LXNoYWRvdzogXCJcIiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tY2FyZCB7XHJcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi10aXRsZSB7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA1JTtcclxuICAgIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgICBmb250LXNpemU6IDV2dztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLmRvd25sb2FkLWljb24ge1xyXG4gICAgd2lkdGg6IDMwJTtcclxuICAgIGhlaWdodDogMzAlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uY29uc3VsdGF0aW9uIHtcclxuICAgIHBhZGRpbmctbGVmdDogMXJlbTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDFyZW07XHJcbn1cclxuXHJcbi5jb25zdWx0YXRpb25fX2hlYWRlciB7XHJcbiAgICBtYXJnaW4tdG9wOiAxLjhyZW07XHJcbn1cclxuXHJcbi5jb25zdWx0YXRpb25fX2RhdGEge1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcclxufVxyXG5cclxuLmNvbnN1bHRhdGlvbl9fY29udGVudCB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IC41cmVtO1xyXG4gICAgcGFkZGluZy1yaWdodDogLjVyZW07XHJcbn1cclxuXHJcbi5kaWFnbm9zaXNfX25hbWUge1xyXG4gICAgZm9udC1zaXplOiAxLjI1cmVtO1xyXG59XHJcblxyXG4udGV4dC1yZWd1bGFyIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuXHJcbi5kb3dubG9hZC1idXR0b24ge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi5jb25zdWx0YXRpb25fX2Rvd25sb2FkLWJ1dHRvbiB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDJyZW07XHJcbn1cclxuXHJcbi5kb3dubG9hZC1idXR0b24ge1xyXG4gICAgd2lkdGg6IDM1JTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG59IiwiLnJlZCB7XG4gIGNvbG9yOiAjRUMyNzJGO1xufVxuXG5pb24taXRlbS5ib3JkZXItcmVkIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNFQzI3MkY7XG59XG5cbi5oZWFkZXItdGV4dCB7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjNTM1MzUzO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG5pb24tbGlzdCB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogI0VDMjcyRjtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI0ZGRkZGRjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5zYy1pb24tY2FyZC1tZC1oIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAtd2Via2l0LWJveC1zaGFkb3c6IFwiXCIgIWltcG9ydGFudDtcbn1cblxuaW9uLWNhcmQge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10aXRsZSB7XG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDUlO1xuICBmb250LXNpemU6IDV2dztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uZG93bmxvYWQtaWNvbiB7XG4gIHdpZHRoOiAzMCU7XG4gIGhlaWdodDogMzAlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb25zdWx0YXRpb24ge1xuICBwYWRkaW5nLWxlZnQ6IDFyZW07XG4gIHBhZGRpbmctcmlnaHQ6IDFyZW07XG59XG5cbi5jb25zdWx0YXRpb25fX2hlYWRlciB7XG4gIG1hcmdpbi10b3A6IDEuOHJlbTtcbn1cblxuLmNvbnN1bHRhdGlvbl9fZGF0YSB7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG5cbi5jb25zdWx0YXRpb25fX2NvbnRlbnQge1xuICBwYWRkaW5nLWxlZnQ6IDAuNXJlbTtcbiAgcGFkZGluZy1yaWdodDogMC41cmVtO1xufVxuXG4uZGlhZ25vc2lzX19uYW1lIHtcbiAgZm9udC1zaXplOiAxLjI1cmVtO1xufVxuXG4udGV4dC1yZWd1bGFyIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuLmRvd25sb2FkLWJ1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4uY29uc3VsdGF0aW9uX19kb3dubG9hZC1idXR0b24ge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDJyZW07XG59XG5cbi5kb3dubG9hZC1idXR0b24ge1xuICB3aWR0aDogMzUlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/RM/health-certificates/health-certificate-detail/health-certificate-detail.component.ts":
/*!*********************************************************************************************************!*\
  !*** ./src/app/RM/health-certificates/health-certificate-detail/health-certificate-detail.component.ts ***!
  \*********************************************************************************************************/
/*! exports provided: HealthCertificateDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HealthCertificateDetailComponent", function() { return HealthCertificateDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_device_device_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/device/device.service */ "./src/app/device/device.service.ts");
/* harmony import */ var src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _health_certificate_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../health-certificate.service */ "./src/app/RM/health-certificates/health-certificate.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");










var HealthCertificateDetailComponent = /** @class */ (function () {
    function HealthCertificateDetailComponent(navController, healthCertificateService, loadingController, storage, transfer, file, platform, deviceDetailsService, fileOpener, alertController) {
        this.navController = navController;
        this.healthCertificateService = healthCertificateService;
        this.loadingController = loadingController;
        this.storage = storage;
        this.transfer = transfer;
        this.file = file;
        this.platform = platform;
        this.deviceDetailsService = deviceDetailsService;
        this.fileOpener = fileOpener;
        this.alertController = alertController;
        this.processErrorRM = function (error) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                _this.loadingController.dismiss();
                _this.storage.get('token').then(function (val) {
                    if (val) {
                        _this.loadingWithMessage("Descargando");
                        _this.refreshUtils.refreshTokenRM(val).then(function (value) {
                            _this.loadingController.dismiss();
                            resolve(value);
                        }).catch(function (errorRefresh) {
                            _this.loadingController.dismiss();
                            if (errorRefresh.status == 401) {
                                _this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].GENERIC_ERROR);
                            }
                            else {
                                _this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        _this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].GENERIC_ERROR);
                    }
                });
            });
        };
    }
    HealthCertificateDetailComponent.prototype.ngOnInit = function () {
        // Cuando no tenga certificado actual lo devuelvo a la vista  general asi vuelve a pedir los datos al backend
        if (!this.healthCertificateService.currentCertificate)
            this.navController.navigateRoot("/health-certificate");
    };
    HealthCertificateDetailComponent.prototype.loadingWithMessage = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: messageText,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    HealthCertificateDetailComponent.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
        this.healthCertificateService.clearStates();
    };
    Object.defineProperty(HealthCertificateDetailComponent.prototype, "currentCertificate", {
        get: function () {
            return this.healthCertificateService.currentCertificate;
        },
        enumerable: true,
        configurable: true
    });
    HealthCertificateDetailComponent.prototype.download = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loadingWithMessage("Descargando");
                this.storage.get('token').then(function (token) {
                    if (token) {
                        var fileName_1 = "Certificado_" + _this.currentCertificate.id + ".pdf";
                        var filePath = src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].URL_RM_PREFIX + "patient/pdf/" + _this.currentCertificate.pdfPathName;
                        var url = encodeURI(filePath);
                        _this.fileTransfer = _this.transfer.create();
                        var options = {
                            headers: {
                                "X-Authorization": "Bearer " + token
                            }
                        };
                        var directory_1 = _this.file.documentsDirectory;
                        if (_this.platform.is("android")) {
                            var soVersion = parseFloat(_this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                            //if(this.file.externalRootDirectory){
                            console.log("[HOME] OS VERSION: " + soVersion);
                            if (soVersion < 11) {
                                if (_this.file.externalRootDirectory) {
                                    directory_1 = _this.file.externalRootDirectory + src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].FOLDER_DOWNLOAD;
                                }
                                else {
                                    directory_1 = _this.file.dataDirectory + src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].FOLDER_DOWNLOAD;
                                }
                            }
                            else {
                                directory_1 = _this.file.dataDirectory + src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].FOLDER_DOWNLOAD;
                            }
                        }
                        _this.fileTransfer.download(url, directory_1 + fileName_1, true, options).then(function (entry) {
                            _this.loadingController.dismiss();
                            //here logging our success downloaded file path in mobile. 
                            console.log('download completed: ' + entry.toURL());
                            _this.file.resolveDirectoryUrl(directory_1).then(function (rootDir) {
                                _this.file.getFile(rootDir, fileName_1, { create: false }).then(function (fileEntry) {
                                    fileEntry.getMetadata(function (metadata) {
                                        if (metadata.size != 0) {
                                            // open downloaded file 
                                            _this.openFileHandler(entry.toURL());
                                            if (_this.platform.is("android")) {
                                                var soVersion = parseFloat(_this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                                                if (soVersion < 11) {
                                                    if (_this.file.externalRootDirectory) {
                                                        _this.alert("Documento \"" + fileName_1 + "\" guardado en la carpeta \"" + src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                                                    }
                                                }
                                            }
                                        }
                                        else {
                                            _this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].FILE_SIZE_0_ERROR);
                                        }
                                    });
                                });
                            });
                        }).catch(function (error) {
                            _this.loadingController.dismiss();
                            if (error != null && error.http_status != null && error.http_status == 409) {
                                _this.alert(JSON.parse(error.body).message);
                            }
                            else {
                                _this.processErrorRM(error).then(function (value) {
                                    _this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].GENERIC_ERROR);
                                });
                            }
                        });
                    }
                    else {
                        _this.loadingController.dismiss();
                        _this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_7__["constants"].GENERIC_ERROR);
                    }
                });
                return [2 /*return*/];
            });
        });
    };
    HealthCertificateDetailComponent.prototype.openFileHandler = function (path) {
        this.fileOpener.open(path, "")
            .then(function () { return console.log('File is opened'); })
            .catch(function (e) { return console.log('Error opening file', e); });
    };
    HealthCertificateDetailComponent.prototype.alert = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Portal puntano',
                            message: messageText,
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel',
                                    cssClass: 'primary',
                                    handler: function () {
                                        console.log('OK pressed!!');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    HealthCertificateDetailComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
        { type: _health_certificate_service__WEBPACK_IMPORTED_MODULE_8__["HealthCertificateService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_9__["Storage"] },
        { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_3__["FileTransfer"] },
        { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_4__["File"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"] },
        { type: src_app_device_device_service__WEBPACK_IMPORTED_MODULE_6__["DeviceDetailsService"] },
        { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_2__["FileOpener"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] }
    ]; };
    HealthCertificateDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-health-certificate-detail',
            template: __webpack_require__(/*! raw-loader!./health-certificate-detail.component.html */ "./node_modules/raw-loader/index.js!./src/app/RM/health-certificates/health-certificate-detail/health-certificate-detail.component.html"),
            styles: [__webpack_require__(/*! ./health-certificate-detail.component.scss */ "./src/app/RM/health-certificates/health-certificate-detail/health-certificate-detail.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"],
            _health_certificate_service__WEBPACK_IMPORTED_MODULE_8__["HealthCertificateService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_9__["Storage"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_3__["FileTransfer"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_4__["File"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"],
            src_app_device_device_service__WEBPACK_IMPORTED_MODULE_6__["DeviceDetailsService"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_2__["FileOpener"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"]])
    ], HealthCertificateDetailComponent);
    return HealthCertificateDetailComponent;
}());



/***/ }),

/***/ "./src/app/RM/health-certificates/health-certificate.service.ts":
/*!**********************************************************************!*\
  !*** ./src/app/RM/health-certificates/health-certificate.service.ts ***!
  \**********************************************************************/
/*! exports provided: HealthCertificateService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HealthCertificateService", function() { return HealthCertificateService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);



var HealthCertificateService = /** @class */ (function () {
    function HealthCertificateService() {
        /**
         * Debe tener todos los certificados en memoria
         */
        this._healthCertificates = [];
        this._filteredCertificates = [];
    }
    Object.defineProperty(HealthCertificateService.prototype, "healthCertificates", {
        set: function (healthCertificates) {
            this.clearStates();
            this._healthCertificates = healthCertificates;
            // Si existen certificados, voy a mostrar los ultimos 3
            this._filteredCertificates = this._healthCertificates.slice(0, 3).slice();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificateService.prototype, "hasCertificates", {
        get: function () {
            return this._healthCertificates != null && this._healthCertificates.length > 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificateService.prototype, "currentCertificate", {
        get: function () {
            return this._currentCertificate;
        },
        set: function (certificate) {
            this._currentCertificate = certificate;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificateService.prototype, "dateFrom", {
        get: function () {
            return this._dateFrom ? this._dateFrom : null;
        },
        set: function (date) {
            this._dateFrom = date;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificateService.prototype, "specialties", {
        get: function () {
            var specialties = new Set(this._healthCertificates.map(function (c) { return c.consultation.specialty; }));
            return specialties;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificateService.prototype, "currentSpecialty", {
        get: function () {
            return this._currentSpecialty;
        },
        set: function (specialty) {
            this._currentSpecialty = specialty;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificateService.prototype, "canCleanFilter", {
        get: function () {
            return this._dateFrom != null || this._currentSpecialty != null;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificateService.prototype, "canSearch", {
        get: function () {
            return this._dateFrom != null;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificateService.prototype, "filteredCertificates", {
        get: function () {
            return this._filteredCertificates;
        },
        enumerable: true,
        configurable: true
    });
    HealthCertificateService.prototype.clearStates = function () {
        this._healthCertificates = [];
        this._currentCertificate = null;
        this._dateFrom = null;
        this._currentSpecialty = null;
        this._filteredCertificates = [];
    };
    HealthCertificateService.prototype.clearCurrentFilterStates = function () {
        this._dateFrom = null;
        this._currentSpecialty = null;
        // Al darle a limpiar filtros vuelvo a mostrar los ultimos 3 certificados
        this._filteredCertificates = this._healthCertificates.slice(0, 3).slice();
    };
    /**
     * Tengo que filtrar los certificados por fecha y especialidad
     */
    HealthCertificateService.prototype.filterCertificates = function () {
        var _this = this;
        this._filteredCertificates = this._healthCertificates.filter(function (c) {
            var dateConsultation = moment__WEBPACK_IMPORTED_MODULE_2__(c.consultation.dateCreated, "DD-MM-YYYY HH:mm:ss");
            var dateFrom = moment__WEBPACK_IMPORTED_MODULE_2__(_this._dateFrom);
            var compareDates = dateConsultation.isSameOrAfter(dateFrom.startOf('day'));
            // Si tiene especialidad seleccionada entonces tengo que compararlo, caso contrario siempre cumple
            debugger;
            var compareSpecialty = _this._currentSpecialty ? _this._currentSpecialty === c.consultation.specialty : true;
            return compareDates && compareSpecialty;
        });
    };
    HealthCertificateService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], HealthCertificateService);
    return HealthCertificateService;
}());



/***/ }),

/***/ "./src/app/RM/health-certificates/health-certificates.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/RM/health-certificates/health-certificates.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #EC272F;\n}\n\n.secondary {\n  color: #616161;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #EC272F;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.content {\n  padding: 0 1rem;\n}\n\n.display-none {\n  display: none;\n}\n\n.icon-item {\n  position: relative;\n}\n\n.icon-lock {\n  position: absolute;\n  top: 0;\n  left: 0;\n  z-index: 9999999;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.content-icon {\n  display: flex;\n  align-items: flex-start;\n  justify-content: center;\n  font-size: 2rem;\n  margin-top: 1rem;\n  color: #EC272F;\n}\n\n.icon-trash {\n  font-size: 1.5rem;\n  color: #EC272F;\n}\n\n.icon-trash-container {\n  height: 100%;\n  width: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n::ng-deep .mat-expansion-panel {\n  box-shadow: none !important;\n  border: 1px solid #EC272F;\n}\n\n::ng-deep .mat-expansion-panel-header,\n::ng-deep .mat-expansion-panel-header:hover,\n::ng-deep .mat-expansion-panel-header:focus {\n  background: #EC272F !important;\n  box-shadow: none;\n}\n\n::ng-deep .mat-expansion-panel-header-title,\n::ng-deep .mat-expansion-indicator::after {\n  color: #fff;\n}\n\n::ng-deep .mat-expansion-panel-header-title {\n  font-size: 1.1rem;\n}\n\n::ng-deep .mat-expansion-panel-body {\n  padding: 1rem 0.5rem !important;\n}\n\n::ng-deep .mat-expansion-panel.hidden {\n  box-shadow: none !important;\n  border: 1px solid #969696;\n}\n\n::ng-deep .mat-expansion-panel-header.hidden,\n::ng-deep .mat-expansion-panel-header.hidden:hover,\n::ng-deep .mat-expansion-panel-header.hidden:focus {\n  background: #969696 !important;\n  box-shadow: none;\n}\n\n.search {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding-left: 1rem;\n  padding-right: 1rem;\n}\n\n.search__btn {\n  background: #EC272F;\n  color: white;\n  padding: 0.5rem 3rem;\n  border-radius: 5rem;\n  margin: 0.5rem;\n}\n\n.search__btn__disabled {\n  background: #ff9498;\n  color: white;\n  padding: 0.5rem 3rem;\n  border-radius: 5rem;\n  margin: 0.5rem;\n}\n\n.search__title {\n  margin-left: 1rem;\n}\n\n.input-date {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\nion-select {\n  max-width: 100% !important;\n}\n\nion-item-divider {\n  padding: 0px !important;\n  background-color: transparent;\n  border-bottom: 2px solid #000000;\n}\n\n.item-header {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n}\n\n.item-buttons {\n  width: 100%;\n  display: flex;\n  justify-content: center;\n}\n\n.text-header {\n  color: #000000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUk0vaGVhbHRoLWNlcnRpZmljYXRlcy9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXFJNXFxoZWFsdGgtY2VydGlmaWNhdGVzXFxoZWFsdGgtY2VydGlmaWNhdGVzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9STS9oZWFsdGgtY2VydGlmaWNhdGVzL2hlYWx0aC1jZXJ0aWZpY2F0ZXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0FDQ0o7O0FERUE7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSxxQkFBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtBQ0NKOztBREVBO0VBQ0kseUJBQUE7QUNDSjs7QURFQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsZ0JBQUE7QUNDSjs7QURFQTtFQUNJLFdBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVBO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FDQ0o7O0FESUE7RUFDSSwyQkFBQTtFQUNBLHlCQUFBO0FDREo7O0FESUE7OztFQUdJLDhCQUFBO0VBQ0EsZ0JBQUE7QUNESjs7QURJQTs7RUFFSSxXQUFBO0FDREo7O0FESUE7RUFDSSxpQkFBQTtBQ0RKOztBREtBO0VBQ0ksK0JBQUE7QUNGSjs7QURLQTtFQUNJLDJCQUFBO0VBQ0EseUJBQUE7QUNGSjs7QURLQTs7O0VBR0ksOEJBQUE7RUFDQSxnQkFBQTtBQ0ZKOztBRE1BO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNISjs7QURNQTtFQUNJLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FDSEo7O0FETUE7RUFDSSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQ0hKOztBRE1BO0VBQ0ksaUJBQUE7QUNISjs7QURNQTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDSEo7O0FETUE7RUFDSSwwQkFBQTtBQ0hKOztBRE1BO0VBQ0ksdUJBQUE7RUFDQSw2QkFBQTtFQUNBLGdDQUFBO0FDSEo7O0FETUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0FDSEo7O0FETUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0FDSEo7O0FETUE7RUFDSSxjQUFBO0FDSEoiLCJmaWxlIjoic3JjL2FwcC9STS9oZWFsdGgtY2VydGlmaWNhdGVzL2hlYWx0aC1jZXJ0aWZpY2F0ZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVkIHtcclxuICAgIGNvbG9yOiAjRUMyNzJGO1xyXG59XHJcblxyXG4uc2Vjb25kYXJ5IHtcclxuICAgIGNvbG9yOiAjNjE2MTYxO1xyXG59XHJcblxyXG4uaGVhZGVyLXRleHQge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxufVxyXG5cclxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNFQzI3MkY7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcclxuICAgIGNvbG9yOiAjRkZGRkZGO1xyXG59XHJcblxyXG4ud2hpdGUge1xyXG4gICAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLXRpdGxlIHtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIGZvbnQtc2l6ZTogNXZ3O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uY29udGVudCB7XHJcbiAgICBwYWRkaW5nOiAwIDFyZW07XHJcbn1cclxuXHJcbi5kaXNwbGF5LW5vbmUge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuLmljb24taXRlbSB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5pY29uLWxvY2sge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHotaW5kZXg6IDk5OTk5OTk7XHJcbn1cclxuXHJcbi53LTEwMCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLmNvbnRlbnQtaWNvbiB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMnJlbTtcclxuICAgIG1hcmdpbi10b3A6IDFyZW07XHJcbiAgICBjb2xvcjogI0VDMjcyRjtcclxufVxyXG5cclxuLmljb24tdHJhc2gge1xyXG4gICAgZm9udC1zaXplOiAxLjVyZW07XHJcbiAgICBjb2xvcjogI0VDMjcyRjtcclxufVxyXG5cclxuLmljb24tdHJhc2gtY29udGFpbmVyIHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuXHJcbi8vIGFjY29yZGlvbiBlc3RpbG9zOlxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwge1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI0VDMjcyRjtcclxufVxyXG5cclxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlcixcclxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlcjpob3ZlcixcclxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlcjpmb2N1cyB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRUMyNzJGICFpbXBvcnRhbnQ7XHJcbiAgICBib3gtc2hhZG93OiBub25lO1xyXG59XHJcblxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLXRpdGxlLFxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24taW5kaWNhdG9yOjphZnRlciB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxufVxyXG5cclxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci10aXRsZSB7XHJcbiAgICBmb250LXNpemU6IDEuMXJlbTtcclxufVxyXG5cclxuXHJcbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1ib2R5IHtcclxuICAgIHBhZGRpbmc6IDFyZW0gLjVyZW0gIWltcG9ydGFudDtcclxufVxyXG5cclxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLmhpZGRlbiB7XHJcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjOTY5Njk2O1xyXG59XHJcblxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLmhpZGRlbixcclxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci5oaWRkZW46aG92ZXIsXHJcbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXIuaGlkZGVuOmZvY3VzIHtcclxuICAgIGJhY2tncm91bmQ6ICM5Njk2OTYgIWltcG9ydGFudDtcclxuICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbn1cclxuXHJcblxyXG4uc2VhcmNoIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxcmVtO1xyXG4gICAgcGFkZGluZy1yaWdodDogMXJlbTtcclxufVxyXG5cclxuLnNlYXJjaF9fYnRuIHtcclxuICAgIGJhY2tncm91bmQ6ICNFQzI3MkY7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nOiAuNXJlbSAzcmVtO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXJlbTtcclxuICAgIG1hcmdpbjogMC41cmVtO1xyXG59XHJcblxyXG4uc2VhcmNoX19idG5fX2Rpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQ6ICNmZjk0OTg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nOiAuNXJlbSAzcmVtO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXJlbTtcclxuICAgIG1hcmdpbjogMC41cmVtO1xyXG59XHJcblxyXG4uc2VhcmNoX190aXRsZSB7XHJcbiAgICBtYXJnaW4tbGVmdDogMXJlbTtcclxufVxyXG5cclxuLmlucHV0LWRhdGUge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuaW9uLXNlbGVjdCB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWl0ZW0tZGl2aWRlciB7XHJcbiAgICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICMwMDAwMDA7XHJcbn1cclxuXHJcbi5pdGVtLWhlYWRlciB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuXHJcbi5pdGVtLWJ1dHRvbnMge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi50ZXh0LWhlYWRlcntcclxuICAgIGNvbG9yOiAjMDAwMDAwO1xyXG59IiwiLnJlZCB7XG4gIGNvbG9yOiAjRUMyNzJGO1xufVxuXG4uc2Vjb25kYXJ5IHtcbiAgY29sb3I6ICM2MTYxNjE7XG59XG5cbi5oZWFkZXItdGV4dCB7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjNTM1MzUzO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG5cbmlvbi1saXN0IHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjRUMyNzJGO1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuXG4ud2hpdGUge1xuICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xufVxuXG5pb24tdGl0bGUge1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgZm9udC1zaXplOiA1dnc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRlbnQge1xuICBwYWRkaW5nOiAwIDFyZW07XG59XG5cbi5kaXNwbGF5LW5vbmUge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG4uaWNvbi1pdGVtIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4uaWNvbi1sb2NrIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHotaW5kZXg6IDk5OTk5OTk7XG59XG5cbi53LTEwMCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uY29udGVudC1pY29uIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmb250LXNpemU6IDJyZW07XG4gIG1hcmdpbi10b3A6IDFyZW07XG4gIGNvbG9yOiAjRUMyNzJGO1xufVxuXG4uaWNvbi10cmFzaCB7XG4gIGZvbnQtc2l6ZTogMS41cmVtO1xuICBjb2xvcjogI0VDMjcyRjtcbn1cblxuLmljb24tdHJhc2gtY29udGFpbmVyIHtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgYm9yZGVyOiAxcHggc29saWQgI0VDMjcyRjtcbn1cblxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlcixcbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXI6aG92ZXIsXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyOmZvY3VzIHtcbiAgYmFja2dyb3VuZDogI0VDMjcyRiAhaW1wb3J0YW50O1xuICBib3gtc2hhZG93OiBub25lO1xufVxuXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLXRpdGxlLFxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLWluZGljYXRvcjo6YWZ0ZXIge1xuICBjb2xvcjogI2ZmZjtcbn1cblxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMS4xcmVtO1xufVxuXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtYm9keSB7XG4gIHBhZGRpbmc6IDFyZW0gMC41cmVtICFpbXBvcnRhbnQ7XG59XG5cbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC5oaWRkZW4ge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gIGJvcmRlcjogMXB4IHNvbGlkICM5Njk2OTY7XG59XG5cbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXIuaGlkZGVuLFxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci5oaWRkZW46aG92ZXIsXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLmhpZGRlbjpmb2N1cyB7XG4gIGJhY2tncm91bmQ6ICM5Njk2OTYgIWltcG9ydGFudDtcbiAgYm94LXNoYWRvdzogbm9uZTtcbn1cblxuLnNlYXJjaCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBwYWRkaW5nLWxlZnQ6IDFyZW07XG4gIHBhZGRpbmctcmlnaHQ6IDFyZW07XG59XG5cbi5zZWFyY2hfX2J0biB7XG4gIGJhY2tncm91bmQ6ICNFQzI3MkY7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogMC41cmVtIDNyZW07XG4gIGJvcmRlci1yYWRpdXM6IDVyZW07XG4gIG1hcmdpbjogMC41cmVtO1xufVxuXG4uc2VhcmNoX19idG5fX2Rpc2FibGVkIHtcbiAgYmFja2dyb3VuZDogI2ZmOTQ5ODtcbiAgY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nOiAwLjVyZW0gM3JlbTtcbiAgYm9yZGVyLXJhZGl1czogNXJlbTtcbiAgbWFyZ2luOiAwLjVyZW07XG59XG5cbi5zZWFyY2hfX3RpdGxlIHtcbiAgbWFyZ2luLWxlZnQ6IDFyZW07XG59XG5cbi5pbnB1dC1kYXRlIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbmlvbi1zZWxlY3Qge1xuICBtYXgtd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW0tZGl2aWRlciB7XG4gIHBhZGRpbmc6IDBweCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICMwMDAwMDA7XG59XG5cbi5pdGVtLWhlYWRlciB7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG5cbi5pdGVtLWJ1dHRvbnMge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi50ZXh0LWhlYWRlciB7XG4gIGNvbG9yOiAjMDAwMDAwO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/RM/health-certificates/health-certificates.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/RM/health-certificates/health-certificates.component.ts ***!
  \*************************************************************************/
/*! exports provided: HealthCertificatesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HealthCertificatesComponent", function() { return HealthCertificatesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_health_certificate_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/health-certificate-api.service */ "./src/app/services/health-certificate-api.service.ts");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");
/* harmony import */ var _health_certificate_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./health-certificate.service */ "./src/app/RM/health-certificates/health-certificate.service.ts");








var HealthCertificatesComponent = /** @class */ (function () {
    function HealthCertificatesComponent(navController, router, healthCertificateApiService, healthCertificateService, localStorageService, screenOrientation) {
        this.navController = navController;
        this.router = router;
        this.healthCertificateApiService = healthCertificateApiService;
        this.healthCertificateService = healthCertificateService;
        this.localStorageService = localStorageService;
        this.screenOrientation = screenOrientation;
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    }
    HealthCertificatesComponent.prototype.ngOnInit = function () {
        this.getPatientData();
    };
    HealthCertificatesComponent.prototype.goToBack = function () {
        this.navController.navigateBack("/rm");
        this.healthCertificateService.clearStates();
    };
    HealthCertificatesComponent.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
        this.healthCertificateService.clearStates();
    };
    HealthCertificatesComponent.prototype.openCertificateDetail = function (certificate) {
        this.healthCertificateService.currentCertificate = certificate;
        this.router.navigate(['health-certificate/details']);
    };
    /**
     * Busca todos los certificados del paciente
     */
    HealthCertificatesComponent.prototype.getPatientData = function () {
        var _this = this;
        this.localStorageService.getUserData().then(function (userData) {
            _this.healthCertificateApiService.getByPatientParams(userData.docNumber, userData.sex).subscribe(function (response) {
                _this.healthCertificateService.healthCertificates = response;
            });
        });
    };
    /**
     * Hace el filtrado de certificados en base a los que tiene en memoria
     */
    HealthCertificatesComponent.prototype.filterCertificates = function () {
        if (this.canSearch)
            this.healthCertificateService.filterCertificates();
    };
    HealthCertificatesComponent.prototype.cleanFilters = function () {
        if (this.canCleanFilter)
            this.healthCertificateService.clearCurrentFilterStates();
    };
    Object.defineProperty(HealthCertificatesComponent.prototype, "healthCertificates", {
        get: function () {
            return this.healthCertificateService.filteredCertificates;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificatesComponent.prototype, "hasCertificates", {
        get: function () {
            return this.healthCertificateService.hasCertificates;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificatesComponent.prototype, "specialties", {
        get: function () {
            return this.healthCertificateService.specialties;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificatesComponent.prototype, "currentSpecialty", {
        get: function () {
            return this.healthCertificateService.currentSpecialty;
        },
        set: function (specialty) {
            this.healthCertificateService.currentSpecialty = specialty;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificatesComponent.prototype, "canCleanFilter", {
        get: function () {
            return this.healthCertificateService.canCleanFilter;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificatesComponent.prototype, "dateFrom", {
        get: function () {
            return this.healthCertificateService.dateFrom;
        },
        set: function (date) {
            this.healthCertificateService.dateFrom = date;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HealthCertificatesComponent.prototype, "canSearch", {
        get: function () {
            return this.healthCertificateService.canSearch;
        },
        enumerable: true,
        configurable: true
    });
    HealthCertificatesComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: src_app_services_health_certificate_api_service__WEBPACK_IMPORTED_MODULE_5__["HealthCertificateApiService"] },
        { type: _health_certificate_service__WEBPACK_IMPORTED_MODULE_7__["HealthCertificateService"] },
        { type: src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_6__["LocalStorageService"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__["ScreenOrientation"] }
    ]; };
    HealthCertificatesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-health-certificates',
            template: __webpack_require__(/*! raw-loader!./health-certificates.component.html */ "./node_modules/raw-loader/index.js!./src/app/RM/health-certificates/health-certificates.component.html"),
            styles: [__webpack_require__(/*! ./health-certificates.component.scss */ "./src/app/RM/health-certificates/health-certificates.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            src_app_services_health_certificate_api_service__WEBPACK_IMPORTED_MODULE_5__["HealthCertificateApiService"],
            _health_certificate_service__WEBPACK_IMPORTED_MODULE_7__["HealthCertificateService"],
            src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_6__["LocalStorageService"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__["ScreenOrientation"]])
    ], HealthCertificatesComponent);
    return HealthCertificatesComponent;
}());



/***/ }),

/***/ "./src/app/RM/health-certificates/health-certificates.module.ts":
/*!**********************************************************************!*\
  !*** ./src/app/RM/health-certificates/health-certificates.module.ts ***!
  \**********************************************************************/
/*! exports provided: HealthCertificatesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HealthCertificatesModule", function() { return HealthCertificatesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _health_certificates_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./health-certificates.component */ "./src/app/RM/health-certificates/health-certificates.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/interceptors/interceptor-rm.service */ "./src/app/core/interceptors/interceptor-rm.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _health_certificate_detail_health_certificate_detail_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./health-certificate-detail/health-certificate-detail.component */ "./src/app/RM/health-certificates/health-certificate-detail/health-certificate-detail.component.ts");
/* harmony import */ var src_app_services_health_certificate_api_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/health-certificate-api.service */ "./src/app/services/health-certificate-api.service.ts");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");
/* harmony import */ var src_app_utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/esm5/form-field.es5.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/esm5/datepicker.es5.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm5/input.es5.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/esm5/core.es5.js");
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm5/material-moment-adapter.es5.js");






















var HealthCertificatesModule = /** @class */ (function () {
    function HealthCertificatesModule() {
    }
    HealthCertificatesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_16__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
                _angular_material_form_field__WEBPACK_IMPORTED_MODULE_17__["MatFormFieldModule"],
                _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepickerModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_16__["ReactiveFormsModule"],
                _angular_material_input__WEBPACK_IMPORTED_MODULE_19__["MatInputModule"],
                _angular_material_core__WEBPACK_IMPORTED_MODULE_20__["MatNativeDateModule"],
                _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_21__["MatMomentDateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _health_certificates_component__WEBPACK_IMPORTED_MODULE_3__["HealthCertificatesComponent"]
                    },
                    {
                        path: 'details',
                        component: _health_certificate_detail_health_certificate_detail_component__WEBPACK_IMPORTED_MODULE_8__["HealthCertificateDetailComponent"]
                    }
                ])
            ],
            providers: [
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"],
                src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_10__["LocalStorageService"],
                src_app_utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__["RefreshUtils"],
                src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_12__["AlertService"],
                src_app_services_health_certificate_api_service__WEBPACK_IMPORTED_MODULE_9__["HealthCertificateApiService"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_13__["FileTransfer"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_13__["FileTransferObject"],
                _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_15__["File"],
                _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_14__["FileOpener"],
                {
                    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"],
                    useClass: src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_6__["InterceptorRm"],
                    multi: true
                }
            ],
            declarations: [
                _health_certificates_component__WEBPACK_IMPORTED_MODULE_3__["HealthCertificatesComponent"],
                _health_certificate_detail_health_certificate_detail_component__WEBPACK_IMPORTED_MODULE_8__["HealthCertificateDetailComponent"]
            ],
            entryComponents: []
        })
    ], HealthCertificatesModule);
    return HealthCertificatesModule;
}());



/***/ }),

/***/ "./src/app/services/health-certificate-api.service.ts":
/*!************************************************************!*\
  !*** ./src/app/services/health-certificate-api.service.ts ***!
  \************************************************************/
/*! exports provided: HealthCertificateApiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HealthCertificateApiService", function() { return HealthCertificateApiService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");




var HealthCertificateApiService = /** @class */ (function () {
    function HealthCertificateApiService(http) {
        this.http = http;
    }
    HealthCertificateApiService.prototype.getByPatientParams = function (docNumber, sex) {
        var path = _utils_constants__WEBPACK_IMPORTED_MODULE_3__["constants"].URL_RM_PREFIX + "health-certificate/patient/" + docNumber + "/sex/" + sex;
        return this.http.get(path);
    };
    HealthCertificateApiService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    HealthCertificateApiService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], HealthCertificateApiService);
    return HealthCertificateApiService;
}());



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var LoadingService = /** @class */ (function () {
    function LoadingService(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    LoadingService.prototype.present = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.isLoading = true;
                        return [4 /*yield*/, this.loadingController.create({
                                message: '...Cargando',
                                duration: 7500,
                            }).then(function (a) {
                                a.present().then(function () {
                                    console.log('presented');
                                    if (!_this.isLoading) {
                                        a.dismiss().then(function () { return console.log('abort presenting'); });
                                    }
                                });
                            })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    LoadingService.prototype.dismiss = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.isLoading = false;
                        return [4 /*yield*/, this.loadingController.dismiss().then(function () { return console.log('dismissed'); })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    LoadingService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
    ]; };
    LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
    ], LoadingService);
    return LoadingService;
}());



/***/ })

}]);
//# sourceMappingURL=RM-health-certificates-health-certificates-module-es5.js.map