(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["RC-proceedings-proceedings-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/RC/proceedings/proceedings.page.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RC/proceedings/proceedings.page.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\">\r\n        <!-- <svg xmlns='http://www.w3.org/2000/svg'  height='50' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='328 112 184 256 328 400' style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg> -->\r\n      </ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTRO CIVIL</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-list>\r\n    <ion-list-header >\r\n      <h2 class=\"header-text-2\"><b>MIS ACTAS</b></h2>\r\n    </ion-list-header>\r\n  </ion-list>\r\n\r\n  <ion-list *ngFor=\"let item of proceedings\">\r\n    <ion-list-header class=\"header-text\" (click)=\"expandOrCollapse(item)\">\r\n      <h5 style=\"margin-top: 0px; margin-bottom: 0px;\"><b>ACTAS DE {{item.type}}</b></h5>\r\n      <svg *ngIf=\"!item.expanded\" xmlns='http://www.w3.org/2000/svg'  height='50' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='112 184 256 328 400 184' style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg>\r\n      <svg *ngIf=\"item.expanded\" xmlns='http://www.w3.org/2000/svg' height='50' viewBox='0 0 512 512'><title>ionicons-v5-a</title><polyline points='112 328 256 184 400 328' style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px'/></svg>\r\n    </ion-list-header>\r\n    <div *ngIf=\"item.expanded\">\r\n      <div *ngFor=\"let proceeding of item.certificates; let i = index\">\r\n        <ion-item class=\"border-red\">\r\n          <ion-list >\r\n            <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n              <ion-label class=\"ion-text-wrap\">\r\n                <ion-text class=\"red\">\r\n                  <h2 style=\"display: inline;\">{{proceeding.key}}: {{proceeding.value}}</h2>\r\n                </ion-text>\r\n              </ion-label>\r\n\r\n            </ion-item>\r\n\r\n            <ion-item lines=\"none\" (click)=\"checkPassword(proceeding)\">\r\n              <ion-card text-center style=\"padding: 0px; margin: 0px;\">\r\n                <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n                     width=\"30%\" height=\"30%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n       <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#1E88E5\" d=\"M862.973,656.11h-89.835v148.416\r\n         c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n         c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n         c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n         c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n         C840.518,409.458,840.518,415.762,837.57,419.12\"/>\r\n       </svg>\r\n              </ion-card>\r\n            </ion-item>\r\n          </ion-list>\r\n\r\n        </ion-item>\r\n\r\n      </div>\r\n\r\n    </div>\r\n\r\n\r\n  </ion-list>\r\n\r\n\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\" ></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n"

/***/ }),

/***/ "./src/app/RC/proceedings/proceedings-routing.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/RC/proceedings/proceedings-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: ProceedingsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProceedingsPageRoutingModule", function() { return ProceedingsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _proceedings_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./proceedings.page */ "./src/app/RC/proceedings/proceedings.page.ts");




var routes = [
    {
        path: '',
        component: _proceedings_page__WEBPACK_IMPORTED_MODULE_3__["ProceedingsPage"]
    }
];
var ProceedingsPageRoutingModule = /** @class */ (function () {
    function ProceedingsPageRoutingModule() {
    }
    ProceedingsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], ProceedingsPageRoutingModule);
    return ProceedingsPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/RC/proceedings/proceedings.module.ts":
/*!******************************************************!*\
  !*** ./src/app/RC/proceedings/proceedings.module.ts ***!
  \******************************************************/
/*! exports provided: ProceedingsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProceedingsPageModule", function() { return ProceedingsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _proceedings_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./proceedings-routing.module */ "./src/app/RC/proceedings/proceedings-routing.module.ts");
/* harmony import */ var _proceedings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./proceedings.page */ "./src/app/RC/proceedings/proceedings.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");












var ProceedingsPageModule = /** @class */ (function () {
    function ProceedingsPageModule() {
    }
    ProceedingsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
                _proceedings_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProceedingsPageRoutingModule"]
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
                _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
                _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"],
                _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__["FileOpener"]],
            declarations: [_proceedings_page__WEBPACK_IMPORTED_MODULE_6__["ProceedingsPage"]]
        })
    ], ProceedingsPageModule);
    return ProceedingsPageModule;
}());



/***/ }),

/***/ "./src/app/RC/proceedings/proceedings.page.scss":
/*!******************************************************!*\
  !*** ./src/app/RC/proceedings/proceedings.page.scss ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #1E88E5;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #1E88E5;\n}\n\n.header-text {\n  padding-left: 10px;\n  width: 95%;\n  margin-bottom: 10px;\n  margin-top: 5px;\n  margin-left: 10px;\n  margin-right: 10px;\n  background-color: #1E88E5;\n  color: #ffffff;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #1E88E5;\n}\n\nion-header ion-toolbar ion-title {\n  color: #ffffff;\n}\n\n.white {\n  color: #ffffff !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\n.show-all {\n  --min-height: 20px;\n  border-radius: 6px;\n  background-color: #e6e6e6;\n  --ion-background-color: #e6e6e6;\n  margin-top: 2%;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.header-text-2 {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n  margin-bottom: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUkMvcHJvY2VlZGluZ3MvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxSQ1xccHJvY2VlZGluZ3NcXHByb2NlZWRpbmdzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvUkMvcHJvY2VlZGluZ3MvcHJvY2VlZGluZ3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtBQ0NGOztBRElBO0VBQ0UsZ0NBQUE7QUNERjs7QURJQTtFQUdFLGtCQUFBO0VBQ0EsVUFBQTtFQUdBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSw4QkFBQTtBQ0xGOztBRFFBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FDTEY7O0FEUUE7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0FDTEY7O0FEUUE7RUFDRSxxQkFBQTtBQ0xGOztBRE9BO0VBQ0UsY0FBQTtBQ0pGOztBRE9BO0VBQ0UseUJBQUE7QUNKRjs7QURPQTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtBQ0pGOztBRE9BO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNKRjs7QURPQTtFQUNFLDJCQUFBO0VBQ0EsaUNBQUE7QUNKRjs7QURPQTtFQUNFLDJCQUFBO0FDSkY7O0FETUE7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSwrQkFBQTtFQUNBLGNBQUE7QUNIRjs7QURNQTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNIRjs7QURNQTtFQUNFLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtBQ0hGIiwiZmlsZSI6InNyYy9hcHAvUkMvcHJvY2VlZGluZ3MvcHJvY2VlZGluZ3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJlZCB7XHJcbiAgY29sb3I6ICMxRTg4RTU7XHJcbn1cclxuXHJcblxyXG5cclxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMxRTg4RTU7XHJcbn1cclxuXHJcbi5oZWFkZXItdGV4dCB7XHJcbiAgLy8gYm9yZGVyLWJvdHRvbToycHggc29saWQgIzUzNTM1MztcclxuICAvLyBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIHBhZGRpbmctbGVmdDogMTBweDtcclxuICB3aWR0aDogOTUlO1xyXG4gIC8vIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gIC8vIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgbWFyZ2luLXRvcDogNXB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMTBweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMUU4OEU1O1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWl0ZW0ge1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG59XHJcblxyXG5pb24tbGlzdCB7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xyXG4gIC0tYmFja2dyb3VuZDogIzFFODhFNTtcclxufVxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbn1cclxuXHJcbi53aGl0ZSB7XHJcbiAgY29sb3I6ICNmZmZmZmYgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWxhYmVsIHtcclxuICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgbWFyZ2luLXRvcDogMHB4O1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4uc2MtaW9uLWNhcmQtbWQtaCB7XHJcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG4gIC13ZWJraXQtYm94LXNoYWRvdzogXCJcIiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tY2FyZCB7XHJcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcbi5zaG93LWFsbCB7XHJcbiAgLS1taW4taGVpZ2h0OiAyMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNlNmU2ZTY7XHJcbiAgbWFyZ2luLXRvcDogMiU7XHJcbn1cclxuXHJcbmlvbi10aXRsZXtcclxuICBwYWRkaW5nLXJpZ2h0OiA1JTtcclxuICBwYWRkaW5nLWxlZnQ6IDUlO1xyXG4gIGZvbnQtc2l6ZTogNXZ3O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLmhlYWRlci10ZXh0LTJ7XHJcbiAgYm9yZGVyLWJvdHRvbToycHggc29saWQgIzUzNTM1MztcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxufVxyXG4iLCIucmVkIHtcbiAgY29sb3I6ICMxRTg4RTU7XG59XG5cbmlvbi1pdGVtLmJvcmRlci1yZWQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzFFODhFNTtcbn1cblxuLmhlYWRlci10ZXh0IHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB3aWR0aDogOTUlO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICMxRTg4RTU7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG5pb24tbGlzdCB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzFFODhFNTtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI2ZmZmZmZjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNmZmZmZmYgIWltcG9ydGFudDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5zYy1pb24tY2FyZC1tZC1oIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAtd2Via2l0LWJveC1zaGFkb3c6IFwiXCIgIWltcG9ydGFudDtcbn1cblxuaW9uLWNhcmQge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbi5zaG93LWFsbCB7XG4gIC0tbWluLWhlaWdodDogMjBweDtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xuICBtYXJnaW4tdG9wOiAyJTtcbn1cblxuaW9uLXRpdGxlIHtcbiAgcGFkZGluZy1yaWdodDogNSU7XG4gIHBhZGRpbmctbGVmdDogNSU7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5oZWFkZXItdGV4dC0yIHtcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICM1MzUzNTM7XG4gIG1hcmdpbi1yaWdodDogNSU7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/RC/proceedings/proceedings.page.ts":
/*!****************************************************!*\
  !*** ./src/app/RC/proceedings/proceedings.page.ts ***!
  \****************************************************/
/*! exports provided: ProceedingsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProceedingsPage", function() { return ProceedingsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _device_device_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../device/device.service */ "./src/app/device/device.service.ts");














var ProceedingsPage = /** @class */ (function () {
    function ProceedingsPage(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, deviceDetailsService, screenOrientation, navController, refreshUtils, statusBar, platform) {
        var _this = this;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.deviceDetailsService = deviceDetailsService;
        this.screenOrientation = screenOrientation;
        this.navController = navController;
        this.refreshUtils = refreshUtils;
        this.statusBar = statusBar;
        this.platform = platform;
        this.processError = function (error) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                _this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        _this.storage.get('psw').then(function (val) {
                            if (val) {
                                _this.loading("Descargando");
                                _this.refreshUtils.refreshToken(val).then(function (value) {
                                    _this.loadingController.dismiss();
                                    resolve(value);
                                }).catch(function (errorRefresh) {
                                    _this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        _this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    _this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(function (params) {
            if (_this.router.getCurrentNavigation().extras.state) {
                _this.proceedings = _this.router.getCurrentNavigation().extras.state.proceedings;
                _this.token = _this.router.getCurrentNavigation().extras.state.token;
                _this.makeProceedingsCollapse();
            }
        });
    }
    ProceedingsPage.prototype.makeProceedingsCollapse = function () {
        var proceedingsTemporal = [];
        var firstTime = true;
        this.proceedings.forEach(function (element) {
            var elementTemporal = {
                type: element.type,
                certificates: element.certificates,
                expanded: firstTime,
            };
            proceedingsTemporal.push(elementTemporal);
            firstTime = false;
        });
        this.proceedings = proceedingsTemporal;
    };
    ProceedingsPage.prototype.expandOrCollapse = function (item) {
        item.expanded = !item.expanded;
    };
    ProceedingsPage.prototype.ionViewWillEnter = function () {
        this.statusBar.backgroundColorByHexString('#1E88E5');
    };
    ProceedingsPage.prototype.ngOnInit = function () { };
    ProceedingsPage.prototype.deleteDataAndExitToLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.storage.clear().then(function () {
                    _this.navController.navigateRoot("/login");
                });
                return [2 /*return*/];
            });
        });
    };
    ProceedingsPage.prototype.alert = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Portal puntano',
                            message: messageText,
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel',
                                    cssClass: 'primary',
                                    handler: function () {
                                        console.log('OK pressed!!');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProceedingsPage.prototype.loading = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: messageText,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProceedingsPage.prototype.checkPassword = function (proceeding) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loading("Descargando");
                this.storage.get('token').then(function (val) {
                    if (val) {
                        _this.token = val;
                        var httpOptions = {
                            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
                                'Content-Type': 'application/json',
                                'Accept': 'application/json',
                                'X-Authorization': 'Bearer ' + _this.token,
                            }),
                            response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpResponse"]({
                                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
                                    'Content-Type': 'application/json',
                                    'Accept': 'application/json'
                                }),
                            })
                        };
                        console.log("URL: " + _utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].URL_BASE_PORTAL + "secure/mobile/check/password");
                        console.log("TOKEN: " + 'Bearer ' + _this.token);
                        _this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].URL_BASE_PORTAL + "secure/mobile/check/password", httpOptions)
                            .subscribe(function (data) {
                            _this.download(proceeding);
                        }, function (error) {
                            _this.processError(error).then(function (value) {
                                _this.checkPassword(proceeding);
                            });
                        });
                    }
                    else {
                        _this.loadingController.dismiss();
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                    }
                });
                return [2 /*return*/];
            });
        });
    };
    ProceedingsPage.prototype.download = function (proceeding) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var fileName, filePath, url, options, directory, soVersion;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                fileName = proceeding.value + ".pdf";
                filePath = _utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].URL_BASE_PORTAL + "secure/civilRegistration/certificate/" + proceeding.id;
                url = encodeURI(filePath);
                this.fileTransfer = this.transfer.create();
                options = {
                    headers: {
                        "X-Authorization": "Bearer " + this.token
                    }
                };
                directory = this.file.documentsDirectory;
                if (this.platform.is("android")) {
                    soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                    //if(this.file.externalRootDirectory){
                    console.log("[HOME] OS VERSION: " + soVersion);
                    if (soVersion < 11) {
                        if (this.file.externalRootDirectory) {
                            directory = this.file.externalRootDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].FOLDER_DOWNLOAD;
                        }
                        else {
                            directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].FOLDER_DOWNLOAD;
                        }
                    }
                    else {
                        directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].FOLDER_DOWNLOAD;
                    }
                }
                this.fileTransfer.download(url, directory + fileName, true, options).then(function (entry) {
                    _this.loadingController.dismiss();
                    //here logging our success downloaded file path in mobile.
                    console.log('download completed: ' + entry.toURL());
                    _this.file.resolveDirectoryUrl(directory).then(function (rootDir) {
                        _this.file.getFile(rootDir, fileName, { create: false }).then(function (fileEntry) {
                            fileEntry.getMetadata(function (metadata) {
                                if (metadata.size != 0) {
                                    // open downloaded file
                                    _this.openFileHandler(entry.toURL());
                                    if (_this.platform.is("android")) {
                                        var soVersion = parseFloat(_this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                                        if (soVersion < 11) {
                                            if (_this.file.externalRootDirectory) {
                                                _this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + _utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                                            }
                                        }
                                    }
                                }
                                else {
                                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].FILE_SIZE_0_ERROR);
                                }
                            });
                        });
                    });
                }).catch(function (error) {
                    _this.loadingController.dismiss();
                    if (error != null && error.http_status != null && error.http_status == 409) {
                        _this.alert(JSON.parse(error.body).message);
                    }
                    else if (error.status == 401) {
                        _this.deleteDataAndExitToLogin();
                    }
                    else if (error.status == 500) {
                        if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                            _this.storage.get('psw').then(function (val) {
                                if (val) {
                                    _this.loading('Descargando');
                                    _this.refreshUtils.refreshToken(val).then(function (value) {
                                        _this.loadingController.dismiss();
                                        _this.download(proceeding);
                                    }).catch(function (error) {
                                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                                    });
                                }
                                else {
                                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                                }
                            });
                        }
                        else {
                            _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                        }
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                    }
                    //here logging an error.
                    console.log('download failed: ' + JSON.stringify(error));
                });
                return [2 /*return*/];
            });
        });
    };
    ProceedingsPage.prototype.openFileHandler = function (path) {
        this.fileOpener.open(path, '')
            .then(function () { return console.log('File is opened'); })
            .catch(function (e) { return console.log('Error opening file', e); });
    };
    ProceedingsPage.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
    };
    ProceedingsPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
        { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__["FileTransfer"] },
        { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
        { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
        { type: _device_device_service__WEBPACK_IMPORTED_MODULE_13__["DeviceDetailsService"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
        { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] }
    ]; };
    ProceedingsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-proceedings',
            template: __webpack_require__(/*! raw-loader!./proceedings.page.html */ "./node_modules/raw-loader/index.js!./src/app/RC/proceedings/proceedings.page.html"),
            styles: [__webpack_require__(/*! ./proceedings.page.scss */ "./src/app/RC/proceedings/proceedings.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__["FileTransfer"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
            _device_device_service__WEBPACK_IMPORTED_MODULE_13__["DeviceDetailsService"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]])
    ], ProceedingsPage);
    return ProceedingsPage;
}());



/***/ })

}]);
//# sourceMappingURL=RC-proceedings-proceedings-module-es5.js.map