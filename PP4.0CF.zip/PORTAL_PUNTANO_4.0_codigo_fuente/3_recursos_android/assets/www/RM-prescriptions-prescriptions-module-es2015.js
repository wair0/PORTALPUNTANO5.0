(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["RM-prescriptions-prescriptions-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/RM/prescriptions/prescriptions.page.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RM/prescriptions/prescriptions.page.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTROS MÉDICOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-list-header>\r\n    <h2 class=\"header-text\"><b>MIS RECETAS DIGITALES</b></h2>\r\n  </ion-list-header>\r\n\r\n  <div class=\"prescriptions\">\r\n    <div class=\"prescriptions__item\" *ngFor=\"let consultation of consultations\" (click)=\"goToPrescription(consultation)\">\r\n      <p class=\"prescriptions__item-text-date\">{{consultation.dateCreated}}</p>\r\n      <p class=\"prescriptions__item-text\">{{consultation.professionalName}}</p>\r\n      <p class=\"prescriptions__item-text\">{{consultation.specialty}}</p>\r\n    </div>\r\n  </div>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" name=\"home\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/RM/prescriptions/prescriptions.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/RM/prescriptions/prescriptions.module.ts ***!
  \**********************************************************/
/*! exports provided: PrescriptionsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrescriptionsModule", function() { return PrescriptionsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _prescriptions_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./prescriptions.page */ "./src/app/RM/prescriptions/prescriptions.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/interceptors/interceptor-rm.service */ "./src/app/core/interceptors/interceptor-rm.service.ts");













let PrescriptionsModule = class PrescriptionsModule {
};
PrescriptionsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _prescriptions_page__WEBPACK_IMPORTED_MODULE_6__["PrescriptionsPage"]
                }
            ])
        ],
        providers: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__["RefreshUtils"],
            src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_9__["PatientService"],
            src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_10__["ConsultationService"],
            src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_11__["AlertService"],
            {
                provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HTTP_INTERCEPTORS"],
                useClass: src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_12__["InterceptorRm"],
                multi: true
            }
        ],
        declarations: [_prescriptions_page__WEBPACK_IMPORTED_MODULE_6__["PrescriptionsPage"]]
    })
], PrescriptionsModule);



/***/ }),

/***/ "./src/app/RM/prescriptions/prescriptions.page.scss":
/*!**********************************************************!*\
  !*** ./src/app/RM/prescriptions/prescriptions.page.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #EC272F;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #EC272F;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #EC272F;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.prescriptions {\n  padding-left: 1rem;\n  padding-right: 1rem;\n}\n\n.prescriptions__item {\n  border-bottom: 1px solid #ff9898;\n  margin-top: 1.5rem;\n  padding-bottom: 1rem;\n}\n\n.prescriptions__item-text-date {\n  margin-bottom: 1rem;\n}\n\n.prescriptions__item-text {\n  margin: 0.5rem 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUk0vcHJlc2NyaXB0aW9ucy9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXFJNXFxwcmVzY3JpcHRpb25zXFxwcmVzY3JpcHRpb25zLnBhZ2Uuc2NzcyIsInNyYy9hcHAvUk0vcHJlc2NyaXB0aW9ucy9wcmVzY3JpcHRpb25zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7QUNDSjs7QURJQTtFQUNJLGdDQUFBO0FDREo7O0FESUc7RUFDQyxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0FDREo7O0FESUc7RUFDQyxlQUFBO0VBQ0EsZ0JBQUE7QUNESjs7QURJRztFQUNJLG1CQUFBO0VBQ0Esa0JBQUE7QUNEUDs7QURJRztFQUNDLHFCQUFBO0FDREo7O0FESUc7RUFDQyxjQUFBO0FDREo7O0FESUE7RUFDSSx5QkFBQTtBQ0RKOztBRElBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0RKOztBREtBO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtBQ0ZKOztBREtBO0VBQ0ksZ0NBQUE7RUFDQSxrQkFBQTtFQUNBLG9CQUFBO0FDRko7O0FES0E7RUFDSSxtQkFBQTtBQ0ZKOztBREtBO0VBQ0ksZ0JBQUE7QUNGSiIsImZpbGUiOiJzcmMvYXBwL1JNL3ByZXNjcmlwdGlvbnMvcHJlc2NyaXB0aW9ucy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVke1xyXG4gICAgY29sb3I6ICNFQzI3MkZcclxufVxyXG5cclxuXHJcblxyXG5pb24taXRlbS5ib3JkZXItcmVkIHtcclxuICAgIGJvcmRlci1ib3R0b206MXB4IHNvbGlkICNFQzI3MkY7XHJcbiAgIH1cclxuXHJcbiAgIC5oZWFkZXItdGV4dHtcclxuICAgIGJvcmRlci1ib3R0b206MnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICAgfVxyXG5cclxuICAgaW9uLWl0ZW17XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICB9XHJcblxyXG4gICBpb24tbGlzdHtcclxuICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICBtYXJnaW4tYm90dG9tOjBweDtcclxuICAgfVxyXG5cclxuICAgaW9uLWhlYWRlciBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogI0VDMjcyRjtcclxuICAgIFxyXG4gICB9XHJcbiAgIGlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxle1xyXG4gICAgY29sb3I6ICNGRkZGRkY7XHJcbiAgIH1cclxuXHJcbi53aGl0ZXtcclxuICAgIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi10aXRsZXtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIGZvbnQtc2l6ZTogNXZ3O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG5cclxuLnByZXNjcmlwdGlvbnMge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxcmVtO1xyXG4gICAgcGFkZGluZy1yaWdodDogMXJlbTtcclxufVxyXG5cclxuLnByZXNjcmlwdGlvbnNfX2l0ZW0ge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZjk4OTg7XHJcbiAgICBtYXJnaW4tdG9wOiAxLjVyZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxufVxyXG5cclxuLnByZXNjcmlwdGlvbnNfX2l0ZW0tdGV4dC1kYXRlIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDFyZW07XHJcbn1cclxuXHJcbi5wcmVzY3JpcHRpb25zX19pdGVtLXRleHQge1xyXG4gICAgbWFyZ2luOiAuNXJlbSAwO1xyXG59IiwiLnJlZCB7XG4gIGNvbG9yOiAjRUMyNzJGO1xufVxuXG5pb24taXRlbS5ib3JkZXItcmVkIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNFQzI3MkY7XG59XG5cbi5oZWFkZXItdGV4dCB7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjNTM1MzUzO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG5pb24tbGlzdCB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogI0VDMjcyRjtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI0ZGRkZGRjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cblxuaW9uLXRpdGxlIHtcbiAgcGFkZGluZy1yaWdodDogNSU7XG4gIHBhZGRpbmctbGVmdDogNSU7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5wcmVzY3JpcHRpb25zIHtcbiAgcGFkZGluZy1sZWZ0OiAxcmVtO1xuICBwYWRkaW5nLXJpZ2h0OiAxcmVtO1xufVxuXG4ucHJlc2NyaXB0aW9uc19faXRlbSB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZmY5ODk4O1xuICBtYXJnaW4tdG9wOiAxLjVyZW07XG4gIHBhZGRpbmctYm90dG9tOiAxcmVtO1xufVxuXG4ucHJlc2NyaXB0aW9uc19faXRlbS10ZXh0LWRhdGUge1xuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xufVxuXG4ucHJlc2NyaXB0aW9uc19faXRlbS10ZXh0IHtcbiAgbWFyZ2luOiAwLjVyZW0gMDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/RM/prescriptions/prescriptions.page.ts":
/*!********************************************************!*\
  !*** ./src/app/RM/prescriptions/prescriptions.page.ts ***!
  \********************************************************/
/*! exports provided: PrescriptionsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrescriptionsPage", function() { return PrescriptionsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");











let PrescriptionsPage = class PrescriptionsPage {
    constructor(router, screenOrientation, statusBar, navController, refreshUtils, consultationService, localStorageService, patientService, alertService) {
        this.router = router;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.refreshUtils = refreshUtils;
        this.consultationService = consultationService;
        this.localStorageService = localStorageService;
        this.patientService = patientService;
        this.alertService = alertService;
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#EC272F');
    }
    ngOnInit() {
        this.localStorageService.getUserData().then(userData => {
            this.userData = userData;
            this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(patientId => {
                this.patientId = patientId;
                this.consultationService.getConsultationsWithPrescriptionsByPatientId(patientId).subscribe(response => {
                    this.consultations = response;
                }, error => {
                    if (error.message)
                        this.alertService.showErrorAlert(error.message);
                    else
                        this.alertService.showErrorAlert();
                });
            });
        });
    }
    goToPrescription(consultation) {
        let navigationExtras = {
            state: {
                consultation
            }
        };
        this.router.navigate(['prescription'], navigationExtras);
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
};
PrescriptionsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__["ScreenOrientation"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_4__["RefreshUtils"] },
    { type: src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_7__["ConsultationService"] },
    { type: src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_8__["LocalStorageService"] },
    { type: src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_9__["PatientService"] },
    { type: src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_10__["AlertService"] }
];
PrescriptionsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-prescriptions',
        template: __webpack_require__(/*! raw-loader!./prescriptions.page.html */ "./node_modules/raw-loader/index.js!./src/app/RM/prescriptions/prescriptions.page.html"),
        styles: [__webpack_require__(/*! ./prescriptions.page.scss */ "./src/app/RM/prescriptions/prescriptions.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__["ScreenOrientation"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_4__["RefreshUtils"],
        src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_7__["ConsultationService"],
        src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_8__["LocalStorageService"],
        src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_9__["PatientService"],
        src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_10__["AlertService"]])
], PrescriptionsPage);



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let LoadingService = class LoadingService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    present() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController.create({
                message: '...Cargando',
                duration: 7500,
            }).then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss().then(() => console.log('dismissed'));
        });
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
], LoadingService);



/***/ })

}]);
//# sourceMappingURL=RM-prescriptions-prescriptions-module-es2015.js.map