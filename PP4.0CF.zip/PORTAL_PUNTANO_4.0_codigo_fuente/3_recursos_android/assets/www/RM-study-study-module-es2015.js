(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["RM-study-study-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/RM/study/study.page.html":
/*!********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RM/study/study.page.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTROS MÉDICOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n\r\n  <div class=\"studies\">\r\n\r\n    <div>\r\n      <p>{{consultation.dateCreated}}</p>\r\n      <p class=\"my-1\">{{consultation.professionalName}}</p>\r\n      <p class=\"my-1\">{{consultation.specialty}}</p>\r\n    </div>\r\n\r\n    <div class=\"studies__required\">\r\n      <div>\r\n        <h2 class=\"studies__title\">Estudios Requeridos</h2>\r\n  \r\n        <ul>\r\n          <li class=\"studies__required__list studies__name\" *ngFor=\"let study of requiredStudies\">{{study.study.description}}</li>\r\n        </ul>\r\n        \r\n        <div *ngIf=\"requiredStudies && requiredStudies.length === 0\">\r\n          <p class=\"studies__empty\">No hay Estudios requeridos para mostrar</p>\r\n        </div>\r\n\r\n        <div *ngIf=\"requiredStudiesInfo && requiredStudies.length > 0\">\r\n          <p>Profesional que lo solicitó: <b>{{requiredStudiesInfo.professionalNameRequired}}</b></p>\r\n          <p>Fecha de solicitud: <b>{{requiredStudiesInfo.dateRequired}}</b></p>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"download-icon-container\" *ngIf=\"requiredStudiesInfo && requiredStudiesInfo.pdfPathName\">\r\n        <button class=\"download-button\" (click)=\"download(requiredStudiesInfo.pdfPathName)\">\r\n          <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n          width=\"100%\" height=\"100%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#EC1C24\" d=\"M862.973,656.11h-89.835v148.416\r\n          c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n          c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n          c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n          c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n          C840.518,409.458,840.518,415.762,837.57,419.12\"/>\r\n          </svg>\r\n        </button>\r\n      </div>\r\n\r\n    </div>\r\n    \r\n    <div>\r\n      <h2 class=\"studies__title\">Estudios completados</h2>\r\n\r\n      <div *ngIf=\"completedStudies && completedStudies.length === 0\">\r\n        <p class=\"studies__empty\">No hay Estudios completados para mostrar</p>\r\n      </div>\r\n\r\n      <div *ngIf=\"completedStudies && completedStudies.length > 0\">\r\n        <div  class=\"studies__completed__list\" *ngFor=\"let study of completedStudies\">\r\n          <p class=\"studies__name\">{{study.study.description}}</p>\r\n          <p>Estado: <b>{{study.statusLabel}}</b></p>\r\n          <p>Profesional que lo solicitó: <b>{{study.professionalNameRequired}}</b></p>\r\n          <p>Fecha de solicitud: <b>{{study.dateRequired}}</b></p>\r\n          <p>Resultado: <b>{{study.result}}</b></p>\r\n          <p>Fecha de resultado: <b>{{study.dateCompleted}}</b></p>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"download-icon-container\" *ngIf=\"completedStudiesInfo && completedStudiesInfo.pdfPathName\">\r\n        <button class=\"download-button\" (click)=\"download(completedStudiesInfo.pdfPathName)\">\r\n          <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n          width=\"100%\" height=\"100%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#EC1C24\" d=\"M862.973,656.11h-89.835v148.416\r\n          c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n          c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n          c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n          c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n          C840.518,409.458,840.518,415.762,837.57,419.12\"/>\r\n          </svg>\r\n        </button>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</ion-content>\r\n\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" name=\"home\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/RM/study/study.module.ts":
/*!******************************************!*\
  !*** ./src/app/RM/study/study.module.ts ***!
  \******************************************/
/*! exports provided: StudyModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudyModule", function() { return StudyModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _study_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./study.page */ "./src/app/RM/study/study.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var src_app_services_studies_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/studies.service */ "./src/app/services/studies.service.ts");
/* harmony import */ var src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/interceptors/interceptor-rm.service */ "./src/app/core/interceptors/interceptor-rm.service.ts");













let StudyModule = class StudyModule {
};
StudyModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _study_page__WEBPACK_IMPORTED_MODULE_6__["StudyPage"]
                }
            ])
        ],
        providers: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__["FileOpener"],
            src_app_services_studies_service__WEBPACK_IMPORTED_MODULE_11__["StudiesService"],
            {
                provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HTTP_INTERCEPTORS"],
                useClass: src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_12__["InterceptorRm"],
                multi: true
            }
        ],
        declarations: [_study_page__WEBPACK_IMPORTED_MODULE_6__["StudyPage"]]
    })
], StudyModule);



/***/ }),

/***/ "./src/app/RM/study/study.page.scss":
/*!******************************************!*\
  !*** ./src/app/RM/study/study.page.scss ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #EC272F;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #EC272F;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #EC272F;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.studies {\n  padding: 0 1rem;\n}\n\n.studies__title {\n  font-size: 1.5rem;\n  font-weight: 700;\n}\n\n.studies__required {\n  border-bottom: 2px solid #000;\n  padding-bottom: 1rem;\n}\n\n.studies__required__list {\n  margin: 0.5rem 0;\n}\n\n.studies__required ul {\n  padding-left: 1rem;\n}\n\n.studies__completed__list {\n  border-bottom: 1px solid #bbb;\n}\n\n.studies__name {\n  font-size: 1.25rem;\n  margin: 1.5rem 0;\n}\n\n.download-icon-container {\n  display: flex;\n  justify-content: flex-end;\n  margin: 1.5rem 0;\n}\n\n.download-button {\n  width: 20%;\n  background-color: transparent;\n}\n\n.studies__empty {\n  margin: 2rem 0;\n}\n\n.my-1 {\n  margin: 0.5rem 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUk0vc3R1ZHkvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxSTVxcc3R1ZHlcXHN0dWR5LnBhZ2Uuc2NzcyIsInNyYy9hcHAvUk0vc3R1ZHkvc3R1ZHkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksY0FBQTtBQ0FKOztBREtBO0VBQ0ksZ0NBQUE7QUNGSjs7QURLRztFQUNDLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7QUNGSjs7QURLRztFQUNDLGVBQUE7RUFDQSxnQkFBQTtBQ0ZKOztBREtHO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtBQ0ZQOztBREtHO0VBQ0MscUJBQUE7QUNGSjs7QURLRztFQUNDLGNBQUE7QUNGSjs7QURLQTtFQUNJLHlCQUFBO0FDRko7O0FES0c7RUFDSSxrQkFBQTtFQUNBLGVBQUE7QUNGUDs7QURNRztFQUNDLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FDSEo7O0FETUE7RUFDSSwyQkFBQTtFQUNBLGlDQUFBO0FDSEo7O0FETUE7RUFDSSwyQkFBQTtBQ0hKOztBRE1BO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0hKOztBRE1BO0VBQ0ksZUFBQTtBQ0hKOztBRE1BO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtBQ0hKOztBRE1BO0VBQ0ksNkJBQUE7RUFDQSxvQkFBQTtBQ0hKOztBRE1BO0VBQ0ksZ0JBQUE7QUNISjs7QURNQTtFQUNJLGtCQUFBO0FDSEo7O0FETUE7RUFDSSw2QkFBQTtBQ0hKOztBRE1BO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBQ0hKOztBRE1BO0VBQ0ksYUFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7QUNISjs7QURLQTtFQUNJLFVBQUE7RUFDQSw2QkFBQTtBQ0ZKOztBREtBO0VBQ0ksY0FBQTtBQ0ZKOztBREtBO0VBQ0ksZ0JBQUE7QUNGSiIsImZpbGUiOiJzcmMvYXBwL1JNL3N0dWR5L3N0dWR5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4ucmVke1xyXG4gICAgY29sb3I6ICNFQzI3MkZcclxufVxyXG5cclxuXHJcblxyXG5pb24taXRlbS5ib3JkZXItcmVkIHtcclxuICAgIGJvcmRlci1ib3R0b206MXB4IHNvbGlkICNFQzI3MkY7XHJcbiAgIH1cclxuXHJcbiAgIC5oZWFkZXItdGV4dHtcclxuICAgIGJvcmRlci1ib3R0b206MnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICAgfVxyXG5cclxuICAgaW9uLWl0ZW17XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICB9XHJcblxyXG4gICBpb24tbGlzdHtcclxuICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICBtYXJnaW4tYm90dG9tOjBweDtcclxuICAgfVxyXG5cclxuICAgaW9uLWhlYWRlciBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogI0VDMjcyRjtcclxuICAgIFxyXG4gICB9XHJcbiAgIGlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxle1xyXG4gICAgY29sb3I6ICNGRkZGRkY7XHJcbiAgIH1cclxuXHJcbi53aGl0ZXtcclxuICAgIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbiAgIGlvbi1sYWJlbHtcclxuICAgICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgICAgIG1hcmdpbi10b3A6IDBweDtcclxuICAgfVxyXG5cclxuXHJcbiAgIGlvbi1jb250ZW50IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zYy1pb24tY2FyZC1tZC1oIHtcclxuICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICAgIC13ZWJraXQtYm94LXNoYWRvdzpcIlwiICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1jYXJke1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tdGl0bGV7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA1JTtcclxuICAgIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgICBmb250LXNpemU6IDV2dztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLnN0dWRpZXMge1xyXG4gICAgcGFkZGluZzogMCAxcmVtO1xyXG59XHJcblxyXG4uc3R1ZGllc19fdGl0bGUge1xyXG4gICAgZm9udC1zaXplOiAxLjVyZW07XHJcbiAgICBmb250LXdlaWdodDogNzAwXHJcbn1cclxuXHJcbi5zdHVkaWVzX19yZXF1aXJlZCB7XHJcbiAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzAwMDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxcmVtO1xyXG59XHJcblxyXG4uc3R1ZGllc19fcmVxdWlyZWRfX2xpc3Qge1xyXG4gICAgbWFyZ2luOiAuNXJlbSAwO1xyXG59XHJcblxyXG4uc3R1ZGllc19fcmVxdWlyZWQgdWwge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxcmVtO1xyXG59XHJcblxyXG4uc3R1ZGllc19fY29tcGxldGVkX19saXN0IHtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjYmJiO1xyXG59XHJcblxyXG4uc3R1ZGllc19fbmFtZSB7XHJcbiAgICBmb250LXNpemU6IDEuMjVyZW07XHJcbiAgICBtYXJnaW46IDEuNXJlbSAwO1xyXG59XHJcblxyXG4uZG93bmxvYWQtaWNvbi1jb250YWluZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbiAgICBtYXJnaW46IDEuNXJlbSAwO1xyXG59XHJcbi5kb3dubG9hZC1idXR0b24ge1xyXG4gICAgd2lkdGg6IDIwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG59XHJcblxyXG4uc3R1ZGllc19fZW1wdHkge1xyXG4gICAgbWFyZ2luOiAycmVtIDA7XHJcbn1cclxuXHJcbi5teS0xIHtcclxuICAgIG1hcmdpbjogLjVyZW0gMDtcclxufSIsIi5yZWQge1xuICBjb2xvcjogI0VDMjcyRjtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRUMyNzJGO1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzUzNTM1MztcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuaW9uLWxpc3Qge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICNFQzI3MkY7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xufVxuXG5pb24tY29udGVudCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uc2MtaW9uLWNhcmQtbWQtaCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBcIlwiICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG5pb24tdGl0bGUge1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgZm9udC1zaXplOiA1dnc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnN0dWRpZXMge1xuICBwYWRkaW5nOiAwIDFyZW07XG59XG5cbi5zdHVkaWVzX190aXRsZSB7XG4gIGZvbnQtc2l6ZTogMS41cmVtO1xuICBmb250LXdlaWdodDogNzAwO1xufVxuXG4uc3R1ZGllc19fcmVxdWlyZWQge1xuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzAwMDtcbiAgcGFkZGluZy1ib3R0b206IDFyZW07XG59XG5cbi5zdHVkaWVzX19yZXF1aXJlZF9fbGlzdCB7XG4gIG1hcmdpbjogMC41cmVtIDA7XG59XG5cbi5zdHVkaWVzX19yZXF1aXJlZCB1bCB7XG4gIHBhZGRpbmctbGVmdDogMXJlbTtcbn1cblxuLnN0dWRpZXNfX2NvbXBsZXRlZF9fbGlzdCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjYmJiO1xufVxuXG4uc3R1ZGllc19fbmFtZSB7XG4gIGZvbnQtc2l6ZTogMS4yNXJlbTtcbiAgbWFyZ2luOiAxLjVyZW0gMDtcbn1cblxuLmRvd25sb2FkLWljb24tY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgbWFyZ2luOiAxLjVyZW0gMDtcbn1cblxuLmRvd25sb2FkLWJ1dHRvbiB7XG4gIHdpZHRoOiAyMCU7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4uc3R1ZGllc19fZW1wdHkge1xuICBtYXJnaW46IDJyZW0gMDtcbn1cblxuLm15LTEge1xuICBtYXJnaW46IDAuNXJlbSAwO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/RM/study/study.page.ts":
/*!****************************************!*\
  !*** ./src/app/RM/study/study.page.ts ***!
  \****************************************/
/*! exports provided: StudyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudyPage", function() { return StudyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var src_app_services_studies_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/studies.service */ "./src/app/services/studies.service.ts");
/* harmony import */ var src_app_device_device_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/device/device.service */ "./src/app/device/device.service.ts");













let StudyPage = class StudyPage {
    constructor(deviceDetailsService, alertController, loadingController, storage, route, router, transfer, file, fileOpener, screenOrientation, statusBar, navController, studiesService, platform) {
        this.deviceDetailsService = deviceDetailsService;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.studiesService = studiesService;
        this.platform = platform;
        this.requiredStudies = [];
        this.requiredStudiesInfo = {
            professionalNameRequired: "",
            dateRequired: undefined,
            pdfPathName: ""
        };
        this.completedStudies = [];
        this.completedStudiesInfo = {
            pdfPathName: ""
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#EC272F');
    }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.consultation = this.router.getCurrentNavigation().extras.state.consultation;
                this.studiesService.getStudiesByConsultationId(this.consultation.consultationId).subscribe(response => {
                    this.studies = response;
                    this.studies.forEach(study => {
                        if (study.status === "REQ") {
                            this.requiredStudies.push(study);
                            this.requiredStudiesInfo.professionalNameRequired = study.professionalNameRequired;
                            this.requiredStudiesInfo.dateRequired = study.dateRequired;
                            if (study.pdfPathName)
                                this.requiredStudiesInfo.pdfPathName = study.pdfPathName;
                        }
                        else {
                            this.completedStudies.push(study);
                            if (study.pdfPathName)
                                this.completedStudiesInfo.pdfPathName = study.pdfPathName;
                        }
                    });
                });
            }
        });
    }
    download(path) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storage.get('token').then((val) => {
                if (val) {
                    this.token = val;
                    let fileName = "Estudios_" + this.consultation.consultationId + ".pdf";
                    let filePath = `${_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].URL_RM_PREFIX}patient/pdf/${path}`;
                    let url = encodeURI(filePath);
                    this.fileTransfer = this.transfer.create();
                    let options = {
                        headers: {
                            "X-Authorization": "Bearer " + this.token
                        }
                    };
                    let directory = this.file.documentsDirectory;
                    // if (this.platform.is("android")) {
                    //   if(this.file.externalRootDirectory){
                    //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
                    //     }else{
                    //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
                    //     }
                    // }
                    if (this.platform.is("android")) {
                        let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                        //if(this.file.externalRootDirectory){
                        console.log("[HOME] OS VERSION: " + soVersion);
                        if (soVersion < 11) {
                            if (this.file.externalRootDirectory) {
                                directory = this.file.externalRootDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FOLDER_DOWNLOAD;
                            }
                            else {
                                directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FOLDER_DOWNLOAD;
                            }
                        }
                        else {
                            directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FOLDER_DOWNLOAD;
                        }
                    }
                    this.fileTransfer.download(url, directory + fileName, true, options).then((entry) => {
                        this.loadingController.dismiss();
                        //here logging our success downloaded file path in mobile. 
                        console.log('download completed: ' + entry.toURL());
                        this.file.resolveDirectoryUrl(directory).then((rootDir) => {
                            this.file.getFile(rootDir, fileName, { create: false }).then((fileEntry) => {
                                fileEntry.getMetadata(metadata => {
                                    if (metadata.size != 0) {
                                        // open downloaded file 
                                        this.openFileHandler(entry.toURL());
                                        if (this.platform.is("android")) {
                                            let soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                                            if (soVersion < 11) {
                                                if (this.file.externalRootDirectory) {
                                                    this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + _utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                                                }
                                            }
                                        }
                                    }
                                    else {
                                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].FILE_SIZE_0_ERROR);
                                    }
                                });
                            });
                        });
                    }).catch((error) => {
                        this.loadingController.dismiss();
                        if (error != null && error.http_status != null && error.http_status == 409) {
                            this.alert(JSON.parse(error.body).message);
                        }
                        else {
                            this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                        }
                    });
                }
                else {
                    this.loadingController.dismiss();
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                }
            });
        });
    }
    openFileHandler(path) {
        this.fileOpener.open(path, '')
            .then(() => console.log('File is opened'))
            .catch(e => console.log('Error opening file', e));
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                            console.log('OK pressed!!');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
StudyPage.ctorParameters = () => [
    { type: src_app_device_device_service__WEBPACK_IMPORTED_MODULE_12__["DeviceDetailsService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_5__["FileTransfer"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__["File"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_7__["FileOpener"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: src_app_services_studies_service__WEBPACK_IMPORTED_MODULE_11__["StudiesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] }
];
StudyPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-study',
        template: __webpack_require__(/*! raw-loader!./study.page.html */ "./node_modules/raw-loader/index.js!./src/app/RM/study/study.page.html"),
        styles: [__webpack_require__(/*! ./study.page.scss */ "./src/app/RM/study/study.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_device_device_service__WEBPACK_IMPORTED_MODULE_12__["DeviceDetailsService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_5__["FileTransfer"],
        _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__["File"],
        _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_7__["FileOpener"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        src_app_services_studies_service__WEBPACK_IMPORTED_MODULE_11__["StudiesService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]])
], StudyPage);



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let LoadingService = class LoadingService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    present() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController.create({
                message: '...Cargando',
                duration: 7500,
            }).then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss().then(() => console.log('dismissed'));
        });
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
], LoadingService);



/***/ }),

/***/ "./src/app/services/studies.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/studies.service.ts ***!
  \*********************************************/
/*! exports provided: StudiesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudiesService", function() { return StudiesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var src_app_utils_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utils/constants */ "./src/app/utils/constants.ts");




let StudiesService = class StudiesService {
    constructor(http) {
        this.http = http;
    }
    getStudiesByConsultationId(consultationId) {
        return this.http.get(`${src_app_utils_constants__WEBPACK_IMPORTED_MODULE_3__["constants"].URL_RM_PREFIX}studies/consultationId/${consultationId}`);
    }
};
StudiesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
StudiesService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], StudiesService);



/***/ })

}]);
//# sourceMappingURL=RM-study-study-module-es2015.js.map