(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["procedures-current-procedures-current-procedures-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/procedures/current-procedures/current-procedures.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/procedures/current-procedures/current-procedures.component.html ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>TRÁMITES VIGENTES</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-item class=\"border-red\" *ngFor=\"let item of procedures\" (click)=\"getProcedureDetail(item.id)\">\r\n    <ion-row style=\"align-items: center;\">\r\n      <ion-col size=\"auto\">\r\n        <h1 class=\"status\"><b>{{item.status}}</b></h1>\r\n      </ion-col>\r\n      <ion-col>\r\n        <ion-label class=\"ion-text-wrap\">\r\n          <h2 class=\"red\"><b>{{item.dateCreated | date:\"dd/MM/yyyy - HH:mm a\"}}</b></h2>\r\n          <h2 class=\"red\">{{item.coverLetter}}</h2>\r\n          <h2 class=\"red\">Nro de trámite: {{item.id}}</h2>\r\n          <h2 class=\"red\"><b>{{item.fileNumber}}</b></h2>\r\n        </ion-label>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-item>\r\n  \r\n  <ion-item class=\"show-all\" lines=\"none\" (click)=\"getAllProcedures()\">\r\n    <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n      <h4 style=\"display: inline;\"><b>Mostrar todos</b></h4>\r\n    </ion-text>\r\n    <svg xmlns='http://www.w3.org/2000/svg' height='25' viewBox='0 0 512 512'>\r\n      <title>ionicons-v5-a</title>\r\n      <polyline points='184 112 328 256 184 400'\r\n        style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n    </svg>\r\n  </ion-item>\r\n\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/procedures/current-procedures/current-procedures.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/procedures/current-procedures/current-procedures.component.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: #FF0067;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvY2VkdXJlcy9jdXJyZW50LXByb2NlZHVyZXMvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxwcm9jZWR1cmVzXFxjdXJyZW50LXByb2NlZHVyZXNcXGN1cnJlbnQtcHJvY2VkdXJlcy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcHJvY2VkdXJlcy9jdXJyZW50LXByb2NlZHVyZXMvY3VycmVudC1wcm9jZWR1cmVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUNDSjs7QURHQTtFQUNJLGNBQUE7QUNBSjs7QURHQTtFQUNJLHlCQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC9wcm9jZWR1cmVzL2N1cnJlbnQtcHJvY2VkdXJlcy9jdXJyZW50LXByb2NlZHVyZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIGlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogI0ZGMDA2NztcclxuXHJcbn1cclxuXHJcbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcclxuICAgIGNvbG9yOiAjRkZGRkZGO1xyXG59XHJcblxyXG4ud2hpdGUge1xyXG4gICAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcclxufSIsImlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICNGRjAwNjc7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/procedures/current-procedures/current-procedures.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/procedures/current-procedures/current-procedures.component.ts ***!
  \*******************************************************************************/
/*! exports provided: CurrentProceduresComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrentProceduresComponent", function() { return CurrentProceduresComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/procedures.service */ "./src/app/services/procedures.service.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");






let CurrentProceduresComponent = class CurrentProceduresComponent {
    constructor(proceduresService, screenOrientation, loadingController, router) {
        this.proceduresService = proceduresService;
        this.screenOrientation = screenOrientation;
        this.loadingController = loadingController;
        this.router = router;
        this.procedures = [];
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    }
    ngOnInit() {
        this.getProcedures();
    }
    getAllProcedures() {
        this.loading();
        this.proceduresService.getCurrentProcedures('ACT').subscribe((response) => {
            if (response && response.content && response.content.length > 0) {
                this.loadingController.dismiss();
                this.procedures = response.content;
            }
        }, (error) => {
            this.loadingController.dismiss();
        });
    }
    getProcedures() {
        this.loading();
        this.proceduresService.getCurrentProcedures('ACT', 5).subscribe((response) => {
            if (response && response.content && response.content.length > 0) {
                this.loadingController.dismiss();
                this.procedures = response.content;
            }
        }, (error) => {
            this.loadingController.dismiss();
        });
    }
    getProcedureDetail(idProcedure) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loading();
            this.proceduresService.getDetailsProcedures(idProcedure).subscribe((data) => {
                this.makeProcedure(data);
            });
        });
    }
    makeProcedure(procedure) {
        let steps = new Map();
        procedure.procedureSteps.forEach(element => {
            steps.set(element.step, element.title);
        });
        let attributes = new Map();
        let files = new Array();
        procedure.procedureTypeAttrs.forEach(element => {
            if (element.step) {
                if (attributes.get(element.step)) {
                    attributes.get(element.step).push(element);
                }
                else {
                    let array = new Array();
                    array.push(element);
                    attributes.set(element.step, array);
                }
            }
            else {
                files.push(element);
            }
        });
        let array = new Array();
        if (files.length > 0) {
            let dataFiles = {
                name: "",
                attributes: files
            };
            array.push(dataFiles);
        }
        attributes.forEach((value, key) => {
            let data = {
                name: steps.get(key),
                attributes: value
            };
            array.push(data);
        });
        if (procedure.comments) {
            let attributeComments = {
                name: "Observaciones",
                dataValue: procedure.comments
            };
            let arrayComments = new Array();
            arrayComments.push(attributeComments);
            let stepComments = {
                name: "COMENTARIOS",
                attributes: arrayComments
            };
            array.push(stepComments);
        }
        this.goToProcedureDetail(procedure, array);
    }
    goToProcedureDetail(procedureItem, steps) {
        this.loadingController.dismiss();
        if (steps.length > 0) {
            let navigationExtras = {
                state: {
                    procedureItem: procedureItem,
                    steps: steps
                }
            };
            this.router.navigate(['procedureDetail'], navigationExtras);
        }
        else {
            alert("No se encontraron datos");
        }
    }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando',
            });
            yield loading.present();
        });
    }
};
CurrentProceduresComponent.ctorParameters = () => [
    { type: src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_2__["ProceduresService"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__["ScreenOrientation"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
CurrentProceduresComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-current-procedures',
        template: __webpack_require__(/*! raw-loader!./current-procedures.component.html */ "./node_modules/raw-loader/index.js!./src/app/procedures/current-procedures/current-procedures.component.html"),
        styles: [__webpack_require__(/*! ./current-procedures.component.scss */ "./src/app/procedures/current-procedures/current-procedures.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_2__["ProceduresService"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__["ScreenOrientation"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
], CurrentProceduresComponent);



/***/ }),

/***/ "./src/app/procedures/current-procedures/current-procedures.module.ts":
/*!****************************************************************************!*\
  !*** ./src/app/procedures/current-procedures/current-procedures.module.ts ***!
  \****************************************************************************/
/*! exports provided: CurrentProceduresModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrentProceduresModule", function() { return CurrentProceduresModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _current_procedures_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./current-procedures.component */ "./src/app/procedures/current-procedures/current-procedures.component.ts");
/* harmony import */ var src_app_utils_refreshUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");








let CurrentProceduresModule = class CurrentProceduresModule {
};
CurrentProceduresModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _current_procedures_component__WEBPACK_IMPORTED_MODULE_6__["CurrentProceduresComponent"]
                }
            ])
        ],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], src_app_utils_refreshUtils__WEBPACK_IMPORTED_MODULE_7__["RefreshUtils"]],
        declarations: [_current_procedures_component__WEBPACK_IMPORTED_MODULE_6__["CurrentProceduresComponent"]]
    })
], CurrentProceduresModule);



/***/ })

}]);
//# sourceMappingURL=procedures-current-procedures-current-procedures-module-es2015.js.map