(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shifts-shifts-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/shifts/shifts.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shifts/shifts.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <!-- <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\">\r\n      </ion-back-button> -->\r\n      <ion-button class=\"white\" text=\"Atrás\" (click)=\"goToHome()\">Atrás</ion-button>\r\n    </ion-buttons>\r\n    <ion-title>PORTAL PUNTANO</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-list>\r\n    <ion-list-header>\r\n      <h2 class=\"header-text-2\"><b>MIS TURNOS</b></h2>\r\n    </ion-list-header>\r\n  </ion-list>\r\n\r\n  <div *ngIf=\"shifts\">\r\n    <ion-list *ngFor=\"let item of shifts\">\r\n      <ion-list-header class=\"header-text\" (click)=\"expandOrCollapse(item)\">\r\n        <h5 style=\"margin-top: 0px; margin-bottom: 0px;\"><b>{{item.typeDesc}}</b></h5>\r\n        <svg *ngIf=\"!item.expanded\" xmlns='http://www.w3.org/2000/svg' height='50' viewBox='0 0 512 512'>\r\n          <title>ionicons-v5-a</title>\r\n          <polyline points='112 184 256 328 400 184'\r\n            style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n        </svg>\r\n        <svg *ngIf=\"item.expanded\" xmlns='http://www.w3.org/2000/svg' height='50' viewBox='0 0 512 512'>\r\n          <title>ionicons-v5-a</title>\r\n          <polyline points='112 328 256 184 400 328'\r\n            style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n        </svg>\r\n      </ion-list-header>\r\n      <div *ngIf=\"item.expanded\">\r\n        <div *ngFor=\"let liquidation of item.appointmentItemDtoList; let i = index\">        \r\n          <ion-item class=\"border-red\" *ngIf=\"2>i\">\r\n            <ion-list style=\"display: contents\">\r\n              <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n                <ion-label class=\"ion-text-wrap\">\r\n                  <ion-text class=\"red\">\r\n                    <div *ngFor=\"let file of liquidation.items\">\r\n                      <h2 *ngIf=\"file.value && file.name != 'id'\" style=\"display: block;\">{{file.name}}: {{file.value}}</h2>\r\n                    </div>\r\n                  </ion-text>\r\n                </ion-label>\r\n  \r\n              </ion-item>\r\n              <ion-button *ngIf=\"liquidation.items[5].value === 'Turno asignado'\" class=\"material-icons closeBtn\" (click)=\"cancelShift(liquidation)\">\r\n                <ion-icon ios=\"close\" md=\"close\"></ion-icon>\r\n              </ion-button>   \r\n            </ion-list>\r\n  \r\n          </ion-item>\r\n  \r\n        </div>\r\n        <!-- *ngIf=\"item.appointmentItemDtoList.length > 0\" -->\r\n        <div *ngIf=\"item.type === 'RM'\">\r\n          <ion-item  class=\"show-all\" lines=\"none\" (click)=\"goToShiftsDetailsRM(item)\">\r\n            <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n              <h4 style=\"display: inline;\"><b>Mostrar todos</b></h4>\r\n            </ion-text>\r\n            <svg xmlns='http://www.w3.org/2000/svg' height='25' viewBox='0 0 512 512'>\r\n              <title>ionicons-v5-a</title>\r\n              <polyline points='184 112 328 256 184 400'\r\n                style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n            </svg>\r\n          </ion-item>\r\n          <ion-item *ngIf=\"item.type === 'RM' \" class=\"show-all\" lines=\"none\" (click)=\"goNewShift()\">\r\n            <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n              <h4 style=\"display: inline;\"><b>Solicitar Turno</b></h4>\r\n            </ion-text>\r\n            <svg xmlns='http://www.w3.org/2000/svg' height='25' viewBox='0 0 512 512'>\r\n              <title>ionicons-v5-a</title>\r\n              <polyline points='184 112 328 256 184 400'\r\n                style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n            </svg>\r\n          </ion-item>\r\n        </div>\r\n  \r\n      </div>\r\n  \r\n  \r\n    </ion-list>\r\n  </div>\r\n  \r\n  <div *ngIf=\"!shifts\">\r\n    <!-- TODO error al compilar con '--prod'-->\r\n    <!--<ion-list-header class=\"header-text\" (click)=\"expandOrCollapse(item)\">-->\r\n    <ion-list-header class=\"header-text\">\r\n      <h5 style=\"margin-top: 0px; margin-bottom: 0px;\"><b>RM</b></h5>\r\n    </ion-list-header>\r\n    <!-- TODO error al compilar con '--prod'-->\r\n    <!-- <ion-item  class=\"show-all\" lines=\"none\" (click)=\"goToShiftsDetailsRM(item)\"> -->\r\n    <ion-item  class=\"show-all\" lines=\"none\">\r\n      <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n        <h4 style=\"display: inline;\"><b>Mostrar todos</b></h4>\r\n      </ion-text>\r\n      <svg xmlns='http://www.w3.org/2000/svg' height='25' viewBox='0 0 512 512'>\r\n        <title>ionicons-v5-a</title>\r\n        <polyline points='184 112 328 256 184 400'\r\n          style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n      </svg>\r\n    </ion-item>\r\n    <ion-item class=\"show-all\" lines=\"none\" (click)=\"goNewShift()\">\r\n      <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n        <h4 style=\"display: inline;\"><b>Solicitar Turno</b></h4>\r\n      </ion-text>\r\n      <svg xmlns='http://www.w3.org/2000/svg' height='25' viewBox='0 0 512 512'>\r\n        <title>ionicons-v5-a</title>\r\n        <polyline points='184 112 328 256 184 400'\r\n          style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n      </svg>\r\n    </ion-item>\r\n  </div>\r\n\r\n  <ion-list *ngFor=\"let item of shiftsRC\">\r\n    <ion-list-header class=\"header-text\" (click)=\"expandOrCollapse(item)\">\r\n      <h5 style=\"margin-top: 0px; margin-bottom: 0px;\"><b>{{item.typeDesc}}</b></h5>\r\n      <svg *ngIf=\"!item.expanded\" xmlns='http://www.w3.org/2000/svg' height='50' viewBox='0 0 512 512'>\r\n        <title>ionicons-v5-a</title>\r\n        <polyline points='112 184 256 328 400 184'\r\n          style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n      </svg>\r\n      <svg *ngIf=\"item.expanded\" xmlns='http://www.w3.org/2000/svg' height='50' viewBox='0 0 512 512'>\r\n        <title>ionicons-v5-a</title>\r\n        <polyline points='112 328 256 184 400 328'\r\n          style='fill:none;stroke:#FFF;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n      </svg>\r\n    </ion-list-header>\r\n    <div *ngIf=\"item.expanded\">\r\n      <div *ngFor=\"let liquidation of item.appointmentItemDtoList; let i = index\">        \r\n        <ion-item class=\"border-red\" *ngIf=\"2>i\">\r\n          <ion-list style=\"display: contents\">\r\n            <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n              <ion-label class=\"ion-text-wrap\">\r\n                <ion-text class=\"red\">\r\n                  <div *ngFor=\"let file of liquidation.items\">\r\n                    <h2 *ngIf=\"file.value\" style=\"display: block;\">{{file.name}}: {{file.value}}</h2>\r\n                  </div>\r\n                </ion-text>\r\n              </ion-label>\r\n\r\n            </ion-item>\r\n          </ion-list>\r\n\r\n        </ion-item>\r\n\r\n      </div>\r\n      <div>\r\n        <ion-item class=\"show-all\" lines=\"none\" (click)=\"goToShiftsDetails(item)\">\r\n          <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n            <h4 style=\"display: inline;\"><b>Mostrar todos</b></h4>\r\n          </ion-text>\r\n          <svg xmlns='http://www.w3.org/2000/svg' height='25' viewBox='0 0 512 512'>\r\n            <title>ionicons-v5-a</title>\r\n            <polyline points='184 112 328 256 184 400'\r\n              style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n          </svg>\r\n        </ion-item>\r\n      </div>\r\n\r\n    </div>\r\n\r\n\r\n  </ion-list>\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/shifts/shifts-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/shifts/shifts-routing.module.ts ***!
  \*************************************************/
/*! exports provided: ShiftsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftsPageRoutingModule", function() { return ShiftsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shifts_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shifts.page */ "./src/app/shifts/shifts.page.ts");




var routes = [
    {
        path: '',
        component: _shifts_page__WEBPACK_IMPORTED_MODULE_3__["ShiftsPage"]
    }
];
var ShiftsPageRoutingModule = /** @class */ (function () {
    function ShiftsPageRoutingModule() {
    }
    ShiftsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], ShiftsPageRoutingModule);
    return ShiftsPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/shifts/shifts.module.ts":
/*!*****************************************!*\
  !*** ./src/app/shifts/shifts.module.ts ***!
  \*****************************************/
/*! exports provided: ShiftsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftsPageModule", function() { return ShiftsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _shifts_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./shifts-routing.module */ "./src/app/shifts/shifts-routing.module.ts");
/* harmony import */ var _shifts_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./shifts.page */ "./src/app/shifts/shifts.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _services_shift_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../services/shift.service */ "./src/app/services/shift.service.ts");













var ShiftsPageModule = /** @class */ (function () {
    function ShiftsPageModule() {
    }
    ShiftsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
                _shifts_routing_module__WEBPACK_IMPORTED_MODULE_5__["ShiftsPageRoutingModule"]
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
                _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
                _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"],
                _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__["FileOpener"],
                _services_shift_service__WEBPACK_IMPORTED_MODULE_12__["ShiftService"]],
            declarations: [_shifts_page__WEBPACK_IMPORTED_MODULE_6__["ShiftsPage"]]
        })
    ], ShiftsPageModule);
    return ShiftsPageModule;
}());



/***/ }),

/***/ "./src/app/shifts/shifts.page.scss":
/*!*****************************************!*\
  !*** ./src/app/shifts/shifts.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #20B572;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #20B572;\n}\n\n.header-text {\n  padding-left: 10px;\n  width: 95%;\n  margin-bottom: 10px;\n  margin-top: 5px;\n  margin-left: 10px;\n  margin-right: 10px;\n  background-color: #20B572;\n  color: #ffffff;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #20B572;\n}\n\nion-header ion-toolbar ion-title {\n  color: #ffffff;\n}\n\n.white {\n  color: #ffffff !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\n.show-all {\n  --min-height: 20px;\n  border-radius: 6px;\n  background-color: #e6e6e6;\n  --ion-background-color: #e6e6e6;\n  margin-top: 2%;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.header-text-2 {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n  margin-bottom: 0px;\n}\n\n.closeBtn {\n  cursor: pointer;\n  filter: none !important;\n  -webkit-filter: none !important;\n  --background: transparent;\n  --box-shadow: none;\n  --border-radius: 10rem !important;\n  padding: 0 !important;\n  --background: #20B572;\n  margin-bottom: auto;\n  font-size: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hpZnRzL0Q6XFxSZXBvc2l0b3Jpb3NcXHBvcnRhbC1pb25pYy9zcmNcXGFwcFxcc2hpZnRzXFxzaGlmdHMucGFnZS5zY3NzIiwic3JjL2FwcC9zaGlmdHMvc2hpZnRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUNDRjs7QURJQTtFQUNFLGdDQUFBO0FDREY7O0FESUE7RUFHRSxrQkFBQTtFQUNBLFVBQUE7RUFHQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsOEJBQUE7QUNMRjs7QURRQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQ0xGOztBRFFBO0VBQ0UsbUJBQUE7RUFDQSxrQkFBQTtBQ0xGOztBRFFBO0VBQ0UscUJBQUE7QUNMRjs7QURPQTtFQUNFLGNBQUE7QUNKRjs7QURPQTtFQUNFLHlCQUFBO0FDSkY7O0FET0E7RUFDRSxrQkFBQTtFQUNBLGVBQUE7QUNKRjs7QURPQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FDSkY7O0FET0E7RUFDRSwyQkFBQTtFQUNBLGlDQUFBO0FDSkY7O0FET0E7RUFDRSwyQkFBQTtBQ0pGOztBRE1BO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsK0JBQUE7RUFDQSxjQUFBO0FDSEY7O0FETUE7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDSEY7O0FETUE7RUFDRSxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7QUNIRjs7QURLQTtFQUNFLGVBQUE7RUFDQSx1QkFBQTtFQUNBLCtCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlDQUFBO0VBQ0EscUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtBQ0ZGIiwiZmlsZSI6InNyYy9hcHAvc2hpZnRzL3NoaWZ0cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVkIHtcclxuICBjb2xvcjogIzIwQjU3MjtcclxufVxyXG5cclxuXHJcblxyXG5pb24taXRlbS5ib3JkZXItcmVkIHtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzIwQjU3MjtcclxufVxyXG5cclxuLmhlYWRlci10ZXh0IHtcclxuICAvLyBib3JkZXItYm90dG9tOjJweCBzb2xpZCAjNTM1MzUzO1xyXG4gIC8vIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gIHdpZHRoOiA5NSU7XHJcbiAgLy8gcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgLy8gcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMyMEI1NzI7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gIG1hcmdpbi1yaWdodDogNSU7XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxufVxyXG5cclxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjMjBCNTcyO1xyXG59XHJcbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxufVxyXG5cclxuLndoaXRlIHtcclxuICBjb2xvcjogI2ZmZmZmZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tbGFiZWwge1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zYy1pb24tY2FyZC1tZC1oIHtcclxuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBcIlwiICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1jYXJkIHtcclxuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuLnNob3ctYWxsIHtcclxuICAtLW1pbi1oZWlnaHQ6IDIwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNlNmU2ZTY7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcclxuICBtYXJnaW4tdG9wOiAyJTtcclxufVxyXG5cclxuaW9uLXRpdGxle1xyXG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgZm9udC1zaXplOiA1dnc7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uaGVhZGVyLXRleHQtMntcclxuICBib3JkZXItYm90dG9tOjJweCBzb2xpZCAjNTM1MzUzO1xyXG4gIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcbi5jbG9zZUJ0biB7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGZpbHRlcjogbm9uZSAhaW1wb3J0YW50O1xyXG4gIC13ZWJraXQtZmlsdGVyOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiAxMHJlbSAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICAtLWJhY2tncm91bmQ6ICMyMEI1NzI7XHJcbiAgbWFyZ2luLWJvdHRvbTogYXV0bztcclxuICBmb250LXNpemU6IDE1cHg7XHJcbn0iLCIucmVkIHtcbiAgY29sb3I6ICMyMEI1NzI7XG59XG5cbmlvbi1pdGVtLmJvcmRlci1yZWQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzIwQjU3Mjtcbn1cblxuLmhlYWRlci10ZXh0IHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB3aWR0aDogOTUlO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICMyMEI1NzI7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG5pb24tbGlzdCB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzIwQjU3Mjtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI2ZmZmZmZjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNmZmZmZmYgIWltcG9ydGFudDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5zYy1pb24tY2FyZC1tZC1oIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAtd2Via2l0LWJveC1zaGFkb3c6IFwiXCIgIWltcG9ydGFudDtcbn1cblxuaW9uLWNhcmQge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbi5zaG93LWFsbCB7XG4gIC0tbWluLWhlaWdodDogMjBweDtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xuICBtYXJnaW4tdG9wOiAyJTtcbn1cblxuaW9uLXRpdGxlIHtcbiAgcGFkZGluZy1yaWdodDogNSU7XG4gIHBhZGRpbmctbGVmdDogNSU7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5oZWFkZXItdGV4dC0yIHtcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICM1MzUzNTM7XG4gIG1hcmdpbi1yaWdodDogNSU7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG4uY2xvc2VCdG4ge1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGZpbHRlcjogbm9uZSAhaW1wb3J0YW50O1xuICAtd2Via2l0LWZpbHRlcjogbm9uZSAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAtLWJveC1zaGFkb3c6IG5vbmU7XG4gIC0tYm9yZGVyLXJhZGl1czogMTByZW0gIWltcG9ydGFudDtcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6ICMyMEI1NzI7XG4gIG1hcmdpbi1ib3R0b206IGF1dG87XG4gIGZvbnQtc2l6ZTogMTVweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/shifts/shifts.page.ts":
/*!***************************************!*\
  !*** ./src/app/shifts/shifts.page.ts ***!
  \***************************************/
/*! exports provided: ShiftsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftsPage", function() { return ShiftsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _services_shift_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../services/shift.service */ "./src/app/services/shift.service.ts");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");

















var ShiftsPage = /** @class */ (function () {
    function ShiftsPage(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, shiftService, loading, toastController, screenOrientation, navController, refreshUtils, statusBar, platform) {
        var _this = this;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.shiftService = shiftService;
        this.loading = loading;
        this.toastController = toastController;
        this.screenOrientation = screenOrientation;
        this.navController = navController;
        this.refreshUtils = refreshUtils;
        this.statusBar = statusBar;
        this.platform = platform;
        this.httpOptions = null;
        this.seeAll = false;
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(function (params) {
            if (_this.router.getCurrentNavigation().extras.state) {
                // this.shifts = this.router.getCurrentNavigation().extras.state.shifts;
                _this.token = _this.router.getCurrentNavigation().extras.state.token;
                //this.makeLiquidationsCollapse();
            }
        });
    }
    ShiftsPage.prototype.getAppointmentsRM = function () {
        var _this = this;
        this.loading.present();
        this.getToken().then(function (value) {
            _this.shiftService.getAppointmentsRM(_this.httpOptions, null).subscribe(function (response) {
                _this.loading.dismiss();
                _this.shifts = response;
                if (response[0].appointmentItemDtoList.length > 0) {
                    _this.seeAll = true;
                }
                else {
                    _this.seeAll = false;
                }
                _this.makeLiquidationsCollapse();
            }, function (error) {
                _this.loading.dismiss();
                if (error.status === 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                }
            });
        });
    };
    ShiftsPage.prototype.getAppointmentsRC = function () {
        var _this = this;
        this.loading.present();
        this.getToken().then(function (value) {
            _this.shiftService.getAppointmentsRC(_this.httpOptions).subscribe(function (response) {
                _this.loading.dismiss();
                _this.shiftsRC = response;
                _this.makeLiquidationsCollapseRC();
            }, function (error) {
                _this.loading.dismiss();
                if (error.status === 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                }
            });
        });
    };
    ShiftsPage.prototype.makeLiquidationsCollapse = function () {
        var shiftsTemporal = [];
        var firstTime = true;
        this.shifts.forEach(function (element) {
            var elementTemporal = {
                type: element.type,
                typeDesc: element.typeDesc,
                appointmentItemDtoList: element.appointmentItemDtoList,
                expanded: firstTime,
            };
            shiftsTemporal.push(elementTemporal);
            firstTime = false;
        });
        this.shifts = shiftsTemporal;
    };
    ShiftsPage.prototype.makeLiquidationsCollapseRC = function () {
        var shiftsTemporal = [];
        var firstTime = true;
        this.shiftsRC.forEach(function (element) {
            var elementTemporal = {
                type: element.type,
                typeDesc: element.typeDesc,
                appointmentItemDtoList: element.appointmentItemDtoList,
                expanded: firstTime,
            };
            shiftsTemporal.push(elementTemporal);
            firstTime = false;
        });
        this.shiftsRC = shiftsTemporal;
    };
    ShiftsPage.prototype.expandOrCollapse = function (item) {
        item.expanded = !item.expanded;
    };
    ShiftsPage.prototype.ionViewWillEnter = function () {
        this.statusBar.backgroundColorByHexString('#20B572');
    };
    ShiftsPage.prototype.ngOnInit = function () {
        this.getAppointmentsRM();
        this.getAppointmentsRC();
    };
    ShiftsPage.prototype.deleteDataAndExitToLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.storage.clear().then(function () {
                    _this.navController.navigateRoot("/login");
                });
                return [2 /*return*/];
            });
        });
    };
    ShiftsPage.prototype.alert = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Portal puntano',
                            message: messageText,
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel',
                                    cssClass: 'primary',
                                    handler: function () {
                                        console.log('OK pressed!!');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ShiftsPage.prototype.goToShiftsDetails = function (shifts) {
        var navigationExtras = {
            state: {
                content: shifts,
                token: this.token
            }
        };
        this.router.navigate(['shifts-details'], navigationExtras);
    };
    ShiftsPage.prototype.goToShiftsDetailsRM = function (shifts) {
        var navigationExtras = {
            state: {
                content: shifts,
                token: this.token
            }
        };
        this.router.navigate(['shifts-details-rm'], navigationExtras);
    };
    ShiftsPage.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
    };
    ShiftsPage.prototype.goNewShift = function () {
        //this.navController.navigateRoot("/new-appointment-rm", navigationExtras);
        this.router.navigate(['new-shifts']);
    };
    ShiftsPage.prototype.cancelShift = function (shift) {
        var _this = this;
        this.loading.present();
        sweetalert2__WEBPACK_IMPORTED_MODULE_13___default.a.fire({
            title: 'Aviso',
            text: '¿Desea cancelar el Turno reservado?',
            imageUrl: "../../assets/icon/GreenWarning.png",
            imageWidth: 100,
            imageHeight: 100,
            showCancelButton: true,
            confirmButtonColor: '#20B572',
            confirmButtonText: 'Aceptar',
            cancelButtonText: "Cancelar"
        }).then(function (result) {
            if (result.isConfirmed) {
                _this.getToken().then(function (value) {
                    _this.shiftService.updateAppointmentCancel(_this.httpOptions, shift.items[0].value).subscribe(function (response) {
                        if (response) {
                            _this.getAppointmentsRM();
                        }
                    }, function (error) {
                        _this.loading.dismiss();
                        if (error.status === 409) {
                            _this.alert(error.error.message);
                        }
                        else {
                            _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_12__["constants"].GENERIC_ERROR);
                        }
                    });
                });
            }
        });
    };
    ShiftsPage.prototype.presentToast = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: 'El Turno se Cancelo exitosamente',
                            duration: 5000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ShiftsPage.prototype.getToken = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.storage.get('token').then(function (value) {
                            var httpOptions = {
                                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
                                    'Content-Type': 'application/json',
                                    'Accept': 'application/json',
                                    'X-Authorization': 'Bearer ' + value,
                                }),
                                response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpResponse"]({
                                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
                                        'Content-Type': 'application/json',
                                        'Accept': 'application/json'
                                    }),
                                })
                            };
                            _this.httpOptions = httpOptions;
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ShiftsPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
        { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__["FileTransfer"] },
        { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
        { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
        { type: _services_shift_service__WEBPACK_IMPORTED_MODULE_14__["ShiftService"] },
        { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_16__["LoadingService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
        { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] }
    ]; };
    ShiftsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-shifts',
            template: __webpack_require__(/*! raw-loader!./shifts.page.html */ "./node_modules/raw-loader/index.js!./src/app/shifts/shifts.page.html"),
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_15__["trigger"])('visibilityChanged', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_15__["state"])('shown', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_15__["style"])({ opacity: 1 })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_15__["state"])('hidden', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_15__["style"])({ opacity: 0 })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_15__["transition"])('* => *', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_15__["animate"])('500ms'))
                ])
            ],
            styles: [__webpack_require__(/*! ./shifts.page.scss */ "./src/app/shifts/shifts.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__["FileTransfer"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
            _services_shift_service__WEBPACK_IMPORTED_MODULE_14__["ShiftService"],
            _services_loading_service__WEBPACK_IMPORTED_MODULE_16__["LoadingService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]])
    ], ShiftsPage);
    return ShiftsPage;
}());



/***/ })

}]);
//# sourceMappingURL=shifts-shifts-module-es5.js.map