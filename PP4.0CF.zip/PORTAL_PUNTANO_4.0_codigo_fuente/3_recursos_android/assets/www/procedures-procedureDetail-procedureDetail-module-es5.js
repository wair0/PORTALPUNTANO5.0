(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["procedures-procedureDetail-procedureDetail-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/procedures/procedureDetail/procedureDetail.page.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/procedures/procedureDetail/procedureDetail.page.html ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Detalle del trámite</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-item lines=\"none\" style=\"margin: 0;\" *ngIf=\"item\">\r\n      <ion-row style=\"align-items: center;\">\r\n        <ion-col size=\"auto\" *ngIf=\"item.procedureStatus || item.status\">\r\n          <h1 class=\"status\"><b>{{item.procedureStatus? item.procedureStatus: item.status}}</b></h1>\r\n        </ion-col>\r\n        <ion-col>\r\n          <ion-label class=\"ion-text-wrap\">\r\n            <h3 *ngIf=\"item.dateCreated\"><b>{{item.dateCreated | date:\"dd/MM/yyyy - HH:mm a\"}}</b></h3>\r\n            <h3 *ngIf=\"item.coverLetter\">{{item.coverLetter}}</h3>\r\n            <h3 *ngIf=\"item.procedureId\">Nro de trámite: {{item.procedureId}}</h3>\r\n            <h3 *ngIf=\"item.fileNumber\"><b>{{item.fileNumber}}</b></h3>\r\n          </ion-label>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-item>\r\n\r\n  <ion-list *ngFor=\"let step of steps\">    \r\n\r\n    <ion-list-header *ngIf=\"step.name\">\r\n      <h1 class=\"header-text\"><b>{{step.name}}</b></h1>\r\n    </ion-list-header>\r\n\r\n    <div style=\"margin-bottom: 20px\" *ngIf=\"!step.name\"></div>\r\n\r\n    <div *ngFor=\"let attribute of step.attributes\">\r\n    <ion-item lines=\"none\" style=\"margin-bottom: 10px\" *ngIf=\"attribute.dataValue && attribute.tipo!== 'FILE'\">\r\n      <ion-label class=\"ion-text-wrap\" >\r\n        <ion-text color=\"dark\">\r\n          <h2 > {{attribute.name}}: </h2>\r\n          <h2 ><b>{{attribute.dataValue}}</b></h2>\r\n        </ion-text>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n  <ion-item lines=\"none\" *ngIf=\"attribute.dataValue && attribute.tipo === 'FILE'\" (click)=\"checkPassword(attribute)\">\r\n    <ion-label class=\"ion-text-wrap\" >\r\n      <ion-text color=\"dark\">\r\n        <h2> {{attribute.name}}: </h2>\r\n      </ion-text>\r\n      <ion-card no-margin text-center style=\"padding: 0px; margin: 0px;\" >\r\n        <!-- <ion-icon src=\"../assets/download-outline_pink.svg\" style=\" width: 30%; height: 30%;\"></ion-icon> -->\r\n        <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n        width=\"30%\" height=\"30%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n     <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#FF0067\" d=\"M862.973,656.11h-89.835v148.416\r\n       c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n       c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n       c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n       c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n       C840.518,409.458,840.518,415.762,837.57,419.12\"/>\r\n     </svg>\r\n      </ion-card>\r\n    </ion-label>\r\n    \r\n  </ion-item>\r\n\r\n  </div>\r\n\r\n  </ion-list>\r\n\r\n  <!-- <ion-item lines=\"none\" (click)=\"download(consultation.id)\">\r\n    <ion-card text-center padding >\r\n      <ion-icon src=\"../assets/download-outline_red.svg\" style=\" width: 30%; height: 30%;\"></ion-icon>\r\n    </ion-card>\r\n  </ion-item> -->\r\n\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n      <ion-buttons>\r\n        <ion-button (click)=\"goToHome()\">\r\n          <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\" ></ion-icon>\r\n        </ion-button>\r\n        </ion-buttons>\r\n      </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/procedures/procedureDetail/procedureDetail.module.ts":
/*!**********************************************************************!*\
  !*** ./src/app/procedures/procedureDetail/procedureDetail.module.ts ***!
  \**********************************************************************/
/*! exports provided: ProcedureDetailModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcedureDetailModule", function() { return ProcedureDetailModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _procedureDetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./procedureDetail.page */ "./src/app/procedures/procedureDetail/procedureDetail.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");












var ProcedureDetailModule = /** @class */ (function () {
    function ProcedureDetailModule() {
    }
    ProcedureDetailModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _procedureDetail_page__WEBPACK_IMPORTED_MODULE_6__["ProcedureDetailPage"]
                    }
                ])
            ],
            providers: [
                _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
                _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
                _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__["FileOpener"],
                _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__["RefreshUtils"]
            ],
            declarations: [_procedureDetail_page__WEBPACK_IMPORTED_MODULE_6__["ProcedureDetailPage"]]
        })
    ], ProcedureDetailModule);
    return ProcedureDetailModule;
}());



/***/ }),

/***/ "./src/app/procedures/procedureDetail/procedureDetail.page.scss":
/*!**********************************************************************!*\
  !*** ./src/app/procedures/procedureDetail/procedureDetail.page.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #FF0067;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #FF0067;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #FF0067;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvY2VkdXJlcy9wcm9jZWR1cmVEZXRhaWwvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxwcm9jZWR1cmVzXFxwcm9jZWR1cmVEZXRhaWxcXHByb2NlZHVyZURldGFpbC5wYWdlLnNjc3MiLCJzcmMvYXBwL3Byb2NlZHVyZXMvcHJvY2VkdXJlRGV0YWlsL3Byb2NlZHVyZURldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxjQUFBO0FDQUo7O0FES0E7RUFDSSxnQ0FBQTtBQ0ZKOztBREtHO0VBQ0MsZ0NBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtBQ0ZKOztBREtHO0VBQ0MsZUFBQTtFQUNBLGdCQUFBO0FDRko7O0FES0c7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0FDRlA7O0FES0c7RUFDQyxxQkFBQTtBQ0ZKOztBREtHO0VBQ0MsY0FBQTtBQ0ZKOztBREtBO0VBQ0kseUJBQUE7QUNGSjs7QURLRztFQUNJLGtCQUFBO0VBQ0EsZUFBQTtBQ0ZQOztBRE1HO0VBQ0MsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNISjs7QURNQTtFQUNJLDJCQUFBO0VBQ0EsaUNBQUE7QUNISjs7QURNQTtFQUNJLDJCQUFBO0FDSEo7O0FETUE7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDSEoiLCJmaWxlIjoic3JjL2FwcC9wcm9jZWR1cmVzL3Byb2NlZHVyZURldGFpbC9wcm9jZWR1cmVEZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5yZWR7XHJcbiAgICBjb2xvcjogI0ZGMDA2N1xyXG59XHJcblxyXG5cclxuXHJcbmlvbi1pdGVtLmJvcmRlci1yZWQge1xyXG4gICAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgI0ZGMDA2NztcclxuICAgfVxyXG5cclxuICAgLmhlYWRlci10ZXh0e1xyXG4gICAgYm9yZGVyLWJvdHRvbToycHggc29saWQgIzUzNTM1MztcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICB9XHJcblxyXG4gICBpb24taXRlbXtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgIH1cclxuXHJcbiAgIGlvbi1saXN0e1xyXG4gICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgIG1hcmdpbi1ib3R0b206MHB4O1xyXG4gICB9XHJcblxyXG4gICBpb24taGVhZGVyIGlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRkYwMDY3O1xyXG4gICAgXHJcbiAgIH1cclxuICAgaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGV7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgfVxyXG5cclxuLndoaXRle1xyXG4gICAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcclxufVxyXG5cclxuICAgaW9uLWxhYmVse1xyXG4gICAgICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gICAgICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICB9XHJcblxyXG5cclxuICAgaW9uLWNvbnRlbnQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLnNjLWlvbi1jYXJkLW1kLWgge1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OlwiXCIgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWNhcmR7XHJcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi10aXRsZXtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIGZvbnQtc2l6ZTogNXZ3O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbiIsIi5yZWQge1xuICBjb2xvcjogI0ZGMDA2Nztcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRkYwMDY3O1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzUzNTM1MztcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuaW9uLWxpc3Qge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICNGRjAwNjc7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xufVxuXG5pb24tY29udGVudCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uc2MtaW9uLWNhcmQtbWQtaCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBcIlwiICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG5pb24tdGl0bGUge1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgZm9udC1zaXplOiA1dnc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/procedures/procedureDetail/procedureDetail.page.ts":
/*!********************************************************************!*\
  !*** ./src/app/procedures/procedureDetail/procedureDetail.page.ts ***!
  \********************************************************************/
/*! exports provided: ProcedureDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcedureDetailPage", function() { return ProcedureDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _device_device_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../device/device.service */ "./src/app/device/device.service.ts");














var ProcedureDetailPage = /** @class */ (function () {
    function ProcedureDetailPage(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, deviceDetailsService, screenOrientation, statusBar, navController, refreshUtils, platform) {
        var _this = this;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.deviceDetailsService = deviceDetailsService;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.refreshUtils = refreshUtils;
        this.platform = platform;
        this.processError = function (error) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                _this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        _this.storage.get('psw').then(function (val) {
                            if (val) {
                                _this.loadingWithMessage("Descargando");
                                _this.refreshUtils.refreshToken(val).then(function (value) {
                                    _this.loadingController.dismiss();
                                    resolve(value);
                                }).catch(function (errorRefresh) {
                                    _this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        _this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    _this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(function (params) {
            if (_this.router.getCurrentNavigation().extras.state) {
                _this.item = _this.router.getCurrentNavigation().extras.state.procedureItem;
                _this.steps = _this.router.getCurrentNavigation().extras.state.steps;
                _this.token = _this.router.getCurrentNavigation().extras.state.token;
            }
        });
    }
    ProcedureDetailPage.prototype.ionViewWillEnter = function () {
        this.statusBar.backgroundColorByHexString('#FF0067');
    };
    ProcedureDetailPage.prototype.ngOnInit = function () {
    };
    ProcedureDetailPage.prototype.deleteDataAndExitToLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.storage.clear().then(function () {
                    _this.navController.navigateRoot("/login");
                });
                return [2 /*return*/];
            });
        });
    };
    ProcedureDetailPage.prototype.alert = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Portal puntano',
                            message: messageText,
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel',
                                    cssClass: 'primary',
                                    handler: function () {
                                        console.log('OK pressed!!');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProcedureDetailPage.prototype.loading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: 'Cargando',
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProcedureDetailPage.prototype.loadingWithMessage = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: messageText,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProcedureDetailPage.prototype.checkPassword = function (attribute) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loadingWithMessage("Descargando");
                this.storage.get('token').then(function (val) {
                    if (val) {
                        _this.token = val;
                        var httpOptions = {
                            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                'Content-Type': 'application/json',
                                'Accept': 'application/json',
                                'X-Authorization': 'Bearer ' + _this.token,
                            }),
                            response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                    'Content-Type': 'application/json',
                                    'Accept': 'application/json'
                                }),
                            })
                        };
                        console.log("URL: " + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/mobile/check/password");
                        console.log("TOKEN: " + 'Bearer ' + _this.token);
                        _this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/mobile/check/password", httpOptions)
                            .subscribe(function (data) {
                            _this.download(attribute);
                        }, function (error) {
                            _this.processError(error).then(function (value) {
                                _this.checkPassword(attribute);
                            });
                        });
                    }
                    else {
                        _this.loadingController.dismiss();
                        _this.alert("Ocurrió un problema, intente nuevamente");
                    }
                });
                return [2 /*return*/];
            });
        });
    };
    ProcedureDetailPage.prototype.download = function (attribute) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var fileName, filePath, url, options, directory, soVersion;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                fileName = attribute.name + "_" + attribute.dataValue + ".pdf";
                filePath = _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/files/download/" + attribute.dataValue;
                url = encodeURI(filePath);
                this.fileTransfer = this.transfer.create();
                options = {
                    headers: {
                        "X-Authorization": "Bearer " + this.token
                    }
                };
                directory = this.file.documentsDirectory;
                // if (this.platform.is("android")) {
                //   if(this.file.externalRootDirectory){
                //     directory = this.file.externalRootDirectory + constants.FOLDER_DOWNLOAD
                //     }else{
                //       directory = this.file.dataDirectory + constants.FOLDER_DOWNLOAD
                //     }
                // }
                if (this.platform.is("android")) {
                    soVersion = parseFloat(this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                    //if(this.file.externalRootDirectory){
                    console.log("[HOME] OS VERSION: " + soVersion);
                    if (soVersion < 11) {
                        if (this.file.externalRootDirectory) {
                            directory = this.file.externalRootDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD;
                        }
                        else {
                            directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD;
                        }
                    }
                    else {
                        directory = this.file.dataDirectory + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD;
                    }
                }
                this.fileTransfer.download(url, directory + fileName, true, options).then(function (entry) {
                    _this.loadingController.dismiss();
                    //here logging our success downloaded file path in mobile. 
                    console.log('download completed: ' + entry.toURL());
                    _this.file.resolveDirectoryUrl(directory).then(function (rootDir) {
                        _this.file.getFile(rootDir, fileName, { create: false }).then(function (fileEntry) {
                            fileEntry.getMetadata(function (metadata) {
                                if (metadata.size != 0) {
                                    // open downloaded file 
                                    _this.openFileHandler(entry.toURL());
                                    if (_this.platform.is("android")) {
                                        var soVersion = parseFloat(_this.deviceDetailsService.osVersion.match(/\d+((.|,)\d+)?/)[0]);
                                        if (soVersion < 11) {
                                            if (_this.file.externalRootDirectory) {
                                                _this.alert("Documento \"" + fileName + "\" guardado en la carpeta \"" + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FOLDER_DOWNLOAD.slice(0, -1) + "\" de la memoria del dispositivo");
                                            }
                                        }
                                    }
                                }
                                else {
                                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].FILE_SIZE_0_ERROR);
                                }
                            });
                        });
                    });
                }).catch(function (error) {
                    _this.loadingController.dismiss();
                    if (error != null && error.http_status != null && error.http_status == 409) {
                        _this.alert(JSON.parse(error.body).message);
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                    }
                    //here logging an error. 
                    console.log('download failed: ' + JSON.stringify(error));
                });
                return [2 /*return*/];
            });
        });
    };
    ProcedureDetailPage.prototype.openFileHandler = function (path) {
        this.fileOpener.open(path, '')
            .then(function () { return console.log('File is opened'); })
            .catch(function (e) { return console.log('Error opening file', e); });
    };
    ProcedureDetailPage.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
    };
    ProcedureDetailPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"] },
        { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
        { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
        { type: _device_device_service__WEBPACK_IMPORTED_MODULE_13__["DeviceDetailsService"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_11__["ScreenOrientation"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__["StatusBar"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] }
    ]; };
    ProcedureDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-procedureDetail',
            template: __webpack_require__(/*! raw-loader!./procedureDetail.page.html */ "./node_modules/raw-loader/index.js!./src/app/procedures/procedureDetail/procedureDetail.page.html"),
            styles: [__webpack_require__(/*! ./procedureDetail.page.scss */ "./src/app/procedures/procedureDetail/procedureDetail.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
            _device_device_service__WEBPACK_IMPORTED_MODULE_13__["DeviceDetailsService"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_11__["ScreenOrientation"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__["StatusBar"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_10__["RefreshUtils"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]])
    ], ProcedureDetailPage);
    return ProcedureDetailPage;
}());



/***/ })

}]);
//# sourceMappingURL=procedures-procedureDetail-procedureDetail-module-es5.js.map