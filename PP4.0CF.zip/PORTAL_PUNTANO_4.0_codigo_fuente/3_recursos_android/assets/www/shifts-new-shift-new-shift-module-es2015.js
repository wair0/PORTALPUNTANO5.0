(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shifts-new-shift-new-shift-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/shifts/new-shift/new-shift.component.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shifts/new-shift/new-shift.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>NUEVO TURNO</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-item class=\"tapShift\">\r\n  <ion-button [attr.color]=\"classPersonal\" class=\"btnRight\" (click)=\"chargeForm('Personal')\">Personal</ion-button>\r\n  <ion-button [attr.color]=\"classPersHasDep\" class=\"btnRight\" [attr.disabled]=\"!seeDependents? '' : null\"\r\n    (click)=\"chargeForm('PersonaACargo')\">Persona a Cargo</ion-button>\r\n</ion-item>\r\n\r\n\r\n<ion-content *ngIf=\"currentForm === 'Personal'\">\r\n  <mat-accordion>\r\n    <mat-expansion-panel [expanded]=\"panelOpenState\" (opened)=\"setStep()\">\r\n      <mat-expansion-panel-header>\r\n        <mat-panel-title>\r\n          <ion-card-header>\r\n            <h2 class=\"header-text\"><b>FILTROS DE BÚSQUEDA</b></h2>\r\n          </ion-card-header>\r\n        </mat-panel-title>\r\n      </mat-expansion-panel-header>\r\n      <form [formGroup]=\"formPersonal\">\r\n        <ion-card-content>\r\n          <div class=\"shadowDiv\">\r\n\r\n            <div>\r\n              <ion-item>\r\n                <ion-label>Centro de salud</ion-label>\r\n                <ion-select cancelText=\"Cancelar\" formControlName=\"healthCenterCtrl\" (ionChange)='getSpecialty()'\r\n                  interface='action-sheet'>\r\n                  <ion-select-option [value]=\"item.id\" *ngFor=\"let item of healthCenters\">{{item.name}}\r\n                  </ion-select-option>\r\n                </ion-select>\r\n              </ion-item>\r\n            </div>\r\n\r\n            <ion-item>\r\n              <ion-label>Especialidad</ion-label>\r\n              <ion-select cancelText=\"Cancelar\" [disabled]='!healthCenterSelected' interface='action-sheet'\r\n                formControlName=\"specialtyCtrl\" (ionChange)='getProfessionals()'>\r\n                <ion-select-option class=\"select-full-width\" [value]=\"item\" *ngFor=\"let item of specialties\">\r\n                  {{item.name}}\r\n                </ion-select-option>\r\n              </ion-select>\r\n            </ion-item>\r\n\r\n\r\n            <!-- Profesional -->\r\n            <ion-item>\r\n              <ion-label>Profesional</ion-label>\r\n              <ion-select cancelText=\"Cancelar\" [disabled]='!specialtySelected' interface='action-sheet'\r\n                formControlName=\"professionalCtrl\">\r\n                <ion-select-option class=\"select-full-width\" [value]=\"item\" *ngFor=\"let item of professionalList\">\r\n                  {{item.fullAliasName? item.fullAliasName: item.fullName}}\r\n                </ion-select-option>\r\n              </ion-select>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <mat-form-field class=\"matDate\" appearance=\"fill\">\r\n                <mat-label>Fecha Desde</mat-label>\r\n                <input formControlName=\"fromDateCtrl\" [min]=\"today\" matInput [matDatepicker]=\"picker\">\r\n                <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n                <mat-datepicker #picker></mat-datepicker>\r\n              </mat-form-field>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-button [disabled]='!this.formPersonal.valid' color=\"green\" class=\"btnSearch\"\r\n                (click)=\"searchPersonal()\">\r\n                <ion-icon ios=\"search\" md=\"search\"></ion-icon>\r\n              </ion-button>\r\n            </ion-item>\r\n\r\n\r\n          </div>\r\n        </ion-card-content>\r\n\r\n      </form>\r\n    </mat-expansion-panel>\r\n  </mat-accordion>\r\n  <ion-card class=\"tapShift\">\r\n\r\n    <ion-list *ngFor=\"let item of servicesPersonalList.serviceDateGroups\">\r\n      <ion-item>\r\n        <div class=\"selectedService\">\r\n          <h5> {{item.stringDate}}</h5>\r\n        </div>\r\n      </ion-item>\r\n\r\n      <ion-list *ngFor=\"let service of item.serviceGroup\">\r\n        <ion-item class=\"resultItem tapShift\">\r\n          <div class=\"resultItemService\">\r\n            <ion-label class=\"laberlService labelProf\">{{service.professionalNames}}</ion-label>\r\n            <ion-label class=\"laberlService labelSpecialty\">{{service.specialtyNames}}</ion-label>\r\n            <ion-label class=\"laberlService \">{{service.healthCenterName}}</ion-label>\r\n            <ion-label class=\"laberlService labelHour\">\r\n              {{service.initTime.hour | number:'2.'}}:{{service.initTime.minute | number:'2.'}} -\r\n              {{service.endTime.hour | number:'2.'}}:{{service.endTime.minute | number:'2.'}}\r\n            </ion-label>\r\n          </div>\r\n          <ion-button color=\"green\" class=\"btnService\" (click)=\"seeShiftHours(service)\">\r\n            VER HORAS\r\n          </ion-button>\r\n        </ion-item>\r\n\r\n      </ion-list>\r\n    </ion-list>\r\n\r\n    <ion-item class=\"resultItem tapShift\" *ngIf=\"noShiftAvalable\">\r\n      <div class=\"resultItemService\">\r\n        <ion-label color=\"red\" class=\"laberlService labelDanger\">No se encontraron Turnos disponibles</ion-label>\r\n        <ion-label class=\"laberlService\">Desde: {{servicesPersonalList.dateFrom}}</ion-label>\r\n        <ion-label class=\"laberlService labelHour\">Hasta: {{servicesPersonalList.dateTo}}</ion-label>\r\n      </div>\r\n    </ion-item>\r\n\r\n    <ion-infinite-scroll threshold=\"100px\" [disabled]=\"infiniteScroll\" (ionInfinite)=\"loadDataPersonal($event)\">\r\n      <ion-infinite-scroll-content loadingSpinner=\"crescent\" loadingText=\"Cargando Datos ...\">\r\n      </ion-infinite-scroll-content>\r\n    </ion-infinite-scroll>\r\n\r\n  </ion-card>\r\n\r\n</ion-content>\r\n\r\n\r\n<ion-content *ngIf=\"currentForm === 'PersonaACargo'\">\r\n  <mat-accordion>\r\n    <mat-expansion-panel [expanded]=\"panelOpenState\" (opened)=\"setStep()\">\r\n      <mat-expansion-panel-header>\r\n        <mat-panel-title>\r\n          <ion-card-header>\r\n            <h2 class=\"header-text\"><b>FILTROS DE BÚSQUEDA</b></h2>\r\n          </ion-card-header>\r\n        </mat-panel-title>\r\n      </mat-expansion-panel-header>\r\n      <form [formGroup]=\"formPerHasDep\">\r\n        <ion-card-content>\r\n          <div class=\"shadowDiv\">\r\n\r\n            <ion-item>\r\n              <ion-select cancelText=\"Cancelar\" class=\"selectPerHasDep\" interface='action-sheet'\r\n                formControlName=\"personsCtrl\" style=\"margin-top: 1rem;\" placeholder=\"Seleccione persona a cargo\"\r\n                [disabled]='!seeDependents'>\r\n                <ion-select-option *ngFor=\"let item of dependents\" [value]=\"item\">{{item.fullName}}</ion-select-option>\r\n              </ion-select>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-select cancelText=\"Cancelar\" [disabled]='!this.formPerHasDep.get(\"personsCtrl\").value'\r\n                formControlName=\"healthCenterCtrl\" interface='action-sheet' placeholder=\"Centro de salud\"\r\n                (ionChange)='getPerHasDep()'>\r\n                <ion-select-option [value]=\"item.id\" *ngFor=\"let item of healthCenters\">{{item.name}}\r\n                </ion-select-option>\r\n              </ion-select>\r\n            </ion-item>\r\n\r\n            <ion-item *ngIf=\"specialtyPerHasDepSelected == null\">\r\n              <ion-select cancelText=\"Cancelar\" [disabled]='!healthCenterSelected' interface='action-sheet'\r\n                formControlName=\"specialtyCtrl\" placeholder=\"Especialidad\" (ionChange)='getProfessionalsHasDep()'>\r\n                <ion-select-option class=\"select-full-width\" [value]=\"item\" *ngFor=\"let item of specialtiesPerHasDep\">\r\n                  {{item.name}}\r\n                </ion-select-option>\r\n              </ion-select>\r\n            </ion-item>\r\n\r\n            <!-- Profesional -->\r\n            <ion-item>\r\n              <ion-select cancelText=\"Cancelar\" [disabled]='!healthCenterSelected' interface='action-sheet'\r\n                formControlName=\"professionalCtrl\" placeholder=\"Profesional\">\r\n                <ion-select-option class=\"select-full-width\" [value]=\"item\" *ngFor=\"let item of professionalList\">\r\n                  {{item.fullAliasName? item.fullAliasName: item.fullName}}\r\n                </ion-select-option>\r\n              </ion-select>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <mat-form-field class=\"matDate\" appearance=\"fill\">\r\n                <mat-label>Fecha Desde</mat-label>\r\n                <input formControlName=\"fromDateCtrl\" [min]=\"today\" matInput [matDatepicker]=\"picker\">\r\n                <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n                <mat-datepicker #picker></mat-datepicker>\r\n              </mat-form-field>\r\n            </ion-item>\r\n\r\n\r\n            <ion-item>\r\n              <ion-button color=\"green\" class=\"btnSearch\" [disabled]='!this.formPerHasDep.valid'\r\n                (click)=\"searchPerHasDep()\">\r\n                <ion-icon ios=\"search\" md=\"search\"></ion-icon>\r\n              </ion-button>\r\n            </ion-item>\r\n\r\n\r\n          </div>\r\n        </ion-card-content>\r\n\r\n      </form>\r\n    </mat-expansion-panel>\r\n  </mat-accordion>\r\n\r\n  <ion-card class=\"tapShift\">\r\n    <ion-list *ngFor=\"let item of servicesPerHasDepList.serviceDateGroups\">\r\n      <ion-item>\r\n        <div class=\"selectedService\">\r\n          <h5>{{item.stringDate}}</h5>\r\n        </div>\r\n      </ion-item>\r\n\r\n      <ion-list *ngFor=\"let service of item.serviceGroup\">\r\n        <ion-item class=\"resultItem tapShift\">\r\n          <div class=\"resultItemService\">\r\n            <ion-label class=\"laberlService labelProf\">{{service.professionalNames}}</ion-label>\r\n            <ion-label class=\"laberlService labelSpecialty\">{{service.specialtyNames}}</ion-label>\r\n            <ion-label class=\"laberlService \">{{service.healthCenterName}}</ion-label>\r\n            <ion-label class=\"laberlService labelHour\">\r\n              {{service.initTime.hour | number:'2.'}}:{{service.initTime.minute | number:'2.'}} -\r\n              {{service.endTime.hour | number:'2.'}}:{{service.endTime.minute | number:'2.'}}\r\n            </ion-label>\r\n          </div>\r\n          <ion-button color=\"green\" class=\"btnService\" (click)=\"seeShiftHours(service)\">\r\n            VER HORAS\r\n          </ion-button>\r\n        </ion-item>\r\n      </ion-list>\r\n    </ion-list>\r\n\r\n    <ion-item class=\"resultItem tapShift\" *ngIf=\"noShiftAvalableHasPer\">\r\n      <div class=\"resultItemService\">\r\n        <ion-label class=\"laberlService labelDanger \">No se encontraron Turnos disponibles</ion-label>\r\n        <ion-label class=\"laberlService\">Desde: {{servicesPerHasDepList.dateFrom}}</ion-label>\r\n        <ion-label class=\"laberlService labelHour\">Hasta: {{servicesPerHasDepList.dateTo}}</ion-label>\r\n      </div>\r\n    </ion-item>\r\n\r\n    <ion-infinite-scroll threshold=\"100px\" [disabled]=\"infiniteScroll\" (ionInfinite)=\"loadDataPerHasDep($event)\">\r\n      <ion-infinite-scroll-content loadingSpinner=\"crescent\" loadingText=\"Cargando Datos ...\">\r\n      </ion-infinite-scroll-content>\r\n    </ion-infinite-scroll>\r\n\r\n  </ion-card>\r\n\r\n</ion-content>\r\n\r\n<ion-item *ngIf=\"servicesPerHasDepList.length > 0 || servicesPersonalList.length > 0\">\r\n  <ion-button class=\"btnCancel\" (click)=\"clearFilterList()\" color=\"medium\">CANCELAR</ion-button>\r\n</ion-item>\r\n\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let LoadingService = class LoadingService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    present() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController.create({
                message: '...Cargando',
                duration: 7500,
            }).then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss().then(() => console.log('dismissed'));
        });
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
], LoadingService);



/***/ }),

/***/ "./src/app/services/shift.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/shift.service.ts ***!
  \*******************************************/
/*! exports provided: ShiftService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftService", function() { return ShiftService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utils/constants */ "./src/app/utils/constants.ts");





let ShiftService = class ShiftService {
    constructor(http, loadingController) {
        this.http = http;
        this.loadingController = loadingController;
    }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando',
            });
            yield loading.present();
        });
    }
    getSpecialty(param, header) {
        if (param) {
            return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + `secure/specialty${param}`, header);
        }
        else {
            return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + 'secure/specialty', header);
        }
    }
    getService(header, param) {
        return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + `secure/services/${param}`, header);
    }
    getDependents(header) {
        return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + `secure/dependents`, header);
    }
    getShifts(header, param) {
        return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + `secure/services/${param}`, header);
    }
    assignShifts(header, model) {
        return this.http.post(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + `secure/appointment/assign`, model, header);
    }
    getAppointmentsRM(header, param) {
        if (param) {
            return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + `secure/appointments/rm/${param}`, header);
        }
        else {
            return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + `secure/appointments/rm`, header);
        }
    }
    getAppointmentsRC(header) {
        return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + `secure/appointments/rc`, header);
    }
    updateAppointmentCancel(header, appointmentId) {
        return this.http.delete(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_BASE_PORTAL + `/secure/appointment/${appointmentId}/cancel`, header);
    }
    getHealthCenterByPersonData(personData, header) {
        return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_RM_PREFIX + `externalPersonHealthCenters/${personData.docNumber}/${personData.sex}/${personData.docType}`, header);
    }
    getProfessionalsBySpecialtyCode(specialtyCode, healthCenterId, header) {
        return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_4__["constants"].URL_RM_PREFIX + `professionals/${specialtyCode}/${healthCenterId}`, header);
    }
};
ShiftService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] }
];
ShiftService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]])
], ShiftService);



/***/ }),

/***/ "./src/app/shifts/new-shift/new-shift.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/shifts/new-shift/new-shift.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #20B572;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #20B572;\n}\n\n.header-text {\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #20B572;\n}\n\nion-header ion-toolbar ion-title {\n  color: #ffffff;\n}\n\n.white {\n  color: #ffffff !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\n.show-all {\n  --min-height: 20px;\n  border-radius: 6px;\n  background-color: #e6e6e6;\n  --ion-background-color: #e6e6e6;\n  margin-top: 2%;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.header-text-2 {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n  margin-bottom: 0px;\n}\n\nion-tab-button {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 4vw;\n  text-align: center;\n  color: #ffffff;\n}\n\n.shadowDiv {\n  border-radius: 5px !important;\n}\n\n.centrado {\n  text-align: center;\n}\n\n.btnRight {\n  display: block;\n  float: right;\n  width: 85%;\n  height: 80%;\n  color: black;\n}\n\n.btnTap {\n  --background: transparent;\n  color: black;\n}\n\n.btnTapSelected {\n  --background: #20B572;\n  color: white;\n}\n\n.btnSearch {\n  color: black;\n  border: none !important;\n  width: 85%;\n  margin: auto;\n  height: 70%;\n  --background: #20b572;\n  color: white;\n  --border-radius: 10rem !important;\n}\n\n.resultItem {\n  cursor: pointer;\n  border-radius: 0px !important;\n  background-color: white;\n}\n\n.resultItem:hover {\n  background-color: #0000000A;\n}\n\n.searchResultItem {\n  color: black;\n  background-color: #20B572;\n}\n\n.closeBtn {\n  cursor: pointer;\n  filter: none !important;\n  -webkit-filter: none !important;\n  --background: transparent;\n  --box-shadow: none;\n  --border-radius: 10rem !important;\n  padding: 0 !important;\n}\n\n.selectedItem {\n  width: 100%;\n  border-radius: 0.4rem;\n  background-color: #20b572;\n  padding: 0 0 0 1rem;\n  display: flex;\n  color: white;\n  align-items: center;\n  justify-content: space-between;\n  margin: 5px;\n  height: 2.5rem;\n}\n\n.selectedItem h5 {\n  width: 100%;\n  font-weight: 500;\n  margin-bottom: 0;\n  overflow-x: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.tapShift {\n  margin-top: 10px;\n  font-weight: 700;\n}\n\n.selectedService {\n  width: 100%;\n  margin: 0 auto;\n  border-radius: 0.4rem;\n  background-color: #20b572;\n  padding: 0 0 0 1rem;\n  display: flex;\n  color: white;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.selectedService h5 {\n  font-size: 14px;\n  font-weight: 500;\n  text-align: center;\n  width: 100%;\n  margin: 3px;\n}\n\n.resultItemService {\n  display: block;\n  font-weight: 500;\n}\n\n.laberlService {\n  white-space: normal;\n}\n\n.btnService {\n  display: block;\n  float: none;\n  margin-left: auto;\n  /* width: 85%; */\n  --background: #6FE6B0;\n  color: black;\n}\n\n.titleDay {\n  font-weight: 700;\n}\n\n.selectPerHasDep {\n  min-width: 100%;\n}\n\n.btnCancel {\n  margin-left: auto;\n  margin-right: auto;\n}\n\n.labelProf {\n  color: #1BA4DA;\n}\n\n.labelProf {\n  color: #1BA4DA;\n}\n\n.labelSpecialty {\n  color: #1BDA91;\n}\n\n.labelHour {\n  padding-bottom: 1rem;\n}\n\n.labelOption {\n  white-space: break-spaces;\n}\n\n.labelDanger {\n  color: #C83333;\n}\n\n.matDate {\n  width: 100%;\n  background: white !important;\n}\n\n.select-full-width {\n  width: 100%;\n  max-width: 100% !important;\n}\n\nion-select {\n  display: contents;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hpZnRzL25ldy1zaGlmdC9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXHNoaWZ0c1xcbmV3LXNoaWZ0XFxuZXctc2hpZnQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3NoaWZ0cy9uZXctc2hpZnQvbmV3LXNoaWZ0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtBQ0NGOztBREVBO0VBQ0UsZ0NBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0FDQ0Y7O0FERUE7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0FDQ0Y7O0FERUE7RUFDRSxxQkFBQTtBQ0NGOztBREVBO0VBQ0UsY0FBQTtBQ0NGOztBREVBO0VBQ0UseUJBQUE7QUNDRjs7QURFQTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtBQ0NGOztBREVBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNDRjs7QURFQTtFQUNFLDJCQUFBO0VBQ0EsaUNBQUE7QUNDRjs7QURFQTtFQUNFLDJCQUFBO0FDQ0Y7O0FERUE7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSwrQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNDRjs7QURFQTtFQUNFLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtBQ0NGOztBREVBO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUVFLDZCQUFBO0FDQUY7O0FESUE7RUFDRSxrQkFBQTtBQ0RGOztBRElBO0VBQ0UsY0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNERjs7QURJQTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtBQ0RGOztBRElBO0VBQ0UscUJBQUE7RUFDQSxZQUFBO0FDREY7O0FESUE7RUFFRSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxpQ0FBQTtBQ0ZGOztBREtBO0VBQ0UsZUFBQTtFQUVBLDZCQUFBO0VBQ0EsdUJBQUE7QUNIRjs7QURNQTtFQUNFLDJCQUFBO0FDSEY7O0FETUE7RUFDRSxZQUFBO0VBQ0EseUJBQUE7QUNIRjs7QURNQTtFQUNFLGVBQUE7RUFDQSx1QkFBQTtFQUNBLCtCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlDQUFBO0VBQ0EscUJBQUE7QUNIRjs7QURNQTtFQUNFLFdBQUE7RUFDQSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtBQ0hGOztBRE1BO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNIRjs7QURNQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7QUNIRjs7QURNQTtFQUNFLFdBQUE7RUFDQSxjQUFBO0VBQ0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FDSEY7O0FETUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FDSEY7O0FET0E7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7QUNKRjs7QURPQTtFQUNFLG1CQUFBO0FDSkY7O0FET0E7RUFDRSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7QUNKRjs7QURRQTtFQUNFLGdCQUFBO0FDTEY7O0FEUUE7RUFDRSxlQUFBO0FDTEY7O0FEUUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0FDTEY7O0FEUUE7RUFDRSxjQUFBO0FDTEY7O0FEUUE7RUFDRSxjQUFBO0FDTEY7O0FEUUE7RUFDRSxjQUFBO0FDTEY7O0FEUUE7RUFDRSxvQkFBQTtBQ0xGOztBRFFBO0VBQ0UseUJBQUE7QUNMRjs7QURRQTtFQUNFLGNBQUE7QUNMRjs7QURRQTtFQUNFLFdBQUE7RUFDQSw0QkFBQTtBQ0xGOztBRFFBO0VBQ0UsV0FBQTtFQUNBLDBCQUFBO0FDTEY7O0FEUUE7RUFDRSxpQkFBQTtBQ0xGIiwiZmlsZSI6InNyYy9hcHAvc2hpZnRzL25ldy1zaGlmdC9uZXctc2hpZnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVkIHtcclxuICBjb2xvcjogIzIwQjU3MjtcclxufVxyXG5cclxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMyMEI1NzI7XHJcbn1cclxuXHJcbi5oZWFkZXItdGV4dCB7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcclxuICAtLWJhY2tncm91bmQ6ICMyMEI1NzI7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxufVxyXG5cclxuLndoaXRlIHtcclxuICBjb2xvcjogI2ZmZmZmZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tbGFiZWwge1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zYy1pb24tY2FyZC1tZC1oIHtcclxuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBcIlwiICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1jYXJkIHtcclxuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zaG93LWFsbCB7XHJcbiAgLS1taW4taGVpZ2h0OiAyMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNlNmU2ZTY7XHJcbiAgbWFyZ2luLXRvcDogMiU7XHJcbn1cclxuXHJcbmlvbi10aXRsZSB7XHJcbiAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICBmb250LXNpemU6IDV2dztcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5oZWFkZXItdGV4dC0yIHtcclxuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzUzNTM1MztcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxufVxyXG5cclxuaW9uLXRhYi1idXR0b24ge1xyXG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgZm9udC1zaXplOiA0dnc7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG59XHJcblxyXG4uc2hhZG93RGl2IHtcclxuICAvL2JveC1zaGFkb3c6IDJweCAycHggMnB4IDJweCAjNTM1MzUzO1xyXG4gIGJvcmRlci1yYWRpdXM6IDVweCAhaW1wb3J0YW50O1xyXG4gIC8vYm9yZGVyOiBncm9vdmU7XHJcbn1cclxuXHJcbi5jZW50cmFkbyB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uYnRuUmlnaHQge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIGZsb2F0OiByaWdodDtcclxuICB3aWR0aDogODUlO1xyXG4gIGhlaWdodDogODAlO1xyXG4gIGNvbG9yOiBibGFjaztcclxufVxyXG5cclxuLmJ0blRhcCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICBjb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcbi5idG5UYXBTZWxlY3RlZCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjMjBCNTcyO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLmJ0blNlYXJjaCB7XHJcblxyXG4gIGNvbG9yOiBibGFjaztcclxuICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcclxuICB3aWR0aDogODUlO1xyXG4gIG1hcmdpbjogYXV0bztcclxuICBoZWlnaHQ6IDcwJTtcclxuICAtLWJhY2tncm91bmQ6ICMyMGI1NzI7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIC0tYm9yZGVyLXJhZGl1czogMTByZW0gIWltcG9ydGFudDtcclxufVxyXG5cclxuLnJlc3VsdEl0ZW0ge1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICAvL3BhZGRpbmc6IDAuNXJlbSAxcmVtO1xyXG4gIGJvcmRlci1yYWRpdXM6IDBweCAhaW1wb3J0YW50O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ucmVzdWx0SXRlbTpob3ZlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDAwMDBBO1xyXG59XHJcblxyXG4uc2VhcmNoUmVzdWx0SXRlbSB7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMyMEI1NzI7XHJcbn1cclxuXHJcbi5jbG9zZUJ0biB7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGZpbHRlcjogbm9uZSAhaW1wb3J0YW50O1xyXG4gIC13ZWJraXQtZmlsdGVyOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiAxMHJlbSAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudFxyXG59XHJcblxyXG4uc2VsZWN0ZWRJdGVtIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBib3JkZXItcmFkaXVzOiAwLjRyZW07XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzIwYjU3MjtcclxuICBwYWRkaW5nOiAwIDAgMCAxcmVtO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIG1hcmdpbjogNXB4O1xyXG4gIGhlaWdodDogMi41cmVtO1xyXG59XHJcblxyXG4uc2VsZWN0ZWRJdGVtIGg1IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbn1cclxuXHJcbi50YXBTaGlmdCB7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBmb250LXdlaWdodDogNzAwO1xyXG59XHJcblxyXG4uc2VsZWN0ZWRTZXJ2aWNlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBib3JkZXItcmFkaXVzOiAwLjRyZW07XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzIwYjU3MjtcclxuICBwYWRkaW5nOiAwIDAgMCAxcmVtO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG59XHJcblxyXG4uc2VsZWN0ZWRTZXJ2aWNlIGg1IHtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luOiAzcHg7XHJcblxyXG59XHJcblxyXG4ucmVzdWx0SXRlbVNlcnZpY2Uge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuXHJcbi5sYWJlcmxTZXJ2aWNlIHtcclxuICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xyXG59XHJcblxyXG4uYnRuU2VydmljZSB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgZmxvYXQ6IG5vbmU7XHJcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgLyogd2lkdGg6IDg1JTsgKi9cclxuICAtLWJhY2tncm91bmQ6ICM2RkU2QjA7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG5cclxufVxyXG5cclxuLnRpdGxlRGF5IHtcclxuICBmb250LXdlaWdodDogNzAwO1xyXG59XHJcblxyXG4uc2VsZWN0UGVySGFzRGVwIHtcclxuICBtaW4td2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5idG5DYW5jZWwge1xyXG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gIG1hcmdpbi1yaWdodDogYXV0bztcclxufVxyXG5cclxuLmxhYmVsUHJvZiB7XHJcbiAgY29sb3I6ICMxQkE0REE7XHJcbn1cclxuXHJcbi5sYWJlbFByb2Yge1xyXG4gIGNvbG9yOiAjMUJBNERBO1xyXG59XHJcblxyXG4ubGFiZWxTcGVjaWFsdHkge1xyXG4gIGNvbG9yOiAjMUJEQTkxO1xyXG59XHJcblxyXG4ubGFiZWxIb3VyIHtcclxuICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcclxufVxyXG5cclxuLmxhYmVsT3B0aW9uIHtcclxuICB3aGl0ZS1zcGFjZTogYnJlYWstc3BhY2VzO1xyXG59XHJcblxyXG4ubGFiZWxEYW5nZXIge1xyXG4gIGNvbG9yOiAjQzgzMzMzXHJcbn1cclxuXHJcbi5tYXREYXRlIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50XHJcbn1cclxuXHJcbi5zZWxlY3QtZnVsbC13aWR0aCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1zZWxlY3Qge1xyXG4gIGRpc3BsYXk6IGNvbnRlbnRzO1xyXG59IiwiLnJlZCB7XG4gIGNvbG9yOiAjMjBCNTcyO1xufVxuXG5pb24taXRlbS5ib3JkZXItcmVkIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMyMEI1NzI7XG59XG5cbi5oZWFkZXItdGV4dCB7XG4gIG1hcmdpbi1yaWdodDogNSU7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cblxuaW9uLWxpc3Qge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICMyMEI1NzI7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNmZmZmZmY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjZmZmZmZmICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xufVxuXG5pb24tY29udGVudCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uc2MtaW9uLWNhcmQtbWQtaCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiBcIlwiICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG4uc2hvdy1hbGwge1xuICAtLW1pbi1oZWlnaHQ6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbiAgbWFyZ2luLXRvcDogMiU7XG59XG5cbmlvbi10aXRsZSB7XG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDUlO1xuICBmb250LXNpemU6IDV2dztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uaGVhZGVyLXRleHQtMiB7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjNTM1MzUzO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuaW9uLXRhYi1idXR0b24ge1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgZm9udC1zaXplOiA0dnc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNmZmZmZmY7XG59XG5cbi5zaGFkb3dEaXYge1xuICBib3JkZXItcmFkaXVzOiA1cHggIWltcG9ydGFudDtcbn1cblxuLmNlbnRyYWRvIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uYnRuUmlnaHQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgZmxvYXQ6IHJpZ2h0O1xuICB3aWR0aDogODUlO1xuICBoZWlnaHQ6IDgwJTtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4uYnRuVGFwIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4uYnRuVGFwU2VsZWN0ZWQge1xuICAtLWJhY2tncm91bmQ6ICMyMEI1NzI7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmJ0blNlYXJjaCB7XG4gIGNvbG9yOiBibGFjaztcbiAgYm9yZGVyOiBub25lICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiA4NSU7XG4gIG1hcmdpbjogYXV0bztcbiAgaGVpZ2h0OiA3MCU7XG4gIC0tYmFja2dyb3VuZDogIzIwYjU3MjtcbiAgY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1yYWRpdXM6IDEwcmVtICFpbXBvcnRhbnQ7XG59XG5cbi5yZXN1bHRJdGVtIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBib3JkZXItcmFkaXVzOiAwcHggIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG59XG5cbi5yZXN1bHRJdGVtOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDAwMDBBO1xufVxuXG4uc2VhcmNoUmVzdWx0SXRlbSB7XG4gIGNvbG9yOiBibGFjaztcbiAgYmFja2dyb3VuZC1jb2xvcjogIzIwQjU3Mjtcbn1cblxuLmNsb3NlQnRuIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBmaWx0ZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgLXdlYmtpdC1maWx0ZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1ib3gtc2hhZG93OiBub25lO1xuICAtLWJvcmRlci1yYWRpdXM6IDEwcmVtICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbn1cblxuLnNlbGVjdGVkSXRlbSB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXItcmFkaXVzOiAwLjRyZW07XG4gIGJhY2tncm91bmQtY29sb3I6ICMyMGI1NzI7XG4gIHBhZGRpbmc6IDAgMCAwIDFyZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBtYXJnaW46IDVweDtcbiAgaGVpZ2h0OiAyLjVyZW07XG59XG5cbi5zZWxlY3RlZEl0ZW0gaDUge1xuICB3aWR0aDogMTAwJTtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbn1cblxuLnRhcFNoaWZ0IHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cblxuLnNlbGVjdGVkU2VydmljZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW46IDAgYXV0bztcbiAgYm9yZGVyLXJhZGl1czogMC40cmVtO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjBiNTcyO1xuICBwYWRkaW5nOiAwIDAgMCAxcmVtO1xuICBkaXNwbGF5OiBmbGV4O1xuICBjb2xvcjogd2hpdGU7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cblxuLnNlbGVjdGVkU2VydmljZSBoNSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luOiAzcHg7XG59XG5cbi5yZXN1bHRJdGVtU2VydmljZSB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuXG4ubGFiZXJsU2VydmljZSB7XG4gIHdoaXRlLXNwYWNlOiBub3JtYWw7XG59XG5cbi5idG5TZXJ2aWNlIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZsb2F0OiBub25lO1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgLyogd2lkdGg6IDg1JTsgKi9cbiAgLS1iYWNrZ3JvdW5kOiAjNkZFNkIwO1xuICBjb2xvcjogYmxhY2s7XG59XG5cbi50aXRsZURheSB7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG5cbi5zZWxlY3RQZXJIYXNEZXAge1xuICBtaW4td2lkdGg6IDEwMCU7XG59XG5cbi5idG5DYW5jZWwge1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xufVxuXG4ubGFiZWxQcm9mIHtcbiAgY29sb3I6ICMxQkE0REE7XG59XG5cbi5sYWJlbFByb2Yge1xuICBjb2xvcjogIzFCQTREQTtcbn1cblxuLmxhYmVsU3BlY2lhbHR5IHtcbiAgY29sb3I6ICMxQkRBOTE7XG59XG5cbi5sYWJlbEhvdXIge1xuICBwYWRkaW5nLWJvdHRvbTogMXJlbTtcbn1cblxuLmxhYmVsT3B0aW9uIHtcbiAgd2hpdGUtc3BhY2U6IGJyZWFrLXNwYWNlcztcbn1cblxuLmxhYmVsRGFuZ2VyIHtcbiAgY29sb3I6ICNDODMzMzM7XG59XG5cbi5tYXREYXRlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQ6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbi5zZWxlY3QtZnVsbC13aWR0aCB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXgtd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbn1cblxuaW9uLXNlbGVjdCB7XG4gIGRpc3BsYXk6IGNvbnRlbnRzO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/shifts/new-shift/new-shift.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/shifts/new-shift/new-shift.component.ts ***!
  \*********************************************************/
/*! exports provided: FORMAT, NewShiftComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FORMAT", function() { return FORMAT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewShiftComponent", function() { return NewShiftComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/shift.service */ "./src/app/services/shift.service.ts");
/* harmony import */ var src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/esm2015/core.js");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");













const FORMAT = {
    parse: {
        dateInput: 'DD/MM/YYYY',
    },
    display: {
        dateInput: 'DD/MM/YYYY',
        monthYearLabel: 'MMM YYYY',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'MMMM YYYY',
    },
};
let NewShiftComponent = class NewShiftComponent {
    constructor(storage, shiftService, alertController, fb, navController, loading, router, localStorageService) {
        this.storage = storage;
        this.shiftService = shiftService;
        this.alertController = alertController;
        this.fb = fb;
        this.navController = navController;
        this.loading = loading;
        this.router = router;
        this.localStorageService = localStorageService;
        this.infiniteScroll = false;
        this.currentForm = 'Personal';
        this.shiftDependentPerson = true;
        this.shiftPersonal = true;
        this.isSearching = false;
        this.specialtyList = [];
        this.specialtyperHasDepList = [];
        this.specialtySelected = null;
        this.seeListSpecialty = false;
        this.specialtyPerHasDepSelected = null;
        this.seeListPerHasDepSpecialty = false;
        this.professionalList = [];
        this.seeListProfessional = false;
        this.servicesPersonalList = [];
        this.servicePersonalSelected = null;
        //seeListServices:boolean =  false;
        this.servicesPerHasDepList = [];
        this.seePerHasDepListServices = null;
        this.dependents = [];
        this.httpOptions = null;
        this.param = '';
        this.panelOpenState = true;
        this.classPersonal = "green";
        this.classPersHasDep = "white";
        this.noShiftAvalable = false;
        this.noShiftAvalableHasPer = false;
        this.formPersonalValid = false;
        this.formPerHasDepValid = false;
        this.today = new Date();
        this.seeDependents = false;
        this.cmSpecialty = true;
        this.cmSpecialtyPerHasDep = true;
        this.healthCenters = [];
    }
    ngOnInit() {
        this.getUserInfo();
        this.getDependents();
        this.createForma();
    }
    getUserInfo() {
        this.localStorageService.getUserData().then((response) => [
            this.userInfo = response,
            this.getHealthCentersByPersonData()
        ]);
    }
    getHealthCentersByPersonData() {
        let user = this.userInfo;
        this.loading.present();
        this.getToken().then(value => {
            this.shiftService.getHealthCenterByPersonData(user, this.httpOptions).subscribe((response) => {
                this.healthCenters = response;
                this.loading.dismiss();
            });
        });
    }
    createForma() {
        this.formPersonal = this.fb.group({
            healthCenterCtrl: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required],
            specialtyCtrl: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required],
            professionalCtrl: [''],
            fromDateCtrl: [''],
        });
        this.formPerHasDep = this.fb.group({
            healthCenterCtrl: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required],
            personsCtrl: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required],
            specialtyCtrl: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required],
            professionalCtrl: [''],
            fromDateCtrl: [''],
        });
    }
    chargeForm(input) {
        this.currentForm = input;
        if (input === 'Personal') {
            this.classPersonal = 'green';
            this.classPersHasDep = 'white';
        }
        if (input === 'PersonaACargo') {
            this.classPersonal = 'white';
            this.classPersHasDep = 'green';
        }
    }
    selectSpecialtPerHasDep(item) {
        this.specialtyPerHasDepSelected = item;
        this.seeListPerHasDepSpecialty = false;
    }
    searchSpecialty() {
        this.specialtyList = [];
        if (this.formPersonal.get('specialtyCtrl').value.length > 0) {
            this.specialties.forEach(element => {
                if (element.name.toUpperCase().search(this.formPersonal.get('specialtyCtrl').value.toUpperCase()) > -1) {
                    this.specialtyList.push(element);
                }
            });
            this.seeListSpecialty = true;
            this.formPersonalValid = false;
        }
    }
    searchSpecialtyPerHasDep() {
        this.specialtyperHasDepList = [];
        if (this.formPerHasDep.get('specialtyCtrl').value.length > 0) {
            this.specialtiesPerHasDep.forEach(element => {
                if (element.name.toUpperCase().search(this.formPerHasDep.get('specialtyCtrl').value.toUpperCase()) > -1) {
                    this.specialtyperHasDepList.push(element);
                }
            });
            this.seeListPerHasDepSpecialty = true;
            this.formPerHasDepValid = false;
        }
    }
    searchPersonal() {
        this.specialtySelected = this.formPersonal.get('specialtyCtrl').value;
        this.healthCenterSelected = this.formPersonal.get('healthCenterCtrl').value;
        let professionalId = this.formPersonal.get("professionalCtrl").value.id;
        if (this.formPersonal.valid) {
            if (this.specialtySelected || this.formPersonal.get("professionalCtrl").value) {
                let param = '';
                this.specialtySelected != null ? param = param + '&specialtyCode=' + this.specialtySelected.code : '';
                this.healthCenterSelected != null ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
                professionalId && professionalId != '' || professionalId != null ?
                    param = param + '&professionalId=' + professionalId : '';
                this.formPersonal.get("fromDateCtrl").value ? param = param + '&dateFrom=' + moment__WEBPACK_IMPORTED_MODULE_9__(this.formPersonal.get("fromDateCtrl").value).format('YYYY-MM-DD') : '';
                this.infiniteScroll = false;
                this.noShiftAvalable = false;
                this.formPersonalValid = true;
                if (param.length > 0) {
                    param = param.replace('&', '?');
                }
                this.servicesPersonalList = [];
                this.loading.present();
                this.shiftService.getShifts(this.httpOptions, param).subscribe((response) => {
                    this.servicesPersonalList = response;
                    if (this.servicesPersonalList.serviceDateGroups.length < 1) {
                        this.servicesPersonalList.dateFrom = response.stringDateFrom;
                        this.servicesPersonalList.dateTo = response.stringDateTo;
                        this.servicesPersonalList.stringDateFrom = response.stringDateFrom;
                        this.servicesPersonalList.stringDateTo = response.stringDateTo;
                        //this.alert("No exiten turnos disponibles, modifique los filtros para obtenes mas resultados");  
                        this.noShiftAvalable = true;
                    }
                    else {
                        this.lastDay = response.dateTo;
                        param = '';
                        this.specialtySelected != null ? param = param + '&specialtyCode=' + this.specialtySelected.code : '';
                        this.formPersonal.get("professionalCtrl").value != '' ? param = param + '&professionalName=' + this.formPersonal.get("professionalCtrl").value : '';
                        //En Safari el replace remplaza el primer x caracter que encuentre
                        let aux = this.lastDay.replace('-', '/');
                        aux = aux.replace('-', '/');
                        let fechaLastDay = new Date(aux);
                        fechaLastDay.setDate(fechaLastDay.getDate() + 1);
                        this.lastDay ? param = param + '&dateFrom=' + moment__WEBPACK_IMPORTED_MODULE_9__(fechaLastDay).format('YYYY-MM-DD') : '';
                        if (param.length > 0) {
                            param = param.replace('&', '?');
                        }
                        if (!this.validCount(this.servicesPersonalList.serviceDateGroups)) {
                            this.loading.present();
                            this.shiftService.getShifts(this.httpOptions, param).subscribe((response) => {
                                this.loading.dismiss();
                                this.lastDay = response.dateTo;
                                if (response) {
                                    if (response.serviceDateGroups.length > 0) {
                                        response.serviceDateGroups.forEach(element => {
                                            this.servicesPersonalList.serviceDateGroups.push(element);
                                        });
                                    }
                                    else {
                                        this.servicesPersonalList.dateFrom = response.stringDateFrom;
                                        this.servicesPersonalList.dateTo = response.stringDateTo;
                                        this.servicesPersonalList.stringDateFrom = response.stringDateFrom;
                                        this.servicesPersonalList.stringDateTo = response.stringDateTo;
                                        //this.alert("No se encontraron Turnos disponibles desde : "+response.dateFrom+ " Hasta "+response.dateTo ); 
                                        this.noShiftAvalable = false;
                                        this.infiniteScroll = true;
                                    }
                                }
                            }, error => {
                                this.loading.dismiss();
                                if (error.status === 409) {
                                    this.alert(error.error.message);
                                }
                                else {
                                    this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                                }
                            });
                        }
                    }
                    this.loading.dismiss();
                }, error => {
                    this.loading.dismiss();
                    if (error.status === 409) {
                        this.alert(error.error.message);
                    }
                    else {
                        this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                    }
                });
                this.panelOpenState = false;
                //this.getService(param)
            }
            else {
                this.alert("Debe filtrar por Especialidad y/o Profesional");
            }
        }
        else {
            this.alert("El campo Fecha es Obligatorio");
        }
    }
    searchPerHasDep() {
        this.specialtyPerHasDepSelected = this.formPerHasDep.get('specialtyCtrl').value;
        this.healthCenterSelected = this.formPerHasDep.get('healthCenterCtrl').value;
        let professionalId = this.formPerHasDep.get("professionalCtrl").value.id;
        if (this.formPerHasDep.valid) {
            if (this.specialtyPerHasDepSelected || this.formPerHasDep.get("professionalCtrl").value) {
                let param = '';
                this.specialtyPerHasDepSelected != null ? param = param + '&specialtyCode=' + this.specialtyPerHasDepSelected.code : '';
                this.healthCenterSelected != null ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
                professionalId && professionalId != '' ? param = param + '&professionalId=' + professionalId : '';
                this.formPerHasDep.get("fromDateCtrl").value ? param = param + '&dateFrom=' + moment__WEBPACK_IMPORTED_MODULE_9__(this.formPerHasDep.get("fromDateCtrl").value).format('YYYY-MM-DD') : '';
                this.formPerHasDep.get("personsCtrl").value != '' ? param = param + '&sexWards=' + this.formPerHasDep.get("personsCtrl").value.sex : '';
                this.formPerHasDep.get("personsCtrl").value ? param = param + '&docNumberWards=' + this.formPerHasDep.get("personsCtrl").value.docNumber : '';
                this.infiniteScroll = false;
                this.noShiftAvalableHasPer = false;
                this.formPerHasDepValid = true;
                if (param.length > 0) {
                    param = param.replace('&', '?');
                }
                this.servicesPerHasDepList = [];
                this.loading.present();
                this.shiftService.getShifts(this.httpOptions, param).subscribe((response) => {
                    this.servicesPerHasDepList = response;
                    if (this.servicesPerHasDepList.serviceDateGroups.length < 1) {
                        this.servicesPerHasDepList.dateFrom = response.stringDateFrom;
                        this.servicesPerHasDepList.dateTo = response.stringDateTo;
                        this.servicesPerHasDepList.stringDateFrom = response.stringDateFrom;
                        this.servicesPerHasDepList.stringDateTo = response.stringDateTo;
                        this.noShiftAvalableHasPer = true;
                    }
                    else {
                        this.lastDay = response.dateTo;
                        param = '';
                        this.specialtyPerHasDepSelected != null ? param = param + '&specialtyCode=' + this.specialtyPerHasDepSelected.code : '';
                        this.formPerHasDep.get("professionalCtrl").value != '' ? param = param + '&professionalName=' + this.formPerHasDep.get("professionalCtrl").value : '';
                        //this.lastDay ? param = param + '&dateFrom=' + moment(this.lastDay).format('YYYY-MM-DD') : '';
                        this.formPerHasDep.get("personsCtrl").value != '' ? param = param + '&sexWards=' + this.formPerHasDep.get("personsCtrl").value.sex : '';
                        this.formPerHasDep.get("personsCtrl").value ? param = param + '&docNumberWards=' + this.formPerHasDep.get("personsCtrl").value.docNumber : '';
                        //En Safari el replace remplaza el primer x caracter que encuentre
                        let aux = this.lastDay.replace('-', '/');
                        aux = aux.replace('-', '/');
                        let fechaLastDay = new Date(aux);
                        fechaLastDay.setDate(fechaLastDay.getDate() + 1);
                        this.lastDay ? param = param + '&dateFrom=' + moment__WEBPACK_IMPORTED_MODULE_9__(fechaLastDay).format('YYYY-MM-DD') : '';
                        if (param.length > 0) {
                            param = param.replace('&', '?');
                        }
                        if (!this.validCount(this.servicesPerHasDepList.serviceDateGroups)) {
                            this.loading.present();
                            this.shiftService.getShifts(this.httpOptions, param).subscribe((response) => {
                                this.loading.dismiss();
                                this.lastDay = response.dateTo;
                                if (response) {
                                    if (response.serviceDateGroups.length > 0) {
                                        response.serviceDateGroups.forEach(element => {
                                            this.servicesPerHasDepList.serviceDateGroups.push(element);
                                        });
                                    }
                                    else {
                                        this.servicesPerHasDepList.dateFrom = response.stringDateFrom;
                                        this.servicesPerHasDepList.dateTo = response.stringDateTo;
                                        this.servicesPerHasDepList.stringDateFrom = response.stringDateFrom;
                                        this.servicesPerHasDepList.stringDateTo = response.stringDateTo;
                                        this.noShiftAvalableHasPer = false;
                                        this.infiniteScroll = true;
                                    }
                                }
                            }, error => {
                                this.loading.dismiss();
                                if (error.status === 409) {
                                    this.alert(error.error.message);
                                }
                                else {
                                    this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                                }
                            });
                        }
                    }
                    this.loading.dismiss();
                }, error => {
                    this.loading.dismiss();
                    if (error.status === 409) {
                        this.alert(error.error.message);
                    }
                    else {
                        this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                    }
                });
                this.panelOpenState = false;
                //this.getService(param)
            }
            else {
                this.alert("Debe filtrar por Especialidad y/o Profesional");
            }
        }
        else {
            if (!this.formPerHasDep.get("personsCtrl").valid && !this.formPerHasDep.get("fromDateCtrl").valid) {
                this.alert("El campo a Persona a Cargo y Fecha son Obligatorios");
            }
            else {
                if (!this.formPerHasDep.get("personsCtrl").valid) {
                    this.alert("Debe seleccionar una Persona a Cargo");
                }
                if (!this.formPerHasDep.get("fromDateCtrl").valid) {
                    this.alert("El campo Fecha es Obligatorio");
                }
            }
        }
    }
    validCount(itemList) {
        let serviceCount = 6;
        let countAux = 0;
        itemList.forEach(element => {
            element.serviceGroup.forEach(element => {
                countAux++;
            });
        });
        if (countAux >= serviceCount) {
            return true;
        }
        else {
            return false;
        }
    }
    getSpecialty() {
        this.loading.present();
        this.getToken().then(value => {
            let param = '';
            this.healthCenterSelected = this.formPersonal.get('healthCenterCtrl').value;
            this.healthCenterSelected ? param = param + '?healthCenterId=' + this.healthCenterSelected : '';
            this.shiftService.getSpecialty(param, this.httpOptions).subscribe((response) => {
                this.specialties = response;
                this.specialties.sort((a, b) => a.name.localeCompare(b.name));
                if (response.length) {
                    this.cmSpecialty = false;
                }
                this.loading.dismiss();
            }, error => {
                this.specialties = [];
                if (error.status === 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                }
            });
        });
    }
    getSpecialtyPerHasDep(per) {
        this.loading.present();
        this.getToken().then(value => {
            this.shiftService.getSpecialty(per, this.httpOptions).subscribe((response) => {
                this.specialtiesPerHasDep = response;
                if (response.length) {
                    this.cmSpecialtyPerHasDep = false;
                }
                this.loading.dismiss();
            }, error => {
                this.specialtiesPerHasDep = [];
                if (error.status === 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                }
            });
        });
    }
    getDependents() {
        this.getToken().then(value => {
            this.shiftService.getDependents(this.httpOptions).subscribe((response) => {
                this.dependents = response.wards;
                this.seeDependents = this.dependents.length > 0;
                this.loading.dismiss();
            }, error => {
                this.dependents = [];
                if (error.status === 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                }
            });
        });
        //this.loading.dismiss();
    }
    getToken() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.storage.get('token').then(value => {
                let httpOptions = {
                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Authorization': 'Bearer ' + value,
                    }),
                    response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        }),
                    })
                };
                this.httpOptions = httpOptions;
            });
        });
    }
    getProfessionals() {
        this.specialtySelected = this.formPersonal.get('specialtyCtrl').value.code;
        let healthCenterId = this.formPersonal.get('healthCenterCtrl').value;
        this.getToken().then(value => {
            this.shiftService.getProfessionalsBySpecialtyCode(this.specialtySelected, healthCenterId, this.httpOptions).subscribe((response) => {
                this.professionalList = response;
            });
        });
    }
    getProfessionalsHasDep() {
        this.specialtySelected = this.formPerHasDep.get('specialtyCtrl').value.code;
        let healthCenterId = this.formPerHasDep.get('healthCenterCtrl').value;
        this.getToken().then(value => {
            this.shiftService.getProfessionalsBySpecialtyCode(this.specialtySelected, healthCenterId, this.httpOptions).subscribe((response) => {
                this.professionalList = response;
            });
        });
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                            console.log('OK pressed!!');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    enableSearchSpecialty() {
        this.specialtySelected = null;
        this.formPersonal.get('specialtyCtrl').setValue('');
        //this.searchText = null;
    }
    enableSearchSpecialtyPerHasDep() {
        this.specialtyPerHasDepSelected = null;
        this.formPerHasDep.get('specialtyCtrl').setValue('');
    }
    loadDataPersonal(event) {
        if (this.formPersonalValid) {
            let param = '';
            let fechaLastDay = new Date(this.lastDay.year, this.lastDay.monthValue - 1, this.lastDay.dayOfMonth + 1);
            this.specialtySelected != null ? param = param + '&specialtyCode=' + this.specialtySelected.code : '';
            this.healthCenterSelected ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
            this.formPersonal.get("professionalCtrl").value != '' ? param = param + '&professionalId=' + this.formPersonal.get("professionalCtrl").value.id : '';
            this.lastDay ? param = param + '&dateFrom=' + moment__WEBPACK_IMPORTED_MODULE_9__(fechaLastDay).format('YYYY-MM-DD') : '';
            if (param.length > 0) {
                param = param.replace('&', '?');
            }
            this.shiftService.getShifts(this.httpOptions, param).subscribe((response) => {
                this.loading.dismiss();
                event.target.complete();
                this.lastDay = response.dateTo;
                if (response) {
                    if (response.serviceDateGroups.length > 0) {
                        response.serviceDateGroups.forEach(element => {
                            this.servicesPersonalList.serviceDateGroups.push(element);
                            this.servicesPersonalList.dateTo = element.stringDate;
                            this.servicesPersonalList.stringDateTo = element.stringDate;
                        });
                        this.lastDay = response.dateTo;
                    }
                    else {
                        //this.alert("No se encontraron Turnos disponibles desde : "+response.dateFrom+ " Hasta "+response.dateTo );              
                        this.servicesPersonalList.dateFrom = this.servicesPersonalList.stringDateTo;
                        this.servicesPersonalList.dateTo = response.stringDateTo;
                        this.servicesPersonalList.stringDateFrom = this.servicesPersonalList.dateTo;
                        this.servicesPersonalList.stringDateTo = response.stringDateTo;
                        this.noShiftAvalable = true;
                        event.target.complete();
                        this.infiniteScroll = true;
                    }
                }
            }, error => {
                if (error.status === 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                }
            });
            console.log("Cargando ...");
        }
        else {
            event.target.complete();
        }
    }
    loadDataPerHasDep(event) {
        if (this.formPerHasDepValid) {
            let param = '';
            let fechaLastDay = new Date(this.lastDay.year, this.lastDay.monthValue - 1, this.lastDay.dayOfMonth + 1);
            this.specialtyPerHasDepSelected != null ? param = param + '&specialtyCode=' + this.specialtyPerHasDepSelected.code : '';
            this.healthCenterSelected ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
            this.formPerHasDep.get("professionalCtrl").value != '' ? param = param + '&professionalId=' + this.formPerHasDep.get("professionalCtrl").value.id : '';
            this.lastDay ? param = param + '&dateFrom=' + moment__WEBPACK_IMPORTED_MODULE_9__(fechaLastDay).format('YYYY-MM-DD') : '';
            if (param.length > 0) {
                param = param.replace('&', '?');
            }
            this.shiftService.getShifts(this.httpOptions, param).subscribe((response) => {
                this.loading.dismiss();
                event.target.complete();
                this.lastDay = response.dateTo;
                if (response) {
                    if (response.serviceDateGroups.length > 0) {
                        response.serviceDateGroups.forEach(element => {
                            this.servicesPerHasDepList.serviceDateGroups.push(element);
                            this.servicesPerHasDepList.dateTo = element.stringDate;
                            this.servicesPerHasDepList.stringDateTo = element.stringDate;
                        });
                        this.lastDay = response.dateTo;
                    }
                    else {
                        //this.alert("No se encontraron Turnos disponibles desde : "+response.dateFrom+ " Hasta "+response.dateTo ); 
                        this.servicesPerHasDepList.dateFrom = this.servicesPerHasDepList.stringDateTo;
                        this.servicesPerHasDepList.dateTo = response.stringDateTo;
                        this.servicesPerHasDepList.stringDateFrom = this.servicesPerHasDepList.stringDateTo;
                        this.servicesPerHasDepList.stringDateTo = response.stringDateTo;
                        this.noShiftAvalableHasPer = true;
                        event.target.complete();
                        this.infiniteScroll = true;
                    }
                }
            }, error => {
                if (error.status === 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                }
            });
            console.log("Cargando ...");
        }
        else {
            event.target.complete();
        }
    }
    seeShiftHours(item) {
        this.loading.dismiss();
        if (item) {
            let navigationExtras = {
                state: {
                    shift: item,
                    person: this.formPerHasDep.get("personsCtrl").value ? this.formPerHasDep.get("personsCtrl").value : null,
                }
            };
            this.router.navigate(['available-shifts'], navigationExtras);
        }
    }
    clearFilterList() {
        this.formPersonal.get("specialtyCtrl").setValue("");
        this.formPersonal.get("professionalCtrl").setValue("");
        this.formPersonal.get("fromDateCtrl").setValue(null);
        this.formPerHasDep.get("personsCtrl").setValue("");
        this.formPerHasDep.get("specialtyCtrl").setValue("");
        this.formPerHasDep.get("professionalCtrl").setValue("");
        this.formPerHasDep.get("fromDateCtrl").setValue(null);
        this.servicesPerHasDepList = [];
        this.servicesPersonalList = [];
        this.specialtySelected = null;
        this.specialtyPerHasDepSelected = null;
        this.panelOpenState = true;
    }
    goToShifts() {
        this.router.navigate(['shifts']);
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
    getPerHasDep() {
        this.healthCenterSelected = this.formPerHasDep.get('healthCenterCtrl').value;
        if (this.formPerHasDep.get("personsCtrl").value) {
            this.enableSearchSpecialtyPerHasDep();
            let param = '';
            this.formPerHasDep.get("personsCtrl").value != '' ? param = param + '&sexWards=' + this.formPerHasDep.get("personsCtrl").value.sex : '';
            this.formPerHasDep.get("personsCtrl").value ? param = param + '&docNumberWards=' + this.formPerHasDep.get("personsCtrl").value.docNumber : '';
            this.healthCenterSelected ? param = param + '&healthCenterId=' + this.healthCenterSelected : '';
            if (param.length > 0) {
                param = param.replace('&', '?');
            }
            this.cmSpecialtyPerHasDep = true;
            this.getSpecialtyPerHasDep(param);
        }
    }
    setStep() {
        this.panelOpenState = true;
    }
};
NewShiftComponent.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"] },
    { type: src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_5__["ShiftService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_10__["LoadingService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] },
    { type: src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_12__["LocalStorageService"] }
];
NewShiftComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-new-shift',
        template: __webpack_require__(/*! raw-loader!./new-shift.component.html */ "./node_modules/raw-loader/index.js!./src/app/shifts/new-shift/new-shift.component.html"),
        providers: [
            { provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_11__["MAT_DATE_FORMATS"], useValue: FORMAT },
        ],
        styles: [__webpack_require__(/*! ./new-shift.component.scss */ "./src/app/shifts/new-shift/new-shift.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"],
        src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_5__["ShiftService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
        src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_10__["LoadingService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"],
        src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_12__["LocalStorageService"]])
], NewShiftComponent);



/***/ }),

/***/ "./src/app/shifts/new-shift/new-shift.module.ts":
/*!******************************************************!*\
  !*** ./src/app/shifts/new-shift/new-shift.module.ts ***!
  \******************************************************/
/*! exports provided: NewShiftModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewShiftModule", function() { return NewShiftModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _new_shifts_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./new-shifts-routing.module */ "./src/app/shifts/new-shift/new-shifts-routing.module.ts");
/* harmony import */ var _new_shift_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./new-shift.component */ "./src/app/shifts/new-shift/new-shift.component.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/shift.service */ "./src/app/services/shift.service.ts");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/esm2015/expansion.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/esm2015/datepicker.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm2015/input.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/esm2015/core.js");
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm2015/material-moment-adapter.js");














let NewShiftModule = class NewShiftModule {
};
NewShiftModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
            _new_shifts_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewShiftsRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionModule"],
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_10__["MatDatepickerModule"],
            _angular_material_input__WEBPACK_IMPORTED_MODULE_11__["MatInputModule"],
            _angular_material_core__WEBPACK_IMPORTED_MODULE_12__["MatNativeDateModule"],
            _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_13__["MatMomentDateModule"],
        ],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"],
            src_app_services_shift_service__WEBPACK_IMPORTED_MODULE_8__["ShiftService"],
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_10__["MatDatepickerModule"]],
        declarations: [_new_shift_component__WEBPACK_IMPORTED_MODULE_6__["NewShiftComponent"]]
    })
], NewShiftModule);



/***/ }),

/***/ "./src/app/shifts/new-shift/new-shifts-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/shifts/new-shift/new-shifts-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: NewShiftsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewShiftsRoutingModule", function() { return NewShiftsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _new_shift_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./new-shift.component */ "./src/app/shifts/new-shift/new-shift.component.ts");




const routes = [
    {
        path: '',
        component: _new_shift_component__WEBPACK_IMPORTED_MODULE_3__["NewShiftComponent"]
    }
];
let NewShiftsRoutingModule = class NewShiftsRoutingModule {
};
NewShiftsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], NewShiftsRoutingModule);



/***/ })

}]);
//# sourceMappingURL=shifts-new-shift-new-shift-module-es2015.js.map