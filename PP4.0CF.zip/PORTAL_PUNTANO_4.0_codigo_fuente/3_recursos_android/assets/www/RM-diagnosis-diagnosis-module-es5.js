(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["RM-diagnosis-diagnosis-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/RM/diagnosis/diagnosis.component.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RM/diagnosis/diagnosis.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTROS MÉDICOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-list-header>\r\n      <h2 class=\"header-text\"><b>MIS DIAGNÓSTICOS</b></h2>\r\n    </ion-list-header>\r\n  </ion-list>\r\n\r\n  <ion-grid>\r\n\r\n    <ion-row class=\"accordion__container\" *ngFor=\"let diagnosis of diagnoses\">\r\n      <ion-col [size]=\"hasHiddenDiagnosis ? 10 : 12\">\r\n\r\n        <mat-accordion multi>\r\n          <mat-expansion-panel [ngClass]=\"{'hidden': diagnosis.hiddenDiagnosis}\"\r\n            (opened)=\"openDiagnosisDetail(diagnosis)\">\r\n            <mat-expansion-panel-header [ngClass]=\"{'hidden': diagnosis.hiddenDiagnosis}\">\r\n              <mat-panel-title>\r\n                {{diagnosis.description}}\r\n              </mat-panel-title>\r\n            </mat-expansion-panel-header>\r\n            <div *ngIf=\"diagnosis.diagnosisEvolution &&  diagnosis.diagnosisEvolution.length > 0\">\r\n              <div class=\"accordion__content\"\r\n                *ngFor=\"let diagnosisEvolution of diagnosis.diagnosisEvolution; let last = last\">\r\n\r\n                <div class=\"accordion__description\">\r\n                  <b>{{diagnosisEvolution.date}} - </b> {{diagnosisEvolution.description}}\r\n                </div>\r\n                <div class=\"accordion__description-info\" [ngClass]=\"{'last-child': !last}\">\r\n                  <p>{{diagnosisEvolution.professionalName}}</p>\r\n                  <p>{{diagnosisEvolution.specialty}}</p>\r\n                  <p>{{diagnosisEvolution.healthCenterName}}</p>\r\n                </div>\r\n              </div>\r\n              <div class=\"accordion__access\" *ngIf=\"diagnosis && diagnosis.hiddenDiagnosis\">\r\n                <h5>PROFESIONALES CON ACCESO</h5>\r\n\r\n                <div *ngIf=\"diagnosis.professionalWithPermission && diagnosis.professionalWithPermission.length === 0\">\r\n                  Este diagnóstico no tiene profesionales con permiso de acceso\r\n                </div>\r\n\r\n                <ul>\r\n                  <li *ngFor=\"let professional of diagnosis.professionalWithPermission\">\r\n                    <ion-grid>\r\n                      <ion-row>\r\n                        <ion-col size=\"10\">\r\n                          <span class=\"accordion__professional\">{{professional.fullName}}</span>\r\n                        </ion-col>\r\n                        <ion-col size=\"2\" *ngIf=\"!professional.creator\"\r\n                          (click)=\"presentAlertToDeleteProfessional(diagnosis, professional)\">\r\n                          <div class=\"icon-trash-container\">\r\n                            <ion-icon class=\"icon-trash\" name=\"trash-outline\"></ion-icon>\r\n                          </div>\r\n                        </ion-col>\r\n                      </ion-row>\r\n                    </ion-grid>\r\n                  </li>\r\n\r\n                </ul>\r\n              </div>\r\n            </div>\r\n\r\n          </mat-expansion-panel>\r\n        </mat-accordion>\r\n      </ion-col>\r\n      <ion-col *ngIf=\"diagnosis && diagnosis.hiddenDiagnosis\" class=\"content-icon\" [size]=\"hasHiddenDiagnosis ? 2 : 0\">\r\n        <ion-icon name=\"lock-closed\" (click)=\"presentAlertToSelectProfessional(diagnosis)\"></ion-icon>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n\r\n\r\n\r\n\r\n  <!-- \r\n  <div class=\"content\">\r\n    <div #accordion class=\"accordion\" >\r\n      <div class=\"accordion__header\" (click)=\"handleAccordion($event)\">\r\n        <h3>titulo</h3>\r\n        <ion-icon name=\"chevron-down-outline\"></ion-icon>\r\n      </div>\r\n      <div class=\"accordion__content\">\r\n        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>\r\n      </div>\r\n    </div>\r\n    <div #accordion class=\"accordion\" >\r\n      <div class=\"accordion__header\" (click)=\"handleAccordion($event)\">\r\n        <h3>titulo</h3>\r\n        <ion-icon name=\"chevron-down-outline\"></ion-icon>\r\n      </div>\r\n      <div class=\"accordion__content\">\r\n        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>\r\n      </div>\r\n    </div>\r\n  </div> -->\r\n\r\n\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" name=\"home\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/RM/diagnosis/diagnosis.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/RM/diagnosis/diagnosis.component.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #EC272F;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #EC272F;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #EC272F;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.content {\n  padding: 0 1rem;\n}\n\n.display-none {\n  display: none;\n}\n\n.icon-item {\n  position: relative;\n}\n\n.icon-lock {\n  position: absolute;\n  top: 0;\n  left: 0;\n  z-index: 9999999;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.content-icon {\n  display: flex;\n  align-items: flex-start;\n  justify-content: center;\n  font-size: 2rem;\n  margin-top: 1rem;\n  color: #EC272F;\n}\n\n.accordion__container {\n  margin: 0.5rem 0;\n}\n\n.accordion__description,\n.accordion__description-info,\n.accordion__professional {\n  font-size: 1rem;\n}\n\n.accordion__description-info {\n  margin: 1rem 0;\n}\n\n.accordion__description-info.last-child {\n  border-bottom: 1px solid #969696;\n}\n\n.accordion__description-info p {\n  margin: 0.5rem 0;\n}\n\n.accordion__access {\n  border-top: 0.5px solid black;\n}\n\n.accordion__access ul {\n  margin: 0;\n  padding-left: 1rem;\n  list-style-type: disc;\n}\n\n.icon-trash {\n  font-size: 1.5rem;\n  color: #EC272F;\n}\n\n.icon-trash-container {\n  height: 100%;\n  width: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n::ng-deep .mat-expansion-panel {\n  box-shadow: none !important;\n  border: 1px solid #EC272F;\n}\n\n::ng-deep .mat-expansion-panel-header,\n::ng-deep .mat-expansion-panel-header:hover,\n::ng-deep .mat-expansion-panel-header:focus {\n  background: #EC272F !important;\n  box-shadow: none;\n}\n\n::ng-deep .mat-expansion-panel-header-title,\n::ng-deep .mat-expansion-indicator::after {\n  color: #fff;\n}\n\n::ng-deep .mat-expansion-panel-header-title {\n  font-size: 1.1rem;\n}\n\n::ng-deep .mat-expansion-panel-body {\n  padding: 1rem 0.5rem !important;\n}\n\n::ng-deep .mat-expansion-panel.hidden {\n  box-shadow: none !important;\n  border: 1px solid #969696;\n}\n\n::ng-deep .mat-expansion-panel-header.hidden,\n::ng-deep .mat-expansion-panel-header.hidden:hover,\n::ng-deep .mat-expansion-panel-header.hidden:focus {\n  background: #969696 !important;\n  box-shadow: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUk0vZGlhZ25vc2lzL0Q6XFxSZXBvc2l0b3Jpb3NcXHBvcnRhbC1pb25pYy9zcmNcXGFwcFxcUk1cXGRpYWdub3Npc1xcZGlhZ25vc2lzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9STS9kaWFnbm9zaXMvZGlhZ25vc2lzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UsY0FBQTtBQ0FGOztBREVBO0VBQ0UsZ0NBQUE7QUNDRjs7QURFQztFQUNDLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7QUNDRjs7QURFQztFQUNDLGVBQUE7RUFDQSxnQkFBQTtBQ0NGOztBREVDO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtBQ0NMOztBREVDO0VBQ0MscUJBQUE7QUNDRjs7QURFQztFQUNDLGNBQUE7QUNDRjs7QURFQTtFQUNFLHlCQUFBO0FDQ0Y7O0FERUE7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0FDQ0Y7O0FERUE7RUFDRSxhQUFBO0FDQ0Y7O0FERUE7RUFDRSxrQkFBQTtBQ0NGOztBREVBO0VBQ0Usa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxXQUFBO0FDQ0Y7O0FERUE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0FDQ0Y7O0FERUE7OztFQUdFLGVBQUE7QUNDRjs7QURFQTtFQUNFLGNBQUE7QUNDRjs7QURDQTtFQUNFLGdDQUFBO0FDRUY7O0FEQUE7RUFDRSxnQkFBQTtBQ0dGOztBREFBO0VBQ0UsNkJBQUE7QUNHRjs7QUREQTtFQUNFLFNBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0FDSUY7O0FEREE7RUFDRSxpQkFBQTtFQUNBLGNBQUE7QUNJRjs7QUREQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNJRjs7QURDQTtFQUNFLDJCQUFBO0VBQ0EseUJBQUE7QUNFRjs7QURDQTs7O0VBR0UsOEJBQUE7RUFDQSxnQkFBQTtBQ0VGOztBREFBOztFQUVFLFdBQUE7QUNHRjs7QUREQTtFQUNFLGlCQUFBO0FDSUY7O0FEQUE7RUFDRSwrQkFBQTtBQ0dGOztBREFBO0VBQ0UsMkJBQUE7RUFDQSx5QkFBQTtBQ0dGOztBREFBOzs7RUFJRSw4QkFBQTtFQUNBLGdCQUFBO0FDRUYiLCJmaWxlIjoic3JjL2FwcC9STS9kaWFnbm9zaXMvZGlhZ25vc2lzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5yZWR7XHJcbiAgY29sb3I6ICNFQzI3MkY7XHJcbn1cclxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XHJcbiAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgI0VDMjcyRjtcclxuIH1cclxuXHJcbiAuaGVhZGVyLXRleHR7XHJcbiAgYm9yZGVyLWJvdHRvbToycHggc29saWQgIzUzNTM1MztcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gfVxyXG5cclxuIGlvbi1pdGVte1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gfVxyXG5cclxuIGlvbi1saXN0e1xyXG4gICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgbWFyZ2luLWJvdHRvbTowcHg7XHJcbiB9XHJcblxyXG4gaW9uLWhlYWRlciBpb24tdG9vbGJhcntcclxuICAtLWJhY2tncm91bmQ6ICNFQzI3MkY7XHJcbiAgXHJcbiB9XHJcbiBpb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZXtcclxuICBjb2xvcjogI0ZGRkZGRjtcclxuIH1cclxuXHJcbi53aGl0ZXtcclxuICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tdGl0bGV7XHJcbiAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICBmb250LXNpemU6IDV2dztcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5jb250ZW50IHtcclxuICBwYWRkaW5nOiAwIDFyZW07XHJcbn1cclxuXHJcbi5kaXNwbGF5LW5vbmUge1xyXG4gIGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbi5pY29uLWl0ZW0ge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLmljb24tbG9jayB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIHotaW5kZXg6IDk5OTk5OTk7XHJcbn1cclxuXHJcbi53LTEwMCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5jb250ZW50LWljb24ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZm9udC1zaXplOiAycmVtO1xyXG4gIG1hcmdpbi10b3A6IDFyZW07XHJcbiAgY29sb3I6ICNFQzI3MkY7XHJcbn1cclxuXHJcbi5hY2NvcmRpb25fX2NvbnRhaW5lciB7XHJcbiAgbWFyZ2luOiAuNXJlbSAwO1xyXG59XHJcblxyXG4uYWNjb3JkaW9uX19kZXNjcmlwdGlvbixcclxuLmFjY29yZGlvbl9fZGVzY3JpcHRpb24taW5mbyxcclxuLmFjY29yZGlvbl9fcHJvZmVzc2lvbmFsIHtcclxuICBmb250LXNpemU6IDFyZW07XHJcbn1cclxuXHJcbi5hY2NvcmRpb25fX2Rlc2NyaXB0aW9uLWluZm8ge1xyXG4gIG1hcmdpbjogMXJlbSAwO1xyXG59XHJcbi5hY2NvcmRpb25fX2Rlc2NyaXB0aW9uLWluZm8ubGFzdC1jaGlsZCB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICM5Njk2OTY7XHJcbn1cclxuLmFjY29yZGlvbl9fZGVzY3JpcHRpb24taW5mbyBwIHtcclxuICBtYXJnaW46IC41cmVtIDA7XHJcbn1cclxuXHJcbi5hY2NvcmRpb25fX2FjY2VzcyB7XHJcbiAgYm9yZGVyLXRvcDogLjVweCBzb2xpZCBibGFjaztcclxufVxyXG4uYWNjb3JkaW9uX19hY2Nlc3MgdWwge1xyXG4gIG1hcmdpbjogMDtcclxuICBwYWRkaW5nLWxlZnQ6IDFyZW07XHJcbiAgbGlzdC1zdHlsZS10eXBlOiBkaXNjO1xyXG59XHJcblxyXG4uaWNvbi10cmFzaCB7XHJcbiAgZm9udC1zaXplOiAxLjVyZW07XHJcbiAgY29sb3I6ICNFQzI3MkY7XHJcbn1cclxuXHJcbi5pY29uLXRyYXNoLWNvbnRhaW5lciB7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuXHJcbi8vIGFjY29yZGlvbiBlc3RpbG9zOlxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwge1xyXG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjRUMyNzJGO1xyXG59XHJcblxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLFxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyOmhvdmVyLFxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyOmZvY3VzIHtcclxuICBiYWNrZ3JvdW5kOiAjRUMyNzJGICFpbXBvcnRhbnQ7XHJcbiAgYm94LXNoYWRvdzogbm9uZTtcclxufVxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLXRpdGxlLFxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24taW5kaWNhdG9yOjphZnRlciB7XHJcbiAgY29sb3I6ICNmZmY7XHJcbn1cclxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci10aXRsZXtcclxuICBmb250LXNpemU6IDEuMXJlbTtcclxufVxyXG5cclxuXHJcbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1ib2R5IHtcclxuICBwYWRkaW5nOiAxcmVtIC41cmVtICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC5oaWRkZW4ge1xyXG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjOTY5Njk2O1xyXG59XHJcblxyXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLmhpZGRlbixcclxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci5oaWRkZW46aG92ZXIsXHJcbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXIuaGlkZGVuOmZvY3VzXHJcbntcclxuICBiYWNrZ3JvdW5kOiAjOTY5Njk2ICFpbXBvcnRhbnQ7XHJcbiAgYm94LXNoYWRvdzogbm9uZTtcclxufVxyXG5cclxuLy8gLmFjY29yZGlvbi1jb250ZW50IHtcclxuLy8gICBwYWRkaW5nOiAxcmVtIDA7XHJcbi8vIH1cclxuXHJcblxyXG5cclxuLy8gLmFjY29yZGlvbiB7XHJcbi8vICAgbWFyZ2luOiAxcmVtIDA7XHJcbi8vICAgd2lkdGg6IDEwMCU7XHJcbi8vICAgYm9yZGVyLXJhZGl1czogMXJlbTtcclxuLy8gICBvdmVyZmxvdzogaGlkZGVuO1xyXG4vLyAgIHRyYW5zaXRpb246IGFsbCAxcyBlYXNlO1xyXG4vLyAgIGJvcmRlcjogMXB4IHNvbGlkICNFQzI3MkY7XHJcbi8vIH1cclxuXHJcbi8vIC5hY2NvcmRpb25fX2hlYWRlciB7XHJcbi8vICAgcGFkZGluZzogLjVyZW0gMXJlbTtcclxuLy8gICBkaXNwbGF5OiBmbGV4O1xyXG4vLyAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbi8vICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4vLyAgIGZsZXgtd3JhcDogbm93cmFwO1xyXG4vLyAgIGJhY2tncm91bmQtY29sb3I6ICNFQzI3MkY7XHJcbi8vICAgY29sb3I6IHdoaXRlO1xyXG4vLyAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbi8vICAgYm9yZGVyLXJhZGl1czogMXJlbTtcclxuLy8gfVxyXG5cclxuLy8gLmFjY29yZGlvbl9faGVhZGVyIGlvbi1pY29uIHtcclxuLy8gICBmb250LXNpemU6IDEuMnJlbTtcclxuLy8gfVxyXG5cclxuLy8gLmFjY29yZGlvbl9fY29udGVudCB7XHJcbi8vICAgaGVpZ2h0OiAwcHg7XHJcbi8vIH1cclxuXHJcbi8vIC5hY2NvcmRpb25fX2hlYWRlci5hY3RpdmUgfiAuYWNjb3JkaW9uX19jb250ZW50IHtcclxuLy8gICBoZWlnaHQ6IDEwMCU7XHJcbi8vIH1cclxuXHJcbi8vIC5hY2NvcmRpb25fX2hlYWRlci5hY3RpdmUgaW9uLWljb24ge1xyXG4vLyAgIHRyYW5zZm9ybTogcm90YXRlKDE4MGRlZyk7XHJcbi8vIH1cclxuXHJcbiIsIi5yZWQge1xuICBjb2xvcjogI0VDMjcyRjtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRUMyNzJGO1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzUzNTM1MztcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuaW9uLWxpc3Qge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICNFQzI3MkY7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10aXRsZSB7XG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDUlO1xuICBmb250LXNpemU6IDV2dztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY29udGVudCB7XG4gIHBhZGRpbmc6IDAgMXJlbTtcbn1cblxuLmRpc3BsYXktbm9uZSB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5pY29uLWl0ZW0ge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi5pY29uLWxvY2sge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgei1pbmRleDogOTk5OTk5OTtcbn1cblxuLnctMTAwIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5jb250ZW50LWljb24ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMnJlbTtcbiAgbWFyZ2luLXRvcDogMXJlbTtcbiAgY29sb3I6ICNFQzI3MkY7XG59XG5cbi5hY2NvcmRpb25fX2NvbnRhaW5lciB7XG4gIG1hcmdpbjogMC41cmVtIDA7XG59XG5cbi5hY2NvcmRpb25fX2Rlc2NyaXB0aW9uLFxuLmFjY29yZGlvbl9fZGVzY3JpcHRpb24taW5mbyxcbi5hY2NvcmRpb25fX3Byb2Zlc3Npb25hbCB7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbn1cblxuLmFjY29yZGlvbl9fZGVzY3JpcHRpb24taW5mbyB7XG4gIG1hcmdpbjogMXJlbSAwO1xufVxuXG4uYWNjb3JkaW9uX19kZXNjcmlwdGlvbi1pbmZvLmxhc3QtY2hpbGQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzk2OTY5Njtcbn1cblxuLmFjY29yZGlvbl9fZGVzY3JpcHRpb24taW5mbyBwIHtcbiAgbWFyZ2luOiAwLjVyZW0gMDtcbn1cblxuLmFjY29yZGlvbl9fYWNjZXNzIHtcbiAgYm9yZGVyLXRvcDogMC41cHggc29saWQgYmxhY2s7XG59XG5cbi5hY2NvcmRpb25fX2FjY2VzcyB1bCB7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZy1sZWZ0OiAxcmVtO1xuICBsaXN0LXN0eWxlLXR5cGU6IGRpc2M7XG59XG5cbi5pY29uLXRyYXNoIHtcbiAgZm9udC1zaXplOiAxLjVyZW07XG4gIGNvbG9yOiAjRUMyNzJGO1xufVxuXG4uaWNvbi10cmFzaC1jb250YWluZXIge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICBib3JkZXI6IDFweCBzb2xpZCAjRUMyNzJGO1xufVxuXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLFxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlcjpob3Zlcixcbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXI6Zm9jdXMge1xuICBiYWNrZ3JvdW5kOiAjRUMyNzJGICFpbXBvcnRhbnQ7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXItdGl0bGUsXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24taW5kaWNhdG9yOjphZnRlciB7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLXRpdGxlIHtcbiAgZm9udC1zaXplOiAxLjFyZW07XG59XG5cbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1ib2R5IHtcbiAgcGFkZGluZzogMXJlbSAwLjVyZW0gIWltcG9ydGFudDtcbn1cblxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLmhpZGRlbiB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzk2OTY5Njtcbn1cblxuOjpuZy1kZWVwIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci5oaWRkZW4sXG46Om5nLWRlZXAgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLmhpZGRlbjpob3Zlcixcbjo6bmctZGVlcCAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXIuaGlkZGVuOmZvY3VzIHtcbiAgYmFja2dyb3VuZDogIzk2OTY5NiAhaW1wb3J0YW50O1xuICBib3gtc2hhZG93OiBub25lO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/RM/diagnosis/diagnosis.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/RM/diagnosis/diagnosis.component.ts ***!
  \*****************************************************/
/*! exports provided: DiagnosisComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiagnosisComponent", function() { return DiagnosisComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var src_app_services_diagnosis_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/diagnosis.service */ "./src/app/services/diagnosis.service.ts");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");









var DiagnosisComponent = /** @class */ (function () {
    function DiagnosisComponent(statusBar, screenOrientation, navController, alertController, diagnosisService, patientService, localStorageService, alertService) {
        this.statusBar = statusBar;
        this.screenOrientation = screenOrientation;
        this.navController = navController;
        this.alertController = alertController;
        this.diagnosisService = diagnosisService;
        this.patientService = patientService;
        this.localStorageService = localStorageService;
        this.alertService = alertService;
        this.diagnoses = [];
        this.hasHiddenDiagnosis = false;
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    }
    DiagnosisComponent.prototype.ionViewWillEnter = function () {
        this.statusBar.backgroundColorByHexString('#EC272F');
    };
    DiagnosisComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.localStorageService.getUserData().then(function (userData) {
            _this.userData = userData;
            _this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(function (patientId) {
                _this.patientId = patientId;
                _this.diagnosisService.getDiagnosisByPatientId(patientId).subscribe(function (response) {
                    _this.diagnoses = response;
                    _this.verifyIfhasHiddenDiagnosis();
                    _this.orderDiagnosesList(_this.diagnoses);
                }, function (error) {
                    if (error.message)
                        _this.alertService.showErrorAlert(error.message);
                    else
                        _this.alertService.showErrorAlert();
                });
            });
        });
    };
    DiagnosisComponent.prototype.openDiagnosisDetail = function (diagnosis) {
        var _this = this;
        // Si diagnosis ya cargó sus diagnosisEvolution, no se cargarán nuevamente:
        if (diagnosis.diagnosisEvolution && diagnosis.diagnosisEvolution.length > 0) {
            return;
        }
        this.diagnosisService.getDiagnosisEvolutionByDiagnosisIdAndPatientId(diagnosis.diagnosisEvolutionId, this.patientId).subscribe(function (response) {
            _this.diagnoses.forEach(function (diag) {
                if (diag.id === diagnosis.id) {
                    diag.diagnosisEvolution = response;
                }
            });
        });
    };
    DiagnosisComponent.prototype.presentAlertToSelectProfessional = function (diagnosis) {
        var _this = this;
        if (this.professionalsAttendedPatient) {
            var professionalsAttendedPatientFiltered = this.filterProfessionalsWithAccess(diagnosis);
            this.presentAlertRadio(professionalsAttendedPatientFiltered, diagnosis);
        }
        else {
            this.patientService.getProfessionalsByPatientId(this.patientId).subscribe(function (response) {
                _this.professionalsAttendedPatient = response;
                var professionalsAttendedPatientFiltered = _this.filterProfessionalsWithAccess(diagnosis);
                _this.presentAlertRadio(professionalsAttendedPatientFiltered, diagnosis);
            });
        }
    };
    DiagnosisComponent.prototype.presentAlertRadio = function (professionalsList, diagnosis) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var professionalsListInAlert, alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        professionalsListInAlert = [];
                        professionalsList.forEach(function (professional) {
                            var input = {
                                name: professional.fullName,
                                type: "radio",
                                label: professional.fullName,
                                value: professional.id,
                            };
                            professionalsListInAlert.push(input);
                        });
                        return [4 /*yield*/, this.alertController.create({
                                header: 'Autorizar visualización a Profesionales',
                                inputs: professionalsListInAlert,
                                message: professionalsListInAlert.length === 0 ? "No hay profesionales disponibles" : "",
                                buttons: [
                                    {
                                        text: 'Cancelar',
                                        role: 'cancel',
                                        cssClass: 'primary',
                                    }, {
                                        text: 'Aceptar',
                                        handler: function (elementSelected) {
                                            var professionalSelected = professionalsList.find(function (el) { return el.id == elementSelected; });
                                            // Se pasa una lista de ids de profesionales porque posiblemente se pida mas adelante
                                            var professionalIds = [];
                                            professionalIds.push(elementSelected);
                                            _this.diagnosisService.postHiddenDiagnosisPermission(_this.patientId, diagnosis.id, professionalIds).subscribe(function (response) {
                                                _this.addProfessionalSelectedWithAccess(professionalSelected, diagnosis.id);
                                                _this.alertService.showCustomAlert({
                                                    message: "Se ha autorizado el acceso en el diagn\u00F3stico " + diagnosis.description + " al profesional " + professionalSelected.fullName
                                                });
                                            }, function (error) {
                                                _this.alertService.showErrorAlert();
                                            });
                                        }
                                    }
                                ]
                            })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    DiagnosisComponent.prototype.presentAlertToDeleteProfessional = function (diagnosis, professional) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: "\u00BFDesea revocar el permiso de visualizaci\u00F3n al profesional " + professional.fullName + " ?",
                            buttons: [
                                {
                                    text: 'Cancelar',
                                    role: 'cancel',
                                    cssClass: 'primary',
                                    handler: function (blah) {
                                        console.log('Confirm Cancel: blah');
                                    }
                                }, {
                                    text: 'Aceptar',
                                    handler: function () {
                                        //TODO: El back deberia recibir un id unico en vez de una lista
                                        var professionalIds = [];
                                        professionalIds.push(professional.id);
                                        _this.diagnosisService.deleteHiddenDiagnosisPermission(_this.patientId, diagnosis.id, professionalIds).subscribe(function (response) {
                                            _this.deleteProfessionalWithAccess(professional, diagnosis.id);
                                            _this.alertService.showCustomAlert({ message: "Se le ha removido el permiso de acceso al profesional " + professional.fullName });
                                        }, function (error) {
                                            _this.alertService.showErrorAlert();
                                        });
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    DiagnosisComponent.prototype.deleteProfessionalWithAccess = function (professional, diagnosisId) {
        this.diagnoses.forEach(function (diagnosis) {
            if (diagnosis.id === diagnosisId) {
                diagnosis.professionalWithPermission = diagnosis.professionalWithPermission.filter(function (prof) { return prof.id !== professional.id; });
            }
        });
    };
    DiagnosisComponent.prototype.addProfessionalSelectedWithAccess = function (professional, diagnosisId) {
        this.diagnoses.forEach(function (diagnosis) {
            if (diagnosis.id === diagnosisId) {
                diagnosis.professionalWithPermission.push(professional);
            }
        });
    };
    DiagnosisComponent.prototype.filterProfessionalsWithAccess = function (diagnosis) {
        //Elimina los profesionales que ya tienen acceso en el diagnostico seleccionado
        var professionalsAttendedPatientFiltered = this.professionalsAttendedPatient;
        if (diagnosis.professionalWithPermission && diagnosis.professionalWithPermission.length > 0) {
            diagnosis.professionalWithPermission.forEach(function (prof) {
                professionalsAttendedPatientFiltered = professionalsAttendedPatientFiltered.filter(function (profToFilter) { return prof.id !== profToFilter.id; });
            });
        }
        return professionalsAttendedPatientFiltered;
    };
    DiagnosisComponent.prototype.orderDiagnosesList = function (list) {
        list.sort(function (a, b) {
            return Number(b.hiddenDiagnosis) - Number(a.hiddenDiagnosis);
        });
    };
    DiagnosisComponent.prototype.verifyIfhasHiddenDiagnosis = function () {
        var _this = this;
        this.diagnoses.forEach(function (element) {
            if (element.hiddenDiagnosis)
                _this.hasHiddenDiagnosis = true;
        });
    };
    DiagnosisComponent.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
    };
    DiagnosisComponent.ctorParameters = function () { return [
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_2__["ScreenOrientation"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
        { type: src_app_services_diagnosis_service__WEBPACK_IMPORTED_MODULE_6__["DiagnosisService"] },
        { type: src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_8__["PatientService"] },
        { type: src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_7__["LocalStorageService"] },
        { type: src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"] }
    ]; };
    DiagnosisComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-diagnosis',
            template: __webpack_require__(/*! raw-loader!./diagnosis.component.html */ "./node_modules/raw-loader/index.js!./src/app/RM/diagnosis/diagnosis.component.html"),
            styles: [__webpack_require__(/*! ./diagnosis.component.scss */ "./src/app/RM/diagnosis/diagnosis.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_2__["ScreenOrientation"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"],
            src_app_services_diagnosis_service__WEBPACK_IMPORTED_MODULE_6__["DiagnosisService"],
            src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_8__["PatientService"],
            src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_7__["LocalStorageService"],
            src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"]])
    ], DiagnosisComponent);
    return DiagnosisComponent;
}());



/***/ }),

/***/ "./src/app/RM/diagnosis/diagnosis.module.ts":
/*!**************************************************!*\
  !*** ./src/app/RM/diagnosis/diagnosis.module.ts ***!
  \**************************************************/
/*! exports provided: DiagnosisModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiagnosisModule", function() { return DiagnosisModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _diagnosis_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./diagnosis.component */ "./src/app/RM/diagnosis/diagnosis.component.ts");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/esm5/expansion.es5.js");
/* harmony import */ var src_app_services_diagnosis_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/diagnosis.service */ "./src/app/services/diagnosis.service.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");
/* harmony import */ var src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/interceptors/interceptor-rm.service */ "./src/app/core/interceptors/interceptor-rm.service.ts");















var DiagnosisModule = /** @class */ (function () {
    function DiagnosisModule() {
    }
    DiagnosisModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            schemas: [
                _angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]
            ],
            entryComponents: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClientModule"],
                _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _diagnosis_component__WEBPACK_IMPORTED_MODULE_8__["DiagnosisComponent"]
                    }
                ])
            ],
            providers: [
                _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"],
                _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_7__["RefreshUtils"],
                src_app_services_diagnosis_service__WEBPACK_IMPORTED_MODULE_10__["DiagnosisService"],
                src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_11__["AlertService"],
                src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_12__["LocalStorageService"],
                src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_13__["PatientService"],
                {
                    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HTTP_INTERCEPTORS"],
                    useClass: src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_14__["InterceptorRm"],
                    multi: true
                }
            ],
            declarations: [
                _diagnosis_component__WEBPACK_IMPORTED_MODULE_8__["DiagnosisComponent"]
            ]
        })
    ], DiagnosisModule);
    return DiagnosisModule;
}());



/***/ }),

/***/ "./src/app/services/diagnosis.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/diagnosis.service.ts ***!
  \***********************************************/
/*! exports provided: DiagnosisService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiagnosisService", function() { return DiagnosisService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_app_utils_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utils/constants */ "./src/app/utils/constants.ts");




var DiagnosisService = /** @class */ (function () {
    function DiagnosisService(http) {
        this.http = http;
    }
    DiagnosisService.prototype.getDiagnosisByPatientId = function (patientId) {
        return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_3__["constants"].URL_RM_PREFIX + "diagnosis/patient/" + patientId);
    };
    DiagnosisService.prototype.getDiagnosisEvolutionByDiagnosisIdAndPatientId = function (diagnosisEvolutionId, patientId) {
        return this.http.get(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_3__["constants"].URL_RM_PREFIX + "diagnosisEvolutions/" + diagnosisEvolutionId + "/patient/" + patientId);
    };
    DiagnosisService.prototype.postHiddenDiagnosisPermission = function (patientId, diagnosisId, professionalIds) {
        return this.http.post(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_3__["constants"].URL_RM_PREFIX + "patient/" + patientId + "/hiddenDiagnosis/" + diagnosisId + "/addPermission", professionalIds);
    };
    DiagnosisService.prototype.deleteHiddenDiagnosisPermission = function (patientId, diagnosisId, professionalIds) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json' }),
            body: professionalIds
        };
        return this.http.delete(src_app_utils_constants__WEBPACK_IMPORTED_MODULE_3__["constants"].URL_RM_PREFIX + "patient/" + patientId + "/hiddenDiagnosis/" + diagnosisId + "/removePermission", httpOptions);
    };
    DiagnosisService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    DiagnosisService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], DiagnosisService);
    return DiagnosisService;
}());



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var LoadingService = /** @class */ (function () {
    function LoadingService(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    LoadingService.prototype.present = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.isLoading = true;
                        return [4 /*yield*/, this.loadingController.create({
                                message: '...Cargando',
                                duration: 7500,
                            }).then(function (a) {
                                a.present().then(function () {
                                    console.log('presented');
                                    if (!_this.isLoading) {
                                        a.dismiss().then(function () { return console.log('abort presenting'); });
                                    }
                                });
                            })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    LoadingService.prototype.dismiss = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.isLoading = false;
                        return [4 /*yield*/, this.loadingController.dismiss().then(function () { return console.log('dismissed'); })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    LoadingService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
    ]; };
    LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
    ], LoadingService);
    return LoadingService;
}());



/***/ })

}]);
//# sourceMappingURL=RM-diagnosis-diagnosis-module-es5.js.map