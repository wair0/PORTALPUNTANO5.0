(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["credentials-credentials-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/credentials/credentials.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/credentials/credentials.page.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <!-- <ion-thumbnail slot=\"start\"> -->\r\n    <!-- <ion-img [src]=\"../../assets/ppHeader.png\"></ion-img> -->\r\n    <!-- </ion-thumbnail> -->\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <div style=\"padding-left: 5%; margin:0%\">\r\n      <!-- <h1 style=\"color: #AB1E7E; text-align: center;\">Portal <b>Puntano</b></h1> -->\r\n      <svg version=\"1.1\" id=\"Capa_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"\r\n        x=\"0px\" y=\"0px\" height=\"15\" viewBox=\"0 0 1154.05 101.99\" style=\"enable-background:new 0 0 1154.05 101.99;\"\r\n        xml:space=\"preserve\">\r\n        <style type=\"text/css\">\r\n          .st0 {\r\n            fill: #AA1F7F;\r\n          }\r\n        </style>\r\n        <g>\r\n          <path class=\"st0\" d=\"M1.45,100.25C0.58,100.25,0,99.67,0,98.8V3.19c0-0.88,0.58-1.45,1.45-1.45h35.06\r\n             c18.98,0,31.29,11.59,31.29,29.41c0,17.81-12.31,29.41-31.29,29.41H13.76c-0.58,0-0.87,0.29-0.87,0.87V98.8\r\n             c0,0.87-0.58,1.45-1.45,1.45H1.45z M55.05,31.15c0-10.73-7.1-17.39-19.27-17.39H13.76c-0.58,0-0.87,0.29-0.87,0.87v33.03\r\n             c0,0.58,0.29,0.87,0.87,0.87h22.02C47.95,48.53,55.05,41.87,55.05,31.15z\" />\r\n          <path class=\"st0\" d=\"M84.89,78.81c-1.88-5.65-2.61-11.59-2.61-27.82c0-16.23,0.72-22.17,2.61-27.82\r\n             c5.07-15.21,16.95-23.04,33.47-23.04c16.66,0,28.54,7.82,33.61,23.04c1.88,5.65,2.61,11.59,2.61,27.82\r\n             c0,16.22-0.72,22.16-2.61,27.82c-5.07,15.21-16.95,23.03-33.61,23.03C101.84,101.84,89.97,94.02,84.89,78.81z M139.37,75.19\r\n             c1.16-3.62,2.17-10,2.17-24.19c0-14.2-1.02-20.58-2.17-24.2c-3.04-9.42-10-14.63-21-14.63c-10.87,0-17.82,5.21-20.86,14.63\r\n             c-1.16,3.62-2.17,10-2.17,24.2c0,14.19,1.01,20.57,2.17,24.19c3.04,9.42,10,14.63,20.86,14.63\r\n             C129.37,89.82,136.33,84.6,139.37,75.19z\" />\r\n          <path class=\"st0\" d=\"M232.52,100.25c-1.01,0-1.45-0.43-1.88-1.45l-19.7-40.28H189.2c-0.58,0-0.87,0.3-0.87,0.88v39.4\r\n             c0,0.87-0.58,1.45-1.45,1.45h-10c-0.87,0-1.45-0.58-1.45-1.45V3.19c0-0.88,0.58-1.45,1.45-1.45h35.64\r\n             c18.4,0,30.86,11.31,30.86,28.39c0,13.33-7.53,23.04-19.41,26.8l21.01,41.58c0.58,0.87,0.14,1.74-0.87,1.74H232.52z M230.49,30.13\r\n             c0-10.29-6.81-16.37-18.25-16.37H189.2c-0.58,0-0.87,0.29-0.87,0.87v31c0,0.58,0.29,0.87,0.87,0.87h23.03\r\n             C223.68,46.5,230.49,40.42,230.49,30.13z\" />\r\n          <path class=\"st0\" d=\"M285.97,100.25c-0.87,0-1.45-0.58-1.45-1.45V14.63c0-0.58-0.29-0.87-0.87-0.87h-26.95\r\n             c-0.87,0-1.45-0.58-1.45-1.45V3.19c0-0.88,0.58-1.45,1.45-1.45h68.52c0.87,0,1.45,0.58,1.45,1.45v9.13c0,0.87-0.58,1.45-1.45,1.45\r\n             h-26.95c-0.58,0-0.87,0.29-0.87,0.87V98.8c0,0.87-0.58,1.45-1.45,1.45H285.97z\" />\r\n          <path class=\"st0\" d=\"M357.11,3.19c0.29-0.88,0.72-1.45,1.74-1.45h9.42c1.01,0,1.59,0.58,1.88,1.45L403.9,98.8\r\n             c0.29,0.87-0.14,1.45-1.01,1.45h-10.14c-1.01,0-1.6-0.43-1.89-1.45l-7.53-21.44h-39.84l-7.53,21.44c-0.44,1.01-1.02,1.45-1.89,1.45\r\n             h-10.14c-0.87,0-1.3-0.58-1.01-1.45L357.11,3.19z M379.13,65.48l-15.5-44.77h-0.29l-15.64,44.77H379.13z\" />\r\n          <path class=\"st0\"\r\n            d=\"M419.55,3.19c0-0.88,0.58-1.45,1.45-1.45h10c0.87,0,1.45,0.58,1.45,1.45v84.17c0,0.58,0.29,0.87,0.87,0.87\r\n             h46.94c0.87,0,1.45,0.58,1.45,1.45v9.13c0,0.87-0.58,1.45-1.45,1.45h-59.25c-0.87,0-1.45-0.58-1.45-1.45V3.19z\" />\r\n          <path class=\"st0\" d=\"M527.62,100.25c-0.87,0-1.45-0.58-1.45-1.45V3.19c0-0.88,0.58-1.45,1.45-1.45h40.71\r\n             c27.09,0,38.97,14.35,38.97,34.05c0,19.12-12.32,34.05-38.97,34.05h-11.01c-0.58,0-0.87,0.29-0.87,0.87v28.1\r\n             c0,0.87-0.58,1.45-1.45,1.45H527.62z M576.87,35.78c0-5.51-3.47-8.84-10.14-8.84h-9.42c-0.58,0-0.87,0.29-0.87,0.87v15.94\r\n             c0,0.58,0.29,0.87,0.87,0.87h9.42C573.4,44.62,576.87,41.29,576.87,35.78z\" />\r\n          <path class=\"st0\" d=\"M615.85,60.12V3.19c0-0.88,0.58-1.45,1.45-1.45h27.53c0.87,0,1.45,0.58,1.45,1.45v59.54\r\n             c0,7.68,3.48,12.31,10.43,12.31c6.96,0,10.43-4.63,10.43-12.31V3.19c0-0.88,0.58-1.45,1.45-1.45h27.53c0.87,0,1.45,0.58,1.45,1.45\r\n             v56.93c0,28.25-15.79,41.86-40.71,41.86C631.78,101.99,615.85,88.37,615.85,60.12z\" />\r\n          <path class=\"st0\" d=\"M710.16,3.19c0-0.88,0.58-1.45,1.45-1.45h25.93c0.87,0,2.03,0.43,2.46,1.45l23.47,48.53h0.72V3.19\r\n             c0-0.88,0.58-1.45,1.45-1.45h24.49c0.87,0,1.45,0.58,1.45,1.45V98.8c0,0.87-0.58,1.45-1.45,1.45H764.2c-0.87,0-2.03-0.43-2.46-1.45\r\n             l-23.33-48.53h-0.87V98.8c0,0.87-0.58,1.45-1.45,1.45h-24.48c-0.87,0-1.45-0.58-1.45-1.45V3.19z\" />\r\n          <path class=\"st0\" d=\"M825.91,100.25c-0.87,0-1.45-0.58-1.45-1.45V29.55c0-0.58-0.29-0.87-0.87-0.87h-23.33\r\n             c-0.87,0-1.45-0.58-1.45-1.45V3.19c0-0.88,0.58-1.45,1.45-1.45h78.81c0.87,0,1.45,0.58,1.45,1.45v24.04c0,0.87-0.58,1.45-1.45,1.45\r\n             h-23.33c-0.58,0-0.87,0.29-0.87,0.87V98.8c0,0.87-0.58,1.45-1.45,1.45H825.91z\" />\r\n          <path class=\"st0\" d=\"M905.74,3.19c0.29-0.88,0.87-1.45,1.88-1.45h29.55c1.02,0,1.6,0.58,1.89,1.45l33.32,95.61\r\n             c0.29,0.87-0.14,1.45-1.01,1.45h-29.41c-1.01,0-1.59-0.58-1.88-1.45l-3.62-12.9h-28.97l-3.62,12.9c-0.29,0.87-0.87,1.45-1.88,1.45\r\n             h-29.41c-0.87,0-1.3-0.58-1.01-1.45L905.74,3.19z M929.64,61.14l-7.24-26.22h-0.43l-7.53,26.22H929.64z\" />\r\n          <path class=\"st0\"\r\n            d=\"M979.62,3.19c0-0.88,0.58-1.45,1.45-1.45H1007c0.87,0,2.03,0.43,2.46,1.45l23.47,48.53h0.72V3.19\r\n             c0-0.88,0.58-1.45,1.45-1.45h24.49c0.87,0,1.45,0.58,1.45,1.45V98.8c0,0.87-0.58,1.45-1.45,1.45h-25.93\r\n             c-0.87,0-2.03-0.43-2.46-1.45l-23.32-48.53H1007V98.8c0,0.87-0.58,1.45-1.45,1.45h-24.48c-0.87,0-1.45-0.58-1.45-1.45V3.19z\" />\r\n          <path class=\"st0\" d=\"M1074.81,77.51c-2.61-8.26-3.04-14.2-3.04-26.51c0-12.32,0.43-18.25,3.04-26.51\r\n             C1080.17,7.97,1095.23,0,1112.91,0s32.74,7.97,38.1,24.49c2.61,8.26,3.04,14.19,3.04,26.51c0,12.31-0.43,18.25-3.04,26.51\r\n             c-5.36,16.51-20.43,24.48-38.1,24.48S1080.17,94.02,1074.81,77.51z M1122.18,68.82c1.01-3.19,1.16-7.39,1.16-17.82\r\n             s-0.14-14.63-1.16-17.82c-1.3-4.06-4.78-6.23-9.27-6.23s-7.97,2.17-9.27,6.23c-1.01,3.18-1.16,7.39-1.16,17.82\r\n             s0.14,14.63,1.16,17.82c1.3,4.05,4.78,6.23,9.27,6.23S1120.87,72.87,1122.18,68.82z\" />\r\n        </g>\r\n      </svg>\r\n    </div>\r\n    <!-- <ion-buttons slot=\"primary\">\r\n      <ion-button (click)=\"settings()\">\r\n        <svg xmlns='http://www.w3.org/2000/svg' height='90%' viewBox='0 0 512 512'>\r\n          <title>ionicons-v5-q</title>\r\n          <path\r\n            d='M262.29,192.31a64,64,0,1,0,57.4,57.4A64.13,64.13,0,0,0,262.29,192.31ZM416.39,256a154.34,154.34,0,0,1-1.53,20.79l45.21,35.46A10.81,10.81,0,0,1,462.52,326l-42.77,74a10.81,10.81,0,0,1-13.14,4.59l-44.9-18.08a16.11,16.11,0,0,0-15.17,1.75A164.48,164.48,0,0,1,325,400.8a15.94,15.94,0,0,0-8.82,12.14l-6.73,47.89A11.08,11.08,0,0,1,298.77,470H213.23a11.11,11.11,0,0,1-10.69-8.87l-6.72-47.82a16.07,16.07,0,0,0-9-12.22,155.3,155.3,0,0,1-21.46-12.57,16,16,0,0,0-15.11-1.71l-44.89,18.07a10.81,10.81,0,0,1-13.14-4.58l-42.77-74a10.8,10.8,0,0,1,2.45-13.75l38.21-30a16.05,16.05,0,0,0,6-14.08c-.36-4.17-.58-8.33-.58-12.5s.21-8.27.58-12.35a16,16,0,0,0-6.07-13.94l-38.19-30A10.81,10.81,0,0,1,49.48,186l42.77-74a10.81,10.81,0,0,1,13.14-4.59l44.9,18.08a16.11,16.11,0,0,0,15.17-1.75A164.48,164.48,0,0,1,187,111.2a15.94,15.94,0,0,0,8.82-12.14l6.73-47.89A11.08,11.08,0,0,1,213.23,42h85.54a11.11,11.11,0,0,1,10.69,8.87l6.72,47.82a16.07,16.07,0,0,0,9,12.22,155.3,155.3,0,0,1,21.46,12.57,16,16,0,0,0,15.11,1.71l44.89-18.07a10.81,10.81,0,0,1,13.14,4.58l42.77,74a10.8,10.8,0,0,1-2.45,13.75l-38.21,30a16.05,16.05,0,0,0-6.05,14.08C416.17,247.67,416.39,251.83,416.39,256Z'\r\n            style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px' />\r\n        </svg>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <!-- TODO error al compilar con '--prod'-->\r\n  <!-- <ion-slides [options]=\"slideOpts\" pager=\"false\" mode=\"ios\" style=\"height: 100%\"> -->\r\n  <ion-slides pager=\"false\" mode=\"ios\" style=\"height: 100%\">\r\n    <!--pager=\"true\"-->\r\n    <ion-slide>\r\n      <ion-grid style=\"height: 97%;\">\r\n        <ion-row style=\"align-items: center; height: 25%;\" (click)=\"goToDriverLicense()\">\r\n          <!-- TODO error al compilar con '--prod'-->\r\n          <!-- <ion-col size=\"{{colSize}}\"> -->\r\n          <ion-col>\r\n            <ion-card text-center [ngClass]=\"btnDriverLicense\" style=\" padding: 5%; margin: 3%\">\r\n              <!-- <ion-icon ios=\"card-outline\" md=\"card-sharp\" style=\"color: white; width: 80%; height: 80%;\"></ion-icon> -->\r\n              <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\"\r\n                xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" width=\"80%\" height=\"80%\"\r\n                viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n                <g>\r\n                  <path fill=\"#FFFFFF\"\r\n                    d=\"M940.838,721.183c-2.189,6.812-3.623,13.964-6.676,20.349c-13.635,28.606-36.609,43.846-68.27,44.258\r\n                                        c-43.406,0.56-86.824,0.147-130.232,0.147c-187.203,0-374.404,0-561.605,0c-45.293,0-70.129-18.901-82.195-62.529\r\n                                        c-0.217-0.776-0.68-1.483-1.021-2.225c0-139.452,0-278.893,0-418.356c1.254-4.489,2.326-9.037,3.783-13.464\r\n                                        c10.035-30.455,38.35-51.069,71.139-51.217c51.703-0.218,103.416-0.062,155.119-0.062c179.465,0,358.92,0,538.385,0\r\n                                        c43.689,0,69.436,20.02,80.504,62.514c0.193,0.792,0.705,1.486,1.07,2.229C940.838,442.29,940.838,581.73,940.838,721.183z\r\n                                        M515.998,287.89c-115.336,0-230.682-0.012-346.02,0c-19.885,0.012-29.322,9.523-29.334,29.566c0,129.724,0,259.446,0,389.17\r\n                                        c0.012,19.981,9.488,29.492,29.408,29.492c230.416,0.012,460.818,0.012,691.219,0.012c20.432-0.012,29.748-9.414,29.76-29.992\r\n                                        c0-129.456,0-258.896,0-388.353c-0.012-20.543-9.34-29.896-29.832-29.896C746.131,287.89,631.064,287.89,515.998,287.89z\" />\r\n                  <path fill=\"#FFFFFF\" d=\"M292.758,504.839c-41.594-49.889-28.094-109.63,6.691-141.142c36.668-33.228,92.844-34.54,130.633-3.005\r\n                                        c36.684,30.613,53.344,92.13,10.217,144.221c21.029,10.509,39.732,24.059,55.217,41.752\r\n                                        c28.217,32.245,42.883,69.788,43.555,112.659c0.252,16.02-10.07,26.844-26.102,26.867c-97.615,0.123-195.217,0.123-292.818,0.015\r\n                                        c-16.443-0.026-26.953-10.874-26.332-27.44c2.529-66.818,33.408-116.527,91.191-149.778\r\n                                        C287.383,507.627,289.84,506.396,292.758,504.839z M485.846,636.17c-5.301-42.191-51.129-100.949-126.279-97.737\r\n                                        c-53.563,2.299-112.111,52.481-112.258,97.737C326.596,636.17,405.879,636.17,485.846,636.17z M366.096,487.083\r\n                                        c27.316,0.136,49.879-22.063,50.098-49.268c0.23-27.367-21.83-49.977-49.051-50.292c-27.742-0.33-50.451,22.013-50.498,49.659\r\n                                        C316.596,464.485,338.852,486.951,366.096,487.083z\" />\r\n                  <path fill=\"#FFFFFF\"\r\n                    d=\"M714.996,337.693c32.061,0,64.107-0.023,96.166,0.012c16.932,0.012,28.219,9.864,28.377,24.63\r\n                                        c0.145,14.801-11.203,25.139-27.865,25.15c-64.654,0.038-129.307,0.062-193.977-0.023c-19.922-0.023-32.68-17.659-25.029-34.662\r\n                                        c4.66-10.326,13.16-15.142,24.52-15.118C649.795,337.731,682.391,337.693,714.996,337.693z\" />\r\n                  <path fill=\"#FFFFFF\"\r\n                    d=\"M715.02,437.304c32.061,0,64.109-0.023,96.17,0.012c16.916,0.012,28.203,9.876,28.35,24.652\r\n                                        c0.133,14.801-11.215,25.115-27.889,25.127c-64.654,0.038-129.311,0.063-193.977-0.023c-19.922-0.023-32.668-17.686-24.994-34.688\r\n                                        c4.672-10.326,13.184-15.116,24.531-15.104C649.818,437.339,682.414,437.304,715.02,437.304z\" />\r\n                  <path fill=\"#FFFFFF\"\r\n                    d=\"M714.146,586.717c-31.779,0-63.563,0.023-95.342-0.012c-16.832-0.023-28.156-10.023-28.227-24.773\r\n                                        c-0.086-14.777,11.273-24.995,27.984-25.007c64.387-0.038,128.762-0.038,193.146,0c16.652,0.012,28.012,10.374,27.83,25.177\r\n                                        c-0.182,14.498-11.371,24.568-27.584,24.592C779.348,586.755,746.752,586.717,714.146,586.717z\" />\r\n                  <path fill=\"#FFFFFF\"\r\n                    d=\"M665.166,636.523c16.008,0,32.023-0.086,48.043,0.023c15.457,0.097,26.549,10.396,26.721,24.579\r\n                                        c0.158,14.521-11.057,25.127-26.965,25.177c-31.756,0.086-63.512,0.071-95.268,0c-15.957-0.038-27.193-10.521-27.119-25.018\r\n                                        c0.059-14.45,11.32-24.68,27.375-24.75C633.689,636.473,649.43,636.523,665.166,636.523z\" />\r\n                </g>\r\n              </svg>\r\n            </ion-card>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <h2 style=\"font-size:6vw; text-align: left\">LICENCIA DE CONDUCIR</h2>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row style=\"align-items: center; height: 25%;\" (click)=\"goToHealthCredential()\">\r\n          <!-- TODO error al compilar con '--prod'-->\r\n          <!-- <ion-col size=\"{{colSize}}\"> -->\r\n          <ion-col>\r\n              <ion-card text-center [ngClass]=\"btnCredential\" style=\" margin: 3%\">\r\n                  <!-- <ion-icon ios=\"card-outline\" md=\"card-sharp\" style=\"color: white; width: 80%; height: 80%;\"></ion-icon> -->\r\n\r\n                  <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\"\r\n                  xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n                  width=\"85%\" height=\"80%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\"\r\n                  xml:space=\"preserve\">                                               \r\n                      <style *ngIf=\"btnCredential === 'btnCredentialAct' \" type=\"text/css\">\r\n                          .st0{fill:#971C74;}\r\n                          .st1{fill:#FFFFFF;}\r\n                      </style> \r\n                      <g>\r\n                          <path *ngIf=\"btnCredential === 'btnCredentialAct' \" class=\"st0\" d=\"M126.2,0h771.5C967.5,0,1024,56.5,1024,126.2v771.5c0,69.7-56.5,126.2-126.2,126.2H126.2\r\n                              C56.5,1024,0,967.5,0,897.8V126.2C0,56.5,56.5,0,126.2,0z\"/> \r\n                          <path class=\"st1\" d=\"M835.7,671.28c-1.67,5.19-2.76,10.64-5.08,15.5c-10.39,21.79-27.88,33.4-52,33.71\r\n                              c-33.06,0.43-66.13,0.11-99.19,0.11c-142.58,0-285.17,0-427.75,0c-34.5,0-53.41-14.4-62.6-47.63c-0.17-0.59-0.52-1.13-0.78-1.69\r\n                              c0-106.21,0-212.42,0-318.64c0.96-3.42,1.77-6.88,2.88-10.25c7.64-23.2,29.21-38.9,54.18-39.01c39.38-0.17,78.77-0.05,118.15-0.05\r\n                              c136.69,0,273.37,0,410.06,0c33.28,0,52.89,15.25,61.32,47.61c0.15,0.6,0.54,1.13,0.81,1.7C835.7,458.86,835.7,565.07,835.7,671.28z\r\n                              M512.12,341.26c-87.85,0-175.7-0.01-263.55,0c-15.15,0.01-22.33,7.25-22.34,22.52c0,98.8,0,197.61,0,296.41\r\n                              c0.01,15.22,7.23,22.46,22.4,22.46c175.5,0.01,350.98,0.01,526.47,0.01c15.56-0.01,22.66-7.17,22.67-22.84c0-98.6,0-197.19,0-295.79\r\n                              c-0.01-15.65-7.11-22.77-22.72-22.77C687.4,341.26,599.76,341.26,512.12,341.26z\"/>\r\n                          <path class=\"st1\" d=\"M342.09,506.5c-31.68-38-21.4-83.5,5.1-107.5c27.93-25.31,70.71-26.31,99.5-2.29\r\n                              c27.94,23.32,40.63,70.17,7.78,109.85c16.02,8,30.26,18.32,42.06,31.8c21.49,24.56,32.66,53.15,33.17,85.81\r\n                              c0.19,12.2-7.67,20.45-19.88,20.46c-74.35,0.09-148.69,0.09-223.03,0.01c-12.52-0.02-20.53-8.28-20.06-20.9\r\n                              c1.93-50.89,25.45-88.75,69.46-114.08C338,508.63,339.87,507.69,342.09,506.5z M489.16,606.53c-4.04-32.13-38.94-76.89-96.18-74.44\r\n                              c-40.8,1.75-85.39,39.97-85.5,74.44C367.86,606.53,428.25,606.53,489.16,606.53z M397.95,492.98c20.81,0.1,37.99-16.8,38.16-37.53\r\n                              c0.18-20.84-16.63-38.07-37.36-38.3c-21.13-0.25-38.43,16.77-38.46,37.82C360.25,475.77,377.2,492.88,397.95,492.98z\"/>\r\n                          <path class=\"st1\" d=\"M611.68,616.19c9.18,0,114.88-0.05,124.06,0.01c8.86,0.06,15.22,5.96,15.32,14.09\r\n                              c0.09,8.32-6.34,14.4-15.46,14.43c-18.2,0.05-132.93,0.04-151.13,0c-9.15-0.02-15.59-6.03-15.54-14.34\r\n                              c0.03-8.28,6.49-14.15,15.69-14.19C593.63,616.17,602.66,616.19,611.68,616.19z\"/>\r\n                          <path class=\"st1\" d=\"M611.68,569.28c9.18,0,114.88-0.05,124.06,0.01c8.86,0.06,15.22,5.96,15.32,14.09\r\n                              c0.09,8.32-6.34,14.4-15.46,14.43c-18.2,0.05-132.93,0.04-151.13,0c-9.15-0.02-15.59-6.03-15.54-14.34\r\n                              c0.03-8.28,6.49-14.15,15.69-14.19C593.63,569.25,602.66,569.28,611.68,569.28z\"/>\r\n                          <rect x=\"666.39\" y=\"394.42\" class=\"st1\" width=\"32.57\" height=\"121.29\"/>\r\n                          <rect x=\"666.39\" y=\"394.42\" transform=\"matrix(-1.836970e-16 1 -1 -1.836970e-16 1137.743 -227.6181)\" class=\"st1\" width=\"32.57\" height=\"121.29\"/>\r\n                      </g>\r\n                  </svg>  \r\n                  <!-- <ion-img style=\"color: white; margin:auto; width: 85%; height: 80%;\" src=\"assets/icon/Icono_matriculaMedica.svg\"></ion-img> -->\r\n\r\n              </ion-card>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n              <h2 style=\"font-size:6vw; text-align: left\">MATRICULA</h2>\r\n          </ion-col>\r\n      </ion-row>\r\n      </ion-grid>\r\n    </ion-slide>\r\n  </ion-slides>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/credentials/credentials-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/credentials/credentials-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: CredentialsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CredentialsPageRoutingModule", function() { return CredentialsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _credentials_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./credentials.page */ "./src/app/credentials/credentials.page.ts");




var routes = [
    {
        path: '',
        component: _credentials_page__WEBPACK_IMPORTED_MODULE_3__["CredentialsPage"]
    }
];
var CredentialsPageRoutingModule = /** @class */ (function () {
    function CredentialsPageRoutingModule() {
    }
    CredentialsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], CredentialsPageRoutingModule);
    return CredentialsPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/credentials/credentials.module.ts":
/*!***************************************************!*\
  !*** ./src/app/credentials/credentials.module.ts ***!
  \***************************************************/
/*! exports provided: CredentialsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CredentialsPageModule", function() { return CredentialsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _credentials_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./credentials-routing.module */ "./src/app/credentials/credentials-routing.module.ts");
/* harmony import */ var _credentials_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./credentials.page */ "./src/app/credentials/credentials.page.ts");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");









var CredentialsPageModule = /** @class */ (function () {
    function CredentialsPageModule() {
    }
    CredentialsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _credentials_routing_module__WEBPACK_IMPORTED_MODULE_6__["CredentialsPageRoutingModule"]
            ],
            providers: [
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"],
                _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__["RefreshUtils"]
            ],
            declarations: [_credentials_page__WEBPACK_IMPORTED_MODULE_7__["CredentialsPage"]]
        })
    ], CredentialsPageModule);
    return CredentialsPageModule;
}());



/***/ }),

/***/ "./src/app/credentials/credentials.page.scss":
/*!***************************************************!*\
  !*** ./src/app/credentials/credentials.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-slide.swiper-slide {\n  align-items: flex-start;\n}\n\n.sc-ion-card-ios-h {\n  -webkit-margin-start: 0px;\n  margin-inline-start: 0px;\n  -webkit-margin-end: 0px;\n  margin-inline-end: 0px;\n}\n\n.btnCredentialAct {\n  background-color: #971C74;\n}\n\n.btnCredentialDes {\n  background-color: #dee2e6;\n}\n\n.btnCredentialDes .st1 {\n  fill: #f8f9fa;\n}\n\n.btnDriverLicenseAct {\n  background-color: #F7931E;\n}\n\n.btnDriverLicenseDes {\n  background-color: #dee2e6;\n}\n\n.btnDriverLicenseDes .st1 {\n  fill: #f8f9fa;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3JlZGVudGlhbHMvRDpcXFJlcG9zaXRvcmlvc1xccG9ydGFsLWlvbmljL3NyY1xcYXBwXFxjcmVkZW50aWFsc1xcY3JlZGVudGlhbHMucGFnZS5zY3NzIiwic3JjL2FwcC9jcmVkZW50aWFscy9jcmVkZW50aWFscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx1QkFBQTtBQ0NKOztBREdBO0VBQ0sseUJBQUE7RUFDQSx3QkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7QUNBTDs7QURHQTtFQUVJLHlCQUFBO0FDREo7O0FESUE7RUFFSSx5QkFBQTtBQ0ZKOztBREdJO0VBQUssYUFBQTtBQ0FUOztBREdBO0VBRUkseUJBQUE7QUNESjs7QURJQTtFQUVJLHlCQUFBO0FDRko7O0FER0k7RUFBSyxhQUFBO0FDQVQiLCJmaWxlIjoic3JjL2FwcC9jcmVkZW50aWFscy9jcmVkZW50aWFscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tc2xpZGUuc3dpcGVyLXNsaWRlIHtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgLy8gd2lkdGg6IGF1dG87XHJcbn1cclxuXHJcbi5zYy1pb24tY2FyZC1pb3MtaCB7XHJcbiAgICAgLXdlYmtpdC1tYXJnaW4tc3RhcnQ6IDBweDsgXHJcbiAgICAgbWFyZ2luLWlubGluZS1zdGFydDogMHB4OyBcclxuICAgICAtd2Via2l0LW1hcmdpbi1lbmQ6IDBweDsgXHJcbiAgICAgbWFyZ2luLWlubGluZS1lbmQ6IDBweDsgXHJcbn1cclxuXHJcbi5idG5DcmVkZW50aWFsQWN0XHJcbntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM5NzFDNzQ7XHJcbn1cclxuXHJcbi5idG5DcmVkZW50aWFsRGVzXHJcbntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNkZWUyZTY7XHJcbiAgICAuc3Qxe2ZpbGw6I2Y4ZjlmYTt9XHJcbn1cclxuXHJcbi5idG5Ecml2ZXJMaWNlbnNlQWN0XHJcbntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGNzkzMUU7XHJcbn1cclxuXHJcbi5idG5Ecml2ZXJMaWNlbnNlRGVzXHJcbntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNkZWUyZTY7XHJcbiAgICAuc3Qxe2ZpbGw6I2Y4ZjlmYTt9XHJcbn1cclxuXHJcbi8vIGlvbi1jYXJke1xyXG5cclxuLy8gICAgIG1hcmdpbjogMCA1cHg7XHJcbi8vICAgICB3aWR0aDogY2FsYygxMDAlIC0gMTBweCk7XHJcbi8vICAgICBwYWRkaW5nOiA1cHg7XHJcbi8vICAgICBib3gtc2hhZG93OiAwIDJweCA0cHggMCByZ2JhKDAsIDAsIDAsIDAuMTApO1xyXG4vLyAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4vLyB9XHJcblxyXG4vLyBpb24tcm93IHtcclxuLy8gICAgIHBhZGRpbmc6IDAgMTJweDtcclxuLy8gfVxyXG4vLyBpb24tY29sIHtcclxuLy8gICAgIHBhZGRpbmc6IDVweCAwO1xyXG4vLyB9XHJcblxyXG4iLCJpb24tc2xpZGUuc3dpcGVyLXNsaWRlIHtcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG59XG5cbi5zYy1pb24tY2FyZC1pb3MtaCB7XG4gIC13ZWJraXQtbWFyZ2luLXN0YXJ0OiAwcHg7XG4gIG1hcmdpbi1pbmxpbmUtc3RhcnQ6IDBweDtcbiAgLXdlYmtpdC1tYXJnaW4tZW5kOiAwcHg7XG4gIG1hcmdpbi1pbmxpbmUtZW5kOiAwcHg7XG59XG5cbi5idG5DcmVkZW50aWFsQWN0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzk3MUM3NDtcbn1cblxuLmJ0bkNyZWRlbnRpYWxEZXMge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGVlMmU2O1xufVxuLmJ0bkNyZWRlbnRpYWxEZXMgLnN0MSB7XG4gIGZpbGw6ICNmOGY5ZmE7XG59XG5cbi5idG5Ecml2ZXJMaWNlbnNlQWN0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0Y3OTMxRTtcbn1cblxuLmJ0bkRyaXZlckxpY2Vuc2VEZXMge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGVlMmU2O1xufVxuLmJ0bkRyaXZlckxpY2Vuc2VEZXMgLnN0MSB7XG4gIGZpbGw6ICNmOGY5ZmE7XG59Il19 */"

/***/ }),

/***/ "./src/app/credentials/credentials.page.ts":
/*!*************************************************!*\
  !*** ./src/app/credentials/credentials.page.ts ***!
  \*************************************************/
/*! exports provided: CredentialsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CredentialsPage", function() { return CredentialsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");







var CredentialsPage = /** @class */ (function () {
    function CredentialsPage(storage, http, alertController, route, platform, router, loadingController) {
        this.storage = storage;
        this.http = http;
        this.alertController = alertController;
        this.route = route;
        this.platform = platform;
        this.router = router;
        this.loadingController = loadingController;
        this.httpOptions = null;
        this.btnCredential = "btnCredentialDes";
        this.btnDriverLicense = "btnDriverLicenseDes";
        this.data = {
            token: '',
            iduser: 0,
            dni: 0,
            liquidations: [],
            judicialExpedients: [],
            proceduresAct: [],
            proceduresFin: [],
            procedures: [],
            totalProceduresAct: 0,
            totalProceduresFin: 0
        };
        // async getLocalDriverLicense() {
        //   this.storage.get('driverLicense').then((val) => {
        //     if (val) {
        //       // this.loadingController.dismiss();
        //       //this.goToDriverLicense(val);
        //       this.btnDriverLicense = "btnDriverLicenseAct";
        //       this.licenseData = val;
        //     } else {
        //       this.getDriverLicense();
        //     }
        //   });
        // }
        this.processError = function (error) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                // this.loadingController.dismiss();
                if (error.status === 500) {
                    if (error.error.exception === 'io.jsonwebtoken.ExpiredJwtException') {
                        _this.storage.get('psw').then(function (val) {
                            if (val) {
                                // this.loading();
                                _this.refreshUtils.refreshToken(val).then(function (value) {
                                    resolve(value);
                                }).catch(function (errorRefresh) {
                                    // this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        _this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    _this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                }
            });
        };
    }
    CredentialsPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.queryParams.subscribe(function (params) {
            if (_this.router.getCurrentNavigation().extras.state) {
                // this.shifts = this.router.getCurrentNavigation().extras.state.shifts;
                _this.token = _this.router.getCurrentNavigation().extras.state.token;
                //this.makeLiquidationsCollapse();
            }
        });
        this.getValidateRegistration();
        this.checkPasswordDL();
    };
    CredentialsPage.prototype.checkPasswordDL = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loading();
                this.getToken().then(function (value) {
                    _this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].URL_BASE_PORTAL + 'secure/mobile/check/password', _this.httpOptions)
                        .subscribe(function (data) {
                        _this.getDriverLicense();
                    }, function (error) {
                        _this.processError(error).then(function (value) {
                            _this.checkPasswordDL();
                        });
                    });
                });
                return [2 /*return*/];
            });
        });
    };
    CredentialsPage.prototype.loading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.loadingController.dismiss();
                        return [4 /*yield*/, this.loadingController.create({
                                message: 'Cargando',
                                duration: 5000,
                            })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CredentialsPage.prototype.goToDriverLicense = function () {
        if (this.btnDriverLicense == 'btnDriverLicenseAct') {
            var navigationExtras = {
                state: {
                    driverLicense: this.licenseData,
                    token: this.data.token
                }
            };
            this.router.navigate(['driverLicense'], navigationExtras);
        }
        else {
            if (this.licenseData) {
                this.alert(this.licenseData);
            }
            else {
                this.alert('Usted no posee licencia de conducir CIPE');
            }
        }
    };
    CredentialsPage.prototype.getDriverLicense = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loading();
                this.getToken().then(function (value) {
                    _this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].URL_BASE_PORTAL + 'secure/driverLicense/license', _this.httpOptions)
                        .subscribe(function (response) {
                        _this.storage.set('driverLicense', response);
                        if (JSON.stringify(response) != '{}') {
                            _this.licenseData = response;
                            _this.btnDriverLicense = "btnDriverLicenseAct";
                        }
                        _this.loadingController.dismiss();
                    }, function (error) {
                        if (error.status === 409) {
                            _this.licenseData = error.error.message;
                            _this.alert(error.error.message);
                        }
                        else {
                            error.error.message = _utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR;
                            _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                        }
                    });
                });
                return [2 /*return*/];
            });
        });
    };
    CredentialsPage.prototype.goToHealthCredential = function () {
        if (this.btnCredential == 'btnCredentialAct') {
            this.loadingController.dismiss();
            var navigationExtras = {
                state: {
                    token: this.data.token,
                    data: this.credentialData
                }
            };
            this.router.navigate(['health-credential'], navigationExtras);
        }
        else {
            if (this.credentialData) {
                this.alert(this.credentialData);
            }
            else {
                this.alert("Usted no posee credencial de personal de la salud");
            }
        }
    };
    CredentialsPage.prototype.getValidateRegistration = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loading();
                this.getToken().then(function (value) {
                    _this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].URL_BASE_PORTAL + 'secure/ministryOfHealth/credential', _this.httpOptions)
                        .subscribe(function (data) {
                        //this.goToHealthCredential(data);
                        _this.credentialData = data;
                        _this.btnCredential = 'btnCredentialAct';
                        _this.loadingController.dismiss();
                    }, function (error) {
                        if (error.status === 409) {
                            _this.credentialData = error.error.message;
                            _this.alert(error.error.message);
                        }
                        else {
                            _this.credentialData = _utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR;
                            _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                        }
                    });
                });
                return [2 /*return*/];
            });
        });
    };
    CredentialsPage.prototype.alert = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Portal puntano',
                            message: messageText,
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel',
                                    cssClass: 'primary',
                                    handler: function () {
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CredentialsPage.prototype.getToken = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.storage.get('token').then(function (value) {
                            var httpOptions = {
                                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                    'Content-Type': 'application/json',
                                    'Accept': 'application/json',
                                    'X-Authorization': 'Bearer ' + value,
                                }),
                                response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                        'Content-Type': 'application/json',
                                        'Accept': 'application/json'
                                    }),
                                })
                            };
                            _this.httpOptions = httpOptions;
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CredentialsPage.ctorParameters = function () { return [
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] }
    ]; };
    CredentialsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-credentials',
            template: __webpack_require__(/*! raw-loader!./credentials.page.html */ "./node_modules/raw-loader/index.js!./src/app/credentials/credentials.page.html"),
            styles: [__webpack_require__(/*! ./credentials.page.scss */ "./src/app/credentials/credentials.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"], _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]])
    ], CredentialsPage);
    return CredentialsPage;
}());



/***/ })

}]);
//# sourceMappingURL=credentials-credentials-module-es5.js.map