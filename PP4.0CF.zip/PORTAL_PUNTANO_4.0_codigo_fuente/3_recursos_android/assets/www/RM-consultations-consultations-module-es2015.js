(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["RM-consultations-consultations-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/RM/consultations/consultations.page.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/RM/consultations/consultations.page.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>REGISTROS MÉDICOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list-header>\r\n    <h2 class=\"header-text\"><b>MIS CONSULTAS MÉDICAS</b></h2>\r\n  </ion-list-header>\r\n\r\n  <h3 class=\"search__title\">Buscar:</h3>\r\n  <div class=\"search\">\r\n\r\n    <div class=\"w-100 input-date\">\r\n      <mat-form-field class=\"matDate\" appearance=\"outline\">\r\n        <mat-label>Fecha Desde</mat-label>\r\n        <input matInput [matDatepicker]=\"picker\" [(ngModel)]=\"dateFrom\">\r\n        <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n        <mat-datepicker #picker></mat-datepicker>\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <ion-item class=\"w-100\">\r\n      <ion-label>Especialidad:</ion-label>\r\n      <ion-select class=\"color-red\" placeholder=\"Seleccione especialidad\" okText=\"Ok\" cancelText=\"Cerrar\"\r\n        [(ngModel)]=\"specialtyIdSelected\">\r\n        <ion-select-option [value]=0>Todas las especialidades</ion-select-option>\r\n        <ion-content *ngFor=\"let item of specialties\">\r\n          <ion-select-option value={{item.id}}>{{item.name}}</ion-select-option>\r\n        </ion-content>\r\n      </ion-select>\r\n    </ion-item>\r\n    <div class=\"search__btn\" (click)=\"search()\">\r\n      <ion-icon name=\"search-outline\"></ion-icon>\r\n    </div>\r\n  </div>\r\n\r\n  <ion-list>\r\n    <ion-item *ngIf=\"consultations.length === 0\">\r\n      <p>No se encontraron consultas</p>\r\n    </ion-item>\r\n\r\n    <ion-item class=\"border-red\" *ngFor=\"let item of consultations\" (click)=\"goToConsultation(item.consultationId)\">\r\n      <ion-label class=\"ion-text-wrap\">\r\n        <ion-text color=\"dark\">\r\n          <h2 style=\"display: inline;\"> {{item.dateCreated}}</h2>\r\n          <ion-icon style=\" vertical-align: middle; margin: 0px !important;\" name=\"ios-arrow-forward\"></ion-icon>\r\n        </ion-text>\r\n        <h2 class=\"red\">{{item.specialty}}</h2>\r\n        <h2 class=\"red\">{{item.professionalName}}</h2>\r\n        <h3 class=\"red\">{{item.healthCenterName}}</h3>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n  </ion-list>\r\n\r\n  <ion-item class=\"show-all\" lines=\"none\" [routerLink]=\"'/all-consultations'\">\r\n    <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n      <h4 style=\"display: inline;\"><b>Mostrar todas</b></h4>\r\n    </ion-text>\r\n    <svg xmlns='http://www.w3.org/2000/svg' height='25' viewBox='0 0 512 512'>\r\n      <polyline points='184 112 328 256 184 400'\r\n        style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n    </svg>\r\n  </ion-item>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" name=\"home\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/RM/consultations/consultations.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/RM/consultations/consultations.module.ts ***!
  \**********************************************************/
/*! exports provided: ConsultationsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConsultationsModule", function() { return ConsultationsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _consultations_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./consultations.page */ "./src/app/RM/consultations/consultations.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/esm2015/form-field.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/esm2015/datepicker.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/esm2015/core.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm2015/input.js");
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm2015/material-moment-adapter.js");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");
/* harmony import */ var src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/interceptors/interceptor-rm.service */ "./src/app/core/interceptors/interceptor-rm.service.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");


















let ConsultationsModule = class ConsultationsModule {
};
ConsultationsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatFormFieldModule"],
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_10__["MatDatepickerModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
            _angular_material_input__WEBPACK_IMPORTED_MODULE_12__["MatInputModule"],
            _angular_material_core__WEBPACK_IMPORTED_MODULE_11__["MatNativeDateModule"],
            _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_13__["MatMomentDateModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _consultations_page__WEBPACK_IMPORTED_MODULE_6__["ConsultationsPage"]
                }
            ])
        ],
        providers: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__["RefreshUtils"],
            src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_14__["ConsultationService"],
            src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_15__["PatientService"],
            src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_17__["AlertService"],
            {
                provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HTTP_INTERCEPTORS"],
                useClass: src_app_core_interceptors_interceptor_rm_service__WEBPACK_IMPORTED_MODULE_16__["InterceptorRm"],
                multi: true
            }
        ],
        declarations: [_consultations_page__WEBPACK_IMPORTED_MODULE_6__["ConsultationsPage"]],
        entryComponents: []
    })
], ConsultationsModule);



/***/ }),

/***/ "./src/app/RM/consultations/consultations.page.scss":
/*!**********************************************************!*\
  !*** ./src/app/RM/consultations/consultations.page.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":root {\n  --ion-color-primary: #EC272F ;\n}\n\n.red {\n  color: #EC272F;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #EC272F;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #EC272F;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.search {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n\n.search__btn {\n  background: #EC272F;\n  color: white;\n  padding: 0.5rem 4rem;\n  font-size: 1.5rem;\n  border-radius: 5rem;\n  margin: 1rem 0;\n}\n\n.search__title {\n  margin-left: 1rem;\n}\n\n.color-red {\n  color: #EC272F;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.input-date {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.show-all {\n  --min-height: 20px;\n  border-radius: 6px;\n  background-color: #e6e6e6;\n  --ion-background-color: #e6e6e6;\n  margin-top: 0.5rem;\n  margin-bottom: 1.5rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUk0vY29uc3VsdGF0aW9ucy9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXFJNXFxjb25zdWx0YXRpb25zXFxjb25zdWx0YXRpb25zLnBhZ2Uuc2NzcyIsInNyYy9hcHAvUk0vY29uc3VsdGF0aW9ucy9jb25zdWx0YXRpb25zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDZCQUFBO0FDQ0o7O0FER0E7RUFDSSxjQUFBO0FDQUo7O0FES0E7RUFDSSxnQ0FBQTtBQ0ZKOztBREtHO0VBQ0MsZ0NBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtBQ0ZKOztBREtHO0VBQ0MsZUFBQTtFQUNBLGdCQUFBO0FDRko7O0FES0c7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0FDRlA7O0FES0c7RUFDQyxxQkFBQTtBQ0ZKOztBREtHO0VBQ0MsY0FBQTtBQ0ZKOztBREtBO0VBQ0kseUJBQUE7QUNGSjs7QURLQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNGSjs7QURLQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNGSjs7QURLQTtFQUNJLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUNGSjs7QURLQTtFQUNJLGlCQUFBO0FDRko7O0FES0E7RUFDSSxjQUFBO0FDRko7O0FES0E7RUFDSSxXQUFBO0FDRko7O0FES0E7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0ZKOztBREtBO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsK0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0FDRkoiLCJmaWxlIjoic3JjL2FwcC9STS9jb25zdWx0YXRpb25zL2NvbnN1bHRhdGlvbnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOnJvb3Qge1xyXG4gICAgLS1pb24tY29sb3ItcHJpbWFyeTogI0VDMjcyRlxyXG4gIH1cclxuXHJcblxyXG4ucmVke1xyXG4gICAgY29sb3I6ICNFQzI3MkZcclxufVxyXG5cclxuXHJcblxyXG5pb24taXRlbS5ib3JkZXItcmVkIHtcclxuICAgIGJvcmRlci1ib3R0b206MXB4IHNvbGlkICNFQzI3MkY7XHJcbiAgIH1cclxuXHJcbiAgIC5oZWFkZXItdGV4dHtcclxuICAgIGJvcmRlci1ib3R0b206MnB4IHNvbGlkICM1MzUzNTM7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICAgfVxyXG5cclxuICAgaW9uLWl0ZW17XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gICB9XHJcblxyXG4gICBpb24tbGlzdHtcclxuICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICBtYXJnaW4tYm90dG9tOjBweDtcclxuICAgfVxyXG5cclxuICAgaW9uLWhlYWRlciBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogI0VDMjcyRjtcclxuICAgIFxyXG4gICB9XHJcbiAgIGlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxle1xyXG4gICAgY29sb3I6ICNGRkZGRkY7XHJcbiAgIH1cclxuXHJcbi53aGl0ZXtcclxuICAgIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi10aXRsZXtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIGZvbnQtc2l6ZTogNXZ3O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uc2VhcmNoIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4uc2VhcmNoX19idG4ge1xyXG4gICAgYmFja2dyb3VuZDogI0VDMjcyRjtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHBhZGRpbmc6IC41cmVtIDRyZW07XHJcbiAgICBmb250LXNpemU6IDEuNXJlbTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVyZW07XHJcbiAgICBtYXJnaW46IDFyZW0gMDtcclxufVxyXG5cclxuLnNlYXJjaF9fdGl0bGUge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDFyZW07XHJcbn1cclxuXHJcbi5jb2xvci1yZWQge1xyXG4gICAgY29sb3I6ICNFQzI3MkY7XHJcbn1cclxuXHJcbi53LTEwMCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLmlucHV0LWRhdGUge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLnNob3ctYWxsIHtcclxuICAgIC0tbWluLWhlaWdodDogMjBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlNmU2ZTY7XHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xyXG4gICAgbWFyZ2luLXRvcDogLjVyZW07XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxLjVyZW07XHJcbiAgfSIsIjpyb290IHtcbiAgLS1pb24tY29sb3ItcHJpbWFyeTogI0VDMjcyRiA7XG59XG5cbi5yZWQge1xuICBjb2xvcjogI0VDMjcyRjtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRUMyNzJGO1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzUzNTM1MztcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuaW9uLWxpc3Qge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICNFQzI3MkY7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10aXRsZSB7XG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDUlO1xuICBmb250LXNpemU6IDV2dztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uc2VhcmNoIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5zZWFyY2hfX2J0biB7XG4gIGJhY2tncm91bmQ6ICNFQzI3MkY7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogMC41cmVtIDRyZW07XG4gIGZvbnQtc2l6ZTogMS41cmVtO1xuICBib3JkZXItcmFkaXVzOiA1cmVtO1xuICBtYXJnaW46IDFyZW0gMDtcbn1cblxuLnNlYXJjaF9fdGl0bGUge1xuICBtYXJnaW4tbGVmdDogMXJlbTtcbn1cblxuLmNvbG9yLXJlZCB7XG4gIGNvbG9yOiAjRUMyNzJGO1xufVxuXG4udy0xMDAge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmlucHV0LWRhdGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLnNob3ctYWxsIHtcbiAgLS1taW4taGVpZ2h0OiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlNmU2ZTY7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNlNmU2ZTY7XG4gIG1hcmdpbi10b3A6IDAuNXJlbTtcbiAgbWFyZ2luLWJvdHRvbTogMS41cmVtO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/RM/consultations/consultations.page.ts":
/*!********************************************************!*\
  !*** ./src/app/RM/consultations/consultations.page.ts ***!
  \********************************************************/
/*! exports provided: ConsultationsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConsultationsPage", function() { return ConsultationsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/local-storage.service */ "./src/app/services/local-storage.service.ts");
/* harmony import */ var src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/consultation.service */ "./src/app/services/consultation.service.ts");
/* harmony import */ var src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/patient.service */ "./src/app/services/patient.service.ts");
/* harmony import */ var src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/alert.service */ "./src/app/services/alert.service.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_12__);













let ConsultationsPage = class ConsultationsPage {
    constructor(alertController, loadingController, storage, router, screenOrientation, statusBar, navController, localStorageService, consultationService, patientService, alertService) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.storage = storage;
        this.router = router;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.localStorageService = localStorageService;
        this.consultationService = consultationService;
        this.patientService = patientService;
        this.alertService = alertService;
        this.consultations = [];
        this.processError = function (error) {
            return new Promise((resolve, reject) => {
                // this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        this.storage.get('psw').then((val) => {
                            if (val) {
                                // this.loading();
                                this.refreshUtils.refreshToken(val).then((value) => {
                                    this.loadingController.dismiss();
                                    resolve(value);
                                }).catch((errorRefresh) => {
                                    this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.processErrorRM = function (error) {
            return new Promise((resolve, reject) => {
                // this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        this.storage.get('token').then((val) => {
                            if (val) {
                                // this.loading();
                                this.refreshUtils.refreshTokenRM(val).then((value) => {
                                    //  this.loadingController.dismiss();
                                    resolve(value);
                                }).catch((errorRefresh) => {
                                    this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                                    }
                                    else {
                                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                }
                else if (error.status == 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_5__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#EC272F');
    }
    ngOnInit() {
        this.localStorageService.getUserData().then(userData => {
            this.userData = userData;
            this.patientService.getPatientIdByDocNumberAndSex(userData.docNumber, userData.sex).subscribe(patientId => {
                this.patientId = patientId;
                //TODO: DateFrom deberia ser opcional en el back
                this.consultationService.getConsultationsByPatientId({
                    patientId,
                    size: 3,
                    dateFrom: "2000-01-01"
                }).subscribe(response => {
                    this.consultations = response;
                }, error => {
                    if (error.message)
                        this.alertService.showErrorAlert(error.message);
                    else
                        this.alertService.showErrorAlert();
                });
                this.patientService.getSpecialtiesByPatientId(patientId).subscribe(response => {
                    this.specialties = response;
                });
            });
        });
    }
    search() {
        if (!this.dateFrom) {
            this.alertService.showCustomAlert({ message: "Debe seleccionar una fecha" });
            return;
        }
        let dateFrom = moment__WEBPACK_IMPORTED_MODULE_12__(this.dateFrom).format("YYYY-MM-DD");
        this.consultationService.getConsultationsByPatientId({
            patientId: this.patientId,
            dateFrom,
            specialtyId: this.specialtyIdSelected
        }).subscribe(response => {
            this.consultations = response;
        });
    }
    deleteDataAndExitToLogin() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storage.clear().then(() => {
                this.navController.navigateRoot("/login");
            });
        });
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loadingController.dismiss();
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loadingController.dismiss();
            const loading = yield this.loadingController.create({
                message: 'Cargando',
            });
            yield loading.present();
        });
    }
    loadingWithMessage(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loadingController.dismiss();
            const loading = yield this.loadingController.create({
                message: messageText,
            });
            yield loading.present();
        });
    }
    goToConsultation(id) {
        let navigationExtras = {
            state: {
                consultationId: id,
            }
        };
        this.router.navigate(['consultation'], navigationExtras);
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
};
ConsultationsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_6__["ScreenOrientation"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_8__["LocalStorageService"] },
    { type: src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_9__["ConsultationService"] },
    { type: src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_10__["PatientService"] },
    { type: src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_11__["AlertService"] }
];
ConsultationsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-consultations',
        template: __webpack_require__(/*! raw-loader!./consultations.page.html */ "./node_modules/raw-loader/index.js!./src/app/RM/consultations/consultations.page.html"),
        styles: [__webpack_require__(/*! ./consultations.page.scss */ "./src/app/RM/consultations/consultations.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_6__["ScreenOrientation"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        src_app_services_local_storage_service__WEBPACK_IMPORTED_MODULE_8__["LocalStorageService"],
        src_app_services_consultation_service__WEBPACK_IMPORTED_MODULE_9__["ConsultationService"],
        src_app_services_patient_service__WEBPACK_IMPORTED_MODULE_10__["PatientService"],
        src_app_services_alert_service__WEBPACK_IMPORTED_MODULE_11__["AlertService"]])
], ConsultationsPage);



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let LoadingService = class LoadingService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    present() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController.create({
                message: '...Cargando',
                duration: 7500,
            }).then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss().then(() => console.log('dismissed'));
        });
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
], LoadingService);



/***/ })

}]);
//# sourceMappingURL=RM-consultations-consultations-module-es2015.js.map