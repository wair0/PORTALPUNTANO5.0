(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["procedures-proceduresHome-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/procedures/proceduresHome.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/procedures/proceduresHome.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n    </ion-buttons>\r\n    <ion-title>MIS TRÁMITES</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n  <ion-button class='btn-procedures' expand='block' [routerLink]=\"['/newProcedure']\" >\r\n    Nuevo trámite\r\n  </ion-button>\r\n  <ion-button class='btn-procedures' expand='block' (click)='getProceduresAct()'>\r\n    Trámites vigentes\r\n  </ion-button>\r\n  <ion-button class='btn-procedures' expand='block' (click)='getProceduresFin()'>\r\n    Trámites realizados\r\n  </ion-button>\r\n</ion-content>\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/procedures/proceduresHome.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/procedures/proceduresHome.module.ts ***!
  \*****************************************************/
/*! exports provided: ProceduresHomeModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProceduresHomeModule", function() { return ProceduresHomeModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _proceduresHome_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./proceduresHome.page */ "./src/app/procedures/proceduresHome.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");









let ProceduresHomeModule = class ProceduresHomeModule {
};
ProceduresHomeModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _proceduresHome_page__WEBPACK_IMPORTED_MODULE_6__["ProceduresHomePage"]
                }
            ])
        ],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__["RefreshUtils"]],
        declarations: [_proceduresHome_page__WEBPACK_IMPORTED_MODULE_6__["ProceduresHomePage"]]
    })
], ProceduresHomeModule);



/***/ }),

/***/ "./src/app/procedures/proceduresHome.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/procedures/proceduresHome.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #FF0067;\n}\n\n.btn-procedures {\n  --background:#FF0067 ;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #FF0067;\n}\n\n.header-text {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #FF0067;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\n.status {\n  font-size: 3em;\n  color: #FF0067;\n}\n\n.show-all {\n  --min-height: 20px;\n  border-radius: 6px;\n  background-color: #e6e6e6;\n  --ion-background-color: #e6e6e6;\n  margin-top: 2%;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvY2VkdXJlcy9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXHByb2NlZHVyZXNcXHByb2NlZHVyZXNIb21lLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcHJvY2VkdXJlcy9wcm9jZWR1cmVzSG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FDQ0o7O0FERUE7RUFDRyxxQkFBQTtBQ0NIOztBRElBO0VBQ0ksZ0NBQUE7QUNESjs7QURJQTtFQUNJLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7QUNESjs7QURJQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQ0RKOztBRElBO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtBQ0RKOztBRElBO0VBQ0kscUJBQUE7QUNESjs7QURLQTtFQUNJLGNBQUE7QUNGSjs7QURLQTtFQUNJLHlCQUFBO0FDRko7O0FES0E7RUFDSSxjQUFBO0VBQ0EsY0FBQTtBQ0ZKOztBREtBO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsK0JBQUE7RUFDQSxjQUFBO0FDRko7O0FES0E7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDRkoiLCJmaWxlIjoic3JjL2FwcC9wcm9jZWR1cmVzL3Byb2NlZHVyZXNIb21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZWQge1xyXG4gICAgY29sb3I6ICNGRjAwNjdcclxufVxyXG5cclxuLmJ0bi1wcm9jZWR1cmVze1xyXG4gICAtLWJhY2tncm91bmQ6I0ZGMDA2N1xyXG59XHJcblxyXG5cclxuXHJcbmlvbi1pdGVtLmJvcmRlci1yZWQge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNGRjAwNjc7XHJcbn1cclxuXHJcbi5oZWFkZXItdGV4dCB7XHJcbiAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzUzNTM1MztcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG59XHJcblxyXG5pb24tbGlzdCB7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogI0ZGMDA2NztcclxuXHJcbn1cclxuXHJcbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcclxuICAgIGNvbG9yOiAjRkZGRkZGO1xyXG59XHJcblxyXG4ud2hpdGUge1xyXG4gICAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnN0YXR1cyB7XHJcbiAgICBmb250LXNpemU6IDMuMGVtO1xyXG4gICAgY29sb3I6ICNGRjAwNjc7XHJcbn1cclxuXHJcbi5zaG93LWFsbCB7XHJcbiAgICAtLW1pbi1oZWlnaHQ6IDIwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcclxuICAgIG1hcmdpbi10b3A6IDIlO1xyXG59XHJcblxyXG5pb24tdGl0bGUge1xyXG4gICAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xyXG4gICAgZm9udC1zaXplOiA1dnc7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn0iLCIucmVkIHtcbiAgY29sb3I6ICNGRjAwNjc7XG59XG5cbi5idG4tcHJvY2VkdXJlcyB7XG4gIC0tYmFja2dyb3VuZDojRkYwMDY3IDtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRkYwMDY3O1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzUzNTM1MztcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcbn1cblxuaW9uLWxpc3Qge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICNGRjAwNjc7XG59XG5cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG59XG5cbi5zdGF0dXMge1xuICBmb250LXNpemU6IDNlbTtcbiAgY29sb3I6ICNGRjAwNjc7XG59XG5cbi5zaG93LWFsbCB7XG4gIC0tbWluLWhlaWdodDogMjBweDtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZTZlNmU2O1xuICBtYXJnaW4tdG9wOiAyJTtcbn1cblxuaW9uLXRpdGxlIHtcbiAgcGFkZGluZy1yaWdodDogNSU7XG4gIHBhZGRpbmctbGVmdDogNSU7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il19 */"

/***/ }),

/***/ "./src/app/procedures/proceduresHome.page.ts":
/*!***************************************************!*\
  !*** ./src/app/procedures/proceduresHome.page.ts ***!
  \***************************************************/
/*! exports provided: ProceduresHomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProceduresHomePage", function() { return ProceduresHomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _services_procedures_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../services/procedures.service */ "./src/app/services/procedures.service.ts");










let ProceduresHomePage = class ProceduresHomePage {
    constructor(alertController, loadingController, http, storage, router, screenOrientation, statusBar, navController, proceduresService) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.router = router;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.navController = navController;
        this.proceduresService = proceduresService;
        this.allProceduresAct = [];
        this.allProceduresFin = [];
        this.processError = function (error) {
            return new Promise((resolve) => {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        this.storage.get('psw').then((val) => {
                            if (val) {
                                this.loading();
                                this.refreshUtils.refreshToken(val).then((value) => {
                                    this.loadingController.dismiss();
                                    resolve(value);
                                }).catch((errorRefresh) => {
                                    this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    this.alert(error.error.message);
                }
                else {
                    this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.storage.get('token').then((val) => {
            if (val) {
                this.token = val;
                this.storage.get('userId').then((val2) => {
                    if (val2) {
                        this.idUser = val2;
                    }
                });
            }
        });
    }
    ionViewWillEnter() {
        this.statusBar.backgroundColorByHexString('#FF0067');
    }
    ngOnInit() {
    }
    deleteDataAndExitToLogin() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storage.clear().then(() => {
                this.navController.navigateRoot("/login");
            });
        });
    }
    alert(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Portal puntano',
                message: messageText,
                buttons: [
                    {
                        text: 'OK',
                        role: 'cancel',
                        cssClass: 'primary',
                        handler: () => {
                            console.log('OK pressed!!');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    loading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Cargando',
            });
            yield loading.present();
        });
    }
    loadingWithMessage(messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: messageText,
            });
            yield loading.present();
        });
    }
    getProceduresAct() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loading();
            const httpOptions = {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-Authorization': 'Bearer ' + this.token,
                }),
                response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }),
                })
            };
            this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].URL_BASE_PORTAL + "secure/procedure/user/" + this.idUser + "?status=ACT&search=&page=0&size=500&sort=dateCreated,desc", httpOptions)
                .subscribe((data) => {
                this.allProceduresAct = data.content;
                this.goToProceduresAct(this.allProceduresAct, "MIS TRÁMITES VIGENTES");
            }, () => {
                this.allProceduresAct = [];
            });
        });
    }
    getProceduresFin() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.router.navigate(['completedProcedures']);
        });
    }
    getProcedureDetail(idProcedure) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loading();
            const httpOptions = {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-Authorization': 'Bearer ' + this.token,
                }),
                response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }),
                })
            };
            this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_6__["constants"].URL_BASE_PORTAL + "secure/procedure/" + idProcedure, httpOptions)
                .subscribe((data) => {
                this.loadingController.dismiss();
                this.makeProcedure(data);
            }, error => {
                this.processError(error).then(() => {
                    this.getProcedureDetail(idProcedure);
                });
            });
        });
    }
    makeProcedure(procedure) {
        let steps = new Map();
        procedure.procedureSteps.forEach(element => {
            steps.set(element.step, element.title);
        });
        let attributes = new Map();
        let files = new Array();
        procedure.procedureTypeAttrs.forEach(element => {
            if (element.step) {
                if (attributes.get(element.step)) {
                    attributes.get(element.step).push(element);
                }
                else {
                    let array = new Array();
                    array.push(element);
                    attributes.set(element.step, array);
                }
            }
            else {
                files.push(element);
            }
        });
        let array = new Array();
        if (files.length > 0) {
            let dataFiles = {
                name: "",
                attributes: files
            };
            array.push(dataFiles);
        }
        attributes.forEach((value, key) => {
            let data = {
                name: steps.get(key),
                attributes: value
            };
            array.push(data);
        });
        if (procedure.comments) {
            let attributeComments = {
                name: "Observaciones",
                dataValue: procedure.comments
            };
            let arrayComments = new Array();
            arrayComments.push(attributeComments);
            let stepComments = {
                name: "COMENTARIOS",
                attributes: arrayComments
            };
            array.push(stepComments);
        }
        console.log(steps);
        console.log(attributes);
        console.log(array);
        this.goToProcedureDetail(procedure, array);
    }
    goToProcedureDetail(procedureItem, steps) {
        this.loadingController.dismiss();
        if (steps.length > 0) {
            let navigationExtras = {
                state: {
                    procedureItem: procedureItem,
                    steps: steps,
                    token: this.token,
                }
            };
            this.router.navigate(['procedureDetail'], navigationExtras);
        }
        else {
            alert("No se encontraron datos");
        }
    }
    goToProceduresAct(procedures, title) {
        this.loadingController.dismiss();
        if (this.allProceduresAct.length > 0) {
            let navigationExtras = {
                state: {
                    procedures: procedures,
                    token: this.token,
                    title: title
                }
            };
            this.router.navigate(['currentProcedures'], navigationExtras);
        }
        else {
            alert("No se encontraron datos");
        }
    }
    goToHome() {
        this.navController.navigateRoot("/home");
    }
};
ProceduresHomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_7__["ScreenOrientation"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_8__["StatusBar"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _services_procedures_service__WEBPACK_IMPORTED_MODULE_9__["ProceduresService"] }
];
ProceduresHomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-proceduresHome',
        template: __webpack_require__(/*! raw-loader!./proceduresHome.page.html */ "./node_modules/raw-loader/index.js!./src/app/procedures/proceduresHome.page.html"),
        styles: [__webpack_require__(/*! ./proceduresHome.page.scss */ "./src/app/procedures/proceduresHome.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_7__["ScreenOrientation"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_8__["StatusBar"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _services_procedures_service__WEBPACK_IMPORTED_MODULE_9__["ProceduresService"]])
], ProceduresHomePage);



/***/ })

}]);
//# sourceMappingURL=procedures-proceduresHome-module-es2015.js.map