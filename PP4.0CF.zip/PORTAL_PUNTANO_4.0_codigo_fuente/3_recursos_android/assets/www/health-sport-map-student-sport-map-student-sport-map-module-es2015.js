(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["health-sport-map-student-sport-map-student-sport-map-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/components/sport-map-details/sport-map-details.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/sport-map-details/sport-map-details.component.html ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-card-header class=\"examHeade\">\r\n  <ion-label><b>FECHA :</b> {{(item.FECHA_RELEVAMIENTO)}}</ion-label>\r\n</ion-card-header>\r\n\r\n<ion-list>\r\n  <ion-item *ngIf=\"item?.description\">\r\n    <p><b>DESCRIPCION: </b> {{item.description}} </p>\r\n  </ion-item>\r\n  <ion-item style=\"font-size: medium;\">\r\n    <div>\r\n      <ion-row>\r\n        <ion-col size=\"8\">\r\n          <p><b>PESO :</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n          {{item.PESO}}\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"8\">\r\n          <p><b>TALLE:</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n          {{item.TALLA}}\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"8\">\r\n          <p><b>TALLE SENTADA:</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n          {{item.TALLA_SENTADA}}\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"8\">\r\n          <p><b>ENVERGADURA:</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n          {{item.ENVERGADURA}}\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"8\">\r\n          <p><b>LONGITUD MANO:</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n          {{item.LONGITUD_MANO}}\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"8\">\r\n          <p><b>LONGITUD PIE:</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n          {{item.LONGITUD_PIE}}\r\n        </ion-col>\r\n      </ion-row>\r\n      <!-- <ion-row>\r\n        <ion-col size=\"8\">\r\n          <p><b>TENSION ARTERIAL:</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n          <p><b>TENSION</b></p>\r\n        </ion-col>\r\n      </ion-row> -->\r\n      <ion-row>\r\n        <ion-col size=\"8\">\r\n          <p><b>TENSION SISTOLICA:</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n          {{item.TENSION_ARTERIAL_SISTOLICA_PC}}\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"8\">\r\n          <p><b>TENSION DIASTOLICA:</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n          {{item.TENSION_ARTERIAL_DIASTOLICA_PC}}\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <p><b>USA ANTEOJOS:</b></p>\r\n        </ion-col>\r\n        <ion-col>\r\n          <p><b>{{item.USA_ANTEOJOS}}</b></p>\r\n        </ion-col>\r\n      </ion-row>\r\n      <!-- SIN LENTE -->\r\n      <div *ngIf=\"item.USA_ANTEOJOS == 'NO'\">\r\n        <ion-row>\r\n          <ion-col size=\"8\">\r\n            <p><b>EXAMEN OJO DERECHO:</b></p>\r\n          </ion-col>\r\n          <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n            {{item.EVALUACION_VISUAL_OJO_DERECHO}}\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col size=\"8\">\r\n            <p><b>EXAMEN OJO IZQUIERDO:</b></p>\r\n          </ion-col>\r\n          <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n            {{item.EVALUACION_VISUAL_OJO_IZQUIERDO}}\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n      <!-- CON LENTE -->\r\n      <div *ngIf=\"item.USA_ANTEOJOS == 'SI'\">\r\n        <ion-row>\r\n          <ion-col size=\"8\">\r\n            <p><b>EXAMEN LENTE OJO DERECHO:</b></p>\r\n          </ion-col>\r\n          <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n            {{item.EVALUACION_VISUAL_OJO_DERECHO_ANTEOJOS}}\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col size=\"8\">\r\n            <p><b>EXAMEN LENTE OJO IZQUIERDO:</b></p>\r\n          </ion-col>\r\n          <ion-col size=\"4\" style=\"padding-top: 18px;\">\r\n            {{item.EVALUACION_VISUAL_OJO_IZQUIERDO_ANTEOJOS}}\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n    </div>\r\n  </ion-item>\r\n</ion-list>\r\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/health/sport-map/student-sport-map/student-sport-map.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/health/sport-map/student-sport-map/student-sport-map.component.html ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" class=\"white\" text=\"Atrás\" default-href=\"home\">\r\n      </ion-back-button>\r\n      <!-- <ion-button class=\"white\" text=\"Atrás\" (click)=\"goToHome()\">Atrás</ion-button> -->\r\n    </ion-buttons>\r\n    <!-- <ion-thumbnail slot=\"start\"> -->\r\n    <!-- <ion-img [src]=\"../../assets/ppHeader.png\"></ion-img> -->\r\n    <!-- </ion-thumbnail> -->\r\n    <div style=\"padding-left: 5%; margin:0%\">\r\n      <h1 style=\"color: #AB1E7E; text-align: center;\">Portal <b>Puntano</b></h1>\r\n    </div>\r\n    <ion-buttons slot=\"primary\">\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n  <ion-list class=\"headerTitle\">\r\n    <ion-list-header>\r\n      <h2 class=\"header-text-2\"><b>MAPA DEPORTIVO</b></h2>\r\n    </ion-list-header>\r\n  </ion-list>\r\n  <ion-grid>\r\n    <ion-card style=\"padding: 5px;\">\r\n        <!-- TODO error al compilar con '--prod'-->\r\n        <!-- <ion-row (click)=\"goToSportMapOfPerson(item)\"> -->\r\n        <ion-row>\r\n        <ion-col size=\"3\" size-lg class=\"iconCol\">\r\n          <ion-card-content>\r\n            <ion-button class=\"\" style=\"color: #ffff;\">\r\n              <ion-icon ios=\"person\" md=\"person\"></ion-icon>\r\n              <!-- <ion-icon  ios=\"woman-sharp\" md=\"woman-sharp\" ></ion-icon> -->\r\n            </ion-button>\r\n          </ion-card-content>\r\n        </ion-col>\r\n        <ion-col size=\"9\" size-lg>\r\n          <ion-card-content *ngIf=\"student\">\r\n            <b>Nombre alumno : </b> {{student.firstName + ' ' + student.lastName}}\r\n            <br>\r\n            <b>DNI :</b> {{student.docNumber}}\r\n            <br>\r\n            <b *ngIf=\"student.age\"> {{student.age}} </b> \r\n            <br>\r\n            <span *ngIf=\"student.educationalCenterName\"> <b> Esc : </b> {{student.educationalCenterName}} </span>\r\n            <br>\r\n            <!-- <div *ngIf=\"item.concurrenceStatus\">\r\n              <ion-badge [ngStyle]=\"{'background' : item.concurrenceColor}\">{{item.concurrenceStatus}}</ion-badge> \r\n              <p class=\"stuff\">{{item.subjectName}}</p> \r\n            </div>             -->\r\n          </ion-card-content>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-card>\r\n  </ion-grid>\r\n  <!-- <mat-accordion>\r\n    <mat-expansion-panel class=\"accordion\">\r\n      <mat-expansion-panel-header class=\"accordionHeader\">\r\n        <mat-panel-title>\r\n          <b class=\"accordionTitle\" style=\"color: #ffff;\">AÑO</b>\r\n        </mat-panel-title>\r\n      </mat-expansion-panel-header>\r\n      <ion-item class=\"warningMessage\" *ngIf=\"!schoolCycle && !matriculations\">\r\n          <ion-label>Debe seleccionar un Ciclo Lectivo</ion-label>\r\n        </ion-item>\r\n      <div>\r\n        <app-sport-map-details></app-sport-map-details>\r\n      </div>\r\n    </mat-expansion-panel>\r\n  </mat-accordion> -->\r\n\r\n  <ion-item class=\"warningMessage\" *ngIf=\"sportMaps?.RESULTADO === 'SIN_DATOS'\">\r\n            <ion-label class=\"warningMessage\">No se encontro Informacion del mapa Deportivo de la persona.</ion-label>\r\n  </ion-item>\r\n\r\n  <div style=\"margin-top: 5px;\"  *ngFor=\"let sportMap of sportMaps?.CUESTIONARIOS\">\r\n    <mat-accordion>\r\n      <mat-expansion-panel class=\"accordion\">\r\n        <mat-expansion-panel-header class=\"accordionHeader\">\r\n          <mat-panel-title>\r\n            <b class=\"accordionTitle\" style=\"color: #ffff;\">{{sportMap.ANIO_RELEVAMIENTO}}</b>\r\n          </mat-panel-title>\r\n        </mat-expansion-panel-header>\r\n         <!-- <ion-item class=\"warningMessage\" *ngIf=\"!schoolCycle && !matriculations\">\r\n            <ion-label>Debe seleccionar un Ciclo Lectivo</ion-label>\r\n          </ion-item> -->\r\n        <div>\r\n          <app-sport-map-details [sportMap]=\"sportMap\" [description]=\"sportMaps?.DESCRIPCION\"></app-sport-map-details>\r\n        </div>\r\n      </mat-expansion-panel>\r\n    </mat-accordion>\r\n  </div>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/components/sport-map-details/sport-map-details.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/components/sport-map-details/sport-map-details.component.scss ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".examHeade {\n  text-align: center;\n}\n\n.mat-expansion-panel-body {\n  padding: 0 0px 0px !important;\n}\n\n.mat-expansion-panel-content {\n  padding: 0 0px 0px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9zcG9ydC1tYXAtZGV0YWlscy9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXGNvbXBvbmVudHNcXHNwb3J0LW1hcC1kZXRhaWxzXFxzcG9ydC1tYXAtZGV0YWlscy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvY29tcG9uZW50cy9zcG9ydC1tYXAtZGV0YWlscy9zcG9ydC1tYXAtZGV0YWlscy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSw2QkFBQTtBQ0NKOztBREVBO0VBQ0ksNkJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc3BvcnQtbWFwLWRldGFpbHMvc3BvcnQtbWFwLWRldGFpbHMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXhhbUhlYWRle1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4ubWF0LWV4cGFuc2lvbi1wYW5lbC1ib2R5IHtcclxuICAgIHBhZGRpbmc6IDAgMHB4IDBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubWF0LWV4cGFuc2lvbi1wYW5lbC1jb250ZW50e1xyXG4gICAgcGFkZGluZzogMCAwcHggMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuIiwiLmV4YW1IZWFkZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLm1hdC1leHBhbnNpb24tcGFuZWwtYm9keSB7XG4gIHBhZGRpbmc6IDAgMHB4IDBweCAhaW1wb3J0YW50O1xufVxuXG4ubWF0LWV4cGFuc2lvbi1wYW5lbC1jb250ZW50IHtcbiAgcGFkZGluZzogMCAwcHggMHB4ICFpbXBvcnRhbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/components/sport-map-details/sport-map-details.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/components/sport-map-details/sport-map-details.component.ts ***!
  \*****************************************************************************/
/*! exports provided: SportMapDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SportMapDetailsComponent", function() { return SportMapDetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let SportMapDetailsComponent = class SportMapDetailsComponent {
    constructor() { }
    ngOnInit() {
        this.item = this.sportMap;
        this.item.description = this.description;
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], SportMapDetailsComponent.prototype, "sportMap", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], SportMapDetailsComponent.prototype, "description", void 0);
SportMapDetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-sport-map-details',
        template: __webpack_require__(/*! raw-loader!./sport-map-details.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/sport-map-details/sport-map-details.component.html"),
        styles: [__webpack_require__(/*! ./sport-map-details.component.scss */ "./src/app/components/sport-map-details/sport-map-details.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], SportMapDetailsComponent);



/***/ }),

/***/ "./src/app/health/sport-map/student-sport-map/student-sport-map-routing.module.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/health/sport-map/student-sport-map/student-sport-map-routing.module.ts ***!
  \****************************************************************************************/
/*! exports provided: StudentSportMapRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudentSportMapRoutingModule", function() { return StudentSportMapRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _student_sport_map_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./student-sport-map.component */ "./src/app/health/sport-map/student-sport-map/student-sport-map.component.ts");




const routes = [
    {
        path: '',
        component: _student_sport_map_component__WEBPACK_IMPORTED_MODULE_3__["StudentSportMapComponent"]
    }
];
let StudentSportMapRoutingModule = class StudentSportMapRoutingModule {
};
StudentSportMapRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], StudentSportMapRoutingModule);



/***/ }),

/***/ "./src/app/health/sport-map/student-sport-map/student-sport-map.component.scss":
/*!*************************************************************************************!*\
  !*** ./src/app/health/sport-map/student-sport-map/student-sport-map.component.scss ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".example-headers-align .mat-expansion-panel-header-title,\n.example-headers-align .mat-expansion-panel-header-description {\n  flex-basis: 0;\n}\n\n.example-headers-align .mat-expansion-panel-header-description {\n  justify-content: space-between;\n  align-items: center;\n}\n\n.example-headers-align .mat-form-field + .mat-form-field {\n  margin-left: 8px;\n}\n\n@media (hover: none) {\n  .mat-expansion-panel:not(.mat-expanded):not([aria-disabled=true]) .mat-expansion-panel-header:hover {\n    background: #1A4377;\n  }\n}\n\n.mat-expansion-panel-header.mat-expanded:focus, .mat-expansion-panel-header.mat-expanded:hover {\n  background: #1A4377;\n}\n\n.accordionHeader {\n  background-color: #1A4377;\n}\n\n.warningMessage {\n  color: #FF0000;\n  white-space: normal;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhbHRoL3Nwb3J0LW1hcC9zdHVkZW50LXNwb3J0LW1hcC9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXGhlYWx0aFxcc3BvcnQtbWFwXFxzdHVkZW50LXNwb3J0LW1hcFxcc3R1ZGVudC1zcG9ydC1tYXAuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2hlYWx0aC9zcG9ydC1tYXAvc3R1ZGVudC1zcG9ydC1tYXAvc3R1ZGVudC1zcG9ydC1tYXAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7O0VBRUUsYUFBQTtBQ0FGOztBREdBO0VBQ0UsOEJBQUE7RUFDQSxtQkFBQTtBQ0FGOztBREdBO0VBQ0UsZ0JBQUE7QUNBRjs7QURHQTtFQUNJO0lBQ0ksbUJBQUE7RUNBTjtBQUNGOztBREVBO0VBQ0ksbUJBQUE7QUNBSjs7QURHQTtFQUNJLHlCQUFBO0FDQUo7O0FER0E7RUFDSSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvaGVhbHRoL3Nwb3J0LW1hcC9zdHVkZW50LXNwb3J0LW1hcC9zdHVkZW50LXNwb3J0LW1hcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uZXhhbXBsZS1oZWFkZXJzLWFsaWduIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci10aXRsZSxcclxuLmV4YW1wbGUtaGVhZGVycy1hbGlnbiAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXItZGVzY3JpcHRpb24ge1xyXG4gIGZsZXgtYmFzaXM6IDA7XHJcbn1cclxuXHJcbi5leGFtcGxlLWhlYWRlcnMtYWxpZ24gLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLWRlc2NyaXB0aW9uIHtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmV4YW1wbGUtaGVhZGVycy1hbGlnbiAubWF0LWZvcm0tZmllbGQgKyAubWF0LWZvcm0tZmllbGQge1xyXG4gIG1hcmdpbi1sZWZ0OiA4cHg7XHJcbn1cclxuXHJcbkBtZWRpYSAoaG92ZXI6IG5vbmUpe1xyXG4gICAgLm1hdC1leHBhbnNpb24tcGFuZWw6bm90KC5tYXQtZXhwYW5kZWQpOm5vdChbYXJpYS1kaXNhYmxlZD10cnVlXSkgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjMUE0Mzc3OztcclxuICAgIH1cclxufVxyXG4ubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXIubWF0LWV4cGFuZGVkOmZvY3VzLCAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXIubWF0LWV4cGFuZGVkOmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQ6ICMxQTQzNzc7O1xyXG59XHJcblxyXG4uYWNjb3JkaW9uSGVhZGVye1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzFBNDM3NztcclxufVxyXG5cclxuLndhcm5pbmdNZXNzYWdle1xyXG4gICAgY29sb3I6I0ZGMDAwMDtcclxuICAgIHdoaXRlLXNwYWNlOiBub3JtYWw7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuIiwiLmV4YW1wbGUtaGVhZGVycy1hbGlnbiAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXItdGl0bGUsXG4uZXhhbXBsZS1oZWFkZXJzLWFsaWduIC5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci1kZXNjcmlwdGlvbiB7XG4gIGZsZXgtYmFzaXM6IDA7XG59XG5cbi5leGFtcGxlLWhlYWRlcnMtYWxpZ24gLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLWRlc2NyaXB0aW9uIHtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uZXhhbXBsZS1oZWFkZXJzLWFsaWduIC5tYXQtZm9ybS1maWVsZCArIC5tYXQtZm9ybS1maWVsZCB7XG4gIG1hcmdpbi1sZWZ0OiA4cHg7XG59XG5cbkBtZWRpYSAoaG92ZXI6IG5vbmUpIHtcbiAgLm1hdC1leHBhbnNpb24tcGFuZWw6bm90KC5tYXQtZXhwYW5kZWQpOm5vdChbYXJpYS1kaXNhYmxlZD10cnVlXSkgLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjMUE0Mzc3O1xuICB9XG59XG4ubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXIubWF0LWV4cGFuZGVkOmZvY3VzLCAubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXIubWF0LWV4cGFuZGVkOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogIzFBNDM3Nztcbn1cblxuLmFjY29yZGlvbkhlYWRlciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMxQTQzNzc7XG59XG5cbi53YXJuaW5nTWVzc2FnZSB7XG4gIGNvbG9yOiAjRkYwMDAwO1xuICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il19 */"

/***/ }),

/***/ "./src/app/health/sport-map/student-sport-map/student-sport-map.component.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/health/sport-map/student-sport-map/student-sport-map.component.ts ***!
  \***********************************************************************************/
/*! exports provided: StudentSportMapComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudentSportMapComponent", function() { return StudentSportMapComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_student_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/student.service */ "./src/app/services/student.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/loading.service */ "./src/app/services/loading.service.ts");








let StudentSportMapComponent = class StudentSportMapComponent {
    constructor(route, router, navController, studentService, storage, loading) {
        this.route = route;
        this.router = router;
        this.navController = navController;
        this.studentService = studentService;
        this.storage = storage;
        this.loading = loading;
        this.step = 0;
        this.description = '';
    }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.student = this.router.getCurrentNavigation().extras.state.content;
                if (!this.student) {
                    this.navController.navigateRoot("/health");
                }
                else {
                    // this.getSportMap();
                    this.sportMaps = this.student.map;
                }
            }
            else {
                this.navController.navigateRoot("/health");
            }
        });
    }
    // schoolCycleChange(){
    //   if(this.schoolCycle){
    //     this.getToken().then(value => {    
    //       this.studentService.getRegistrationByStudent(this.student.studentId, this.schoolCycle.id, this.httpOptions).subscribe((response:any) =>{
    //         this.matriculations = response;
    //       },error =>{
    //         if (error.status === 409) {
    //           this.alert(error.error.message);
    //         }
    //         else{
    //           this.alert(constants.GENERIC_ERROR);
    //         }  
    //       })
    //     })       
    //   };
    // }
    getToken() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.storage.get('token').then(value => {
                let httpOptions = {
                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Authorization': 'Bearer ' + value,
                    }),
                    response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpResponse"]({
                        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        }),
                    })
                };
                this.httpOptions = httpOptions;
            });
        });
    }
    getSportMap() {
        this.loading.present();
        this.getToken().then(value => {
            this.studentService.getSportMap(this.student.docNumber, this.student.sex, this.httpOptions).subscribe((response) => {
                if (response) {
                    this.sportMaps = response;
                    this.loading.dismiss();
                }
            });
        });
    }
    setStep(index) {
        this.step = index;
    }
};
StudentSportMapComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: src_app_services_student_service__WEBPACK_IMPORTED_MODULE_5__["StudentService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"] }
];
StudentSportMapComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-student-sport-map',
        template: __webpack_require__(/*! raw-loader!./student-sport-map.component.html */ "./node_modules/raw-loader/index.js!./src/app/health/sport-map/student-sport-map/student-sport-map.component.html"),
        styles: [__webpack_require__(/*! ./student-sport-map.component.scss */ "./src/app/health/sport-map/student-sport-map/student-sport-map.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
        src_app_services_student_service__WEBPACK_IMPORTED_MODULE_5__["StudentService"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"],
        src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"]])
], StudentSportMapComponent);



/***/ }),

/***/ "./src/app/health/sport-map/student-sport-map/student-sport-map.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/health/sport-map/student-sport-map/student-sport-map.module.ts ***!
  \********************************************************************************/
/*! exports provided: StudentSportMapModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StudentSportMapModule", function() { return StudentSportMapModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _student_sport_map_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./student-sport-map.component */ "./src/app/health/sport-map/student-sport-map/student-sport-map.component.ts");
/* harmony import */ var _student_sport_map_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./student-sport-map-routing.module */ "./src/app/health/sport-map/student-sport-map/student-sport-map-routing.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/esm2015/expansion.js");
/* harmony import */ var src_app_components_sport_map_details_sport_map_details_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/sport-map-details/sport-map-details.component */ "./src/app/components/sport-map-details/sport-map-details.component.ts");
/* harmony import */ var src_app_services_student_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/student.service */ "./src/app/services/student.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/loading.service */ "./src/app/services/loading.service.ts");












let StudentSportMapModule = class StudentSportMapModule {
};
StudentSportMapModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _student_sport_map_component__WEBPACK_IMPORTED_MODULE_3__["StudentSportMapComponent"],
            src_app_components_sport_map_details_sport_map_details_component__WEBPACK_IMPORTED_MODULE_8__["SportMapDetailsComponent"]
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _student_sport_map_routing_module__WEBPACK_IMPORTED_MODULE_4__["StudentSportMapRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__["MatExpansionModule"],
        ],
        providers: [
            src_app_services_student_service__WEBPACK_IMPORTED_MODULE_9__["StudentService"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClient"],
            src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_11__["LoadingService"],
        ]
    })
], StudentSportMapModule);



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let LoadingService = class LoadingService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    present() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController.create({
                message: '...Cargando',
                duration: 7500,
            }).then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss().then(() => console.log('dismissed'));
        });
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
], LoadingService);



/***/ })

}]);
//# sourceMappingURL=health-sport-map-student-sport-map-student-sport-map-module-es2015.js.map