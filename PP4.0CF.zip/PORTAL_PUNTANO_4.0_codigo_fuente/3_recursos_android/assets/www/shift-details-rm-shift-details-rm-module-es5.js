(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shift-details-rm-shift-details-rm-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/shift-details-rm/shift-details-rm.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shift-details-rm/shift-details-rm.page.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>MIS TURNOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-list-header>\r\n      <h4 *ngIf=\"content\" class=\"header-text-2\"><b>MIS TURNOS {{content.type}}</b></h4>\r\n      <ion-item class=\"show-all\" lines=\"none\" (click)=\"goNewShift()\">\r\n        <ion-icon color=\"green\" ios=\"calendar\" md=\"calendar\" style=\"width: 5rem;\"></ion-icon>          \r\n      </ion-item>\r\n    </ion-list-header>\r\n\r\n    \r\n\r\n    <ion-item>\r\n      <form class=\"formAppointment\" [formGroup]=\"formAppointment\">\r\n        <h1 style=\"text-align: center; margin-left: 5%; margin-right: 5%; white-space: pre-line\"><b>Filtros de Búsqueda</b></h1>\r\n        <ion-item>\r\n          <ion-select class=\"selectPerHasDep\" formControlName=\"personsCtrl\" style=\"margin-top: 1rem;\"\r\n            placeholder=\"Persona\">\r\n            <ion-select-option *ngFor=\"let item of dependents\" [value]=\"item\">\r\n              {{item.fullAliasName? item.fullAliasName: item.fullName}}\r\n            </ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-select class=\"selectPerHasDep\" formControlName=\"yearCtrl\" style=\"margin-top: 1rem;\"\r\n            placeholder=\"Seleccione un Año\">\r\n            <ion-select-option *ngFor=\"let item of years\" [value]=\"item\">{{item}}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-button color=\"green\"  class=\"btnSearch\" (click)=\"search()\">\r\n            <ion-icon ios=\"search\" md=\"search\"></ion-icon>\r\n          </ion-button>\r\n        </ion-item>\r\n      </form>\r\n    </ion-item>\r\n\r\n    <div class=\"divShift\" *ngIf=\"historic.length < 1 && content\">\r\n      <ion-item class=\"border-red\" *ngFor=\"let liquidation of content.appointmentItemDtoList; let i = index\">\r\n        <ion-list style=\"display: contents\">\r\n          <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n            <ion-label class=\"ion-text-wrap\">\r\n              <ion-text class=\"red\" >\r\n                <div *ngFor=\"let file of liquidation.items\">\r\n                  <h2 *ngIf=\"file.value && file.name != 'id'\" style=\"display: block;\"> <b>{{file.name}}: </b>{{file.value}}</h2>\r\n                </div>\r\n              </ion-text>\r\n            </ion-label>\r\n\r\n          </ion-item>          \r\n          <ion-button *ngIf=\"liquidation.items[5].value === 'Turno asignado'\" class=\"material-icons closeBtn\" (click)=\"cancelShift(liquidation)\">\r\n            <ion-icon ios=\"close\" md=\"close\"></ion-icon>\r\n          </ion-button>                  \r\n        </ion-list>\r\n      </ion-item>\r\n    </div> \r\n    <div class=\"divShift\" *ngIf=\"historic.length > 0\">\r\n      <div *ngFor=\"let item of historic\">\r\n        <ion-item class=\"border-red\" *ngFor=\"let liquidation of item.appointmentItemDtoList; let i = index\">\r\n          <ion-list style=\"display: contents\">\r\n            <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n              <ion-label class=\"ion-text-wrap\">\r\n                <ion-text class=\"red\">\r\n                  <div *ngFor=\"let file of liquidation.items\">\r\n                    <h2 *ngIf=\"file.value && file.name != 'id'\" style=\"display: block;\"> <b>{{file.name}}: </b>{{file.value}}</h2>\r\n                  </div>\r\n                </ion-text>\r\n              </ion-label>\r\n\r\n            </ion-item>\r\n            <ion-button *ngIf=\"liquidation.items[5].value === 'Turno asignado'\" class=\"material-icons closeBtn\" (click)=\"cancelShift(liquidation)\">\r\n              <ion-icon ios=\"close\" md=\"close\"></ion-icon>\r\n            </ion-button>\r\n          </ion-list>\r\n        </ion-item>\r\n      </div>\r\n    </div>\r\n\r\n    <div *ngIf=\"emptyShift\">\r\n      <ion-item class=\"resultItem tapShift\" >\r\n        <div class=\"resultItemService\">\r\n          <h3> <ion-label class=\"laberlService labelDanger \">No se encontraron Turnos para esta Busqueda</ion-label> </h3>\r\n        </div>\r\n      </ion-item> \r\n    </div>\r\n\r\n  </ion-list>\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-buttons>\r\n      <ion-button (click)=\"goToHome()\">\r\n        <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/shift-details-rm/shift-details-rm-routing.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/shift-details-rm/shift-details-rm-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: ShiftDetailsRMPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftDetailsRMPageRoutingModule", function() { return ShiftDetailsRMPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shift_details_rm_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shift-details-rm.page */ "./src/app/shift-details-rm/shift-details-rm.page.ts");




var routes = [
    {
        path: '',
        component: _shift_details_rm_page__WEBPACK_IMPORTED_MODULE_3__["ShiftDetailsRMPage"]
    }
];
var ShiftDetailsRMPageRoutingModule = /** @class */ (function () {
    function ShiftDetailsRMPageRoutingModule() {
    }
    ShiftDetailsRMPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], ShiftDetailsRMPageRoutingModule);
    return ShiftDetailsRMPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/shift-details-rm/shift-details-rm.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/shift-details-rm/shift-details-rm.module.ts ***!
  \*************************************************************/
/*! exports provided: ShiftDetailsRMPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftDetailsRMPageModule", function() { return ShiftDetailsRMPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _shift_details_rm_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./shift-details-rm-routing.module */ "./src/app/shift-details-rm/shift-details-rm-routing.module.ts");
/* harmony import */ var _shift_details_rm_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./shift-details-rm.page */ "./src/app/shift-details-rm/shift-details-rm.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _services_shift_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../services/shift.service */ "./src/app/services/shift.service.ts");











var ShiftDetailsRMPageModule = /** @class */ (function () {
    function ShiftDetailsRMPageModule() {
    }
    ShiftDetailsRMPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
                _shift_details_rm_routing_module__WEBPACK_IMPORTED_MODULE_5__["ShiftDetailsRMPageRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_material_dialog__WEBPACK_IMPORTED_MODULE_9__["MatDialogModule"]
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
                _services_shift_service__WEBPACK_IMPORTED_MODULE_10__["ShiftService"],
                _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_8__["RefreshUtils"]],
            declarations: [_shift_details_rm_page__WEBPACK_IMPORTED_MODULE_6__["ShiftDetailsRMPage"]]
        })
    ], ShiftDetailsRMPageModule);
    return ShiftDetailsRMPageModule;
}());



/***/ }),

/***/ "./src/app/shift-details-rm/shift-details-rm.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/shift-details-rm/shift-details-rm.page.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #20B572;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #20B572;\n}\n\n.header-text {\n  margin-right: 5%;\n  padding-left: 20px;\n  width: 100%;\n  padding-bottom: 10px;\n  padding-top: 10px;\n  background-color: #20B572;\n  color: #FFFFFF;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #20B572;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n\n.header-text-2 {\n  border-bottom: 2px solid #535353;\n  margin-right: 5%;\n  width: 100%;\n  padding-bottom: 10px;\n  margin-bottom: 0px;\n}\n\n.closeBtn {\n  cursor: pointer;\n  filter: none !important;\n  -webkit-filter: none !important;\n  --background: transparent;\n  --box-shadow: none;\n  --border-radius: 10rem !important;\n  padding: 0 !important;\n  --background: #20B572;\n  margin-bottom: auto;\n  font-size: 15px;\n}\n\n.show-all {\n  border-radius: 6px;\n  background-color: #e6e6e6;\n  --ion-background-color: #e6e6e6;\n  margin-top: 1rem;\n}\n\n.swal-wide {\n  width: 350px !important;\n}\n\n.selectPerHasDep {\n  margin-top: 10%;\n  margin-bottom: 10%;\n  min-width: 100%;\n}\n\n.formAppointment {\n  min-width: 100%;\n}\n\n.btnSearch {\n  color: black;\n  border: none !important;\n  width: 85%;\n  margin: auto;\n  height: 70%;\n  --background: #20b572;\n  color: white;\n  --border-radius: 10rem !important;\n}\n\n@media (any-hover: hover) {\n  button.button-native:host(:hover) .button-native {\n    background: #20b572 !important;\n  }\n}\n\n.labelDanger {\n  color: #C83333;\n  font-style: italic;\n  text-align: center;\n}\n\n.laberlService {\n  white-space: normal;\n}\n\n.divShift {\n  margin-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hpZnQtZGV0YWlscy1ybS9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXHNoaWZ0LWRldGFpbHMtcm1cXHNoaWZ0LWRldGFpbHMtcm0ucGFnZS5zY3NzIiwic3JjL2FwcC9zaGlmdC1kZXRhaWxzLXJtL3NoaWZ0LWRldGFpbHMtcm0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBRElFO0VBQ0UsZ0NBQUE7QUNESjs7QURJRTtFQUVFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLDhCQUFBO0FDRko7O0FES0U7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUNGSjs7QURLRTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7QUNGSjs7QURLRTtFQUNFLHFCQUFBO0FDRko7O0FES0U7RUFDRSxjQUFBO0FDRko7O0FES0U7RUFDRSx5QkFBQTtBQ0ZKOztBREtFO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FDRko7O0FETUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQ0hKOztBRE1FO0VBQ0UsMkJBQUE7RUFDQSxpQ0FBQTtBQ0hKOztBRE1FO0VBQ0UsMkJBQUE7QUNISjs7QURNRTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNISjs7QURNRTtFQUNFLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtBQ0hKOztBRE1FO0VBQ0UsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsK0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUNBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0FDSEo7O0FETUU7RUFFRSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsK0JBQUE7RUFDQSxnQkFBQTtBQ0pKOztBRE1FO0VBQ0UsdUJBQUE7QUNISjs7QURLRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNGSjs7QURJRTtFQUNFLGVBQUE7QUNESjs7QURHRTtFQUVFLFlBQUE7RUFDQSx1QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGlDQUFBO0FDREo7O0FER0U7RUFDRTtJQUNFLDhCQUFBO0VDQUo7QUFDRjs7QURJRTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDRko7O0FES0U7RUFDRSxtQkFBQTtBQ0ZKOztBRElFO0VBQ0UsbUJBQUE7QUNESiIsImZpbGUiOiJzcmMvYXBwL3NoaWZ0LWRldGFpbHMtcm0vc2hpZnQtZGV0YWlscy1ybS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVke1xyXG4gICAgY29sb3I6ICMyMEI1NzJcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgXHJcbiAgaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XHJcbiAgICBib3JkZXItYm90dG9tOjFweCBzb2xpZCAjMjBCNTcyO1xyXG4gIH1cclxuICBcclxuICAuaGVhZGVyLXRleHR7XHJcbiAgICAvLyBib3JkZXItYm90dG9tOjJweCBzb2xpZCAjNTM1MzUzO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICAgIHBhZGRpbmctbGVmdDogMjBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgICBwYWRkaW5nLXRvcDogMTBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMyMEI1NzI7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHggIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLWl0ZW17XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIH1cclxuICBcclxuICBpb24tbGlzdHtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tYm90dG9tOjBweDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLWhlYWRlciBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogIzIwQjU3MjtcclxuICBcclxuICB9XHJcbiAgaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGV7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxuICB9XHJcbiAgXHJcbiAgLndoaXRle1xyXG4gICAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLWxhYmVse1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gIH1cclxuICBcclxuICBcclxuICBpb24tY29udGVudCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIH1cclxuICBcclxuICAuc2MtaW9uLWNhcmQtbWQtaCB7XHJcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAtd2Via2l0LWJveC1zaGFkb3c6XCJcIiAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBcclxuICBpb24tY2FyZHtcclxuICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLXRpdGxle1xyXG4gICAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xyXG4gICAgZm9udC1zaXplOiA1dnc7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfVxyXG4gIFxyXG4gIC5oZWFkZXItdGV4dC0ye1xyXG4gICAgYm9yZGVyLWJvdHRvbToycHggc29saWQgIzUzNTM1MztcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIH1cclxuXHJcbiAgLmNsb3NlQnRuIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGZpbHRlcjogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgLXdlYmtpdC1maWx0ZXI6IG5vbmUgIWltcG9ydGFudDtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAtLWJvcmRlci1yYWRpdXM6IDEwcmVtICFpbXBvcnRhbnQ7XHJcbiAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XHJcbiAgICAtLWJhY2tncm91bmQ6ICMyMEI1NzI7XHJcbiAgICBtYXJnaW4tYm90dG9tOiBhdXRvO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gIH1cclxuXHJcbiAgLnNob3ctYWxsIHtcclxuICAgIC8vLS1taW4taGVpZ2h0OiAyMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNlNmU2ZTY7XHJcbiAgICBtYXJnaW4tdG9wOiAxcmVtO1xyXG4gIH1cclxuICAuc3dhbC13aWRle1xyXG4gICAgd2lkdGg6MzUwcHggIWltcG9ydGFudDtcclxuICB9XHJcbiAgLnNlbGVjdFBlckhhc0RlcHtcclxuICAgIG1hcmdpbi10b3A6IDEwJTtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwJTtcclxuICAgIG1pbi13aWR0aDogMTAwJTtcclxuICB9XHJcbiAgLmZvcm1BcHBvaW50bWVudHtcclxuICAgIG1pbi13aWR0aDogMTAwJTtcclxuICB9XHJcbiAgLmJ0blNlYXJjaHtcclxuICBcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGJvcmRlcjogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgd2lkdGg6IDg1JTtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIGhlaWdodDogNzAlO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMjBiNTcyO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiAxMHJlbSAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBAbWVkaWEgKGFueS1ob3ZlcjogaG92ZXIpe1xyXG4gICAgYnV0dG9uLmJ1dHRvbi1uYXRpdmU6aG9zdCg6aG92ZXIpIC5idXR0b24tbmF0aXZlIHtcclxuICAgICAgYmFja2dyb3VuZDogIzIwYjU3MiAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gIH1cclxuICBcclxuXHJcbiAgLmxhYmVsRGFuZ2Vye1xyXG4gICAgY29sb3I6ICNDODMzMzM7XHJcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfVxyXG5cclxuICAubGFiZXJsU2VydmljZXtcclxuICAgIHdoaXRlLXNwYWNlOiBub3JtYWw7XHJcbiAgfSAgXHJcbiAgLmRpdlNoaWZ0e1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxuICB9XHJcbiIsIi5yZWQge1xuICBjb2xvcjogIzIwQjU3Mjtcbn1cblxuaW9uLWl0ZW0uYm9yZGVyLXJlZCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMjBCNTcyO1xufVxuXG4uaGVhZGVyLXRleHQge1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICMyMEI1NzI7XG4gIGNvbG9yOiAjRkZGRkZGO1xuICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xufVxuXG5pb24tbGlzdCB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzIwQjU3Mjtcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI0ZGRkZGRjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5zYy1pb24tY2FyZC1tZC1oIHtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAtd2Via2l0LWJveC1zaGFkb3c6IFwiXCIgIWltcG9ydGFudDtcbn1cblxuaW9uLWNhcmQge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10aXRsZSB7XG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xuICBwYWRkaW5nLWxlZnQ6IDUlO1xuICBmb250LXNpemU6IDV2dztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uaGVhZGVyLXRleHQtMiB7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjNTM1MzUzO1xuICBtYXJnaW4tcmlnaHQ6IDUlO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuLmNsb3NlQnRuIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBmaWx0ZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgLXdlYmtpdC1maWx0ZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1ib3gtc2hhZG93OiBub25lO1xuICAtLWJvcmRlci1yYWRpdXM6IDEwcmVtICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiAjMjBCNTcyO1xuICBtYXJnaW4tYm90dG9tOiBhdXRvO1xuICBmb250LXNpemU6IDE1cHg7XG59XG5cbi5zaG93LWFsbCB7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcbiAgbWFyZ2luLXRvcDogMXJlbTtcbn1cblxuLnN3YWwtd2lkZSB7XG4gIHdpZHRoOiAzNTBweCAhaW1wb3J0YW50O1xufVxuXG4uc2VsZWN0UGVySGFzRGVwIHtcbiAgbWFyZ2luLXRvcDogMTAlO1xuICBtYXJnaW4tYm90dG9tOiAxMCU7XG4gIG1pbi13aWR0aDogMTAwJTtcbn1cblxuLmZvcm1BcHBvaW50bWVudCB7XG4gIG1pbi13aWR0aDogMTAwJTtcbn1cblxuLmJ0blNlYXJjaCB7XG4gIGNvbG9yOiBibGFjaztcbiAgYm9yZGVyOiBub25lICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiA4NSU7XG4gIG1hcmdpbjogYXV0bztcbiAgaGVpZ2h0OiA3MCU7XG4gIC0tYmFja2dyb3VuZDogIzIwYjU3MjtcbiAgY29sb3I6IHdoaXRlO1xuICAtLWJvcmRlci1yYWRpdXM6IDEwcmVtICFpbXBvcnRhbnQ7XG59XG5cbkBtZWRpYSAoYW55LWhvdmVyOiBob3Zlcikge1xuICBidXR0b24uYnV0dG9uLW5hdGl2ZTpob3N0KDpob3ZlcikgLmJ1dHRvbi1uYXRpdmUge1xuICAgIGJhY2tncm91bmQ6ICMyMGI1NzIgIWltcG9ydGFudDtcbiAgfVxufVxuLmxhYmVsRGFuZ2VyIHtcbiAgY29sb3I6ICNDODMzMzM7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4ubGFiZXJsU2VydmljZSB7XG4gIHdoaXRlLXNwYWNlOiBub3JtYWw7XG59XG5cbi5kaXZTaGlmdCB7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59Il19 */"

/***/ }),

/***/ "./src/app/shift-details-rm/shift-details-rm.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/shift-details-rm/shift-details-rm.page.ts ***!
  \***********************************************************/
/*! exports provided: ShiftDetailsRMPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShiftDetailsRMPage", function() { return ShiftDetailsRMPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _services_shift_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../services/shift.service */ "./src/app/services/shift.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");















var ShiftDetailsRMPage = /** @class */ (function () {
    function ShiftDetailsRMPage(alertController, loadingController, http, storage, route, router, shiftService, fb, loading, toastController, screenOrientation, navController, statusBar, dialog, platform) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.shiftService = shiftService;
        this.fb = fb;
        this.loading = loading;
        this.toastController = toastController;
        this.screenOrientation = screenOrientation;
        this.navController = navController;
        this.statusBar = statusBar;
        this.dialog = dialog;
        this.platform = platform;
        this.content = null;
        this.dependents = [];
        this.httpOptions = null;
        this.years = [];
        this.historic = [];
        this.emptyShift = false;
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    }
    ShiftDetailsRMPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.queryParams.subscribe(function (params) {
            if (_this.router.getCurrentNavigation().extras.state) {
                _this.token = _this.router.getCurrentNavigation().extras.state.token;
                _this.content = _this.router.getCurrentNavigation().extras.state.content;
            }
        });
        if (this.content == null) {
            this.loading.present();
            this.getAppointments();
        }
        this.getDependents();
        this.getYear();
        this.createForm();
    };
    ShiftDetailsRMPage.prototype.getAppointments = function () {
        var _this = this;
        this.getToken().then(function (value) {
            _this.shiftService.getAppointmentsRM(_this.httpOptions, null).subscribe(function (response) {
                //this.loadingController.dismiss(); 
                _this.content = response[0];
                _this.loading.dismiss();
            }, function (error) {
                _this.loading.dismiss();
                //this.loadingController.dismiss(); 
                if (error.status === 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                }
            });
        });
    };
    ShiftDetailsRMPage.prototype.getAppointmentsParam = function (param) {
        var _this = this;
        this.getToken().then(function (value) {
            _this.shiftService.getAppointmentsRM(_this.httpOptions, param).subscribe(function (response) {
                _this.historic = response;
                if (_this.historic[0].appointmentItemDtoList.length > 0) {
                    _this.emptyShift = false;
                }
                else {
                    _this.emptyShift = true;
                }
                _this.loading.dismiss();
            }, function (error) {
                _this.loading.dismiss();
                if (error.status === 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                }
            });
        });
    };
    ShiftDetailsRMPage.prototype.getDependents = function () {
        var _this = this;
        this.loading.present();
        this.dependents.push({ docNumber: null, fullName: 'Mis Turnos', sex: null });
        this.getToken().then(function (value) {
            _this.shiftService.getDependents(_this.httpOptions).subscribe(function (response) {
                if (response && response.wards.length > 0) {
                    response.wards.forEach(function (element) {
                        _this.dependents.push(element);
                    });
                }
                _this.loading.dismiss();
            }, function (error) {
                _this.loading.dismiss();
                _this.dependents = [];
                if (error.status === 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                }
            });
        });
        ////this.loadingController.dismiss();
    };
    ShiftDetailsRMPage.prototype.createForm = function () {
        this.formAppointment = this.fb.group({
            personsCtrl: [''],
            yearCtrl: [''],
        });
    };
    ShiftDetailsRMPage.prototype.getYear = function () {
        var today = new Date().getFullYear();
        for (var i = today; i >= 2000; i--) {
            this.years.push(i);
        }
    };
    ShiftDetailsRMPage.prototype.deleteDataAndExitToLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.storage.clear().then(function () {
                    _this.navController.navigateRoot("/login");
                });
                return [2 /*return*/];
            });
        });
    };
    ShiftDetailsRMPage.prototype.getToken = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.storage.get('token').then(function (value) {
                            var httpOptions = {
                                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                    'Content-Type': 'application/json',
                                    'Accept': 'application/json',
                                    'X-Authorization': 'Bearer ' + value,
                                }),
                                response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                                    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                        'Content-Type': 'application/json',
                                        'Accept': 'application/json'
                                    }),
                                })
                            };
                            _this.httpOptions = httpOptions;
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ShiftDetailsRMPage.prototype.alert = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Portal puntano',
                            message: messageText,
                            buttons: [
                                {
                                    text: 'OK',
                                    role: 'cancel',
                                    cssClass: 'primary',
                                    handler: function () {
                                        console.log('OK pressed!!');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    // async loading(messageText:string){
    //   const loading = await this.loadingController.create({
    //     message: messageText,
    //   });
    //   await loading.present();
    // }
    ShiftDetailsRMPage.prototype.ionViewWillEnter = function () {
        this.statusBar.backgroundColorByHexString('#20B572');
    };
    ShiftDetailsRMPage.prototype.goNewShift = function () {
        //this.navController.navigateRoot("/new-appointment-rm", navigationExtras);
        this.router.navigate(['new-shifts']);
    };
    ShiftDetailsRMPage.prototype.cancelShift = function (shift) {
        var _this = this;
        sweetalert2__WEBPACK_IMPORTED_MODULE_10___default.a.fire({
            title: 'Aviso',
            text: '¿Desea cancelar el Turno reservado?',
            imageUrl: "../../assets/icon/GreenWarning.png",
            imageWidth: 100,
            imageHeight: 100,
            showCancelButton: true,
            confirmButtonColor: '#20B572',
            confirmButtonText: 'Aceptar',
            cancelButtonText: "Cancelar"
        }).then(function (result) {
            if (result.isConfirmed) {
                _this.shiftService.updateAppointmentCancel(_this.httpOptions, shift.items[0].value).subscribe(function (response) {
                    if (_this.historic.length < 1) {
                        _this.getAppointments();
                    }
                    else {
                        var param = '';
                        _this.formAppointment.get("yearCtrl").value ? param = param + '&year=' + _this.formAppointment.get("yearCtrl").value : '';
                        _this.formAppointment.get("personsCtrl").value.sex ? param = param + '&wardSex=' + _this.formAppointment.get("personsCtrl").value.sex : '';
                        _this.formAppointment.get("personsCtrl").value.docNumber ? param = param + '&wardDocNumber=' + _this.formAppointment.get("personsCtrl").value.docNumber : '';
                        if (param.length > 0) {
                            param = param.replace('&', '?');
                        }
                        _this.getAppointmentsParam(param);
                    }
                    _this.presentToast();
                }, function (error) {
                    //this.loadingController.dismiss(); 
                    if (error.status === 409) {
                        _this.alert(error.error.message);
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_8__["constants"].GENERIC_ERROR);
                    }
                });
            }
        });
    };
    ShiftDetailsRMPage.prototype.search = function () {
        this.loading.present();
        var param = '';
        this.formAppointment.get("yearCtrl").value ? param = param + '&year=' + this.formAppointment.get("yearCtrl").value : '';
        this.formAppointment.get("personsCtrl").value.sex ? param = param + '&wardSex=' + this.formAppointment.get("personsCtrl").value.sex : '';
        this.formAppointment.get("personsCtrl").value.docNumber ? param = param + '&wardDocNumber=' + this.formAppointment.get("personsCtrl").value.docNumber : '';
        if (param.length > 0) {
            param = param.replace('&', '?');
        }
        this.getAppointmentsParam(param);
    };
    ShiftDetailsRMPage.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
    };
    ShiftDetailsRMPage.prototype.presentToast = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: 'El Turno se Cancelo exitosamente',
                            duration: 5000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ShiftDetailsRMPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _services_shift_service__WEBPACK_IMPORTED_MODULE_11__["ShiftService"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormBuilder"] },
        { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_14__["LoadingService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_6__["ScreenOrientation"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"] },
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_9__["MatDialog"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] }
    ]; };
    ShiftDetailsRMPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-shift-details-rm',
            template: __webpack_require__(/*! raw-loader!./shift-details-rm.page.html */ "./node_modules/raw-loader/index.js!./src/app/shift-details-rm/shift-details-rm.page.html"),
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_13__["trigger"])('visibilityChanged', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_13__["state"])('shown', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_13__["style"])({ opacity: 1 })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_13__["state"])('hidden', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_13__["style"])({ opacity: 0 })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_13__["transition"])('* => *', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_13__["animate"])('500ms'))
                ])
            ],
            styles: [__webpack_require__(/*! ./shift-details-rm.page.scss */ "./src/app/shift-details-rm/shift-details-rm.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _services_shift_service__WEBPACK_IMPORTED_MODULE_11__["ShiftService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormBuilder"],
            _services_loading_service__WEBPACK_IMPORTED_MODULE_14__["LoadingService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_6__["ScreenOrientation"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"],
            _angular_material_dialog__WEBPACK_IMPORTED_MODULE_9__["MatDialog"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]])
    ], ShiftDetailsRMPage);
    return ShiftDetailsRMPage;
}());



/***/ })

}]);
//# sourceMappingURL=shift-details-rm-shift-details-rm-module-es5.js.map