(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["judicialExpedientsAll-judicialExpedientsAll-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/judicialExpedientsAll/judicialExpedientsAll.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/judicialExpedientsAll/judicialExpedientsAll.page.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>EXPEDIENTES {{judicialExpedients.year}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list *ngFor=\"let item of judicialExpedients.expedients\">\r\n    <!-- <ion-list-header>\r\n      <h2 class=\"header-text\"><b>{{item.year}}</b></h2>\r\n    </ion-list-header> -->\r\n    <!-- <div *ngFor=\"let expedient of item.expedients; let i = index\"> -->\r\n    <ion-item class=\"border-red\"  (click)=\"getjudicialExpedientDetail(item)\">\r\n      <ion-list >\r\n      <ion-item lines=\"none\" style=\"margin-top: 10px\">\r\n        <ion-label class=\"ion-text-wrap\">\r\n          <ion-text class=\"red\">\r\n            <h3 style=\"display: inline;\">{{item.name}}</h3>\r\n          </ion-text>\r\n        </ion-label>\r\n\r\n      </ion-item>\r\n\r\n      <!-- <ion-item lines=\"none\" (click)=\"download(liquidation)\">\r\n        <ion-card text-center style=\"padding: 0px; margin: 0px;\">\r\n          <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n          width=\"30%\" height=\"30%\" viewBox=\"0 0 1024 1024\" enable-background=\"new 0 0 1024 1024\" xml:space=\"preserve\">\r\n       <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" fill=\"#003F79\" d=\"M862.973,656.11h-89.835v148.416\r\n         c0,18.885-16.591,35.887-36.75,35.887H287.596c-20.158,0-36.109-17.002-36.109-35.887V656.11h-90.459v148.416\r\n         c0,69.689,56.87,125.308,126.568,125.308h448.792c70.538,0,126.585-55.618,126.585-125.308V656.11z M837.57,419.12L518.298,737.132\r\n         c-3.16,4.421-9.649,4.421-12.821,0L187.251,419.12c-3.98-3.358-3.98-9.662,0-12.594l69.69-70.951l201.329,201.303V111.379\r\n         c0-9.647,7.536-17.213,16.576-17.213h74.944c9.648,0,17.002,7.566,17.002,17.213v425.499L767.06,335.575l70.511,70.951\r\n         C840.518,409.458,840.518,415.762,837.57,419.12\"/>\r\n       </svg>\r\n        </ion-card>\r\n      </ion-item> -->\r\n    </ion-list>\r\n\r\n    </ion-item>\r\n\r\n    <!-- </div> -->\r\n\r\n    <!-- <ion-item lines=\"none\" (click)=\"goToJudicialExpedientsAll(item)\">\r\n      <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:20px; border-radius:6px; background-color: #e6e6e6; width: 100%;\">\r\n          <h5 style=\"display: inline;\"> Mostrar todos</h5>\r\n          <ion-icon style=\"align-content: flex-end; align-self:rigth; vertical-align: middle; margin: 0px !important;\" name=\"ios-arrow-forward\"></ion-icon>\r\n          </ion-text>\r\n  </ion-item> -->\r\n\r\n\r\n  </ion-list>\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n      <ion-buttons>\r\n        <ion-button (click)=\"goToHome()\">\r\n          <ion-icon class=\"red\" ios=\"home-outline\" md=\"home-sharp\" ></ion-icon>\r\n        </ion-button>\r\n        </ion-buttons>\r\n      </ion-toolbar>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/judicialExpedientsAll/judicialExpedientsAll.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/judicialExpedientsAll/judicialExpedientsAll.module.ts ***!
  \***********************************************************************/
/*! exports provided: JudicialExpedientsAllModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JudicialExpedientsAllModule", function() { return JudicialExpedientsAllModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _judicialExpedientsAll_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./judicialExpedientsAll.page */ "./src/app/judicialExpedientsAll/judicialExpedientsAll.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");












var JudicialExpedientsAllModule = /** @class */ (function () {
    function JudicialExpedientsAllModule() {
    }
    JudicialExpedientsAllModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _judicialExpedientsAll_page__WEBPACK_IMPORTED_MODULE_6__["JudicialExpedientsAllPage"]
                    }
                ])
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransfer"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_8__["FileTransferObject"],
                _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_9__["File"],
                _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_11__["RefreshUtils"],
                _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_10__["FileOpener"]],
            declarations: [_judicialExpedientsAll_page__WEBPACK_IMPORTED_MODULE_6__["JudicialExpedientsAllPage"]]
        })
    ], JudicialExpedientsAllModule);
    return JudicialExpedientsAllModule;
}());



/***/ }),

/***/ "./src/app/judicialExpedientsAll/judicialExpedientsAll.page.scss":
/*!***********************************************************************!*\
  !*** ./src/app/judicialExpedientsAll/judicialExpedientsAll.page.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".red {\n  color: #003F79;\n}\n\nion-item.border-red {\n  border-bottom: 1px solid #003F79;\n}\n\n.header-text {\n  margin-right: 5%;\n  padding-left: 20px;\n  width: 100%;\n  padding-bottom: 10px;\n  padding-top: 10px;\n  background-color: #003F79;\n  color: #FFFFFF;\n  border-radius: 10px !important;\n}\n\nion-item {\n  margin-left: 5%;\n  margin-right: 5%;\n}\n\nion-list {\n  align-items: center;\n  margin-bottom: 0px;\n}\n\nion-header ion-toolbar {\n  --background: #003F79;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n\nion-label {\n  margin-bottom: 0px;\n  margin-top: 0px;\n}\n\nion-content {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.sc-ion-card-md-h {\n  box-shadow: none !important;\n  -webkit-box-shadow: \"\" !important;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n\nion-title {\n  padding-right: 5%;\n  padding-left: 5%;\n  font-size: 5vw;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvanVkaWNpYWxFeHBlZGllbnRzQWxsL0Q6XFxSZXBvc2l0b3Jpb3NcXHBvcnRhbC1pb25pYy9zcmNcXGFwcFxcanVkaWNpYWxFeHBlZGllbnRzQWxsXFxqdWRpY2lhbEV4cGVkaWVudHNBbGwucGFnZS5zY3NzIiwic3JjL2FwcC9qdWRpY2lhbEV4cGVkaWVudHNBbGwvanVkaWNpYWxFeHBlZGllbnRzQWxsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7QUNDSjs7QURJQTtFQUNJLGdDQUFBO0FDREo7O0FESUc7RUFFQyxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSw4QkFBQTtBQ0ZKOztBREtHO0VBQ0MsZUFBQTtFQUNBLGdCQUFBO0FDRko7O0FES0c7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0FDRlA7O0FES0c7RUFDQyxxQkFBQTtBQ0ZKOztBREtHO0VBQ0MsY0FBQTtBQ0ZKOztBREtBO0VBQ0kseUJBQUE7QUNGSjs7QURLRztFQUNJLGtCQUFBO0VBQ0EsZUFBQTtBQ0ZQOztBRE1HO0VBQ0MsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNISjs7QURNQTtFQUNJLDJCQUFBO0VBQ0EsaUNBQUE7QUNISjs7QURNQTtFQUNJLDJCQUFBO0FDSEo7O0FETUE7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDSEoiLCJmaWxlIjoic3JjL2FwcC9qdWRpY2lhbEV4cGVkaWVudHNBbGwvanVkaWNpYWxFeHBlZGllbnRzQWxsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZWR7XHJcbiAgICBjb2xvcjogIzAwM0Y3OVxyXG59XHJcblxyXG5cclxuXHJcbmlvbi1pdGVtLmJvcmRlci1yZWQge1xyXG4gICAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgIzAwM0Y3OTtcclxuICAgfVxyXG5cclxuICAgLmhlYWRlci10ZXh0e1xyXG4gICAgLy8gYm9yZGVyLWJvdHRvbToycHggc29saWQgIzUzNTM1MztcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAzRjc5O1xyXG4gICAgY29sb3I6ICNGRkZGRkY7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgIH1cclxuXHJcbiAgIGlvbi1pdGVte1xyXG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICAgfVxyXG5cclxuICAgaW9uLWxpc3R7XHJcbiAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgbWFyZ2luLWJvdHRvbTowcHg7XHJcbiAgIH1cclxuXHJcbiAgIGlvbi1oZWFkZXIgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6ICMwMDNGNzk7XHJcbiAgICBcclxuICAgfVxyXG4gICBpb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZXtcclxuICAgIGNvbG9yOiAjRkZGRkZGO1xyXG4gICB9XHJcblxyXG4ud2hpdGV7XHJcbiAgICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4gICBpb24tbGFiZWx7XHJcbiAgICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgIH1cclxuXHJcblxyXG4gICBpb24tY29udGVudCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4uc2MtaW9uLWNhcmQtbWQtaCB7XHJcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAtd2Via2l0LWJveC1zaGFkb3c6XCJcIiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tY2FyZHtcclxuICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLXRpdGxle1xyXG4gICAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xyXG4gICAgZm9udC1zaXplOiA1dnc7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuIiwiLnJlZCB7XG4gIGNvbG9yOiAjMDAzRjc5O1xufVxuXG5pb24taXRlbS5ib3JkZXItcmVkIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwMDNGNzk7XG59XG5cbi5oZWFkZXItdGV4dCB7XG4gIG1hcmdpbi1yaWdodDogNSU7XG4gIHBhZGRpbmctbGVmdDogMjBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xuICBwYWRkaW5nLXRvcDogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwM0Y3OTtcbiAgY29sb3I6ICNGRkZGRkY7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW0ge1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIG1hcmdpbi1yaWdodDogNSU7XG59XG5cbmlvbi1saXN0IHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMDAzRjc5O1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuXG4ud2hpdGUge1xuICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xufVxuXG5pb24tbGFiZWwge1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi10b3A6IDBweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLnNjLWlvbi1jYXJkLW1kLWgge1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gIC13ZWJraXQtYm94LXNoYWRvdzogXCJcIiAhaW1wb3J0YW50O1xufVxuXG5pb24tY2FyZCB7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbn1cblxuaW9uLXRpdGxlIHtcbiAgcGFkZGluZy1yaWdodDogNSU7XG4gIHBhZGRpbmctbGVmdDogNSU7XG4gIGZvbnQtc2l6ZTogNXZ3O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il19 */"

/***/ }),

/***/ "./src/app/judicialExpedientsAll/judicialExpedientsAll.page.ts":
/*!*********************************************************************!*\
  !*** ./src/app/judicialExpedientsAll/judicialExpedientsAll.page.ts ***!
  \*********************************************************************/
/*! exports provided: JudicialExpedientsAllPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JudicialExpedientsAllPage", function() { return JudicialExpedientsAllPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/constants */ "./src/app/utils/constants.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");













var JudicialExpedientsAllPage = /** @class */ (function () {
    function JudicialExpedientsAllPage(alertController, loadingController, http, storage, route, router, transfer, file, fileOpener, screenOrientation, statusBar, refreshUtils, navController) {
        var _this = this;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.http = http;
        this.storage = storage;
        this.route = route;
        this.router = router;
        this.transfer = transfer;
        this.file = file;
        this.fileOpener = fileOpener;
        this.screenOrientation = screenOrientation;
        this.statusBar = statusBar;
        this.refreshUtils = refreshUtils;
        this.navController = navController;
        this.processError = function (error) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                console.log("Error!!!!!");
                console.log(JSON.stringify(error));
                _this.loadingController.dismiss();
                if (error.status == 500) {
                    if (error.error.exception === "io.jsonwebtoken.ExpiredJwtException") {
                        _this.storage.get('psw').then(function (val) {
                            if (val) {
                                _this.loading();
                                _this.refreshUtils.refreshToken(val).then(function (value) {
                                    _this.loadingController.dismiss();
                                    resolve(value);
                                }).catch(function (errorRefresh) {
                                    _this.loadingController.dismiss();
                                    if (errorRefresh.status == 401) {
                                        _this.deleteDataAndExitToLogin();
                                    }
                                    else {
                                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                                    }
                                });
                            }
                            else {
                                _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                            }
                        });
                    }
                    else {
                        _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                    }
                }
                else if (error.status == 401) {
                    _this.deleteDataAndExitToLogin();
                }
                else if (error.status == 409) {
                    _this.alert(error.error.message);
                }
                else {
                    _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                }
            });
        };
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
        this.route.queryParams.subscribe(function (params) {
            if (_this.router.getCurrentNavigation().extras.state) {
                _this.judicialExpedients = _this.router.getCurrentNavigation().extras.state.content;
                _this.token = _this.router.getCurrentNavigation().extras.state.token;
            }
        });
    }
    JudicialExpedientsAllPage.prototype.ionViewWillEnter = function () {
        this.statusBar.backgroundColorByHexString('#003F79');
    };
    JudicialExpedientsAllPage.prototype.ngOnInit = function () {
    };
    JudicialExpedientsAllPage.prototype.deleteDataAndExitToLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.storage.clear().then(function () {
                    _this.navController.navigateRoot("/login");
                });
                return [2 /*return*/];
            });
        });
    };
    JudicialExpedientsAllPage.prototype.alert = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.loadingController.dismiss();
                        return [4 /*yield*/, this.alertController.create({
                                header: 'Portal puntano',
                                message: messageText,
                                buttons: [
                                    {
                                        text: 'OK',
                                        role: 'cancel',
                                        cssClass: 'primary',
                                        handler: function () {
                                            console.log('OK pressed!!');
                                        }
                                    }
                                ]
                            })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    JudicialExpedientsAllPage.prototype.loading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.loadingController.dismiss();
                        return [4 /*yield*/, this.loadingController.create({
                                message: 'Cargando',
                            })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    JudicialExpedientsAllPage.prototype.loadingWithMessage = function (messageText) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: messageText,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    JudicialExpedientsAllPage.prototype.getjudicialExpedientDetail = function (judicialExpedient) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loading();
                this.storage.get('token').then(function (val) {
                    if (val) {
                        var httpOptions = {
                            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                'Content-Type': 'application/json',
                                'Accept': 'application/json',
                                'X-Authorization': 'Bearer ' + _this.token,
                            }),
                            response: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpResponse"]({
                                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({
                                    'Content-Type': 'application/json',
                                    'Accept': 'application/json'
                                }),
                            })
                        };
                        console.log("URL: " + _utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/actions/expedient/" + judicialExpedient.id); //"secure/liquidations/"+this.data.iduser);
                        console.log("TOKEN: " + 'Bearer ' + _this.token);
                        _this.http.get(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].URL_BASE_PORTAL + "secure/actions/expedient/" + judicialExpedient.id, httpOptions)
                            .subscribe(function (data) {
                            console.log("RESPONSE GET JUDICIAL EXPEDIENT DETAIL!: ");
                            //HARDCODING!!!!!!!!
                            // data = {"id":null,"name":"1077275","actions":[{"nroAction":"16857016","dateSign":"2019-12-23 12:32:49","extract":"CONSTANCIA DE ENTREGA DE EDICTOS"},{"nroAction":"16391024","dateSign":"2019-11-04 12:57:30","extract":"ACUMULESE OFR"},{"nroAction":"16100175","dateSign":"2019-10-04 11:14:15","extract":"VERONICA VIVIAN CUELLO LAPETINA"},{"nroAction":"16068414","dateSign":"2019-09-30 11:56:22","extract":"COMPROBANTE CEDULA RUSSO ADELA AURORA"},{"nroAction":"16068413","dateSign":"2019-09-30 11:56:22","extract":"COMPROBANTE CEDULA RUSSO ADELA AURORA"},{"nroAction":"16031395","dateSign":"2019-09-30 11:56:22","extract":"VERONICA CUELLO LAPETINA"},{"nroAction":"16022798","dateSign":"2019-09-30 11:56:22","extract":"CEDULA RUSSO ADELA AURORA"},{"nroAction":"16022860","dateSign":"2019-09-30 11:56:22","extract":"CEDULA POSTAL CUELLO LAPETINA VERONICA VIVIAN"},{"nroAction":"16022856","dateSign":"2019-09-30 11:56:22","extract":"CEDULA POSTAL CUELLO SUAREZ PABLO MARTIN"},{"nroAction":"16022921","dateSign":"2019-09-30 11:56:22","extract":"CEDULA POSTAL CUELLO SUAREZ ALEJANDRO HERNAN"},{"nroAction":"16044865","dateSign":"2019-09-30 08:25:14","extract":"ALEJANDRO HERNAN CUELLO SUAREZ"},{"nroAction":"16022740","dateSign":"2019-09-26 13:06:27","extract":"RECTIFICA"},{"nroAction":"15982402","dateSign":"2019-09-23 12:55:03","extract":"EDICTO"},{"nroAction":"16004378","dateSign":"2019-09-23 10:39:04","extract":"ADVIERTE ERROR - NUEVA CEDULA"},{"nroAction":"15943796","dateSign":"2019-09-20 10:38:11","extract":"CEDULA POSTAL CUELLO LAPETINA VERONICA VIVIAN"},{"nroAction":"15943794","dateSign":"2019-09-20 10:38:11","extract":"CEDULA POSTAL CUELLO SUAREZ PABLO MARTIN"},{"nroAction":"15987299","dateSign":"2019-09-20 10:38:11","extract":"COMPROBANTE CEDULA RUSSO ADELA AURORA"},{"nroAction":"15943755","dateSign":"2019-09-20 10:38:11","extract":"CEDULA RUSSO ADELA AURORA"},{"nroAction":"15943795","dateSign":"2019-09-20 10:38:11","extract":"CEDULA POSTAL CUELLO SUAREZ ALEJANDRO HERNAN"},{"nroAction":"15943325","dateSign":"2019-09-19 09:41:56","extract":"ABRE PROCESO SUCESORIO Y ORDENA MEDIDAS"},{"nroAction":"15812995","dateSign":"2019-09-04 12:51:58","extract":"CONTESTA VISTA"},{"nroAction":"15740804","dateSign":"2019-08-29 13:41:54","extract":"CORRASE VISTA FISCAL"},{"nroAction":"15602252","dateSign":"2019-08-15 12:41:45","extract":"OFICIO RJU VISTA FISCAL"},{"nroAction":"15553684","dateSign":"2019-08-07 11:05:12","extract":"ADJUNTA ESCRITO FIRMADO PROMOVIENTE"},{"nroAction":"15410980","dateSign":"2019-07-30 11:46:24","extract":"INFORME COLEGIO DE ESCRIBANOS "},{"nroAction":"15410991","dateSign":"2019-07-30 11:46:24","extract":"DECRETO-AGREGUESE "},{"nroAction":"15337404","dateSign":"2019-07-04 12:54:59","extract":"POR ACOMPA?ADO APORTE- POR CONSTITUIDO DOMICILIO PROCESAL"},{"nroAction":"15202957","dateSign":"2019-06-19 07:55:44","extract":"Cumplimenta-Aclara"},{"nroAction":"15170693","dateSign":"2019-06-14 11:47:26","extract":"ACLARE- POR PRESENTADOS HEREDEROS- CONSTITUYA DOMICILIO "},{"nroAction":"15035013","dateSign":"2019-05-31 09:54:11","extract":"ADJUNTA OFICIO CONTROL"},{"nroAction":"15034894","dateSign":"2019-05-31 07:34:19","extract":"Se notifican personalmente. Rectifican domicilio"},{"nroAction":"14984753","dateSign":"2019-05-29 11:11:32","extract":"CONSTANCIA DE COTEJO SE CONDICE"},{"nroAction":"14985147","dateSign":"2019-05-29 10:42:32","extract":"LIBRAR OFICIO COLEGIO DE ESCRIBANOS"},{"nroAction":"14951184","dateSign":"2019-05-23 10:49:44","extract":"ADJUNTA ESCRITO SUSCRIPTO PROMOVIENTE"},{"nroAction":"14919505","dateSign":"2019-05-22 07:25:43","extract":"CONSTANCIA DE RECEPCION DE DOCUMENTAL"},{"nroAction":"14882338","dateSign":"2019-05-20 12:18:41","extract":"DECRETO SIMPLE "},{"nroAction":"14840047","dateSign":"2019-05-14 09:17:06","extract":"DEMANDA DE IOL"}]};
                            console.log(JSON.stringify(data));
                            if (data != null) {
                                data.name = judicialExpedient.name;
                                // this.data.judicialExpedients = data;
                                console.log("JUDICIAL EXPEDIENT DETAIL!!!!");
                                console.log(JSON.stringify(data));
                                _this.goToExpedientDetail(data);
                            }
                            else {
                                _this.alert(_utils_constants__WEBPACK_IMPORTED_MODULE_9__["constants"].GENERIC_ERROR);
                            }
                            _this.loadingController.dismiss();
                        }, function (error) {
                            _this.processError(error).then(function (value) {
                                _this.getjudicialExpedientDetail(judicialExpedient);
                            });
                        });
                    }
                    else {
                        _this.alert("Ocurrió un problema, intente nuevamente");
                    }
                });
                return [2 /*return*/];
            });
        });
    };
    JudicialExpedientsAllPage.prototype.goToExpedientDetail = function (judicialExpedient) {
        var navigationExtras = {
            state: {
                content: judicialExpedient,
                token: this.token
            }
        };
        this.router.navigate(['judicialExpedientDetail'], navigationExtras);
    };
    JudicialExpedientsAllPage.prototype.goToHome = function () {
        this.navController.navigateRoot("/home");
    };
    JudicialExpedientsAllPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"] },
        { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
        { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_10__["ScreenOrientation"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"] },
        { type: _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_12__["RefreshUtils"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
    ]; };
    JudicialExpedientsAllPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-judicialExpedientsAll',
            template: __webpack_require__(/*! raw-loader!./judicialExpedientsAll.page.html */ "./node_modules/raw-loader/index.js!./src/app/judicialExpedientsAll/judicialExpedientsAll.page.html"),
            styles: [__webpack_require__(/*! ./judicialExpedientsAll.page.scss */ "./src/app/judicialExpedientsAll/judicialExpedientsAll.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_10__["ScreenOrientation"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"],
            _utils_refreshUtils__WEBPACK_IMPORTED_MODULE_12__["RefreshUtils"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
    ], JudicialExpedientsAllPage);
    return JudicialExpedientsAllPage;
}());



/***/ })

}]);
//# sourceMappingURL=judicialExpedientsAll-judicialExpedientsAll-module-es5.js.map