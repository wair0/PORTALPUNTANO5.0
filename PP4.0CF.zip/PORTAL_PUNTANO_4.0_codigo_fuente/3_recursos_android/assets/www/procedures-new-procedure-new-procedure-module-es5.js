(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["procedures-new-procedure-new-procedure-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/procedures/new-procedure/new-procedure.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/procedures/new-procedure/new-procedure.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button (click)='goToBack()' icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>NUEVO TRÁMITE</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n  <mat-accordion>\r\n    <mat-expansion-panel>\r\n      <mat-expansion-panel-header>\r\n        <mat-panel-title>\r\n          <b>Certificado de Libre de Deuda de Alimentos</b>\r\n        </mat-panel-title>\r\n      </mat-expansion-panel-header>\r\n      <ion-item (click)='goToNewProcedure(procedures.individual)'>\r\n        <ion-label>Persona Física</ion-label>\r\n      </ion-item>\r\n      <ion-item (click)='goToNewProcedure(procedures.legalEntity)'>\r\n        <ion-label>Persona Jurídica</ion-label>\r\n      </ion-item>\r\n    </mat-expansion-panel>\r\n  </mat-accordion>\r\n  <mat-accordion>\r\n    <mat-expansion-panel>\r\n      <mat-expansion-panel-header>\r\n        <mat-panel-title>\r\n          <b>Defensoría del pueblo</b>\r\n        </mat-panel-title>\r\n      </mat-expansion-panel-header>\r\n      <ion-item (click)='goToNewProcedure(procedures.cityClaims)'>\r\n        <ion-label>Reclamo</ion-label>\r\n      </ion-item>\r\n    </mat-expansion-panel>\r\n  </mat-accordion>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/procedures/new-procedure/new-procedure.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/procedures/new-procedure/new-procedure.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: #FF0067;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvY2VkdXJlcy9uZXctcHJvY2VkdXJlL0Q6XFxSZXBvc2l0b3Jpb3NcXHBvcnRhbC1pb25pYy9zcmNcXGFwcFxccHJvY2VkdXJlc1xcbmV3LXByb2NlZHVyZVxcbmV3LXByb2NlZHVyZS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcHJvY2VkdXJlcy9uZXctcHJvY2VkdXJlL25ldy1wcm9jZWR1cmUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtBQ0NKOztBREdBO0VBQ0ksY0FBQTtBQ0FKOztBREdBO0VBQ0kseUJBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3Byb2NlZHVyZXMvbmV3LXByb2NlZHVyZS9uZXctcHJvY2VkdXJlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNGRjAwNjc7XHJcblxyXG59XHJcblxyXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxufVxyXG5cclxuLndoaXRlIHtcclxuICAgIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XHJcbn0iLCJpb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjRkYwMDY3O1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuXG4ud2hpdGUge1xuICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/procedures/new-procedure/new-procedure.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/procedures/new-procedure/new-procedure.component.ts ***!
  \*********************************************************************/
/*! exports provided: NewProcedureComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewProcedureComponent", function() { return NewProcedureComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/procedures.service */ "./src/app/services/procedures.service.ts");
/* harmony import */ var src_app_utils_ProcedureEnums__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utils/ProcedureEnums */ "./src/app/utils/ProcedureEnums.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var NewProcedureComponent = /** @class */ (function () {
    function NewProcedureComponent(procedureService, router) {
        this.procedureService = procedureService;
        this.router = router;
        this.procedures = src_app_utils_ProcedureEnums__WEBPACK_IMPORTED_MODULE_3__["Procedures"];
    }
    NewProcedureComponent.prototype.ngOnInit = function () { };
    NewProcedureComponent.prototype.goToBack = function () {
        this.router.navigate(['/proceduresHome']);
    };
    NewProcedureComponent.prototype.goToNewProcedure = function (procedureId) {
        var _this = this;
        this.procedureService.generateNewProcedure(procedureId).subscribe(function (response) {
            _this.procedureType = response;
            if (_this.procedureType.id) {
                var navigationExtras = {
                    state: {
                        procedureType: _this.procedureType
                    }
                };
                _this.router.navigate(['/dynamic-form'], navigationExtras);
            }
        });
    };
    NewProcedureComponent.ctorParameters = function () { return [
        { type: src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_2__["ProceduresService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
    ]; };
    NewProcedureComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-new-procedure',
            template: __webpack_require__(/*! raw-loader!./new-procedure.component.html */ "./node_modules/raw-loader/index.js!./src/app/procedures/new-procedure/new-procedure.component.html"),
            styles: [__webpack_require__(/*! ./new-procedure.component.scss */ "./src/app/procedures/new-procedure/new-procedure.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_2__["ProceduresService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], NewProcedureComponent);
    return NewProcedureComponent;
}());



/***/ }),

/***/ "./src/app/procedures/new-procedure/new-procedure.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/procedures/new-procedure/new-procedure.module.ts ***!
  \******************************************************************/
/*! exports provided: NewProcedureModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewProcedureModule", function() { return NewProcedureModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _new_procedure_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./new-procedure.component */ "./src/app/procedures/new-procedure/new-procedure.component.ts");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/esm5/expansion.es5.js");








var NewProcedureModule = /** @class */ (function () {
    function NewProcedureModule() {
    }
    NewProcedureModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
                _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__["MatExpansionModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _new_procedure_component__WEBPACK_IMPORTED_MODULE_6__["NewProcedureComponent"]
                    }
                ])
            ],
            declarations: [_new_procedure_component__WEBPACK_IMPORTED_MODULE_6__["NewProcedureComponent"]],
        })
    ], NewProcedureModule);
    return NewProcedureModule;
}());



/***/ }),

/***/ "./src/app/utils/ProcedureEnums.ts":
/*!*****************************************!*\
  !*** ./src/app/utils/ProcedureEnums.ts ***!
  \*****************************************/
/*! exports provided: Procedures */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Procedures", function() { return Procedures; });
var Procedures;
(function (Procedures) {
    Procedures[Procedures["individual"] = 62] = "individual";
    Procedures[Procedures["legalEntity"] = 63] = "legalEntity";
    Procedures[Procedures["cityClaims"] = 64] = "cityClaims";
})(Procedures || (Procedures = {}));


/***/ })

}]);
//# sourceMappingURL=procedures-new-procedure-new-procedure-module-es5.js.map