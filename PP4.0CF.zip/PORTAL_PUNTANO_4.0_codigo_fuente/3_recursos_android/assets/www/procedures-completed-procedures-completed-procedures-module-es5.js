(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["procedures-completed-procedures-completed-procedures-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/procedures/completed-procedures/completed-procedures.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/procedures/completed-procedures/completed-procedures.component.html ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button icon=\"\" text=\"Atrás\" class=\"white\" default-href=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>TRÁMITES REALIZADOS</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-item class=\"border-red\" (click)='getProcedureDetail(item.id)' *ngFor=\"let item of procedures\">\r\n    <ion-row style=\"align-items: center;\">\r\n      <ion-col size=\"auto\">\r\n        <h1 class=\"status\"><b>{{item.status}}</b></h1>\r\n      </ion-col>\r\n      <ion-col>\r\n        <ion-label class=\"ion-text-wrap\">\r\n          <h2 class=\"red\"><b>{{item.dateCreated | date:\"dd/MM/yyyy - HH:mm a\"}}</b></h2>\r\n          <h2 class=\"red\">{{item.coverLetter}}</h2>\r\n          <h2 class=\"red\">Nro de trámite: {{item.id}}</h2>\r\n          <h2 class=\"red\"><b>{{item.fileNumber}}</b></h2>\r\n        </ion-label>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-item>\r\n\r\n  <ion-item class=\"show-all\" lines=\"none\" (click)=\"getAllProcedures()\">\r\n    <ion-text color=\"dark\" style=\"padding-top:6px; padding-bottom:6px;padding-left:10px; width: 100%;\">\r\n      <h4 style=\"display: inline;\"><b>Mostrar todos</b></h4>\r\n    </ion-text>\r\n    <svg xmlns='http://www.w3.org/2000/svg' height='25' viewBox='0 0 512 512'>\r\n      <title>ionicons-v5-a</title>\r\n      <polyline points='184 112 328 256 184 400'\r\n        style='fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px' />\r\n    </svg>\r\n  </ion-item>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/procedures/completed-procedures/completed-procedures.component.scss":
/*!*************************************************************************************!*\
  !*** ./src/app/procedures/completed-procedures/completed-procedures.component.scss ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-toolbar {\n  --background: #FF0067;\n}\n\nion-header ion-toolbar ion-title {\n  color: #FFFFFF;\n}\n\n.white {\n  color: #FFFFFF !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvY2VkdXJlcy9jb21wbGV0ZWQtcHJvY2VkdXJlcy9EOlxcUmVwb3NpdG9yaW9zXFxwb3J0YWwtaW9uaWMvc3JjXFxhcHBcXHByb2NlZHVyZXNcXGNvbXBsZXRlZC1wcm9jZWR1cmVzXFxjb21wbGV0ZWQtcHJvY2VkdXJlcy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcHJvY2VkdXJlcy9jb21wbGV0ZWQtcHJvY2VkdXJlcy9jb21wbGV0ZWQtcHJvY2VkdXJlcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0FDQ0o7O0FER0E7RUFDSSxjQUFBO0FDQUo7O0FER0E7RUFDSSx5QkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcHJvY2VkdXJlcy9jb21wbGV0ZWQtcHJvY2VkdXJlcy9jb21wbGV0ZWQtcHJvY2VkdXJlcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRkYwMDY3O1xyXG5cclxufVxyXG5cclxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xyXG4gICAgY29sb3I6ICNGRkZGRkY7XHJcbn1cclxuXHJcbi53aGl0ZSB7XHJcbiAgICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xyXG59IiwiaW9uLWhlYWRlciBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogI0ZGMDA2Nztcbn1cblxuaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tdGl0bGUge1xuICBjb2xvcjogI0ZGRkZGRjtcbn1cblxuLndoaXRlIHtcbiAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/procedures/completed-procedures/completed-procedures.component.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/procedures/completed-procedures/completed-procedures.component.ts ***!
  \***********************************************************************************/
/*! exports provided: CompletedProceduresComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompletedProceduresComponent", function() { return CompletedProceduresComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/procedures.service */ "./src/app/services/procedures.service.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");






var CompletedProceduresComponent = /** @class */ (function () {
    function CompletedProceduresComponent(proceduresService, screenOrientation, loadingController, router) {
        this.proceduresService = proceduresService;
        this.screenOrientation = screenOrientation;
        this.loadingController = loadingController;
        this.router = router;
        this.procedures = [];
        this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    }
    CompletedProceduresComponent.prototype.ngOnInit = function () {
        this.getProcedures();
    };
    CompletedProceduresComponent.prototype.getAllProcedures = function () {
        var _this = this;
        this.loading();
        this.proceduresService.getCurrentProcedures('FIN').subscribe(function (response) {
            if (response && response.content && response.content.length > 0) {
                _this.loadingController.dismiss();
                _this.procedures = response.content;
            }
        }, function (error) {
            _this.loadingController.dismiss();
        });
    };
    CompletedProceduresComponent.prototype.getProcedures = function () {
        var _this = this;
        this.loading();
        this.proceduresService.getCurrentProcedures('FIN', 5).subscribe(function (response) {
            _this.loadingController.dismiss();
            if (response && response.content && response.content.length > 0) {
                _this.procedures = response.content;
            }
            else
                alert("No se encontraron datos");
        }, function (error) {
            _this.loadingController.dismiss();
        });
    };
    CompletedProceduresComponent.prototype.loading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: 'Cargando',
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CompletedProceduresComponent.prototype.getProcedureDetail = function (idProcedure) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loading();
                this.proceduresService.getDetailsProcedures(idProcedure).subscribe(function (data) {
                    _this.makeProcedure(data);
                });
                return [2 /*return*/];
            });
        });
    };
    CompletedProceduresComponent.prototype.makeProcedure = function (procedure) {
        var steps = new Map();
        procedure.procedureSteps.forEach(function (element) {
            steps.set(element.step, element.title);
        });
        var attributes = new Map();
        var files = new Array();
        procedure.procedureTypeAttrs.forEach(function (element) {
            if (element.step) {
                if (attributes.get(element.step)) {
                    attributes.get(element.step).push(element);
                }
                else {
                    var array_1 = new Array();
                    array_1.push(element);
                    attributes.set(element.step, array_1);
                }
            }
            else {
                files.push(element);
            }
        });
        var array = new Array();
        if (files.length > 0) {
            var dataFiles = {
                name: "",
                attributes: files
            };
            array.push(dataFiles);
        }
        attributes.forEach(function (value, key) {
            var data = {
                name: steps.get(key),
                attributes: value
            };
            array.push(data);
        });
        if (procedure.comments) {
            var attributeComments = {
                name: "Observaciones",
                dataValue: procedure.comments
            };
            var arrayComments = new Array();
            arrayComments.push(attributeComments);
            var stepComments = {
                name: "COMENTARIOS",
                attributes: arrayComments
            };
            array.push(stepComments);
        }
        this.goToProcedureDetail(procedure, array);
    };
    CompletedProceduresComponent.prototype.goToProcedureDetail = function (procedureItem, steps) {
        this.loadingController.dismiss();
        if (steps.length > 0) {
            var navigationExtras = {
                state: {
                    procedureItem: procedureItem,
                    steps: steps,
                }
            };
            this.router.navigate(['procedureDetail'], navigationExtras);
        }
        else {
            alert("No se encontraron datos");
        }
    };
    CompletedProceduresComponent.ctorParameters = function () { return [
        { type: src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_2__["ProceduresService"] },
        { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__["ScreenOrientation"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
    ]; };
    CompletedProceduresComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-completed-procedures',
            template: __webpack_require__(/*! raw-loader!./completed-procedures.component.html */ "./node_modules/raw-loader/index.js!./src/app/procedures/completed-procedures/completed-procedures.component.html"),
            styles: [__webpack_require__(/*! ./completed-procedures.component.scss */ "./src/app/procedures/completed-procedures/completed-procedures.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_procedures_service__WEBPACK_IMPORTED_MODULE_2__["ProceduresService"],
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__["ScreenOrientation"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
    ], CompletedProceduresComponent);
    return CompletedProceduresComponent;
}());



/***/ }),

/***/ "./src/app/procedures/completed-procedures/completed-procedures.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/procedures/completed-procedures/completed-procedures.module.ts ***!
  \********************************************************************************/
/*! exports provided: CompletedProceduresModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompletedProceduresModule", function() { return CompletedProceduresModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _completed_procedures_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./completed-procedures.component */ "./src/app/procedures/completed-procedures/completed-procedures.component.ts");
/* harmony import */ var src_app_utils_refreshUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/utils/refreshUtils */ "./src/app/utils/refreshUtils.ts");








var CompletedProceduresModule = /** @class */ (function () {
    function CompletedProceduresModule() {
    }
    CompletedProceduresModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _completed_procedures_component__WEBPACK_IMPORTED_MODULE_6__["CompletedProceduresComponent"]
                    }
                ])
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], src_app_utils_refreshUtils__WEBPACK_IMPORTED_MODULE_7__["RefreshUtils"]],
            declarations: [_completed_procedures_component__WEBPACK_IMPORTED_MODULE_6__["CompletedProceduresComponent"]],
        })
    ], CompletedProceduresModule);
    return CompletedProceduresModule;
}());



/***/ })

}]);
//# sourceMappingURL=procedures-completed-procedures-completed-procedures-module-es5.js.map