package org.apache.cordova.whitelist;

import android.content.Context;
import androidx.webkit.ProxyConfig;
import org.apache.cordova.AllowList;
import org.apache.cordova.ConfigXmlParser;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.LOG;
import org.xmlpull.v1.XmlPullParser;

/* loaded from: classes.dex */
public class WhitelistPlugin extends CordovaPlugin {
    private static final String LOG_TAG = "WhitelistPlugin";
    private AllowList allowedIntents;
    private AllowList allowedNavigations;
    private AllowList allowedRequests;

    public WhitelistPlugin() {
    }

    public WhitelistPlugin(Context context) {
        this(new AllowList(), new AllowList(), null);
        new CustomConfigXmlParser().parse(context);
    }

    public WhitelistPlugin(XmlPullParser xmlPullParser) {
        this(new AllowList(), new AllowList(), null);
        new CustomConfigXmlParser().parse(xmlPullParser);
    }

    public WhitelistPlugin(AllowList allowList, AllowList allowList2, AllowList allowList3) {
        if (allowList3 == null) {
            allowList3 = new AllowList();
            allowList3.addAllowListEntry("file:///*", false);
            allowList3.addAllowListEntry("data:*", false);
        }
        this.allowedNavigations = allowList;
        this.allowedIntents = allowList2;
        this.allowedRequests = allowList3;
    }

    @Override // org.apache.cordova.CordovaPlugin
    public void pluginInitialize() {
        if (this.allowedNavigations == null) {
            this.allowedNavigations = new AllowList();
            this.allowedIntents = new AllowList();
            this.allowedRequests = new AllowList();
            new CustomConfigXmlParser().parse(this.webView.getContext());
        }
    }

    private class CustomConfigXmlParser extends ConfigXmlParser {
        @Override // org.apache.cordova.ConfigXmlParser
        public void handleEndTag(XmlPullParser xmlPullParser) {
        }

        private CustomConfigXmlParser() {
        }

        @Override // org.apache.cordova.ConfigXmlParser
        public void handleStartTag(XmlPullParser xmlPullParser) {
            String name = xmlPullParser.getName();
            boolean z = false;
            if (name.equals("content")) {
                WhitelistPlugin.this.allowedNavigations.addAllowListEntry(xmlPullParser.getAttributeValue(null, "src"), false);
                return;
            }
            if (name.equals("allow-navigation")) {
                String attributeValue = xmlPullParser.getAttributeValue(null, "href");
                if (ProxyConfig.MATCH_ALL_SCHEMES.equals(attributeValue)) {
                    WhitelistPlugin.this.allowedNavigations.addAllowListEntry("http://*/*", false);
                    WhitelistPlugin.this.allowedNavigations.addAllowListEntry("https://*/*", false);
                    WhitelistPlugin.this.allowedNavigations.addAllowListEntry("data:*", false);
                    return;
                }
                WhitelistPlugin.this.allowedNavigations.addAllowListEntry(attributeValue, false);
                return;
            }
            if (name.equals("allow-intent")) {
                WhitelistPlugin.this.allowedIntents.addAllowListEntry(xmlPullParser.getAttributeValue(null, "href"), false);
                return;
            }
            if (name.equals("access")) {
                String attributeValue2 = xmlPullParser.getAttributeValue(null, "origin");
                String attributeValue3 = xmlPullParser.getAttributeValue(null, "subdomains");
                boolean z2 = xmlPullParser.getAttributeValue(null, "launch-external") != null;
                if (attributeValue2 != null) {
                    if (z2) {
                        LOG.w(WhitelistPlugin.LOG_TAG, "Found <access launch-external> within config.xml. Please use <allow-intent> instead.");
                        AllowList allowList = WhitelistPlugin.this.allowedIntents;
                        if (attributeValue3 != null && attributeValue3.compareToIgnoreCase("true") == 0) {
                            z = true;
                        }
                        allowList.addAllowListEntry(attributeValue2, z);
                        return;
                    }
                    if (ProxyConfig.MATCH_ALL_SCHEMES.equals(attributeValue2)) {
                        WhitelistPlugin.this.allowedRequests.addAllowListEntry("http://*/*", false);
                        WhitelistPlugin.this.allowedRequests.addAllowListEntry("https://*/*", false);
                        return;
                    }
                    AllowList allowList2 = WhitelistPlugin.this.allowedRequests;
                    if (attributeValue3 != null && attributeValue3.compareToIgnoreCase("true") == 0) {
                        z = true;
                    }
                    allowList2.addAllowListEntry(attributeValue2, z);
                }
            }
        }
    }

    @Override // org.apache.cordova.CordovaPlugin
    public Boolean shouldAllowNavigation(String str) {
        return this.allowedNavigations.isUrlAllowListed(str) ? true : null;
    }

    @Override // org.apache.cordova.CordovaPlugin
    public Boolean shouldAllowRequest(String str) {
        return (Boolean.TRUE == shouldAllowNavigation(str) || this.allowedRequests.isUrlAllowListed(str)) ? true : null;
    }

    @Override // org.apache.cordova.CordovaPlugin
    public Boolean shouldOpenExternalUrl(String str) {
        return this.allowedIntents.isUrlAllowListed(str) ? true : null;
    }

    public AllowList getAllowedNavigations() {
        return this.allowedNavigations;
    }

    public void setAllowedNavigations(AllowList allowList) {
        this.allowedNavigations = allowList;
    }

    public AllowList getAllowedIntents() {
        return this.allowedIntents;
    }

    public void setAllowedIntents(AllowList allowList) {
        this.allowedIntents = allowList;
    }

    public AllowList getAllowedRequests() {
        return this.allowedRequests;
    }

    public void setAllowedRequests(AllowList allowList) {
        this.allowedRequests = allowList;
    }
}
