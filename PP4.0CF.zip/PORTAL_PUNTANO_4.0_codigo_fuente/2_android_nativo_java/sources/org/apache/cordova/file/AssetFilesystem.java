package org.apache.cordova.file;

import android.content.res.AssetManager;
import android.net.Uri;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map;
import org.apache.cordova.CordovaResourceApi;
import org.apache.cordova.LOG;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class AssetFilesystem extends Filesystem {
    private static final String LOG_TAG = "AssetFilesystem";
    private static Map<String, Long> lengthCache;
    private static Map<String, String[]> listCache;
    private static boolean listCacheFromFile;
    private static Object listCacheLock = new Object();
    private final AssetManager assetManager;

    @Override // org.apache.cordova.file.Filesystem
    LocalFilesystemURL URLforFilesystemPath(String str) {
        return null;
    }

    @Override // org.apache.cordova.file.Filesystem
    public boolean canRemoveFileAtLocalURL(LocalFilesystemURL localFilesystemURL) {
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0067 A[Catch: all -> 0x008a, TRY_LEAVE, TryCatch #5 {, blocks: (B:4:0x0003, B:12:0x0028, B:14:0x0063, B:16:0x0067, B:20:0x002d, B:21:0x0033, B:34:0x0057, B:37:0x005c, B:44:0x0079, B:41:0x0087, B:47:0x007e, B:26:0x0042, B:29:0x0047, B:53:0x0088), top: B:3:0x0003, inners: #2, #8, #9, #10 }] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0079 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private void lazyInitCaches() {
        ObjectInputStream objectInputStream;
        Throwable th;
        ClassNotFoundException e;
        String str;
        String localizedMessage;
        synchronized (listCacheLock) {
            if (listCache == null) {
                ObjectInputStream objectInputStream2 = null;
                try {
                    try {
                        objectInputStream = new ObjectInputStream(this.assetManager.open("cdvasset.manifest"));
                        try {
                            listCache = (Map) objectInputStream.readObject();
                            lengthCache = (Map) objectInputStream.readObject();
                            listCacheFromFile = true;
                            try {
                                objectInputStream.close();
                            } catch (IOException e2) {
                                str = LOG_TAG;
                                localizedMessage = e2.getLocalizedMessage();
                                LOG.d(str, localizedMessage);
                                if (listCache == null) {
                                }
                            }
                        } catch (IOException unused) {
                            objectInputStream2 = objectInputStream;
                            if (objectInputStream2 != null) {
                                try {
                                    objectInputStream2.close();
                                } catch (IOException e3) {
                                    str = LOG_TAG;
                                    localizedMessage = e3.getLocalizedMessage();
                                    LOG.d(str, localizedMessage);
                                    if (listCache == null) {
                                    }
                                }
                            }
                            if (listCache == null) {
                            }
                        } catch (ClassNotFoundException e4) {
                            e = e4;
                            e.printStackTrace();
                            if (objectInputStream != null) {
                                try {
                                    objectInputStream.close();
                                } catch (IOException e5) {
                                    str = LOG_TAG;
                                    localizedMessage = e5.getLocalizedMessage();
                                    LOG.d(str, localizedMessage);
                                    if (listCache == null) {
                                    }
                                }
                            }
                            if (listCache == null) {
                            }
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        if (objectInputStream != null) {
                            try {
                                objectInputStream.close();
                            } catch (IOException e6) {
                                LOG.d(LOG_TAG, e6.getLocalizedMessage());
                            }
                        }
                        throw th;
                    }
                } catch (IOException unused2) {
                } catch (ClassNotFoundException e7) {
                    objectInputStream = null;
                    e = e7;
                } catch (Throwable th3) {
                    objectInputStream = null;
                    th = th3;
                    if (objectInputStream != null) {
                    }
                    throw th;
                }
                if (listCache == null) {
                    LOG.w(LOG_TAG, "Asset manifest not found. Recursive copies and directory listing will be slow.");
                    listCache = new HashMap();
                }
            }
        }
    }

    private String[] listAssets(String str) throws IOException {
        if (str.startsWith("/")) {
            str = str.substring(1);
        }
        if (str.endsWith("/")) {
            str = str.substring(0, str.length() - 1);
        }
        lazyInitCaches();
        String[] strArr = listCache.get(str);
        if (strArr != null) {
            return strArr;
        }
        if (listCacheFromFile) {
            return new String[0];
        }
        String[] list = this.assetManager.list(str);
        listCache.put(str, list);
        return list;
    }

    private long getAssetSize(String str) throws FileNotFoundException {
        if (str.startsWith("/")) {
            str = str.substring(1);
        }
        lazyInitCaches();
        Map<String, Long> map = lengthCache;
        if (map != null) {
            Long l = map.get(str);
            if (l == null) {
                throw new FileNotFoundException("Asset not found: " + str);
            }
            return l.longValue();
        }
        CordovaResourceApi.OpenForReadResult openForReadResult = null;
        try {
            try {
                openForReadResult = this.resourceApi.openForRead(nativeUriForFullPath(str));
                long j = openForReadResult.length;
                if (j < 0) {
                    j = openForReadResult.inputStream.available();
                }
                return j;
            } catch (IOException e) {
                FileNotFoundException fileNotFoundException = new FileNotFoundException("File not found: " + str);
                fileNotFoundException.initCause(e);
                throw fileNotFoundException;
            }
        } finally {
            if (openForReadResult != null) {
                try {
                    openForReadResult.inputStream.close();
                } catch (IOException e2) {
                    LOG.d(LOG_TAG, e2.getLocalizedMessage());
                }
            }
        }
    }

    public AssetFilesystem(AssetManager assetManager, CordovaResourceApi cordovaResourceApi) {
        super(Uri.parse("file:///android_asset/"), "assets", cordovaResourceApi);
        this.assetManager = assetManager;
    }

    @Override // org.apache.cordova.file.Filesystem
    public Uri toNativeUri(LocalFilesystemURL localFilesystemURL) {
        return nativeUriForFullPath(localFilesystemURL.path);
    }

    @Override // org.apache.cordova.file.Filesystem
    public LocalFilesystemURL toLocalUri(Uri uri) {
        if (!"file".equals(uri.getScheme())) {
            return null;
        }
        Uri fromFile = Uri.fromFile(new File(uri.getPath()));
        String encodedPath = this.rootUri.getEncodedPath();
        String substring = encodedPath.substring(0, encodedPath.length() - 1);
        if (!fromFile.getEncodedPath().startsWith(substring)) {
            return null;
        }
        String substring2 = fromFile.getEncodedPath().substring(substring.length());
        if (!substring2.isEmpty()) {
            substring2 = substring2.substring(1);
        }
        Uri.Builder path = new Uri.Builder().scheme(LocalFilesystemURL.FILESYSTEM_PROTOCOL).authority("localhost").path(this.name);
        if (!substring2.isEmpty()) {
            path.appendEncodedPath(substring2);
        }
        if (isDirectory(substring2) || uri.getPath().endsWith("/")) {
            path.appendEncodedPath("");
        }
        return LocalFilesystemURL.parse(path.build());
    }

    private boolean isDirectory(String str) {
        try {
            return listAssets(str).length != 0;
        } catch (IOException unused) {
            return false;
        }
    }

    @Override // org.apache.cordova.file.Filesystem
    public LocalFilesystemURL[] listChildren(LocalFilesystemURL localFilesystemURL) throws FileNotFoundException {
        String substring = localFilesystemURL.path.substring(1);
        if (substring.endsWith("/")) {
            substring = substring.substring(0, substring.length() - 1);
        }
        try {
            String[] listAssets = listAssets(substring);
            LocalFilesystemURL[] localFilesystemURLArr = new LocalFilesystemURL[listAssets.length];
            for (int i = 0; i < listAssets.length; i++) {
                localFilesystemURLArr[i] = localUrlforFullPath(new File(localFilesystemURL.path, listAssets[i]).getPath());
            }
            return localFilesystemURLArr;
        } catch (IOException e) {
            FileNotFoundException fileNotFoundException = new FileNotFoundException();
            fileNotFoundException.initCause(e);
            throw fileNotFoundException;
        }
    }

    @Override // org.apache.cordova.file.Filesystem
    public JSONObject getFileForLocalURL(LocalFilesystemURL localFilesystemURL, String str, JSONObject jSONObject, boolean z) throws FileExistsException, IOException, TypeMismatchException, EncodingException, JSONException {
        LocalFilesystemURL localUrlforFullPath;
        if (jSONObject != null && jSONObject.optBoolean("create")) {
            throw new UnsupportedOperationException("Assets are read-only");
        }
        if (z && !str.endsWith("/")) {
            str = str + "/";
        }
        if (str.startsWith("/")) {
            localUrlforFullPath = localUrlforFullPath(normalizePath(str));
        } else {
            localUrlforFullPath = localUrlforFullPath(normalizePath(localFilesystemURL.path + "/" + str));
        }
        getFileMetadataForLocalURL(localUrlforFullPath);
        boolean isDirectory = isDirectory(localUrlforFullPath.path);
        if (z && !isDirectory) {
            throw new TypeMismatchException("path doesn't exist or is file");
        }
        if (!z && isDirectory) {
            throw new TypeMismatchException("path doesn't exist or is directory");
        }
        return makeEntryForURL(localUrlforFullPath);
    }

    @Override // org.apache.cordova.file.Filesystem
    public JSONObject getFileMetadataForLocalURL(LocalFilesystemURL localFilesystemURL) throws FileNotFoundException {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("size", localFilesystemURL.isDirectory ? 0L : getAssetSize(localFilesystemURL.path));
            jSONObject.put("type", localFilesystemURL.isDirectory ? "text/directory" : this.resourceApi.getMimeType(toNativeUri(localFilesystemURL)));
            jSONObject.put("name", new File(localFilesystemURL.path).getName());
            jSONObject.put("fullPath", localFilesystemURL.path);
            jSONObject.put("lastModifiedDate", 0);
            return jSONObject;
        } catch (JSONException unused) {
            return null;
        }
    }

    @Override // org.apache.cordova.file.Filesystem
    long writeToFileAtURL(LocalFilesystemURL localFilesystemURL, String str, int i, boolean z) throws NoModificationAllowedException, IOException {
        throw new NoModificationAllowedException("Assets are read-only");
    }

    @Override // org.apache.cordova.file.Filesystem
    long truncateFileAtURL(LocalFilesystemURL localFilesystemURL, long j) throws IOException, NoModificationAllowedException {
        throw new NoModificationAllowedException("Assets are read-only");
    }

    @Override // org.apache.cordova.file.Filesystem
    String filesystemPathForURL(LocalFilesystemURL localFilesystemURL) {
        return new File(this.rootUri.getPath(), localFilesystemURL.path).toString();
    }

    @Override // org.apache.cordova.file.Filesystem
    boolean removeFileAtLocalURL(LocalFilesystemURL localFilesystemURL) throws InvalidModificationException, NoModificationAllowedException {
        throw new NoModificationAllowedException("Assets are read-only");
    }

    @Override // org.apache.cordova.file.Filesystem
    boolean recursiveRemoveFileAtLocalURL(LocalFilesystemURL localFilesystemURL) throws NoModificationAllowedException {
        throw new NoModificationAllowedException("Assets are read-only");
    }
}
