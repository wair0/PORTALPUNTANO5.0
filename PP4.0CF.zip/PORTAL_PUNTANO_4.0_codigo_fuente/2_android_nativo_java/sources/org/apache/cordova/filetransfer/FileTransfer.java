package org.apache.cordova.filetransfer;

import android.net.Uri;
import android.webkit.CookieManager;
import com.silkimen.http.HttpRequest;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.zip.GZIPInputStream;
import java.util.zip.Inflater;
import org.apache.cordova.AllowList;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaResourceApi;
import org.apache.cordova.LOG;
import org.apache.cordova.PluginManager;
import org.apache.cordova.PluginResult;
import org.apache.cordova.file.FileUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class FileTransfer extends CordovaPlugin {
    public static int ABORTED_ERR = 4;
    private static final String BOUNDARY = "+++++";
    public static int CONNECTION_ERR = 3;
    public static int FILE_NOT_FOUND_ERR = 1;
    public static int INVALID_URL_ERR = 2;
    private static final String LINE_END = "\r\n";
    private static final String LINE_START = "--";
    private static final String LOG_TAG = "FileTransfer";
    private static final int MAX_BUFFER_SIZE = 16384;
    public static int NOT_MODIFIED_ERR = 5;
    private static HashMap<String, RequestContext> activeRequests = new HashMap<>();

    private static final class RequestContext {
        boolean aborted;
        CallbackContext callbackContext;
        HttpURLConnection connection;
        String source;
        String target;
        File targetFile;

        RequestContext(String str, String str2, CallbackContext callbackContext) {
            this.source = str;
            this.target = str2;
            this.callbackContext = callbackContext;
        }

        void sendPluginResult(PluginResult pluginResult) {
            synchronized (this) {
                if (!this.aborted) {
                    this.callbackContext.sendPluginResult(pluginResult);
                }
            }
        }
    }

    private static abstract class TrackingInputStream extends FilterInputStream {
        public abstract long getTotalRawBytesRead();

        public TrackingInputStream(InputStream inputStream) {
            super(inputStream);
        }
    }

    private static class ExposedGZIPInputStream extends GZIPInputStream {
        public ExposedGZIPInputStream(InputStream inputStream) throws IOException {
            super(inputStream);
        }

        public Inflater getInflater() {
            return this.inf;
        }
    }

    private static class TrackingGZIPInputStream extends TrackingInputStream {
        private ExposedGZIPInputStream gzin;

        public TrackingGZIPInputStream(ExposedGZIPInputStream exposedGZIPInputStream) throws IOException {
            super(exposedGZIPInputStream);
            this.gzin = exposedGZIPInputStream;
        }

        @Override // org.apache.cordova.filetransfer.FileTransfer.TrackingInputStream
        public long getTotalRawBytesRead() {
            return this.gzin.getInflater().getBytesRead();
        }
    }

    private static class SimpleTrackingInputStream extends TrackingInputStream {
        private long bytesRead;

        public SimpleTrackingInputStream(InputStream inputStream) {
            super(inputStream);
            this.bytesRead = 0L;
        }

        private int updateBytesRead(int i) {
            if (i != -1) {
                this.bytesRead += i;
            }
            return i;
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public int read() throws IOException {
            return updateBytesRead(super.read());
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public int read(byte[] bArr, int i, int i2) throws IOException {
            return updateBytesRead(super.read(bArr, i, i2));
        }

        @Override // org.apache.cordova.filetransfer.FileTransfer.TrackingInputStream
        public long getTotalRawBytesRead() {
            return this.bytesRead;
        }
    }

    @Override // org.apache.cordova.CordovaPlugin
    public boolean execute(String str, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        if (str.equals("upload") || str.equals("download")) {
            String string = jSONArray.getString(0);
            String string2 = jSONArray.getString(1);
            if (str.equals("upload")) {
                upload(string, string2, jSONArray, callbackContext);
            } else {
                download(string, string2, jSONArray, callbackContext);
            }
            return true;
        }
        if (!str.equals("abort")) {
            return false;
        }
        abort(jSONArray.getString(0));
        callbackContext.success();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void addHeadersToRequest(URLConnection uRLConnection, JSONObject jSONObject) {
        try {
            Iterator<String> keys = jSONObject.keys();
            while (keys.hasNext()) {
                String obj = keys.next().toString();
                String replaceAll = obj.replaceAll("\\n", "").replaceAll("\\s+", "").replaceAll(":", "").replaceAll("[^\\x20-\\x7E]+", "");
                JSONArray optJSONArray = jSONObject.optJSONArray(obj);
                if (optJSONArray == null) {
                    optJSONArray = new JSONArray();
                    optJSONArray.put(jSONObject.getString(obj).replaceAll("\\s+", " ").replaceAll("\\n", " ").replaceAll("[^\\x20-\\x7E]+", " "));
                }
                uRLConnection.setRequestProperty(replaceAll, optJSONArray.getString(0));
                for (int i = 1; i < optJSONArray.length(); i++) {
                    uRLConnection.addRequestProperty(obj, optJSONArray.getString(i));
                }
            }
        } catch (JSONException unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getCookies(String str) {
        String str2;
        boolean z = true;
        try {
            Method method = this.webView.getClass().getMethod("getCookieManager", new Class[0]);
            Class<?> returnType = method.getReturnType();
            str2 = (String) returnType.getMethod("getCookie", String.class).invoke(returnType.cast(method.invoke(this.webView, new Object[0])), str);
        } catch (ClassCastException | IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            str2 = null;
            z = false;
        }
        return (z || CookieManager.getInstance() == null) ? str2 : CookieManager.getInstance().getCookie(str);
    }

    private void upload(final String str, final String str2, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        int i;
        boolean z;
        LOG.d(LOG_TAG, "upload " + str + " to " + str2);
        final String argument = getArgument(jSONArray, 2, "file");
        final String argument2 = getArgument(jSONArray, 3, "image.jpg");
        final String argument3 = getArgument(jSONArray, 4, "image/jpeg");
        final JSONObject jSONObject = jSONArray.optJSONObject(5) == null ? new JSONObject() : jSONArray.optJSONObject(5);
        final boolean z2 = jSONArray.optBoolean(7) || jSONArray.isNull(7);
        final JSONObject optJSONObject = jSONArray.optJSONObject(8) == null ? jSONObject.optJSONObject("headers") : jSONArray.optJSONObject(8);
        final String string = jSONArray.getString(9);
        final String argument4 = getArgument(jSONArray, 10, HttpRequest.METHOD_POST);
        final CordovaResourceApi resourceApi = this.webView.getResourceApi();
        LOG.d(LOG_TAG, "fileKey: " + argument);
        LOG.d(LOG_TAG, "fileName: " + argument2);
        LOG.d(LOG_TAG, "mimeType: " + argument3);
        LOG.d(LOG_TAG, "params: " + jSONObject);
        LOG.d(LOG_TAG, "chunkedMode: " + z2);
        LOG.d(LOG_TAG, "headers: " + optJSONObject);
        LOG.d(LOG_TAG, "objectId: " + string);
        LOG.d(LOG_TAG, "httpMethod: " + argument4);
        final Uri remapUri = resourceApi.remapUri(Uri.parse(str2));
        int uriType = CordovaResourceApi.getUriType(remapUri);
        if (uriType == 6) {
            i = 5;
            z = true;
        } else {
            i = 5;
            z = false;
        }
        if (uriType != i && !z) {
            JSONObject createFileTransferError = createFileTransferError(INVALID_URL_ERR, str, str2, null, 0, null);
            LOG.e(LOG_TAG, "Unsupported URI: " + remapUri);
            callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError));
        } else {
            final RequestContext requestContext = new RequestContext(str, str2, callbackContext);
            synchronized (activeRequests) {
                activeRequests.put(string, requestContext);
            }
            final boolean z3 = z;
            this.f5cordova.getThreadPool().execute(new Runnable() { // from class: org.apache.cordova.filetransfer.FileTransfer.1
                /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
                    jadx.core.utils.exceptions.JadxRuntimeException: Can't find top splitter block for handler:B:260:0x03f0
                    	at jadx.core.utils.BlockUtils.getTopSplitterForHandler(BlockUtils.java:1179)
                    	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.collectHandlerRegions(ExcHandlersRegionMaker.java:53)
                    	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.process(ExcHandlersRegionMaker.java:38)
                    	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:27)
                    */
                /* JADX WARN: Removed duplicated region for block: B:18:0x005f A[Catch: IOException -> 0x0059, all -> 0x040c, FileNotFoundException -> 0x0416, JSONException -> 0x0453, TRY_LEAVE, TryCatch #23 {IOException -> 0x0059, blocks: (B:291:0x004e, B:18:0x005f, B:21:0x0070, B:24:0x0079, B:28:0x0083, B:29:0x0089, B:31:0x008f, B:34:0x009f, B:42:0x015b), top: B:290:0x004e }] */
                /* JADX WARN: Removed duplicated region for block: B:21:0x0070 A[Catch: IOException -> 0x0059, all -> 0x040c, FileNotFoundException -> 0x0416, JSONException -> 0x0453, TRY_ENTER, TRY_LEAVE, TryCatch #23 {IOException -> 0x0059, blocks: (B:291:0x004e, B:18:0x005f, B:21:0x0070, B:24:0x0079, B:28:0x0083, B:29:0x0089, B:31:0x008f, B:34:0x009f, B:42:0x015b), top: B:290:0x004e }] */
                /* JADX WARN: Removed duplicated region for block: B:24:0x0079 A[Catch: IOException -> 0x0059, all -> 0x040c, FileNotFoundException -> 0x0416, JSONException -> 0x0453, TRY_ENTER, TRY_LEAVE, TryCatch #23 {IOException -> 0x0059, blocks: (B:291:0x004e, B:18:0x005f, B:21:0x0070, B:24:0x0079, B:28:0x0083, B:29:0x0089, B:31:0x008f, B:34:0x009f, B:42:0x015b), top: B:290:0x004e }] */
                /* JADX WARN: Removed duplicated region for block: B:271:0x01aa A[Catch: IOException -> 0x0405, all -> 0x040c, FileNotFoundException -> 0x0416, JSONException -> 0x0453, TRY_ENTER, TRY_LEAVE, TryCatch #12 {IOException -> 0x0405, blocks: (B:49:0x016d, B:62:0x01b8, B:271:0x01aa), top: B:48:0x016d }] */
                /* JADX WARN: Removed duplicated region for block: B:284:0x016c  */
                /* JADX WARN: Removed duplicated region for block: B:31:0x008f A[Catch: IOException -> 0x0059, JSONException -> 0x00df, all -> 0x040c, FileNotFoundException -> 0x0416, TryCatch #23 {IOException -> 0x0059, blocks: (B:291:0x004e, B:18:0x005f, B:21:0x0070, B:24:0x0079, B:28:0x0083, B:29:0x0089, B:31:0x008f, B:34:0x009f, B:42:0x015b), top: B:290:0x004e }] */
                /* JADX WARN: Removed duplicated region for block: B:42:0x015b A[Catch: IOException -> 0x0059, all -> 0x040c, FileNotFoundException -> 0x0416, JSONException -> 0x0453, TRY_ENTER, TRY_LEAVE, TryCatch #23 {IOException -> 0x0059, blocks: (B:291:0x004e, B:18:0x005f, B:21:0x0070, B:24:0x0079, B:28:0x0083, B:29:0x0089, B:31:0x008f, B:34:0x009f, B:42:0x015b), top: B:290:0x004e }] */
                /* JADX WARN: Removed duplicated region for block: B:56:0x0195 A[ADDED_TO_REGION] */
                /* JADX WARN: Removed duplicated region for block: B:61:0x019f A[Catch: IOException -> 0x0169, all -> 0x040c, FileNotFoundException -> 0x0416, JSONException -> 0x0453, TRY_LEAVE, TryCatch #31 {IOException -> 0x0169, blocks: (B:47:0x0161, B:51:0x0189, B:61:0x019f, B:237:0x01c9, B:96:0x03fc, B:97:0x0404, B:273:0x01b1), top: B:46:0x0161 }] */
                /* JADX WARN: Removed duplicated region for block: B:69:0x01c2 A[EXC_TOP_SPLITTER, SYNTHETIC] */
                @Override // java.lang.Runnable
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public void run() {
                    /*
                        Method dump skipped, instructions count: 1324
                        To view this dump add '--comments-level debug' option
                    */
                    throw new UnsupportedOperationException("Method not decompiled: org.apache.cordova.filetransfer.FileTransfer.AnonymousClass1.run():void");
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void safeClose(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException unused) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static TrackingInputStream getInputStream(URLConnection uRLConnection) throws IOException {
        String contentEncoding = uRLConnection.getContentEncoding();
        if (contentEncoding != null && contentEncoding.equalsIgnoreCase(HttpRequest.ENCODING_GZIP)) {
            return new TrackingGZIPInputStream(new ExposedGZIPInputStream(uRLConnection.getInputStream()));
        }
        return new SimpleTrackingInputStream(uRLConnection.getInputStream());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static JSONObject createFileTransferError(int i, String str, String str2, URLConnection uRLConnection, Throwable th) {
        StringBuilder sb = new StringBuilder();
        int i2 = 0;
        String str3 = null;
        if (uRLConnection != null) {
            try {
                if (uRLConnection instanceof HttpURLConnection) {
                    i2 = ((HttpURLConnection) uRLConnection).getResponseCode();
                    InputStream errorStream = ((HttpURLConnection) uRLConnection).getErrorStream();
                    if (errorStream != null) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(errorStream, HttpRequest.CHARSET_UTF8));
                        try {
                            String readLine = bufferedReader.readLine();
                            while (readLine != null) {
                                sb.append(readLine);
                                readLine = bufferedReader.readLine();
                                if (readLine != null) {
                                    sb.append('\n');
                                }
                            }
                            String sb2 = sb.toString();
                            try {
                                str3 = sb2;
                            } catch (Throwable th2) {
                                th = th2;
                                str3 = sb2;
                                LOG.w(LOG_TAG, "Error getting HTTP status code from connection.", th);
                                return createFileTransferError(i, str, str2, str3, Integer.valueOf(i2), th);
                            }
                        } finally {
                            bufferedReader.close();
                        }
                    }
                }
            } catch (Throwable th3) {
                th = th3;
            }
        }
        return createFileTransferError(i, str, str2, str3, Integer.valueOf(i2), th);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static JSONObject createFileTransferError(int i, String str, String str2, String str3, Integer num, Throwable th) {
        JSONObject jSONObject = null;
        try {
            JSONObject jSONObject2 = new JSONObject();
            try {
                jSONObject2.put("code", i);
                jSONObject2.put("source", str);
                jSONObject2.put("target", str2);
                if (str3 != null) {
                    jSONObject2.put("body", str3);
                }
                if (num != null) {
                    jSONObject2.put("http_status", num);
                }
                if (th == null) {
                    return jSONObject2;
                }
                String message = th.getMessage();
                if (message == null || "".equals(message)) {
                    message = th.toString();
                }
                jSONObject2.put("exception", message);
                return jSONObject2;
            } catch (JSONException e) {
                e = e;
                jSONObject = jSONObject2;
                LOG.e(LOG_TAG, e.getMessage(), e);
                return jSONObject;
            }
        } catch (JSONException e2) {
            e = e2;
        }
    }

    private static String getArgument(JSONArray jSONArray, int i, String str) {
        String optString;
        return (jSONArray.length() <= i || (optString = jSONArray.optString(i)) == null || "null".equals(optString)) ? str : optString;
    }

    private void download(final String str, final String str2, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        LOG.d(LOG_TAG, "download " + str + " to " + str2);
        final CordovaResourceApi resourceApi = this.webView.getResourceApi();
        final String string = jSONArray.getString(3);
        final JSONObject optJSONObject = jSONArray.optJSONObject(4);
        final Uri remapUri = resourceApi.remapUri(Uri.parse(str));
        int uriType = CordovaResourceApi.getUriType(remapUri);
        boolean z = ((uriType == 6) || uriType == 5) ? false : true;
        if (uriType == -1) {
            JSONObject createFileTransferError = createFileTransferError(INVALID_URL_ERR, str, str2, null, 0, null);
            LOG.e(LOG_TAG, "Unsupported URI: " + remapUri);
            callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError));
            return;
        }
        Boolean bool = z ? true : null;
        if (bool == null) {
            try {
                bool = Boolean.valueOf(((AllowList) this.webView.getClass().getMethod("getWhitelist", new Class[0]).invoke(this.webView, new Object[0])).isUrlAllowListed(str));
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            }
        }
        if (bool == null) {
            try {
                PluginManager pluginManager = (PluginManager) this.webView.getClass().getMethod("getPluginManager", new Class[0]).invoke(this.webView, new Object[0]);
                bool = (Boolean) pluginManager.getClass().getMethod("shouldAllowRequest", String.class).invoke(pluginManager, str);
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused2) {
            }
        }
        if (!Boolean.TRUE.equals(bool)) {
            LOG.w(LOG_TAG, "Source URL is not in white list: '" + str + "'");
            callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError(CONNECTION_ERR, str, str2, null, 401, null)));
            return;
        }
        final RequestContext requestContext = new RequestContext(str, str2, callbackContext);
        synchronized (activeRequests) {
            activeRequests.put(string, requestContext);
        }
        final boolean z2 = z;
        this.f5cordova.getThreadPool().execute(new Runnable() { // from class: org.apache.cordova.filetransfer.FileTransfer.2
            /* JADX WARN: Code restructure failed: missing block: B:145:0x03df, code lost:
            
                if (r4 != null) goto L194;
             */
            /* JADX WARN: Code restructure failed: missing block: B:146:0x0354, code lost:
            
                r4.delete();
                r3 = r3;
                r6 = r6;
             */
            /* JADX WARN: Code restructure failed: missing block: B:162:0x039d, code lost:
            
                if (r4 != null) goto L194;
             */
            /* JADX WARN: Code restructure failed: missing block: B:178:0x0352, code lost:
            
                if (r4 != null) goto L194;
             */
            /* JADX WARN: Code restructure failed: missing block: B:194:0x031a, code lost:
            
                if (r4 != null) goto L194;
             */
            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Removed duplicated region for block: B:135:0x03c7 A[EXC_TOP_SPLITTER, SYNTHETIC] */
            /* JADX WARN: Removed duplicated region for block: B:156:0x0385 A[EXC_TOP_SPLITTER, SYNTHETIC] */
            /* JADX WARN: Removed duplicated region for block: B:172:0x033a A[EXC_TOP_SPLITTER, SYNTHETIC] */
            /* JADX WARN: Removed duplicated region for block: B:188:0x0302 A[EXC_TOP_SPLITTER, SYNTHETIC] */
            /* JADX WARN: Type inference failed for: r1v1 */
            /* JADX WARN: Type inference failed for: r1v19, types: [org.apache.cordova.filetransfer.FileTransfer$RequestContext] */
            /* JADX WARN: Type inference failed for: r1v6 */
            /* JADX WARN: Type inference failed for: r3v3, types: [java.util.HashMap] */
            /* JADX WARN: Type inference failed for: r3v4, types: [java.util.HashMap] */
            /* JADX WARN: Type inference failed for: r3v5, types: [java.util.HashMap] */
            /* JADX WARN: Type inference failed for: r3v8, types: [java.util.HashMap] */
            /* JADX WARN: Type inference failed for: r6v11, types: [java.net.URLConnection] */
            /* JADX WARN: Type inference failed for: r6v13, types: [java.net.URLConnection] */
            /* JADX WARN: Type inference failed for: r6v14, types: [java.net.URLConnection] */
            /* JADX WARN: Type inference failed for: r6v25, types: [java.net.HttpURLConnection, java.net.URLConnection] */
            /* JADX WARN: Type inference failed for: r6v26, types: [java.net.HttpURLConnection, java.net.URLConnection] */
            /* JADX WARN: Type inference failed for: r6v30 */
            /* JADX WARN: Type inference failed for: r6v31 */
            /* JADX WARN: Type inference failed for: r6v32 */
            /* JADX WARN: Type inference failed for: r6v33 */
            /* JADX WARN: Type inference failed for: r6v34 */
            /* JADX WARN: Type inference failed for: r6v35 */
            /* JADX WARN: Type inference failed for: r6v36 */
            /* JADX WARN: Type inference failed for: r6v37 */
            /* JADX WARN: Type inference failed for: r6v38 */
            /* JADX WARN: Type inference failed for: r6v39 */
            /* JADX WARN: Type inference failed for: r6v40 */
            /* JADX WARN: Type inference failed for: r6v41 */
            /* JADX WARN: Type inference failed for: r6v42 */
            /* JADX WARN: Type inference failed for: r6v43 */
            /* JADX WARN: Type inference failed for: r6v44 */
            /* JADX WARN: Type inference failed for: r6v45 */
            /* JADX WARN: Type inference failed for: r6v46 */
            /* JADX WARN: Type inference failed for: r6v47 */
            /* JADX WARN: Type inference failed for: r6v48 */
            /* JADX WARN: Type inference failed for: r6v53 */
            /* JADX WARN: Type inference failed for: r6v54 */
            /* JADX WARN: Type inference failed for: r6v55 */
            /* JADX WARN: Type inference failed for: r6v59 */
            /* JADX WARN: Type inference failed for: r6v60 */
            /* JADX WARN: Type inference failed for: r6v61 */
            /* JADX WARN: Type inference failed for: r6v9, types: [java.net.URLConnection] */
            @Override // java.lang.Runnable
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public void run() {
                boolean z3;
                File file;
                PluginResult pluginResult;
                boolean z4;
                PluginResult pluginResult2;
                boolean z5;
                PluginResult pluginResult3;
                boolean z6;
                PluginResult pluginResult4;
                PluginResult pluginResult5;
                ?? r6;
                boolean z7;
                PluginResult pluginResult6;
                ?? r3;
                PluginResult pluginResult7;
                boolean z8;
                ?? r32;
                ?? r62;
                boolean z9;
                ?? r33;
                PluginResult pluginResult8;
                Throwable th;
                ?? r63;
                ?? r64;
                boolean z10;
                ?? r34;
                boolean z11;
                TrackingInputStream trackingInputStream;
                ?? r65;
                OutputStream outputStream;
                PluginManager pluginManager2;
                PluginResult pluginResult9;
                if (requestContext.aborted) {
                    return;
                }
                Uri parse = Uri.parse(str2);
                CordovaResourceApi cordovaResourceApi = resourceApi;
                if (parse.getScheme() == null) {
                    parse = Uri.fromFile(new File(str2));
                }
                Uri remapUri2 = cordovaResourceApi.remapUri(parse);
                ?? r1 = 1;
                boolean z12 = true;
                boolean z13 = true;
                boolean z14 = true;
                boolean z15 = true;
                Throwable th2 = null;
                try {
                    try {
                        file = resourceApi.mapUriToFile(remapUri2);
                    } catch (Throwable th3) {
                        synchronized (FileTransfer.activeRequests) {
                            FileTransfer.activeRequests.remove(string);
                            if (pluginResult5 == null) {
                                pluginResult5 = new PluginResult(PluginResult.Status.ERROR, FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r63, th2));
                            }
                            if (r1 == 0 && pluginResult5.getStatus() != PluginResult.Status.OK.ordinal() && file != null) {
                                file.delete();
                            }
                            requestContext.sendPluginResult(pluginResult5);
                            throw th3;
                        }
                    }
                } catch (FileNotFoundException e) {
                    e = e;
                    z6 = false;
                    file = null;
                    pluginResult4 = null;
                } catch (IOException e2) {
                    e = e2;
                    z5 = false;
                    file = null;
                    pluginResult3 = null;
                } catch (JSONException e3) {
                    e = e3;
                    z4 = false;
                    file = null;
                    pluginResult2 = null;
                } catch (Throwable th4) {
                    th = th4;
                    z3 = false;
                    file = null;
                    pluginResult = null;
                }
                try {
                    requestContext.targetFile = file;
                    LOG.d(FileTransfer.LOG_TAG, "Download file:" + remapUri);
                    FileProgressResult fileProgressResult = new FileProgressResult();
                    if (z2) {
                        CordovaResourceApi.OpenForReadResult openForRead = resourceApi.openForRead(remapUri);
                        if (openForRead.length != -1) {
                            fileProgressResult.setLengthComputable(true);
                            fileProgressResult.setTotal(openForRead.length);
                        }
                        trackingInputStream = new SimpleTrackingInputStream(openForRead.inputStream);
                        z11 = false;
                        r65 = 0;
                        pluginResult5 = null;
                    } else {
                        ?? createHttpConnection = resourceApi.createHttpConnection(remapUri);
                        try {
                            createHttpConnection.setRequestMethod(HttpRequest.METHOD_GET);
                            String cookies = FileTransfer.this.getCookies(remapUri.toString());
                            if (cookies != null) {
                                createHttpConnection.setRequestProperty("cookie", cookies);
                            }
                            createHttpConnection.setRequestProperty(HttpRequest.HEADER_ACCEPT_ENCODING, HttpRequest.ENCODING_GZIP);
                            JSONObject jSONObject = optJSONObject;
                            if (jSONObject != null) {
                                FileTransfer.addHeadersToRequest(createHttpConnection, jSONObject);
                            }
                            createHttpConnection.connect();
                            if (createHttpConnection.getResponseCode() == 304) {
                                try {
                                    createHttpConnection.disconnect();
                                    LOG.d(FileTransfer.LOG_TAG, "Resource not modified: " + str);
                                    pluginResult5 = new PluginResult(PluginResult.Status.ERROR, FileTransfer.createFileTransferError(FileTransfer.NOT_MODIFIED_ERR, str, str2, createHttpConnection, null));
                                    z11 = true;
                                    trackingInputStream = null;
                                    r65 = createHttpConnection;
                                } catch (FileNotFoundException e4) {
                                    e = e4;
                                    pluginResult5 = null;
                                    z10 = z12;
                                    r64 = createHttpConnection;
                                    JSONObject createFileTransferError2 = FileTransfer.createFileTransferError(FileTransfer.FILE_NOT_FOUND_ERR, str, str2, r64, e);
                                    LOG.e(FileTransfer.LOG_TAG, createFileTransferError2.toString(), e);
                                    pluginResult6 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError2);
                                    synchronized (FileTransfer.activeRequests) {
                                        r34 = FileTransfer.activeRequests;
                                        r34.remove(string);
                                        th2 = r34;
                                        r63 = r64;
                                    }
                                    if (!z10) {
                                        th2 = r34;
                                        th2 = r34;
                                        r63 = r64;
                                        r63 = r64;
                                        th = r34;
                                        pluginResult8 = r64;
                                        if (pluginResult6.getStatus() != PluginResult.Status.OK.ordinal()) {
                                        }
                                    }
                                    r1 = requestContext;
                                    r1.sendPluginResult(pluginResult6);
                                    return;
                                } catch (IOException e5) {
                                    e = e5;
                                    pluginResult5 = null;
                                    z9 = z13;
                                    r62 = createHttpConnection;
                                    JSONObject createFileTransferError3 = FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r62, e);
                                    LOG.e(FileTransfer.LOG_TAG, createFileTransferError3.toString(), e);
                                    pluginResult6 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError3);
                                    synchronized (FileTransfer.activeRequests) {
                                        r33 = FileTransfer.activeRequests;
                                        r33.remove(string);
                                        th2 = r33;
                                        r63 = r62;
                                    }
                                    if (!z9) {
                                        th2 = r33;
                                        th2 = r33;
                                        r63 = r62;
                                        r63 = r62;
                                        th = r33;
                                        pluginResult8 = r62;
                                        if (pluginResult6.getStatus() != PluginResult.Status.OK.ordinal()) {
                                        }
                                    }
                                    r1 = requestContext;
                                    r1.sendPluginResult(pluginResult6);
                                    return;
                                } catch (JSONException e6) {
                                    e = e6;
                                    pluginResult5 = null;
                                    z8 = z14;
                                    pluginResult7 = createHttpConnection;
                                    LOG.e(FileTransfer.LOG_TAG, e.getMessage(), e);
                                    pluginResult6 = new PluginResult(PluginResult.Status.JSON_EXCEPTION);
                                    synchronized (FileTransfer.activeRequests) {
                                        r32 = FileTransfer.activeRequests;
                                        r32.remove(string);
                                        th2 = r32;
                                        r63 = pluginResult7;
                                    }
                                    if (!z8) {
                                        th2 = r32;
                                        th2 = r32;
                                        r63 = pluginResult7;
                                        r63 = pluginResult7;
                                        th = r32;
                                        pluginResult8 = pluginResult7;
                                        if (pluginResult6.getStatus() != PluginResult.Status.OK.ordinal()) {
                                        }
                                    }
                                    r1 = requestContext;
                                    r1.sendPluginResult(pluginResult6);
                                    return;
                                } catch (Throwable th5) {
                                    th = th5;
                                    pluginResult5 = null;
                                    z7 = z15;
                                    r6 = createHttpConnection;
                                    JSONObject createFileTransferError4 = FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r6, th);
                                    LOG.e(FileTransfer.LOG_TAG, createFileTransferError4.toString(), th);
                                    pluginResult6 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError4);
                                    synchronized (FileTransfer.activeRequests) {
                                        r3 = FileTransfer.activeRequests;
                                        r3.remove(string);
                                        th2 = r3;
                                        r63 = r6;
                                    }
                                    if (!z7) {
                                        th2 = r3;
                                        th2 = r3;
                                        r63 = r6;
                                        r63 = r6;
                                        th = r3;
                                        pluginResult8 = r6;
                                        if (pluginResult6.getStatus() != PluginResult.Status.OK.ordinal()) {
                                        }
                                    }
                                    r1 = requestContext;
                                    r1.sendPluginResult(pluginResult6);
                                    return;
                                }
                            } else {
                                if ((createHttpConnection.getContentEncoding() == null || createHttpConnection.getContentEncoding().equalsIgnoreCase(HttpRequest.ENCODING_GZIP)) && createHttpConnection.getContentLength() != -1) {
                                    fileProgressResult.setLengthComputable(true);
                                    fileProgressResult.setTotal(createHttpConnection.getContentLength());
                                }
                                trackingInputStream = FileTransfer.getInputStream(createHttpConnection);
                                z11 = false;
                                pluginResult5 = null;
                                r65 = createHttpConnection;
                            }
                        } catch (FileNotFoundException e7) {
                            e = e7;
                            z12 = false;
                        } catch (IOException e8) {
                            e = e8;
                            z13 = false;
                        } catch (JSONException e9) {
                            e = e9;
                            z14 = false;
                        } catch (Throwable th6) {
                            th = th6;
                            z15 = false;
                        }
                    }
                    try {
                        if (!z11) {
                            try {
                                synchronized (requestContext) {
                                    if (requestContext.aborted) {
                                        synchronized (requestContext) {
                                            requestContext.connection = null;
                                        }
                                        FileTransfer.safeClose(trackingInputStream);
                                        FileTransfer.safeClose(null);
                                        synchronized (FileTransfer.activeRequests) {
                                            FileTransfer.activeRequests.remove(string);
                                        }
                                        if (pluginResult5 == null) {
                                            pluginResult5 = new PluginResult(PluginResult.Status.ERROR, FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r65, null));
                                        }
                                        if (!z11 && pluginResult5.getStatus() != PluginResult.Status.OK.ordinal() && file != null) {
                                            file.delete();
                                        }
                                        requestContext.sendPluginResult(pluginResult5);
                                        return;
                                    }
                                    requestContext.connection = r65;
                                    byte[] bArr = new byte[16384];
                                    outputStream = resourceApi.openOutputStream(remapUri2);
                                    while (true) {
                                        try {
                                            int read = trackingInputStream.read(bArr);
                                            if (read <= 0) {
                                                break;
                                            }
                                            outputStream.write(bArr, 0, read);
                                            fileProgressResult.setLoaded(trackingInputStream.getTotalRawBytesRead());
                                            PluginResult pluginResult10 = new PluginResult(PluginResult.Status.OK, fileProgressResult.toJSONObject());
                                            pluginResult10.setKeepCallback(true);
                                            requestContext.sendPluginResult(pluginResult10);
                                        } catch (Throwable th7) {
                                            th = th7;
                                            synchronized (requestContext) {
                                                requestContext.connection = null;
                                            }
                                            FileTransfer.safeClose(trackingInputStream);
                                            FileTransfer.safeClose(outputStream);
                                            throw th;
                                        }
                                    }
                                    synchronized (requestContext) {
                                        requestContext.connection = null;
                                    }
                                    FileTransfer.safeClose(trackingInputStream);
                                    FileTransfer.safeClose(outputStream);
                                    LOG.d(FileTransfer.LOG_TAG, "Saved file: " + str2);
                                    Class<?> cls = FileTransfer.this.webView.getClass();
                                    try {
                                        pluginManager2 = (PluginManager) cls.getMethod("getPluginManager", new Class[0]).invoke(FileTransfer.this.webView, new Object[0]);
                                    } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused3) {
                                        pluginManager2 = null;
                                    }
                                    if (pluginManager2 == null) {
                                        try {
                                            pluginManager2 = (PluginManager) cls.getField("pluginManager").get(FileTransfer.this.webView);
                                        } catch (IllegalAccessException | NoSuchFieldException unused4) {
                                        }
                                    }
                                    file = resourceApi.mapUriToFile(remapUri2);
                                    requestContext.targetFile = file;
                                    FileUtils fileUtils = (FileUtils) pluginManager2.getPlugin("File");
                                    if (fileUtils != null) {
                                        JSONObject entryForFile = fileUtils.getEntryForFile(file);
                                        if (entryForFile != null) {
                                            pluginResult9 = new PluginResult(PluginResult.Status.OK, entryForFile);
                                        } else {
                                            JSONObject createFileTransferError5 = FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r65, null);
                                            LOG.e(FileTransfer.LOG_TAG, "File plugin cannot represent download path");
                                            pluginResult9 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError5);
                                        }
                                        pluginResult5 = pluginResult9;
                                    } else {
                                        LOG.e(FileTransfer.LOG_TAG, "File plugin not found; cannot save downloaded file");
                                        pluginResult5 = new PluginResult(PluginResult.Status.ERROR, "File plugin not found; cannot save downloaded file");
                                    }
                                }
                            } catch (Throwable th8) {
                                th = th8;
                                outputStream = null;
                            }
                        }
                        synchronized (FileTransfer.activeRequests) {
                            FileTransfer.activeRequests.remove(string);
                        }
                        if (pluginResult5 == null) {
                            pluginResult5 = new PluginResult(PluginResult.Status.ERROR, FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r65, null));
                        }
                        if (!z11 && pluginResult5.getStatus() != PluginResult.Status.OK.ordinal() && file != null) {
                            file.delete();
                        }
                        requestContext.sendPluginResult(pluginResult5);
                    } catch (FileNotFoundException e10) {
                        e = e10;
                        z10 = z11;
                        r64 = r65;
                        JSONObject createFileTransferError22 = FileTransfer.createFileTransferError(FileTransfer.FILE_NOT_FOUND_ERR, str, str2, r64, e);
                        LOG.e(FileTransfer.LOG_TAG, createFileTransferError22.toString(), e);
                        pluginResult6 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError22);
                        synchronized (FileTransfer.activeRequests) {
                        }
                    } catch (IOException e11) {
                        e = e11;
                        z9 = z11;
                        r62 = r65;
                        JSONObject createFileTransferError32 = FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r62, e);
                        LOG.e(FileTransfer.LOG_TAG, createFileTransferError32.toString(), e);
                        pluginResult6 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError32);
                        synchronized (FileTransfer.activeRequests) {
                        }
                    } catch (JSONException e12) {
                        e = e12;
                        z8 = z11;
                        pluginResult7 = r65;
                        LOG.e(FileTransfer.LOG_TAG, e.getMessage(), e);
                        pluginResult6 = new PluginResult(PluginResult.Status.JSON_EXCEPTION);
                        synchronized (FileTransfer.activeRequests) {
                        }
                    } catch (Throwable th9) {
                        th = th9;
                        z7 = z11;
                        r6 = r65;
                        JSONObject createFileTransferError42 = FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r6, th);
                        LOG.e(FileTransfer.LOG_TAG, createFileTransferError42.toString(), th);
                        pluginResult6 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError42);
                        synchronized (FileTransfer.activeRequests) {
                        }
                    }
                } catch (FileNotFoundException e13) {
                    e = e13;
                    z6 = false;
                    pluginResult4 = null;
                    pluginResult5 = pluginResult4;
                    z10 = z6;
                    r64 = pluginResult4;
                    JSONObject createFileTransferError222 = FileTransfer.createFileTransferError(FileTransfer.FILE_NOT_FOUND_ERR, str, str2, r64, e);
                    LOG.e(FileTransfer.LOG_TAG, createFileTransferError222.toString(), e);
                    pluginResult6 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError222);
                    synchronized (FileTransfer.activeRequests) {
                    }
                } catch (IOException e14) {
                    e = e14;
                    z5 = false;
                    pluginResult3 = null;
                    pluginResult5 = pluginResult3;
                    z9 = z5;
                    r62 = pluginResult3;
                    JSONObject createFileTransferError322 = FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r62, e);
                    LOG.e(FileTransfer.LOG_TAG, createFileTransferError322.toString(), e);
                    pluginResult6 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError322);
                    synchronized (FileTransfer.activeRequests) {
                    }
                } catch (JSONException e15) {
                    e = e15;
                    z4 = false;
                    pluginResult2 = null;
                    pluginResult5 = pluginResult2;
                    z8 = z4;
                    pluginResult7 = pluginResult2;
                    LOG.e(FileTransfer.LOG_TAG, e.getMessage(), e);
                    pluginResult6 = new PluginResult(PluginResult.Status.JSON_EXCEPTION);
                    synchronized (FileTransfer.activeRequests) {
                    }
                } catch (Throwable th10) {
                    th = th10;
                    z3 = false;
                    pluginResult = null;
                    pluginResult5 = pluginResult;
                    z7 = z3;
                    r6 = pluginResult;
                    JSONObject createFileTransferError422 = FileTransfer.createFileTransferError(FileTransfer.CONNECTION_ERR, str, str2, r6, th);
                    LOG.e(FileTransfer.LOG_TAG, createFileTransferError422.toString(), th);
                    pluginResult6 = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError422);
                    synchronized (FileTransfer.activeRequests) {
                    }
                }
            }
        });
    }

    private void abort(String str) {
        final RequestContext remove;
        synchronized (activeRequests) {
            remove = activeRequests.remove(str);
        }
        if (remove != null) {
            this.f5cordova.getThreadPool().execute(new Runnable() { // from class: org.apache.cordova.filetransfer.FileTransfer.3
                @Override // java.lang.Runnable
                public void run() {
                    synchronized (remove) {
                        File file = remove.targetFile;
                        if (file != null) {
                            file.delete();
                        }
                        remove.sendPluginResult(new PluginResult(PluginResult.Status.ERROR, FileTransfer.createFileTransferError(FileTransfer.ABORTED_ERR, remove.source, remove.target, null, -1, null)));
                        remove.aborted = true;
                        if (remove.connection != null) {
                            try {
                                remove.connection.disconnect();
                            } catch (Exception e) {
                                LOG.e(FileTransfer.LOG_TAG, "CB-8431 Catch workaround for fatal exception", e);
                            }
                        }
                    }
                }
            });
        }
    }
}
