package io.github.pwlin.cordova.plugins.fileopener2;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.webkit.MimeTypeMap;
import androidx.core.app.NotificationCompat;
import java.io.File;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class FileOpener2 extends CordovaPlugin {
    @Override // org.apache.cordova.CordovaPlugin
    public boolean execute(String str, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        if (str.equals("open")) {
            String string = jSONArray.getString(0);
            String string2 = jSONArray.getString(1);
            boolean z = true;
            if (jSONArray.length() > 2) {
                z = Boolean.valueOf(jSONArray.getBoolean(2));
            }
            _open(string, string2, z, callbackContext);
        } else if (str.equals("uninstall")) {
            _uninstall(jSONArray.getString(0), callbackContext);
        } else if (str.equals("appIsInstalled")) {
            JSONObject jSONObject = new JSONObject();
            if (_appIsInstalled(jSONArray.getString(0))) {
                jSONObject.put(NotificationCompat.CATEGORY_STATUS, PluginResult.Status.OK.ordinal());
                jSONObject.put("message", "Installed");
            } else {
                jSONObject.put(NotificationCompat.CATEGORY_STATUS, PluginResult.Status.NO_RESULT.ordinal());
                jSONObject.put("message", "Not installed");
            }
            callbackContext.success(jSONObject);
        } else {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put(NotificationCompat.CATEGORY_STATUS, PluginResult.Status.INVALID_ACTION.ordinal());
            jSONObject2.put("message", "Invalid action");
            callbackContext.error(jSONObject2);
        }
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:29:0x002d, code lost:
    
        if (r9.trim().equals("") != false) goto L8;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private void _open(String str, String str2, Boolean bool, CallbackContext callbackContext) throws JSONException {
        Intent intent;
        Uri uriForFile;
        try {
            str = this.webView.getResourceApi().remapUri(Uri.parse(str)).getPath();
        } catch (Exception unused) {
        }
        File file = new File(str);
        if (file.exists()) {
            if (str2 != null) {
                try {
                } catch (ActivityNotFoundException e) {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(NotificationCompat.CATEGORY_STATUS, PluginResult.Status.ERROR.ordinal());
                    jSONObject.put("message", "Activity not found: " + e.getMessage());
                    callbackContext.error(jSONObject);
                    return;
                }
            }
            str2 = _getMimeType(str);
            if (str2.equals("application/vnd.android.package-archive")) {
                intent = new Intent("android.intent.action.INSTALL_PACKAGE");
                if (Build.VERSION.SDK_INT < 24) {
                    uriForFile = Uri.fromFile(file);
                } else {
                    uriForFile = FileProvider.getUriForFile(this.f5cordova.getActivity().getApplicationContext(), this.f5cordova.getActivity().getPackageName() + ".opener.provider", file);
                }
                intent.setDataAndType(uriForFile, str2);
                intent.setFlags(268435457);
            } else {
                intent = new Intent("android.intent.action.VIEW");
                intent.setDataAndType(FileProvider.getUriForFile(this.f5cordova.getActivity().getApplicationContext(), this.f5cordova.getActivity().getPackageName() + ".opener.provider", file), str2);
                intent.setFlags(1073741827);
            }
            if (bool.booleanValue()) {
                this.f5cordova.getActivity().startActivity(intent);
            } else {
                this.f5cordova.getActivity().startActivity(Intent.createChooser(intent, "Open File in..."));
            }
            callbackContext.success();
            return;
        }
        JSONObject jSONObject2 = new JSONObject();
        jSONObject2.put(NotificationCompat.CATEGORY_STATUS, PluginResult.Status.ERROR.ordinal());
        jSONObject2.put("message", "File not found");
        callbackContext.error(jSONObject2);
    }

    private String _getMimeType(String str) {
        String mimeTypeFromExtension;
        int lastIndexOf = str.lastIndexOf(46);
        return (lastIndexOf <= 0 || (mimeTypeFromExtension = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str.substring(lastIndexOf + 1))) == null) ? "*/*" : mimeTypeFromExtension;
    }

    private void _uninstall(String str, CallbackContext callbackContext) throws JSONException {
        if (_appIsInstalled(str)) {
            Intent intent = new Intent("android.intent.action.UNINSTALL_PACKAGE");
            intent.setData(Uri.parse("package:" + str));
            this.f5cordova.getActivity().startActivity(intent);
            callbackContext.success();
            return;
        }
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(NotificationCompat.CATEGORY_STATUS, PluginResult.Status.ERROR.ordinal());
        jSONObject.put("message", "This package is not installed");
        callbackContext.error(jSONObject);
    }

    private boolean _appIsInstalled(String str) {
        try {
            this.f5cordova.getActivity().getPackageManager().getPackageInfo(str, 1);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }
}
