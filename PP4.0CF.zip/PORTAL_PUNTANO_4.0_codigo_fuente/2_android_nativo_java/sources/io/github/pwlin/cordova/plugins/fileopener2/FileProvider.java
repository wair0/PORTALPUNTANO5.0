package io.github.pwlin.cordova.plugins.fileopener2;

/* loaded from: classes.dex */
public class FileProvider extends androidx.core.content.FileProvider {
}
