package io.sqlc;

import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteStatement;
import android.os.Build;
import android.util.Log;
import androidx.core.os.EnvironmentCompat;
import java.io.File;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.cordova.CallbackContext;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
class SQLiteAndroidDatabase {
    private static final boolean isPostHoneycomb;
    File dbFile;
    boolean isTransactionActive = false;
    SQLiteDatabase mydb;
    private static final Pattern FIRST_WORD = Pattern.compile("^[\\s;]*([^\\s;]+)", 2);
    private static final Pattern WHERE_CLAUSE = Pattern.compile("\\s+WHERE\\s+(.+)$", 2);
    private static final Pattern UPDATE_TABLE_NAME = Pattern.compile("^\\s*UPDATE\\s+(\\S+)", 2);
    private static final Pattern DELETE_TABLE_NAME = Pattern.compile("^\\s*DELETE\\s+FROM\\s+(\\S+)", 2);

    enum QueryType {
        update,
        insert,
        delete,
        select,
        begin,
        commit,
        rollback,
        other
    }

    SQLiteAndroidDatabase() {
    }

    static {
        isPostHoneycomb = Build.VERSION.SDK_INT >= 11;
    }

    void open(File file) throws Exception {
        if (!isPostHoneycomb) {
            Log.v("SQLiteAndroidDatabase.open", "INTERNAL PLUGIN ERROR: deprecated android.os.Build.VERSION not supported: " + Build.VERSION.SDK_INT);
            throw new RuntimeException("INTERNAL PLUGIN ERROR: deprecated android.os.Build.VERSION not supported: " + Build.VERSION.SDK_INT);
        }
        this.dbFile = file;
        this.mydb = SQLiteDatabase.openOrCreateDatabase(file, (SQLiteDatabase.CursorFactory) null);
    }

    void closeDatabaseNow() {
        SQLiteDatabase sQLiteDatabase = this.mydb;
        if (sQLiteDatabase != null) {
            if (this.isTransactionActive) {
                try {
                    sQLiteDatabase.endTransaction();
                } catch (Exception e) {
                    Log.v("closeDatabaseNow", "INTERNAL PLUGIN ERROR IGNORED: Not able to end active transaction before closing database: " + e.getMessage());
                    e.printStackTrace();
                }
                this.isTransactionActive = false;
            }
            this.mydb.close();
            this.mydb = null;
        }
    }

    void bugWorkaround() throws Exception {
        closeDatabaseNow();
        open(this.dbFile);
    }

    void executeSqlBatch(String[] strArr, JSONArray[] jSONArrayArr, CallbackContext callbackContext) {
        if (this.mydb == null) {
            callbackContext.error("INTERNAL PLUGIN ERROR: database not open");
            return;
        }
        int length = strArr.length;
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < length; i++) {
            executeSqlBatchStatement(strArr[i], jSONArrayArr[i], jSONArray);
        }
        callbackContext.success(jSONArray);
    }

    /* JADX WARN: Can't wrap try/catch for region: R(25:(3:179|180|(17:182|25|26|27|(1:149)(12:30|31|32|33|34|35|36|37|38|(2:40|41)(1:127)|42|43)|44|(7:111|112|113|114|115|116|117)(1:46)|47|(6:99|100|102|103|104|105)|49|(8:79|80|81|82|83|85|86|87)|(5:63|64|65|66|67)|52|53|(1:55)(1:59)|56|57))|14|15|16|17|18|(3:20|22|23)(1:156)|24|25|26|27|(0)|149|44|(0)(0)|47|(0)|49|(0)|(0)|52|53|(0)(0)|56|57) */
    /* JADX WARN: Code restructure failed: missing block: B:150:0x0290, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:151:0x0292, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:157:0x0297, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:158:0x0298, code lost:
    
        r11 = r10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:159:0x02a1, code lost:
    
        r10 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:161:0x0069, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:162:0x006a, code lost:
    
        r0.printStackTrace();
        r0 = r0.getMessage();
        android.util.Log.v("executeSqlBatch", "SQLiteStatement.executeUpdateDelete(): Error=" + r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:163:0x0087, code lost:
    
        r7 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:166:0x0089, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:168:0x008b, code lost:
    
        r0.printStackTrace();
        r0 = "constraint failure: " + r0.getMessage();
     */
    /* JADX WARN: Code restructure failed: missing block: B:170:0x00a3, code lost:
    
        android.util.Log.v("executeSqlBatch", "SQLiteStatement.executeUpdateDelete(): Error=" + r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:171:0x00b7, code lost:
    
        r7 = -1;
        r10 = 6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:173:0x029a, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:174:0x029b, code lost:
    
        r10 = null;
     */
    /* JADX WARN: Removed duplicated region for block: B:111:0x017f A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x01b9  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x02c4 A[Catch: JSONException -> 0x02f9, TRY_ENTER, TryCatch #10 {JSONException -> 0x02f9, blocks: (B:55:0x02c4, B:59:0x02d7), top: B:53:0x02c2 }] */
    /* JADX WARN: Removed duplicated region for block: B:59:0x02d7 A[Catch: JSONException -> 0x02f9, TRY_LEAVE, TryCatch #10 {JSONException -> 0x02f9, blocks: (B:55:0x02c4, B:59:0x02d7), top: B:53:0x02c2 }] */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0238 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:79:0x01fc A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:99:0x01be A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private void executeSqlBatchStatement(String str, JSONArray jSONArray, JSONArray jSONArray2) {
        int i;
        JSONObject jSONObject;
        String message;
        int i2;
        QueryType queryType;
        boolean z;
        String str2;
        boolean z2;
        JSONObject jSONObject2;
        JSONObject jSONObject3;
        long executeInsert;
        JSONObject jSONObject4;
        String str3;
        SQLiteStatement compileStatement;
        JSONObject jSONObject5;
        if (this.mydb == null) {
            return;
        }
        String str4 = EnvironmentCompat.MEDIA_UNKNOWN;
        try {
            queryType = getQueryType(str);
        } catch (Exception e) {
            e = e;
            i = 0;
        }
        try {
            try {
                if (queryType != QueryType.update) {
                    try {
                    } catch (Exception e2) {
                        e = e2;
                        jSONObject = null;
                        i = 0;
                        e.printStackTrace();
                        message = e.getMessage();
                        Log.v("executeSqlBatch", "SQLiteAndroidDatabase.executeSql[Batch](): Error=" + message);
                        i2 = i;
                        if (jSONObject != null) {
                        }
                        return;
                    }
                    if (queryType != QueryType.delete) {
                        z = true;
                        jSONObject = null;
                        i2 = 0;
                        if (queryType == QueryType.insert || jSONArray == null) {
                            str2 = "Raw query error=";
                            jSONObject = jSONObject;
                            message = str4;
                        } else {
                            SQLiteStatement compileStatement2 = this.mydb.compileStatement(str);
                            bindArgsToStatement(compileStatement2, jSONArray);
                            str2 = "Raw query error=";
                            try {
                                executeInsert = compileStatement2.executeInsert();
                                jSONObject4 = jSONObject;
                            } catch (SQLiteConstraintException e3) {
                                e = e3;
                            } catch (SQLiteException e4) {
                                e = e4;
                            }
                            try {
                                jSONObject = new JSONObject();
                            } catch (SQLiteConstraintException e5) {
                                e = e5;
                                jSONObject = jSONObject4;
                            } catch (SQLiteException e6) {
                                e = e6;
                                jSONObject = jSONObject4;
                            } catch (Exception e7) {
                                e = e7;
                                i = i2;
                                jSONObject = jSONObject4;
                                e.printStackTrace();
                                message = e.getMessage();
                                Log.v("executeSqlBatch", "SQLiteAndroidDatabase.executeSql[Batch](): Error=" + message);
                                i2 = i;
                                if (jSONObject != null) {
                                }
                                return;
                            }
                            try {
                                if (executeInsert != -1) {
                                    str3 = str4;
                                    jSONObject.put("insertId", executeInsert);
                                    jSONObject.put("rowsAffected", 1);
                                } else {
                                    str3 = str4;
                                    jSONObject.put("rowsAffected", 0);
                                }
                                message = str3;
                            } catch (SQLiteConstraintException e8) {
                                e = e8;
                                e.printStackTrace();
                                message = "constraint failure: " + e.getMessage();
                                try {
                                    Log.v("executeSqlBatch", "SQLiteDatabase.executeInsert(): Error=" + message);
                                    i2 = 6;
                                    compileStatement2.close();
                                    z = false;
                                    if (queryType != QueryType.begin) {
                                    }
                                    if (queryType == QueryType.commit) {
                                    }
                                    if (queryType == QueryType.rollback) {
                                    }
                                    if (z2) {
                                    }
                                } catch (Exception e9) {
                                    e = e9;
                                    i = 6;
                                    e.printStackTrace();
                                    message = e.getMessage();
                                    Log.v("executeSqlBatch", "SQLiteAndroidDatabase.executeSql[Batch](): Error=" + message);
                                    i2 = i;
                                    if (jSONObject != null) {
                                    }
                                    return;
                                }
                                if (jSONObject != null) {
                                }
                                return;
                            } catch (SQLiteException e10) {
                                e = e10;
                                e.printStackTrace();
                                message = e.getMessage();
                                Log.v("executeSqlBatch", "SQLiteDatabase.executeInsert(): Error=" + message);
                                compileStatement2.close();
                                z = false;
                                if (queryType != QueryType.begin) {
                                }
                                if (queryType == QueryType.commit) {
                                }
                                if (queryType == QueryType.rollback) {
                                }
                                if (z2) {
                                }
                                if (jSONObject != null) {
                                }
                                return;
                            }
                            compileStatement2.close();
                            z = false;
                        }
                        if (queryType != QueryType.begin) {
                            try {
                                this.mydb.beginTransaction();
                                this.isTransactionActive = true;
                                jSONObject2 = new JSONObject();
                            } catch (SQLiteException e11) {
                                e = e11;
                            }
                            try {
                                jSONObject2.put("rowsAffected", 0);
                                jSONObject = jSONObject2;
                            } catch (SQLiteException e12) {
                                e = e12;
                                jSONObject = jSONObject2;
                                e.printStackTrace();
                                message = e.getMessage();
                                Log.v("executeSqlBatch", "SQLiteDatabase.beginTransaction(): Error=" + message);
                                z2 = false;
                                if (queryType == QueryType.commit) {
                                }
                                if (queryType == QueryType.rollback) {
                                }
                                if (z2) {
                                }
                                if (jSONObject != null) {
                                }
                                return;
                            } catch (Exception e13) {
                                e = e13;
                                jSONObject = jSONObject2;
                                i = i2;
                                e.printStackTrace();
                                message = e.getMessage();
                                Log.v("executeSqlBatch", "SQLiteAndroidDatabase.executeSql[Batch](): Error=" + message);
                                i2 = i;
                                if (jSONObject != null) {
                                }
                                return;
                            }
                            z2 = false;
                        } else {
                            z2 = z;
                        }
                        if (queryType == QueryType.commit) {
                            try {
                                this.mydb.setTransactionSuccessful();
                                this.mydb.endTransaction();
                                this.isTransactionActive = false;
                                jSONObject3 = new JSONObject();
                            } catch (SQLiteException e14) {
                                e = e14;
                            }
                            try {
                                try {
                                    jSONObject3.put("rowsAffected", 0);
                                    jSONObject = jSONObject3;
                                } catch (SQLiteException e15) {
                                    e = e15;
                                    jSONObject = jSONObject3;
                                    e.printStackTrace();
                                    message = e.getMessage();
                                    Log.v("executeSqlBatch", "SQLiteDatabase.setTransactionSuccessful/endTransaction(): Error=" + message);
                                    z2 = false;
                                    if (queryType == QueryType.rollback) {
                                    }
                                    if (z2) {
                                    }
                                    if (jSONObject != null) {
                                    }
                                    return;
                                }
                                z2 = false;
                            } catch (Exception e16) {
                                e = e16;
                                jSONObject = jSONObject3;
                                i = i2;
                                e.printStackTrace();
                                message = e.getMessage();
                                Log.v("executeSqlBatch", "SQLiteAndroidDatabase.executeSql[Batch](): Error=" + message);
                                i2 = i;
                                if (jSONObject != null) {
                                }
                                return;
                            }
                        }
                        if (queryType == QueryType.rollback) {
                            try {
                                this.mydb.endTransaction();
                                z2 = false;
                                try {
                                    this.isTransactionActive = false;
                                    jSONObject3 = new JSONObject();
                                } catch (SQLiteException e17) {
                                    e = e17;
                                }
                            } catch (SQLiteException e18) {
                                e = e18;
                                z2 = false;
                            }
                            try {
                                jSONObject3.put("rowsAffected", 0);
                                jSONObject = jSONObject3;
                            } catch (SQLiteException e19) {
                                e = e19;
                                jSONObject = jSONObject3;
                                e.printStackTrace();
                                message = e.getMessage();
                                Log.v("executeSqlBatch", "SQLiteDatabase.endTransaction(): Error=" + message);
                                if (z2) {
                                }
                                if (jSONObject != null) {
                                }
                                return;
                            }
                        }
                        if (z2) {
                            try {
                                jSONObject = executeSqlStatementQuery(this.mydb, str, jSONArray);
                            } catch (SQLiteConstraintException e20) {
                                String str5 = str2;
                                e20.printStackTrace();
                                message = "constraint failure: " + e20.getMessage();
                                Log.v("executeSqlBatch", str5 + message);
                                i = 6;
                            } catch (SQLiteException e21) {
                                e21.printStackTrace();
                                message = e21.getMessage();
                                Log.v("executeSqlBatch", str2 + message);
                            }
                            i = i2;
                            i2 = i;
                        }
                        if (jSONObject != null) {
                            JSONObject jSONObject6 = new JSONObject();
                            jSONObject6.put("type", "success");
                            jSONObject6.put("result", jSONObject);
                            jSONArray2.put(jSONObject6);
                        } else {
                            JSONObject jSONObject7 = new JSONObject();
                            jSONObject7.put("type", "error");
                            JSONObject jSONObject8 = new JSONObject();
                            jSONObject8.put("message", message);
                            jSONObject8.put("code", i2);
                            jSONObject7.put("result", jSONObject8);
                            jSONArray2.put(jSONObject7);
                        }
                        return;
                    }
                }
                if (jSONObject != null) {
                }
                return;
            } catch (JSONException e22) {
                e22.printStackTrace();
                Log.v("executeSqlBatch", "SQLiteAndroidDatabase.executeSql[Batch](): Error=" + e22.getMessage());
                return;
            }
            int i3 = compileStatement.executeUpdateDelete();
            int i4 = 0;
            compileStatement.close();
            if (i3 != -1) {
                jSONObject5 = new JSONObject();
                try {
                    jSONObject5.put("rowsAffected", i3);
                } catch (Exception e23) {
                    e = e23;
                    i = i4;
                    jSONObject = jSONObject5;
                    e.printStackTrace();
                    message = e.getMessage();
                    Log.v("executeSqlBatch", "SQLiteAndroidDatabase.executeSql[Batch](): Error=" + message);
                    i2 = i;
                    if (jSONObject != null) {
                    }
                    return;
                }
            } else {
                jSONObject5 = null;
            }
            z = false;
            JSONObject jSONObject9 = jSONObject5;
            i2 = i4;
            jSONObject = jSONObject9;
            if (queryType == QueryType.insert) {
            }
            str2 = "Raw query error=";
            jSONObject = jSONObject;
            message = str4;
            if (queryType != QueryType.begin) {
            }
            if (queryType == QueryType.commit) {
            }
            if (queryType == QueryType.rollback) {
            }
            if (z2) {
            }
        } catch (Exception e24) {
            e24.printStackTrace();
            Log.v("SQLiteAndroidDatabase.executeSqlBatchStatement", "INTERNAL PLUGIN ERROR: could not do myStatement.executeUpdateDelete(): " + e24.getMessage());
            throw e24;
        }
        compileStatement = this.mydb.compileStatement(str);
        if (jSONArray != null) {
            bindArgsToStatement(compileStatement, jSONArray);
        }
    }

    private final int countRowsAffectedCompat(QueryType queryType, String str, JSONArray jSONArray, SQLiteDatabase sQLiteDatabase) throws JSONException {
        Matcher matcher = WHERE_CLAUSE.matcher(str);
        String str2 = "";
        for (int i = 0; matcher.find(i); i = matcher.start(1)) {
            str2 = " WHERE " + matcher.group(1);
        }
        int i2 = 0;
        for (int i3 = 0; i3 < str2.length(); i3++) {
            if (str2.charAt(i3) == '?') {
                i2++;
            }
        }
        JSONArray jSONArray2 = null;
        if (jSONArray != null) {
            jSONArray2 = new JSONArray();
            int length = jSONArray.length() - i2;
            for (int i4 = length; i4 < jSONArray.length(); i4++) {
                jSONArray2.put(i4 - length, jSONArray.get(i4));
            }
        }
        if (queryType == QueryType.update) {
            Matcher matcher2 = UPDATE_TABLE_NAME.matcher(str);
            if (matcher2.find()) {
                try {
                    SQLiteStatement compileStatement = sQLiteDatabase.compileStatement("SELECT count(*) FROM " + matcher2.group(1) + str2);
                    if (jSONArray2 != null) {
                        bindArgsToStatement(compileStatement, jSONArray2);
                    }
                    return (int) compileStatement.simpleQueryForLong();
                } catch (Exception e) {
                    Log.e("SQLiteAndroidDatabase", "uncaught", e);
                }
            }
        } else {
            Matcher matcher3 = DELETE_TABLE_NAME.matcher(str);
            if (matcher3.find()) {
                try {
                    SQLiteStatement compileStatement2 = sQLiteDatabase.compileStatement("SELECT count(*) FROM " + matcher3.group(1) + str2);
                    bindArgsToStatement(compileStatement2, jSONArray2);
                    return (int) compileStatement2.simpleQueryForLong();
                } catch (Exception e2) {
                    Log.e("SQLiteAndroidDatabase", "uncaught", e2);
                }
            }
        }
        return 0;
    }

    private void bindArgsToStatement(SQLiteStatement sQLiteStatement, JSONArray jSONArray) throws JSONException {
        for (int i = 0; i < jSONArray.length(); i++) {
            if ((jSONArray.get(i) instanceof Float) || (jSONArray.get(i) instanceof Double)) {
                sQLiteStatement.bindDouble(i + 1, jSONArray.getDouble(i));
            } else if (jSONArray.get(i) instanceof Number) {
                sQLiteStatement.bindLong(i + 1, jSONArray.getLong(i));
            } else if (jSONArray.isNull(i)) {
                sQLiteStatement.bindNull(i + 1);
            } else {
                sQLiteStatement.bindString(i + 1, jSONArray.getString(i));
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:43:0x00b5, code lost:
    
        r10 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00b6, code lost:
    
        r10.printStackTrace();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private JSONObject executeSqlStatementQuery(SQLiteDatabase sQLiteDatabase, String str, JSONArray jSONArray) throws Exception {
        JSONObject jSONObject = new JSONObject();
        try {
            String[] strArr = new String[jSONArray.length()];
            for (int i = 0; i < jSONArray.length(); i++) {
                if (jSONArray.isNull(i)) {
                    strArr[i] = "";
                } else {
                    strArr[i] = jSONArray.getString(i);
                }
            }
            Cursor rawQuery = sQLiteDatabase.rawQuery(str, strArr);
            if (rawQuery != null && rawQuery.moveToFirst()) {
                JSONArray jSONArray2 = new JSONArray();
                int columnCount = rawQuery.getColumnCount();
                do {
                    JSONObject jSONObject2 = new JSONObject();
                    for (int i2 = 0; i2 < columnCount; i2++) {
                        try {
                            String columnName = rawQuery.getColumnName(i2);
                            if (isPostHoneycomb) {
                                try {
                                    bindPostHoneycomb(jSONObject2, columnName, rawQuery, i2);
                                } catch (Exception e) {
                                    Log.v("SQLiteAndroidDatabase.executeSqlStatementQuery", "INTERNAL PLUGIN ERROR: could not bindPostHoneycomb: " + e.getMessage());
                                    throw e;
                                }
                            } else {
                                Log.v("SQLiteAndroidDatabase.executeSqlStatementQuery", "INTERNAL PLUGIN ERROR: deprecated android.os.Build.VERSION not supported: " + Build.VERSION.SDK_INT);
                                throw new RuntimeException("INTERNAL PLUGIN ERROR: deprecated android.os.Build.VERSION not supported: " + Build.VERSION.SDK_INT);
                            }
                        } catch (JSONException e2) {
                            e2.printStackTrace();
                        }
                    }
                    jSONArray2.put(jSONObject2);
                } while (rawQuery.moveToNext());
                jSONObject.put("rows", jSONArray2);
            }
            if (rawQuery != null) {
                rawQuery.close();
            }
            return jSONObject;
        } catch (Exception e3) {
            e3.printStackTrace();
            Log.v("executeSqlBatch", "SQLiteAndroidDatabase.executeSql[Batch](): Error=" + e3.getMessage());
            throw e3;
        }
    }

    private void bindPostHoneycomb(JSONObject jSONObject, String str, Cursor cursor, int i) throws JSONException {
        int type = cursor.getType(i);
        if (type == 0) {
            jSONObject.put(str, JSONObject.NULL);
            return;
        }
        if (type == 1) {
            jSONObject.put(str, cursor.getLong(i));
        } else if (type == 2) {
            jSONObject.put(str, cursor.getDouble(i));
        } else {
            jSONObject.put(str, cursor.getString(i));
        }
    }

    static QueryType getQueryType(String str) {
        Matcher matcher = FIRST_WORD.matcher(str);
        if (matcher.find()) {
            try {
                String group = matcher.group(1);
                if (group.length() == 0) {
                    throw new RuntimeException("query not found");
                }
                return QueryType.valueOf(group.toLowerCase(Locale.ENGLISH));
            } catch (IllegalArgumentException unused) {
                return QueryType.other;
            }
        }
        throw new RuntimeException("query not found");
    }
}
