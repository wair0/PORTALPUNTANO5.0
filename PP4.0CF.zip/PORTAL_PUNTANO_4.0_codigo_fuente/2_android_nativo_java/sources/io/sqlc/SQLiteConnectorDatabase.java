package io.sqlc;

import android.util.Log;
import androidx.core.os.EnvironmentCompat;
import io.liteglue.SQLiteConnection;
import io.liteglue.SQLiteConnector;
import io.liteglue.SQLiteStatement;
import java.io.File;
import java.sql.SQLException;
import org.apache.cordova.CallbackContext;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
class SQLiteConnectorDatabase extends SQLiteAndroidDatabase {
    static SQLiteConnector connector = new SQLiteConnector();
    SQLiteConnection mydb;

    @Override // io.sqlc.SQLiteAndroidDatabase
    void bugWorkaround() {
    }

    SQLiteConnectorDatabase() {
    }

    @Override // io.sqlc.SQLiteAndroidDatabase
    void open(File file) throws Exception {
        this.mydb = connector.newSQLiteConnection(file.getAbsolutePath(), 6);
    }

    @Override // io.sqlc.SQLiteAndroidDatabase
    void closeDatabaseNow() {
        try {
            SQLiteConnection sQLiteConnection = this.mydb;
            if (sQLiteConnection != null) {
                sQLiteConnection.dispose();
            }
        } catch (Exception e) {
            Log.e("SQLitePlugin", "couldn't close database, ignoring", e);
        }
    }

    @Override // io.sqlc.SQLiteAndroidDatabase
    void executeSqlBatch(String[] strArr, JSONArray[] jSONArrayArr, CallbackContext callbackContext) {
        String message;
        int i;
        if (this.mydb == null) {
            callbackContext.error("database has been closed");
            return;
        }
        int length = strArr.length;
        JSONArray jSONArray = new JSONArray();
        for (int i2 = 0; i2 < length; i2++) {
            JSONObject jSONObject = null;
            try {
                String str = strArr[i2];
                long totalChanges = this.mydb.getTotalChanges();
                jSONObject = executeSQLiteStatement(str, jSONArrayArr[i2], callbackContext);
                long totalChanges2 = this.mydb.getTotalChanges() - totalChanges;
                jSONObject.put("rowsAffected", totalChanges2);
                if (totalChanges2 > 0) {
                    long lastInsertRowid = this.mydb.getLastInsertRowid();
                    if (lastInsertRowid > 0) {
                        jSONObject.put("insertId", lastInsertRowid);
                    }
                }
                message = EnvironmentCompat.MEDIA_UNKNOWN;
            } catch (SQLException e) {
                e.printStackTrace();
                int errorCode = e.getErrorCode();
                message = e.getMessage();
                Log.v("executeSqlBatch", "SQLitePlugin.executeSql[Batch](): SQL Error code = " + errorCode + " message = " + message);
                if (errorCode == 1) {
                    i = 5;
                } else if (errorCode == 13) {
                    i = 4;
                } else if (errorCode == 19) {
                    i = 6;
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
                message = e2.getMessage();
                Log.e("executeSqlBatch", "SQLitePlugin.executeSql[Batch](): UNEXPECTED JSON Error=" + message);
            }
            i = 0;
            if (jSONObject != null) {
                try {
                    JSONObject jSONObject2 = new JSONObject();
                    jSONObject2.put("type", "success");
                    jSONObject2.put("result", jSONObject);
                    jSONArray.put(jSONObject2);
                } catch (JSONException e3) {
                    e3.printStackTrace();
                    Log.e("executeSqlBatch", "SQLitePlugin.executeSql[Batch](): Error=" + e3.getMessage());
                }
            } else {
                JSONObject jSONObject3 = new JSONObject();
                jSONObject3.put("type", "error");
                JSONObject jSONObject4 = new JSONObject();
                jSONObject4.put("message", message);
                jSONObject4.put("code", i);
                jSONObject3.put("result", jSONObject4);
                jSONArray.put(jSONObject3);
            }
        }
        callbackContext.success(jSONArray);
    }

    /* JADX WARN: Code restructure failed: missing block: B:54:0x00b6, code lost:
    
        r9 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00b7, code lost:
    
        r9.printStackTrace();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private JSONObject executeSQLiteStatement(String str, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException, SQLException {
        JSONObject jSONObject = new JSONObject();
        SQLiteStatement prepareStatement = this.mydb.prepareStatement(str);
        try {
            String[] strArr = new String[jSONArray.length()];
            for (int i = 0; i < jSONArray.length(); i++) {
                if (jSONArray.isNull(i)) {
                    prepareStatement.bindNull(i + 1);
                } else {
                    Object obj = jSONArray.get(i);
                    if (!(obj instanceof Float) && !(obj instanceof Double)) {
                        if (obj instanceof Number) {
                            prepareStatement.bindLong(i + 1, jSONArray.getLong(i));
                        } else {
                            prepareStatement.bindTextNativeString(i + 1, jSONArray.getString(i));
                        }
                    }
                    prepareStatement.bindDouble(i + 1, jSONArray.getDouble(i));
                }
            }
            if (prepareStatement.step()) {
                JSONArray jSONArray2 = new JSONArray();
                int columnCount = prepareStatement.getColumnCount();
                do {
                    JSONObject jSONObject2 = new JSONObject();
                    for (int i2 = 0; i2 < columnCount; i2++) {
                        try {
                            String columnName = prepareStatement.getColumnName(i2);
                            int columnType = prepareStatement.getColumnType(i2);
                            if (columnType == 1) {
                                jSONObject2.put(columnName, prepareStatement.getColumnLong(i2));
                            } else if (columnType == 2) {
                                jSONObject2.put(columnName, prepareStatement.getColumnDouble(i2));
                            } else if (columnType == 5) {
                                jSONObject2.put(columnName, JSONObject.NULL);
                            } else {
                                jSONObject2.put(columnName, prepareStatement.getColumnTextNativeString(i2));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    jSONArray2.put(jSONObject2);
                } while (prepareStatement.step());
                jSONObject.put("rows", jSONArray2);
            }
            prepareStatement.dispose();
            return jSONObject;
        } catch (SQLException e2) {
            e2.printStackTrace();
            Log.v("executeSqlBatch", "SQLitePlugin.executeSql[Batch](): Error=" + e2.getMessage());
            prepareStatement.dispose();
            throw e2;
        } catch (JSONException e3) {
            e3.printStackTrace();
            Log.v("executeSqlBatch", "SQLitePlugin.executeSql[Batch](): Error=" + e3.getMessage());
            prepareStatement.dispose();
            throw e3;
        }
    }
}
