package com.silkimen.cordovahttp;

import com.silkimen.http.TLSConfiguration;
import org.json.JSONObject;

/* loaded from: classes.dex */
class CordovaHttpOperation extends CordovaHttpBase {
    public CordovaHttpOperation(String str, String str2, String str3, Object obj, JSONObject jSONObject, int i, boolean z, String str4, TLSConfiguration tLSConfiguration, CordovaObservableCallbackContext cordovaObservableCallbackContext) {
        super(str, str2, str3, obj, jSONObject, i, z, str4, tLSConfiguration, cordovaObservableCallbackContext);
    }

    public CordovaHttpOperation(String str, String str2, JSONObject jSONObject, int i, boolean z, String str3, TLSConfiguration tLSConfiguration, CordovaObservableCallbackContext cordovaObservableCallbackContext) {
        super(str, str2, jSONObject, i, z, str3, tLSConfiguration, cordovaObservableCallbackContext);
    }
}
