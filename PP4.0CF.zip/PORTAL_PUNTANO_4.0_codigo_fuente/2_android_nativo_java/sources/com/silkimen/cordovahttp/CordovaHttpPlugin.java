package com.silkimen.cordovahttp;

import android.util.Base64;
import android.util.Log;
import com.silkimen.http.TLSConfiguration;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.Future;
import javax.net.ssl.TrustManagerFactory;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class CordovaHttpPlugin extends CordovaPlugin implements Observer {
    private static final String TAG = "Cordova-Plugin-HTTP";
    private HashMap<Integer, Future<?>> reqMap;
    private final Object reqMapLock = new Object();
    private TLSConfiguration tlsConfiguration;

    @Override // org.apache.cordova.CordovaPlugin
    public void initialize(CordovaInterface cordovaInterface, CordovaWebView cordovaWebView) {
        super.initialize(cordovaInterface, cordovaWebView);
        this.tlsConfiguration = new TLSConfiguration();
        this.reqMap = new HashMap<>();
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidCAStore");
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            keyStore.load(null);
            trustManagerFactory.init(keyStore);
            this.tlsConfiguration.setHostnameVerifier(null);
            this.tlsConfiguration.setTrustManagers(trustManagerFactory.getTrustManagers());
        } catch (Exception e) {
            Log.e(TAG, "An error occured while loading system's CA certificates", e);
        }
    }

    @Override // org.apache.cordova.CordovaPlugin
    public boolean execute(String str, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        if (str == null) {
            return false;
        }
        if ("get".equals(str)) {
            return executeHttpRequestWithoutData(str, jSONArray, callbackContext);
        }
        if ("head".equals(str)) {
            return executeHttpRequestWithoutData(str, jSONArray, callbackContext);
        }
        if ("delete".equals(str)) {
            return executeHttpRequestWithoutData(str, jSONArray, callbackContext);
        }
        if ("options".equals(str)) {
            return executeHttpRequestWithoutData(str, jSONArray, callbackContext);
        }
        if ("post".equals(str)) {
            return executeHttpRequestWithData(str, jSONArray, callbackContext);
        }
        if ("put".equals(str)) {
            return executeHttpRequestWithData(str, jSONArray, callbackContext);
        }
        if ("patch".equals(str)) {
            return executeHttpRequestWithData(str, jSONArray, callbackContext);
        }
        if ("uploadFiles".equals(str)) {
            return uploadFiles(jSONArray, callbackContext);
        }
        if ("downloadFile".equals(str)) {
            return downloadFile(jSONArray, callbackContext);
        }
        if ("setServerTrustMode".equals(str)) {
            return setServerTrustMode(jSONArray, callbackContext);
        }
        if ("setClientAuthMode".equals(str)) {
            return setClientAuthMode(jSONArray, callbackContext);
        }
        if ("abort".equals(str)) {
            return abort(jSONArray, callbackContext);
        }
        return false;
    }

    private boolean executeHttpRequestWithoutData(String str, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        String string = jSONArray.getString(0);
        JSONObject jSONObject = jSONArray.getJSONObject(1);
        int i = jSONArray.getInt(2) * 1000;
        boolean z = jSONArray.getBoolean(3);
        String string2 = jSONArray.getString(4);
        Integer valueOf = Integer.valueOf(jSONArray.getInt(5));
        CordovaObservableCallbackContext cordovaObservableCallbackContext = new CordovaObservableCallbackContext(callbackContext, valueOf);
        startRequest(valueOf, cordovaObservableCallbackContext, new CordovaHttpOperation(str.toUpperCase(), string, jSONObject, i, z, string2, this.tlsConfiguration, cordovaObservableCallbackContext));
        return true;
    }

    private boolean executeHttpRequestWithData(String str, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        String string = jSONArray.getString(0);
        Object obj = jSONArray.get(1);
        String string2 = jSONArray.getString(2);
        JSONObject jSONObject = jSONArray.getJSONObject(3);
        int i = jSONArray.getInt(4) * 1000;
        boolean z = jSONArray.getBoolean(5);
        String string3 = jSONArray.getString(6);
        Integer valueOf = Integer.valueOf(jSONArray.getInt(7));
        CordovaObservableCallbackContext cordovaObservableCallbackContext = new CordovaObservableCallbackContext(callbackContext, valueOf);
        startRequest(valueOf, cordovaObservableCallbackContext, new CordovaHttpOperation(str.toUpperCase(), string, string2, obj, jSONObject, i, z, string3, this.tlsConfiguration, cordovaObservableCallbackContext));
        return true;
    }

    private boolean uploadFiles(JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        String string = jSONArray.getString(0);
        JSONObject jSONObject = jSONArray.getJSONObject(1);
        JSONArray jSONArray2 = jSONArray.getJSONArray(2);
        JSONArray jSONArray3 = jSONArray.getJSONArray(3);
        int i = jSONArray.getInt(4) * 1000;
        boolean z = jSONArray.getBoolean(5);
        String string2 = jSONArray.getString(6);
        Integer valueOf = Integer.valueOf(jSONArray.getInt(7));
        CordovaObservableCallbackContext cordovaObservableCallbackContext = new CordovaObservableCallbackContext(callbackContext, valueOf);
        startRequest(valueOf, cordovaObservableCallbackContext, new CordovaHttpUpload(string, jSONObject, jSONArray2, jSONArray3, i, z, string2, this.tlsConfiguration, this.f5cordova.getActivity().getApplicationContext(), cordovaObservableCallbackContext));
        return true;
    }

    private boolean downloadFile(JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        String string = jSONArray.getString(0);
        JSONObject jSONObject = jSONArray.getJSONObject(1);
        String string2 = jSONArray.getString(2);
        int i = jSONArray.getInt(3) * 1000;
        boolean z = jSONArray.getBoolean(4);
        Integer valueOf = Integer.valueOf(jSONArray.getInt(5));
        CordovaObservableCallbackContext cordovaObservableCallbackContext = new CordovaObservableCallbackContext(callbackContext, valueOf);
        startRequest(valueOf, cordovaObservableCallbackContext, new CordovaHttpDownload(string, jSONObject, string2, i, z, this.tlsConfiguration, cordovaObservableCallbackContext));
        return true;
    }

    private void startRequest(Integer num, CordovaObservableCallbackContext cordovaObservableCallbackContext, CordovaHttpBase cordovaHttpBase) {
        synchronized (this.reqMapLock) {
            cordovaObservableCallbackContext.setObserver(this);
            addReq(num, this.f5cordova.getThreadPool().submit(cordovaHttpBase), cordovaObservableCallbackContext);
        }
    }

    private boolean setServerTrustMode(JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        this.f5cordova.getThreadPool().execute(new CordovaServerTrust(jSONArray.getString(0), this.f5cordova.getActivity(), this.tlsConfiguration, callbackContext));
        return true;
    }

    private boolean setClientAuthMode(JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        this.f5cordova.getThreadPool().execute(new CordovaClientAuth(jSONArray.getString(0), jSONArray.isNull(1) ? null : jSONArray.getString(1), jSONArray.isNull(2) ? null : Base64.decode(jSONArray.getString(2), 0), jSONArray.getString(3), this.f5cordova.getActivity(), this.f5cordova.getActivity().getApplicationContext(), this.tlsConfiguration, callbackContext));
        return true;
    }

    private boolean abort(JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        boolean z = false;
        Future<?> future = this.reqMap.get(Integer.valueOf(jSONArray.getInt(0)));
        if (future != null && !future.isDone()) {
            z = future.cancel(true);
        }
        callbackContext.success(new JSONObject().put("aborted", z));
        return true;
    }

    private void addReq(Integer num, Future<?> future, CordovaObservableCallbackContext cordovaObservableCallbackContext) {
        synchronized (this.reqMapLock) {
            if (!future.isDone()) {
                this.reqMap.put(num, future);
            }
        }
    }

    private void removeReq(Integer num) {
        synchronized (this.reqMapLock) {
            this.reqMap.remove(num);
        }
    }

    @Override // java.util.Observer
    public void update(Observable observable, Object obj) {
        synchronized (this.reqMapLock) {
            CordovaObservableCallbackContext cordovaObservableCallbackContext = (CordovaObservableCallbackContext) obj;
            if (cordovaObservableCallbackContext.getCallbackContext().isFinished()) {
                removeReq(cordovaObservableCallbackContext.getRequestId());
            }
        }
    }
}
