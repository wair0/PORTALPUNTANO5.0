package de.appplant.cordova.plugin.notification;

import android.R;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.support.v4.media.session.MediaSessionCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.view.ViewCompat;
import de.appplant.cordova.plugin.notification.action.Action;
import de.appplant.cordova.plugin.notification.action.ActionGroup;
import de.appplant.cordova.plugin.notification.util.AssetUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import kotlinx.coroutines.Debug;
import me.leolin.shortcutbadger.impl.NewHtcHomeBadger;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Options {
    private static final String DEFAULT_ICON = "res://icon";
    public static final String EXTRA_LAUNCH = "NOTIFICATION_LAUNCH";
    static final String EXTRA_SOUND = "NOTIFICATION_SOUND";
    private final AssetUtil assets;
    private final Context context;
    private final JSONObject options;

    public Options(JSONObject jSONObject) {
        this.options = jSONObject;
        this.context = null;
        this.assets = null;
    }

    Options(Context context, JSONObject jSONObject) {
        this.context = context;
        this.options = jSONObject;
        this.assets = AssetUtil.getInstance(context);
    }

    public Context getContext() {
        return this.context;
    }

    public JSONObject getDict() {
        return this.options;
    }

    public String toString() {
        return this.options.toString();
    }

    public Integer getId() {
        return Integer.valueOf(this.options.optInt("id", 0));
    }

    String getIdentifier() {
        return getId().toString();
    }

    public int getBadgeNumber() {
        return this.options.optInt("badge", 0);
    }

    public int getNumber() {
        return this.options.optInt("number", 0);
    }

    public Boolean isSticky() {
        return Boolean.valueOf(this.options.optBoolean("sticky", false));
    }

    Boolean isAutoClear() {
        return Boolean.valueOf(this.options.optBoolean("autoClear", false));
    }

    public JSONObject getTrigger() {
        return this.options.optJSONObject("trigger");
    }

    boolean isSilent() {
        return this.options.optBoolean(NotificationCompat.GROUP_KEY_SILENT, false);
    }

    String getGroup() {
        return this.options.optString("group", null);
    }

    boolean isLaunchingApp() {
        return this.options.optBoolean("launch", true);
    }

    public boolean shallWakeUp() {
        return this.options.optBoolean("wakeup", true);
    }

    String getChannel() {
        return this.options.optString("channel", "default-channel-id");
    }

    boolean getGroupSummary() {
        return this.options.optBoolean("groupSummary", false);
    }

    public String getText() {
        Object opt = this.options.opt("text");
        return opt instanceof String ? (String) opt : "";
    }

    public String getTitle() {
        String optString = this.options.optString("title", "");
        return optString.isEmpty() ? this.context.getApplicationInfo().loadLabel(this.context.getPackageManager()).toString() : optString;
    }

    int getLedColor() {
        String optString;
        Object opt = this.options.opt("led");
        if (opt instanceof String) {
            optString = this.options.optString("led");
        } else if (opt instanceof JSONArray) {
            optString = this.options.optJSONArray("led").optString(0);
        } else {
            optString = opt instanceof JSONObject ? this.options.optJSONObject("led").optString("color") : null;
        }
        if (optString == null) {
            return 0;
        }
        try {
            return Integer.parseInt(stripHex(optString), 16) + ViewCompat.MEASURED_STATE_MASK;
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }

    int getLedOn() {
        Object opt = this.options.opt("led");
        if (opt instanceof JSONArray) {
            return this.options.optJSONArray("led").optInt(1, 1000);
        }
        if (opt instanceof JSONObject) {
            return this.options.optJSONObject("led").optInt(Debug.DEBUG_PROPERTY_VALUE_ON, 1000);
        }
        return 1000;
    }

    int getLedOff() {
        Object opt = this.options.opt("led");
        if (opt instanceof JSONArray) {
            return this.options.optJSONArray("led").optInt(2, 1000);
        }
        if (opt instanceof JSONObject) {
            return this.options.optJSONObject("led").optInt(Debug.DEBUG_PROPERTY_VALUE_OFF, 1000);
        }
        return 1000;
    }

    public int getColor() {
        String optString = this.options.optString("color", null);
        if (optString == null) {
            return 0;
        }
        try {
            String stripHex = stripHex(optString);
            if (stripHex.matches("[^0-9]*")) {
                return Color.class.getDeclaredField(stripHex.toUpperCase()).getInt(null);
            }
            return Integer.parseInt(stripHex, 16) + ViewCompat.MEASURED_STATE_MASK;
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return 0;
        } catch (NoSuchFieldException e2) {
            e2.printStackTrace();
            return 0;
        } catch (NumberFormatException e3) {
            e3.printStackTrace();
            return 0;
        }
    }

    Uri getSound() {
        return this.assets.parse(this.options.optString("sound", null));
    }

    boolean hasLargeIcon() {
        return this.options.optString("icon", null) != null;
    }

    Bitmap getLargeIcon() {
        try {
            return this.assets.getIconFromUri(this.assets.parse(this.options.optString("icon", null)));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    int getSmallIcon() {
        int resId = this.assets.getResId(this.options.optString("smallIcon", DEFAULT_ICON));
        if (resId == 0) {
            resId = this.assets.getResId(DEFAULT_ICON);
        }
        if (resId == 0) {
            resId = this.context.getApplicationInfo().icon;
        }
        return resId == 0 ? R.drawable.ic_popup_reminder : resId;
    }

    private boolean isWithVibration() {
        return this.options.optBoolean("vibrate", true);
    }

    private boolean isWithoutSound() {
        Object opt = this.options.opt("sound");
        return opt == null || opt.equals(false);
    }

    private boolean isWithDefaultSound() {
        Object opt = this.options.opt("sound");
        return opt != null && opt.equals(true);
    }

    private boolean isWithoutLights() {
        Object opt = this.options.opt("led");
        return opt == null || opt.equals(false);
    }

    private boolean isWithDefaultLights() {
        Object opt = this.options.opt("led");
        return opt != null && opt.equals(true);
    }

    int getDefaults() {
        int optInt = this.options.optInt("defaults", 0);
        int i = isWithVibration() ? optInt | 2 : optInt & 2;
        if (isWithDefaultSound()) {
            i |= 1;
        } else if (isWithoutSound()) {
            i &= 1;
        }
        return isWithDefaultLights() ? i | 4 : isWithoutLights() ? i & 4 : i;
    }

    int getVisibility() {
        return this.options.optBoolean("lockscreen", true) ? 1 : -1;
    }

    int getPriority() {
        return Math.min(Math.max(this.options.optInt("priority"), -2), 2);
    }

    boolean getShowWhen() {
        return this.options.optBoolean("showWhen", true);
    }

    boolean isWithProgressBar() {
        return this.options.optJSONObject("progressBar").optBoolean("enabled", false);
    }

    int getProgressValue() {
        return this.options.optJSONObject("progressBar").optInt("value", 0);
    }

    int getProgressMaxValue() {
        return this.options.optJSONObject("progressBar").optInt("maxValue", 100);
    }

    boolean isIndeterminateProgress() {
        return this.options.optJSONObject("progressBar").optBoolean("indeterminate", false);
    }

    public boolean isInfiniteTrigger() {
        JSONObject optJSONObject = this.options.optJSONObject("trigger");
        return optJSONObject.has("every") && optJSONObject.optInt(NewHtcHomeBadger.COUNT, -1) < 0;
    }

    String getSummary() {
        return this.options.optString("summary", null);
    }

    List<Bitmap> getAttachments() {
        JSONArray optJSONArray = this.options.optJSONArray("attachments");
        ArrayList arrayList = new ArrayList();
        if (optJSONArray == null) {
            return arrayList;
        }
        for (int i = 0; i < optJSONArray.length(); i++) {
            Uri parse = this.assets.parse(optJSONArray.optString(i));
            if (parse != Uri.EMPTY) {
                try {
                    arrayList.add(this.assets.getIconFromUri(parse));
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return arrayList;
    }

    Action[] getActions() {
        String optString = this.options.optString("actionGroupId", null);
        JSONArray optJSONArray = this.options.optJSONArray("actions");
        ActionGroup parse = (optJSONArray == null || optJSONArray.length() <= 0) ? null : ActionGroup.parse(this.context, this.options);
        if (parse == null && optString != null) {
            parse = ActionGroup.lookup(optString);
        }
        if (parse == null) {
            return null;
        }
        ActionGroup.register(parse);
        return parse.getActions();
    }

    NotificationCompat.MessagingStyle.Message[] getMessages() {
        Object opt = this.options.opt("text");
        if (opt == null || (opt instanceof String)) {
            return null;
        }
        JSONArray jSONArray = (JSONArray) opt;
        if (jSONArray.length() == 0) {
            return null;
        }
        int length = jSONArray.length();
        NotificationCompat.MessagingStyle.Message[] messageArr = new NotificationCompat.MessagingStyle.Message[length];
        long time = new Date().getTime();
        for (int i = 0; i < length; i++) {
            JSONObject optJSONObject = jSONArray.optJSONObject(i);
            messageArr[i] = new NotificationCompat.MessagingStyle.Message(optJSONObject.optString("message"), optJSONObject.optLong("date", time), optJSONObject.optString("person", null));
        }
        return messageArr;
    }

    MediaSessionCompat.Token getMediaSessionToken() {
        String optString = this.options.optString("mediaSession", null);
        if (optString == null) {
            return null;
        }
        return new MediaSessionCompat(this.context, optString).getSessionToken();
    }

    private String stripHex(String str) {
        return str.charAt(0) == '#' ? str.substring(1) : str;
    }
}
