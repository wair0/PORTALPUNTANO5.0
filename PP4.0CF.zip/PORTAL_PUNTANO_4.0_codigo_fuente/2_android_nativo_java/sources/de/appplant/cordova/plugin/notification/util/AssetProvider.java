package de.appplant.cordova.plugin.notification.util;

import androidx.core.content.FileProvider;

/* loaded from: classes.dex */
public class AssetProvider extends FileProvider {
}
