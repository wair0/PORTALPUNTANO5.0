package de.appplant.cordova.plugin.localnotification;

import android.app.Activity;
import android.app.KeyguardManager;
import android.util.Pair;
import androidx.core.app.NotificationCompat;
import androidx.core.os.EnvironmentCompat;
import de.appplant.cordova.plugin.notification.Manager;
import de.appplant.cordova.plugin.notification.Notification;
import de.appplant.cordova.plugin.notification.Options;
import de.appplant.cordova.plugin.notification.Request;
import de.appplant.cordova.plugin.notification.action.ActionGroup;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class LocalNotification extends CordovaPlugin {
    private static Boolean deviceready = false;
    private static ArrayList<String> eventQueue = new ArrayList<>();
    private static Pair<Integer, String> launchDetails;
    private static WeakReference<CordovaWebView> webView;

    @Override // org.apache.cordova.CordovaPlugin
    public void initialize(CordovaInterface cordovaInterface, CordovaWebView cordovaWebView) {
        webView = new WeakReference<>(cordovaWebView);
    }

    @Override // org.apache.cordova.CordovaPlugin
    public void onResume(boolean z) {
        super.onResume(z);
        deviceready();
    }

    @Override // org.apache.cordova.CordovaPlugin
    public void onDestroy() {
        deviceready = false;
    }

    @Override // org.apache.cordova.CordovaPlugin
    public boolean execute(final String str, final JSONArray jSONArray, final CallbackContext callbackContext) throws JSONException {
        if (str.equals("launch")) {
            launch(callbackContext);
            return true;
        }
        this.f5cordova.getThreadPool().execute(new Runnable() { // from class: de.appplant.cordova.plugin.localnotification.LocalNotification.1
            @Override // java.lang.Runnable
            public void run() {
                if (str.equals("ready")) {
                    LocalNotification.deviceready();
                    return;
                }
                if (str.equalsIgnoreCase("check")) {
                    LocalNotification.this.check(callbackContext);
                    return;
                }
                if (str.equalsIgnoreCase("request")) {
                    LocalNotification.this.request(callbackContext);
                    return;
                }
                if (str.equalsIgnoreCase("actions")) {
                    LocalNotification.this.actions(jSONArray.optJSONObject(0));
                    callbackContext.success();
                    return;
                }
                if (str.equalsIgnoreCase("schedule")) {
                    LocalNotification.this.schedule(jSONArray);
                    LocalNotification.this.check(callbackContext);
                    return;
                }
                if (str.equals("update")) {
                    LocalNotification.this.update(jSONArray);
                    LocalNotification.this.check(callbackContext);
                    return;
                }
                if (str.equals("cancel")) {
                    LocalNotification.this.cancel(jSONArray);
                    callbackContext.success();
                    return;
                }
                if (str.equals("cancelAll")) {
                    LocalNotification.this.cancelAll();
                    callbackContext.success();
                    return;
                }
                if (str.equals("clear")) {
                    LocalNotification.this.clear(jSONArray);
                    callbackContext.success();
                    return;
                }
                if (str.equals("clearAll")) {
                    LocalNotification.this.clearAll();
                    callbackContext.success();
                    return;
                }
                if (str.equals("type")) {
                    LocalNotification.this.type(jSONArray.optInt(0), callbackContext);
                    return;
                }
                if (str.equals("ids")) {
                    LocalNotification.this.ids(callbackContext);
                    return;
                }
                if (str.equals("scheduledIds")) {
                    LocalNotification.this.scheduledIds(callbackContext);
                    return;
                }
                if (str.equals("triggeredIds")) {
                    LocalNotification.this.triggeredIds(callbackContext);
                    return;
                }
                if (str.equals("notification")) {
                    LocalNotification.this.notification(jSONArray.optInt(0), callbackContext);
                    return;
                }
                if (str.equals("notifications")) {
                    LocalNotification.this.notifications(jSONArray, callbackContext);
                } else if (str.equals("scheduledNotifications")) {
                    LocalNotification.this.scheduledNotifications(callbackContext);
                } else if (str.equals("triggeredNotifications")) {
                    LocalNotification.this.triggeredNotifications(callbackContext);
                }
            }
        });
        return true;
    }

    private void launch(CallbackContext callbackContext) {
        if (launchDetails == null) {
            return;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("id", launchDetails.first);
            jSONObject.put("action", launchDetails.second);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        callbackContext.success(jSONObject);
        launchDetails = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void check(CallbackContext callbackContext) {
        callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, getNotMgr().hasPermission()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void request(CallbackContext callbackContext) {
        check(callbackContext);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void actions(JSONObject jSONObject) {
        ActionGroup parse = ActionGroup.parse(this.f5cordova.getActivity(), jSONObject);
        if (parse != null) {
            ActionGroup.register(parse);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void schedule(JSONArray jSONArray) {
        Manager notMgr = getNotMgr();
        for (int i = 0; i < jSONArray.length(); i++) {
            Notification schedule = notMgr.schedule(new Request(new Options(jSONArray.optJSONObject(i))), TriggerReceiver.class);
            if (schedule != null) {
                fireEvent("add", schedule);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void update(JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject optJSONObject = jSONArray.optJSONObject(i);
            Notification update = getNotMgr().update(optJSONObject.optInt("id", 0), optJSONObject, TriggerReceiver.class);
            if (update != null) {
                fireEvent("update", update);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void cancel(JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); i++) {
            Notification cancel = getNotMgr().cancel(jSONArray.optInt(i, 0));
            if (cancel != null) {
                fireEvent("cancel", cancel);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void cancelAll() {
        getNotMgr().cancelAll();
        fireEvent("cancelall");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void clear(JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); i++) {
            Notification clear = getNotMgr().clear(jSONArray.optInt(i, 0));
            if (clear != null) {
                fireEvent("clear", clear);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void clearAll() {
        getNotMgr().clearAll();
        fireEvent("clearall");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void type(int i, CallbackContext callbackContext) {
        Notification notification = getNotMgr().get(i);
        if (notification == null) {
            callbackContext.success(EnvironmentCompat.MEDIA_UNKNOWN);
            return;
        }
        int i2 = AnonymousClass3.$SwitchMap$de$appplant$cordova$plugin$notification$Notification$Type[notification.getType().ordinal()];
        if (i2 == 1) {
            callbackContext.success("scheduled");
        } else if (i2 == 2) {
            callbackContext.success("triggered");
        } else {
            callbackContext.success(EnvironmentCompat.MEDIA_UNKNOWN);
        }
    }

    /* renamed from: de.appplant.cordova.plugin.localnotification.LocalNotification$3, reason: invalid class name */
    static /* synthetic */ class AnonymousClass3 {
        static final /* synthetic */ int[] $SwitchMap$de$appplant$cordova$plugin$notification$Notification$Type;

        static {
            int[] iArr = new int[Notification.Type.values().length];
            $SwitchMap$de$appplant$cordova$plugin$notification$Notification$Type = iArr;
            try {
                iArr[Notification.Type.SCHEDULED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$de$appplant$cordova$plugin$notification$Notification$Type[Notification.Type.TRIGGERED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void ids(CallbackContext callbackContext) {
        callbackContext.success(new JSONArray((Collection) getNotMgr().getIds()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void scheduledIds(CallbackContext callbackContext) {
        callbackContext.success(new JSONArray((Collection) getNotMgr().getIdsByType(Notification.Type.SCHEDULED)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void triggeredIds(CallbackContext callbackContext) {
        callbackContext.success(new JSONArray((Collection) getNotMgr().getIdsByType(Notification.Type.TRIGGERED)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void notification(int i, CallbackContext callbackContext) {
        Options options = getNotMgr().getOptions(i);
        if (options != null) {
            callbackContext.success(options.getDict());
        } else {
            callbackContext.success();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void notifications(JSONArray jSONArray, CallbackContext callbackContext) {
        List<JSONObject> optionsById;
        if (jSONArray.length() == 0) {
            optionsById = getNotMgr().getOptions();
        } else {
            optionsById = getNotMgr().getOptionsById(toList(jSONArray));
        }
        callbackContext.success(new JSONArray((Collection) optionsById));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void scheduledNotifications(CallbackContext callbackContext) {
        callbackContext.success(new JSONArray((Collection) getNotMgr().getOptionsByType(Notification.Type.SCHEDULED)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void triggeredNotifications(CallbackContext callbackContext) {
        callbackContext.success(new JSONArray((Collection) getNotMgr().getOptionsByType(Notification.Type.TRIGGERED)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static synchronized void deviceready() {
        synchronized (LocalNotification.class) {
            deviceready = true;
            Iterator<String> it = eventQueue.iterator();
            while (it.hasNext()) {
                sendJavascript(it.next());
            }
            eventQueue.clear();
        }
    }

    private void fireEvent(String str) {
        fireEvent(str, null, new JSONObject());
    }

    static void fireEvent(String str, Notification notification) {
        fireEvent(str, notification, new JSONObject());
    }

    static void fireEvent(String str, Notification notification, JSONObject jSONObject) {
        String jSONObject2;
        try {
            jSONObject.put(NotificationCompat.CATEGORY_EVENT, str);
            jSONObject.put("foreground", isInForeground());
            jSONObject.put("queued", !deviceready.booleanValue());
            if (notification != null) {
                jSONObject.put("notification", notification.getId());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (notification != null) {
            jSONObject2 = notification.toString() + "," + jSONObject.toString();
        } else {
            jSONObject2 = jSONObject.toString();
        }
        String str2 = "cordova.plugins.notification.local.core.fireEvent(\"" + str + "\"," + jSONObject2 + ")";
        if (launchDetails == null && !deviceready.booleanValue() && notification != null) {
            launchDetails = new Pair<>(Integer.valueOf(notification.getId()), str);
        }
        sendJavascript(str2);
    }

    private static synchronized void sendJavascript(final String str) {
        WeakReference<CordovaWebView> weakReference;
        synchronized (LocalNotification.class) {
            if (deviceready.booleanValue() && (weakReference = webView) != null) {
                final CordovaWebView cordovaWebView = weakReference.get();
                ((Activity) cordovaWebView.getContext()).runOnUiThread(new Runnable() { // from class: de.appplant.cordova.plugin.localnotification.LocalNotification.2
                    @Override // java.lang.Runnable
                    public void run() {
                        CordovaWebView.this.loadUrl("javascript:" + str);
                    }
                });
                return;
            }
            eventQueue.add(str);
        }
    }

    private static boolean isInForeground() {
        WeakReference<CordovaWebView> weakReference;
        if (!deviceready.booleanValue() || (weakReference = webView) == null) {
            return false;
        }
        CordovaWebView cordovaWebView = weakReference.get();
        KeyguardManager keyguardManager = (KeyguardManager) cordovaWebView.getContext().getSystemService("keyguard");
        return (keyguardManager == null || !keyguardManager.isKeyguardLocked()) && cordovaWebView.getView().getWindowVisibility() == 0;
    }

    private List<Integer> toList(JSONArray jSONArray) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(Integer.valueOf(jSONArray.optInt(i)));
        }
        return arrayList;
    }

    private Manager getNotMgr() {
        return Manager.getInstance(this.f5cordova.getActivity());
    }
}
